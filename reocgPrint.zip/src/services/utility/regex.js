// REGEX for validation 

export const VALID_FULL_NAME = /^([\w]{1,})+\s+([\w\s]{1,})+$/i; //example "Sanjay Suthar | Sumit Kumar Suthar"
export const NUMBER_NOT_ALLOWED = /^([^0-9]*)$/;
export const ONLY_NUMBER = /^[0-9\b]+$/;
export const STRONG_PASSWORD =
  /^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[#?!@$%^&*-]).{10,20}$/; //alphanumeric value with one upper case and have atleast one special character
