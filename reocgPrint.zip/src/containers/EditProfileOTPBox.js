import React, { useState, useEffect, useReducer } from "react";
import { Form, Input, notification, Spin } from "antd";
import { config } from "../config";
import moment from "moment";
import { GuestAPI } from "../apis/GuestAPI";
import { useSelector } from "react-redux";
import { encrypt, decrypt, publickey } from "../helpers/makeHash";
import Spinner from "../reusable/Spinner";
import { useLocation } from "react-router-dom";
import CustomInput from "../reusable/CustomInput";

export default function EditProfileOTPBox(props) {
  const [stateOtp, SetStateOtp] = useState({ otp: "" });
  const location = useLocation();
  const [btn, setBtn] = useState(false);
  const ConfigReducer = useSelector((state) => state.user);
  const [form] = Form.useForm();
  const [intervalID, setInterID] = useState();

  const [reverseTimer, setReverseTimer] = useState("5m 00s");
  const [otpVerificationToken, setVerificationToken] = useState("");
  const [loader, setLoader] = useState(false);
  const [state, setState] = useReducer((state, newState) => ({ ...state, ...newState }), {
    clientId: ConfigReducer.clientId,
    groupId: ConfigReducer.groupId,
    twofa: ConfigReducer.twofa,
    sessionId: ConfigReducer.sessionId,
    OTPTimer: true,
    OTPVerifed: false,
    disabled: false,
  });

  useEffect(() => {
    reverseTimerOnLoad();
  }, []);

  useEffect(() => {
    setVerificationToken(props.state.verificationToken);
  }, [props.state.verificationToken]);

  const reverseTimerOnLoad = () => {
    clearInterval(intervalID);

    let validityAuctionEndTime = moment().add(5, "minutes");
    const second = 1000,
      minute = second * 60,
      hour = minute * 60,
      day = hour * 24;

    let countDown = new Date(`${validityAuctionEndTime}`).getTime();

    let letintervalID = setInterval(function () {
      let now = new Date().getTime(),
        distance = countDown - now;

      var getDay = Math.floor(distance / day);

      var getHour = Math.floor((distance % day) / hour);

      var getMinute = Math.floor((distance % hour) / minute);

      var secound = Math.floor((distance % minute) / second);
      let getSecound = secound > 9 ? secound : 0 + secound;

      let cDay = getDay !== 0 ? `${getDay}d` : "";
      let cHour = getHour !== 0 ? `${getHour}h` : "";
      let cMinute = getMinute !== 0 ? `${getMinute}m` : "";
      let cSecound = getSecound !== 0 ? `${getSecound}s` : "";
      let timer = `${cDay} ${cHour} ${cMinute} ${cSecound}`;

      if (distance <= 0) {
        clearInterval(intervalID);
      } else {
        setReverseTimer(timer);
      }
    }, second);
    setInterID(letintervalID);
  };
  const onFinish = (e) => {
    setState({ disabled: true });
    // if (location.pathname === "/profile") {
    //   props.setLoader(true);
    // }
    // if (location.pathname === "/change-email") {
    //   props.setLoader((prevState)=>prevState+1);
    // }
    // if (location.pathname === "/change-password") {
      props.setLoader((prevState)=>prevState+1);
    // }
    // if (props.unlockA) {
    //   props.setParentLoader(true);
    // } else {
    //   setLoader(true);
    // }
    e.preventDefault();
    form.setFields([{ name: "otp", errors: [] }]);

    const optData = {
      requestId: config.requestId,
      requestType: "VERIFYOTP",
      channelId: config.channelId,
      clientId: state.clientId,
      groupId: state.groupId,
      sessionId: state.sessionId,
      ipAddress: "127.0.0.1",
      otpType: props.otpType,
      verificationToken: otpVerificationToken,
      otp: stateOtp.otp,
    };

    if (props.useFor == "addRecipient") {
      optData.accountNo = props.state.formData.accountNo;
    }

    if (config.IS_ENC) {
      var key = config.key;
      var iv = config.iv;
      var body = encrypt(optData, key, iv);
      var pubValue = iv.concat(key);
      var identifier = publickey(props.appState.publicKey, pubValue);

      var postData = {
        body: body,
        identifier: identifier,
      };
    } else {
      var postData = optData;
    }

    GuestAPI.verifyOTP(postData)
      .then((res) => {
        props.setLoader((prevState)=>prevState-1);
        if (config.IS_ENC) {
          var decode = decrypt(res.data.body, key, iv);
          var decodeData = JSON.parse(decode);
        } else {
          var decodeData = res.data;
        }
        clearInterval(intervalID);
        if (decodeData.status == "S") {
          if (location.pathname === "/change-password") {
            props.changePassword(decodeData.verifiedToken);
            // notification.success({ message: decodeData.message });
          }
          if (location.pathname === "/change-email") {
            props.changeEmail(decodeData.verifiedToken);
            // notification.success({ message: decodeData.message });
          }
          // if (location.pathname === "/profile") {
          //   props.setState({ otpVerfiedToken: res.data.verifiedToken });
          //   props.editSenderContactdtls(res.data.verifiedToken);
          //   props.setState({ otpVerfiedToken: "" });
          //   // props.setState({otpBoxEmail:false});
          //   props.setLoader(false);
          //   setState({ disabled: true });
          //   props.setState({ OTPVerifed: true });
          // }

          // props.setState({ isModalVisible: false });
          setState({ OTPTimer: false });
          if (props.useFor == "signup") {
            props.setState({
              verifiedToken: decodeData.verifiedToken,
            });
            props.checkDedupe(decodeData.verifiedToken);
          } else if (props.useFor == "login") {
            props.setState({ verifiedToken: decodeData.verifiedToken });
            props.storeLoginData(props.state.loginData);
          } else if (props.useFor == "addRecipient") {
            props.saveReceiver(decodeData.verifiedToken);
          } else if (props.useFor == "Edit_Address") {
            props.editProfile(decodeData.verifiedToken);
          } else if (props.useFor == "Edit_Contact") {
            setTimeout(() => {
              props.editSenderContactdtls(decodeData.verifiedToken);
            }, 1000);
          } else if (props.useFor == "Edit_Marketing") {
            props.editProfile(decodeData.verifiedToken);
          } else if (props.useFor == "forgot_password") {
            props.setState({
              verifiedToken: decodeData.verifiedToken,
              _isShowSuccessMessage: true,
            });
          } else if (props.useFor == "unlock_account") {
            props.onUnlockAccountHandler();
          }
          props.setCurrent((prev) => prev + 1);
          // if (props.unlockA) {
          //   props.setParentLoader(false);
          // } else {
          //   setLoader(false);
          // }
        } else {
          // if (location.pathname === "/profile") {
          //   props.setState({ OTPVerifed: false });
          //   props.setLoader(false);
          //   setState({ disabled: false });
          // }
          // if (props.unlockA) {
          //   props.setParentLoader(false);
          // } else {
          //   setLoader(false);
          // }
          notification.error({ message: res.data.errorMessage });
          form.setFields([{ name: "otp", errors: [res.data.errorMessage] }]);
          let errors = [];
          res.data.errorList.forEach((error, i) => {
            let errorData = {
              name: error.field,
              errors: [error.error],
            };
            errors.push(errorData);
          });
          if (errors.length > 0) form.setFields(errors);
        }
      })
      .catch((error) => {});
  };
  const onClickResedOTP = async () => {
    // if (location.pathname === "/profile") {
    //   props.setLoader(true);
    // }
    // if (location.pathname === "/change-email") {
    //   props.setLoader((prevState)=>prevState+1);
    // }
    // if (location.pathname === "/change-password") {
      props.setLoader((prevState)=>prevState+1);
    // }
    // if (props.unlockA) {
    //   props.setParentLoader(true);
    // } else {
    //   setLoader(true);
    // }
    const optData = {
      requestId: config.requestId,
      requestType: "RESENDOTP",
      channelId: config.channelId,
      clientId: state.clientId,
      groupId: state.groupId,
      sessionId: state.sessionId,
      ipAddress: "127.0.0.1",
      verificationToken: otpVerificationToken,
      otpOption: "SM",
    };

    if (props.useFor == "addRecipient") {
      optData.accountNo = props.state.formData.accountNo;
    }

    if (config.IS_ENC) {
      var key = config.key;
      var iv = config.iv;
      var body = encrypt(optData, key, iv);
      var pubValue = iv.concat(key);
      var identifier = publickey(props.appState.publicKey, pubValue);

      var postData = {
        body: body,
        identifier: identifier,
      };
    } else {
      var postData = optData;
    }

    await GuestAPI.reSendOTP(postData)
      .then((res) => {
        props.setLoader((prevState)=>prevState-1);
        if (config.IS_ENC) {
          var decode = decrypt(res.data.body, key, iv);
          var decodeData = JSON.parse(decode);
        } else {
          var decodeData = res.data;
        }

        if (decodeData.status == "S") {
          // if (location.pathname === "/profile") {
          //   props.setLoader(false);
          // }
          form.setFieldsValue({ otp: "" });
          setState({ OTPTimer: true });
          // if (props.unlockA) {
          //   props.setParentLoader(false);
          // } else {
          //   setLoader(false);
          // }
          notification.success({ message: decodeData.message });
          props.setState({ verificationToken: decodeData.verificationToken });
          setVerificationToken(decodeData.verificationToken);
          clearInterval(intervalID);
          setTimeout(() => {
            reverseTimerOnLoad();
          }, 200);
        } else {
          // if (location.pathname === "/profile") {
          //   props.setLoader(false);
          // }
          // if (props.unlockA) {
          //   props.setParentLoader(false);
          // } else {
          //   setLoader(false);
          // }

          notification.error({ message: res.data.errorMessage });

          let errors = [];
          res.data.errorList.forEach((error, i) => {
            let errorData = {
              name: error.field,
              errors: [error.error],
            };
            errors.push(errorData);
          });
          if (errors.length > 0) form.setFields(errors);
        }
      })
      .catch((error) => {});
  };
  return (
    // <Spinner spinning={location.pathname === "/profile" ? false : props.unlockA ? props.parentLoader : loader}>
      <div visible={props.state.isModalVisible}>
        <Form form={form} onFinish={(values) => {}}>
          <>
            <div className="mb-3">
              {/* <label className="step-label mb-1">Enter OTP</label>
              <Form.Item
                className="form-item text-start"
                name="otp"
                rules={[
                  { required: true, message: "Please Enter Your OTP" },
                  {
                    pattern: /^[0-9\b]+$/,
                    message: "Only Numbers allowed",
                  },
                  {
                    min: 6,
                    max: 6,
                    message: "Please enter 6 digit OTP",
                  },
                ]}
              >
                <Input
                  size="large"
                  placeholder="Enter OTP sent on your existing email address"
                  onChange={(e) => {
                    SetStateOtp({ otp: e.target.value });
                    e.target.value.length == 6 ? setBtn(true) : setBtn(false);
                  }}
                  onPaste={(e) => {
                    e.preventDefault();
                    return false;
                  }}
                  onCopy={(e) => {
                    e.preventDefault();
                    return false;
                  }}
                  onCut={(e) => {
                    e.preventDefault();
                    return false;
                  }}
                  disabled={location.pathname === "/profile" ? state.disabled : false}
                />
              </Form.Item> */}
              <CustomInput className="form-item text-start"
                name="otp"  min={6} max={6} label="Enter OTP" placeholder="Enter OTP sent on your existing email address"
                validationRules={[{
                  pattern: /^[0-9\b]+$/,
                  message: "Only Numbers allowed",
                },]}
                onChange={(e) => {
                  SetStateOtp({ otp: e.target.value });
                  e.target.value.length == 6 ? setBtn(true) : setBtn(false);
                }}
                onPaste={(e) => {
                  e.preventDefault();
                  return false;
                }}
                onCopy={(e) => {
                  e.preventDefault();
                  return false;
                }}
                onCut={(e) => {
                  e.preventDefault();
                  return false;
                }}
                disabled={location.pathname === "/profile" ? state.disabled : false}
                required
                />
              <p className="text-center" style={{ cursor: "pointer" }} onClick={onClickResedOTP}>
                Resend OTP on email
              </p>
              {state.OTPTimer && (
                <p className="mt-2 text-center">
                  <small>OTP will expire in {reverseTimer}</small>
                </p>
              )}
            </div>
            <div className="d-flex justify-content-end" style={{marginTop:"90px"}}>
            <button className="mt-5 btn btn-sm btn-light text-primary" disabled={!btn || loader || props.state.OTPVerifed} onClick={onFinish}>
              {location.pathname === "/change-password" ? "Change Password" : "Change email adress"}
            </button>
            </div>
          </>
        </Form>
      </div>
    // </Spinner>
  );
}
