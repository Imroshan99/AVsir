import React, { useEffect } from "react";
import { useOutletContext } from "react-router-dom";

const AboutUs = () => {
  const { setTitle } = useOutletContext();
  useEffect(() => {
    setTitle("About Us");
  }, []);
  return (
    <div>
      <section className="section">
        <div className="container">
        <h5 className="mt-1 mb-3">updated soon...</h5>
        </div>
      </section>
    </div>
  );
};

export default AboutUs;
