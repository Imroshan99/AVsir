import React from "react";
import { useSelector } from "react-redux";
import AddReipient2 from "./AddRecipientFlow2/AddRecipient";
import AddReipient1 from "./AddRecipientFlow1/AddRecipient";
import { Modal } from "antd";

const AddRecipientModal = (props) => {
  // const groupConfig = useSelector((state) => state.user);
  // const templateFlow =
  //   groupConfig.groupIdSettings?.AddRecipientForm?.flow;
  const AuthReducer = useSelector((state) => state.user);
  const templateFlow =
  AuthReducer.groupIdSettings?.recipientModule?.AddRecipientForm?.flow;
  return (
    <Modal
      centered
      visible={props.visible}
      onCancel={() => props.setVisible(false)}
      forceRender={true}
      footer={null}
      width={1000}
    >
      {templateFlow === "FLOW1" && (
        <AddReipient1
          appState={props.appState}
          manageAuth={props.manageAuth}
          accountsList={props.accountsList}
          setVisible={props.setVisible}
          visible={props.visible}
          type="MODAL"
        />
      )}
      {templateFlow === "FLOW2" && (
        <AddReipient2
          appState={props.appState}
          manageAuth={props.manageAuth}
          accountsList={props.accountsList}
          setVisible={props.setVisible}
          // visible={props.visible}
          type="MODAL"
        />
      )}
    </Modal>
  );
};

export default AddRecipientModal;
