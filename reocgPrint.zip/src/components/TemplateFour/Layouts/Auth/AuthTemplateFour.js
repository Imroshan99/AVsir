import React from "react";

const AuthTemplateFour = (props) => {
  return (
    <div className="auth_temp4 bg-signIn-image container-fluid p-0 m-0 h-100">
      <div className="row m-auto h-100 d-sm-flex">
        <div className="col-md-6 col-sm-24"></div>
        <div className=" col-md-6 h-100 col-xs-24 order-sm-2 order-md-1">
          <div className="row h-100 justify-content-center align-items-center">
            <div className="col-12 col-md-8 col-xxl-6 ">
              <div className="card">
                <div class="card-body">{props.children}</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AuthTemplateFour;
