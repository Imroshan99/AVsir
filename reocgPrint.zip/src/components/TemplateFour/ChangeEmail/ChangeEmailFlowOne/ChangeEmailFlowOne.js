import { Form, Input, Row, Col, notification } from "antd";
import { useEffect, useReducer, useState } from "react";
import { useSelector } from "react-redux";
import { useNavigate } from "react-router-dom";
import Swal from "sweetalert2";
import { GuestAPI } from "../../../../apis/GuestAPI";
import { ProfileAPI } from "../../../../apis/ProfileAPI";
import logorefresh from "../../../../assets/images/svg/refreshCaptcha.svg";
import EditProfileOTPBox from "../../../../containers/EditProfileOTPBox";

import useHttp from "../../../../hooks/useHttp";
import CustomInput from "../../../../reusable/CustomInput";
import Spinner from "../../../../reusable/Spinner";

export default function ChangeEmail(props) {
  const [form] = Form.useForm();
  const AuthReducer = useSelector((state) => state.user);
  const navigate = useNavigate();
  const [captchaImg, setCaptchaImg] = useState();
  const [captchaID, setCaptchaID] = useState();
  const [loader, setLoader] = useState(0);

  const hookgetCaptcha = useHttp(GuestAPI.getCaptcha);
  const hookVerifyCaptcha = useHttp(GuestAPI.verifyCaptcha);
  const hookSendOTP = useHttp(ProfileAPI.sendOTP);
  const hookSenderContactdtls = useHttp(ProfileAPI.editSenderContactdtls);
  const hookGetProfile = useHttp(ProfileAPI.getProfile);

  const [state, setState] = useReducer((state, newState) => ({ ...state, ...newState }), {
    twofa: AuthReducer.twofa,
    userID: AuthReducer.userID,
    userFullName: AuthReducer.userFullName,
    newEmailid: "",
    confNewPassword: "",
    verificationToken: "",
    OTPInputBox: false,
    oldemailId: "",
    checkExistEmail: "",
    firstName: "",
    middleName: "",
    lastName: "",
    emailId: "",
    dob: "",
    editableMobileNo: "",
    editablemobilePhoneCode: "",
    mobilePhoneCode: "",
    mobileNo: "",
    gender: "",
    citizenship: "",
    citizenshipDesc: "",
    nationality_id: "",
    nationalityDesc: "",
    occupation_id: "",
    occupationDesc: "",
    profession_id: "",
    professionDesc: "",
    isSameCommAddressFlag: "",
    marketCommunication: "",
    address1: "",
    address3: "",
    city: "",
    state: "",
    country: AuthReducer.sendCountryCode,
    zip: "",
    income_id: "",
    incomeDesc: "",
    countryPhoneCodes: [],
    occupationLists: [],
    professionLists: [],
    incomeLists: [],
  });

  useEffect(() => {
    window.scrollTo({ top: 0, behavior: "smooth" });
    getCaptcha();
    getProfile();
  }, []);

  const getCaptcha = () => {
    let payload = {
      requestType: "GETCAPTCHA",
    };
    setLoader((prevState) => prevState + 1);
    hookgetCaptcha.sendRequest(payload, function (data) {
      setLoader((prevState) => prevState - 1);
      if (data.status == "S") {
        setCaptchaID(data.id);
        setCaptchaImg(data.captchaImage);
      } else {
      }
    });
  };
  const getProfile = () => {
    let payload = {
      requestType: "LEAD",
      userId: state.userID,
    };
    setLoader((prevState) => prevState + 1);
    hookGetProfile.sendRequest(payload, function (data) {
      setLoader((prevState) => prevState - 1);
      if (data.status == "S") {
        setState({
          firstName: data.firstName,
          middleName: data.middleName,
          lastName: data.lastName,
          emailId: data.emailId,
          checkExistEmail: data.emailId,
          dob: data.dob,
          mobileNo: data.mobileNo,
          gender: data.gender,
          mobilePhoneCode: data.mobilePhoneCode,
          citizenship: data.citizenship,
          citizenshipDesc: data.citizenshipDesc,
          nationality_id: data.nationality,
          nationalityDesc: data.nationalityDesc,
          occupation_id: data.occupation,
          occupationDesc: data.occupationDesc,
          profession_id: data.profession,
          professionDesc: data.professionDesc,
          address1: data.address1,
          address3: data.address3,
          city: data.city,
          state: data.state,
          zip: data.zip,
          income_id: data.income,
          incomeDesc: data.incomeDesc,
          isSameCommAddressFlag: data.isSameCommAddressFlag,
          marketCommunication: data.marketCommunication,
        });
      }
    });
  };
  const onFinish = (value) => {
    // if (state.checkExistEmail === value.oldemailId) {
    //   if (state.checkExistEmail === value.newEmailid) {
    //     form.setFields([{ name: "newEmailid", errors: ["Enter your new email"] }]);
    //   } else {
    let captchaPayload = {
      requestType: "VERIFYCAPTCHA",
      id: captchaID,
      captchaResponse: value.captcha,
    };
    setLoader((prevState) => prevState + 1);
    hookVerifyCaptcha.sendRequest(captchaPayload, function (data) {
      if (data.status == "S") {
        const OTPData = {
          requestType: "SENDOTP",
          // mobilePhoneCode: state.mobilePhoneCode,
          // mobileNo: state.mobileNo,
          emailId: value.newEmailid,
          otpType: "CU",
          otpService: "EMAIL",
          // senderName: "",
          // userId: state.userID,
          // otpOption: "SM",
        };
        hookSendOTP.sendRequest(OTPData, function (data) {
          setLoader((prevState) => prevState - 1);
          if (data.status == "S") {
            notification.success({ message: data.message });
            setState({
              verificationToken: data.verificationToken,
              OTPInputBox: true,
              oldemailId: value.oldemailId,
              newEmailid: value.newEmailid,
            });
          } else {
            notification.error({ message: data.errorMessage });
          }
        });
      } else {
        setLoader((prevState) => prevState - 1);
        form.setFields([{ name: "captcha", errors: ["Incorrect Captcha"] }]);
        getCaptcha();
      }
    });
    //   }
    // } else {
    //   form.setFields([{ name: "oldemailId", errors: ["Enter your existing email"] }]);
    // }
  };
  const changeEmail = (verifiedToken) => {
    const editProfileData = {
      requestType: "EDITSENDCNTDTLS",
      emailId: state.newEmailid,
      sendCountryCode: AuthReducer.sendCountryCode,
      twofa: "Y",
      verifiedToken: verifiedToken,
      userId: state.userID,
    };

    hookSenderContactdtls.sendRequest(editProfileData, function (data) {
      if (data.status == "S") {
        notification.success({ message: data.message });
        Swal.fire({
          title: "Success",
          text: data.message,
          icon: "success",
          confirmButtonColor: "#2dbe60",
          allowOutsideClick: false,
        }).then((result) => {
          if (result.isConfirmed) {
            navigate("/profile");
          }
        });
      } else {
        setState({
          isModalVisible: false,
        });
        notification.error({ message: data.errorMessage });
      }
      getProfile();
    });
  };
  return (
    <>
      <Spinner spinning={loader === 0 ? false : true}>
        <div className="template2__main">
          <div className="container change_password__page">
            <Form form={form} onFinish={onFinish}>
              <div className="ChangePassword">
                <div className="row mt-5">
                  <div className="col-md-5">
                    <CustomInput className="form-item" name="oldemailId" label="Your existing email">
                      <div className="d-flex ">
                        <Input disabled={true} visibilityToggle={false} value={state.emailId} size="large" />
                      </div>
                    </CustomInput>
                    <CustomInput className="form-item" name="newEmailid" label="Type your new email adress" disabled={state.OTPInputBox} type="email" size="large" required />
                  </div>
                  <div className="col-md-2 text-center d-none d-md-block">
                    <span className="_v_line_secondary mt-5" style={{ height: "100px" }}></span>
                  </div>
                  {state.OTPInputBox ? (
                    <div className="col-md-5">
                      <EditProfileOTPBox state={state} setState={setState} otpType="CU" useFor="signup" appState={props.appState} setCurrent={props.setCurrent} changeEmail={changeEmail} setLoader={setLoader} />
                    </div>
                  ) : (
                    <div className="col-md-5">
                      <label className="form-label">Word Verification</label>
                      <div className="w-100 d-flex mb-3">
                        <div className="me-3">
                          <img src={`data:image/jpeg;base64,${captchaImg}`} alt="captcha" />
                        </div>
                        <div className="d-flex align-items-center my-3" style={{ cursor: "pointer" }} onClick={getCaptcha}>
                          <img src={logorefresh} alt="refresh" className="me-2" />
                          <span className="fs-12">Refresh Code</span>
                        </div>
                      </div>
                      <CustomInput className="form-item" name="captcha" required placeholder="Enter the text shown in the Image" showLabel={false} label="Captcha" />
                    </div>
                  )}
                </div>

                {!state.OTPInputBox && (
                  <div className="d-flex justify-content-end">
                    <button className="mt-5 btn btn-sm btn-light text-primary" type="submit">
                      Get OTP
                    </button>
                  </div>
                )}
              </div>
            </Form>
          </div>
        </div>
      </Spinner>
    </>
  );
}
