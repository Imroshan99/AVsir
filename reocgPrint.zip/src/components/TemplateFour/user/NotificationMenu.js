import Menu from "@mui/material/Menu";
import MenuItem from "@mui/material/MenuItem";
import { useEffect, useReducer, useState } from "react";
import { useSelector } from "react-redux";
import { ProfileAPI } from "../../../apis/ProfileAPI";
import { config } from "../../../config";
import useHttp from "../../../hooks/useHttp";
import { NavLink, useNavigate } from "react-router-dom";
import Spinner from "../../../reusable/Spinner";
import { Tabs } from "antd";

export default function NotificationMenu(props) {
  const navigate = useNavigate();
  const AuthReducer = useSelector((state) => state.user);

  const [state, setState] = useReducer((state, newState) => ({ ...state, ...newState }), {
    clientId: AuthReducer.clientId,
    groupId: AuthReducer.groupId,
    sessionId: AuthReducer.sessionId,
    userID: AuthReducer.userID,
    notificationLists: [],
    notificationDesc: "",
    isModalVisible: false,
  });
  return (
    <>
      <Menu
        className="notification_menu"
        anchorEl={props.anchorElNoti}
        id="account-menu"
        open={Boolean(props.anchorElNoti)}
        onClose={props.handleCloseNotiMenu}
        onClick={props.handleCloseNotiMenu}
        PaperProps={{
          elevation: 0,
          sx: {
            overflow: "visible",
            // filter: "drop-shadow(0px 2px 8px rgba(0,0,0,0.32))",
            mt: 1.5,
            "& .MuiAvatar-root": {
              width: 32,
              height: 32,
              ml: -0.5,
              mr: 1,
            },
            "&:before": {
              content: '""',
              display: "block",
              position: "absolute",
              top: 0,
              right: 14,
              width: 10,
              height: 10,
              bgcolor: "background.paper",
              transform: "translateY(-50%) rotate(45deg)",
              zIndex: 0,
            },
          },
          style: {
            maxHeight: 150 * 4.5,
          },
        }}
        transformOrigin={{ horizontal: "right", vertical: "top" }}
        anchorOrigin={{ horizontal: "right", vertical: "bottom" }}
      >
        <Spinner spinning={props.notificationLoader}>
          <div className="Notification-Menu-Main-Container noti-tab p-3">
            <Tabs defaultActiveKey="1">
              <Tabs.TabPane tab="Notifications" key="1" className="xr_notification">
                {props.state.notificationList == "" ? (
                  <p className="Notification-Menu-Title-h6 px-3">No Notifications</p>
                ) : (
                  props.state.notificationList.map((value, key) => {
                    return (
                      <MenuItem>
                        <div className="Notification-Menu-Container">
                          <h6 className="Notification-Menu-Title-h6 m-0 inner_title_color mb-1">
                            {value.notificationTitle}
                          </h6>
                          <div className="Notification-Menu-Description-p m-0 inner_title_color">
                            {value.notificationDesc}
                          </div>
                        </div>
                      </MenuItem>
                    );
                  })
                )}
              </Tabs.TabPane>
              <Tabs.TabPane tab="Alerts" key="2" className="xr_alerts">
                {props.state.alertList == "" ? (
                  <p className="Notification-Menu-Title-h6 px-3">No Alerts</p>
                ) : (
                  props.state.alertList.map((value, key) => {
                    if (value.notificationName === "ALERT_NOTIFICIATION_REQUEST_MONEY") {
                      return (
                        <MenuItem onClick={() => navigate("recipient-request-list")}>
                          <div className="Notification-Menu-Container">
                            <h6 className="Notification-Menu-Title-h6 m-0 inner_title_color mb-1">
                              {value.notificationTitle}
                            </h6>
                            <div className="Notification-Menu-Description-p m-0 inner_title_color">
                              {value.notificationDesc}
                            </div>
                          </div>
                        </MenuItem>
                      );
                    } else if (value.notificationName === "ALERT_NOTIFICATION_RFXDOC_UPLOAD") {
                      return (
                        <MenuItem onClick={() => props.setIsModalVisible(true)}>
                          <div className="Notification-Menu-Container">
                            <h6 className="Notification-Menu-Title-h6 m-0 inner_title_color mb-1">
                              {value.notificationTitle}
                            </h6>
                            <div className="Notification-Menu-Description-p m-0 inner_title_color">
                              {value.notificationDesc}
                            </div>
                            <div className="Notification-Menu-Description-p m-0 inner_title_color">
                              {value.id}
                            </div>
                          </div>
                        </MenuItem>
                      );
                    } else {
                      return (
                        <MenuItem>
                          <div className="Notification-Menu-Container">
                            <h6 className="Notification-Menu-Title-h6 m-0 inner_title_color mb-1">
                              {value.notificationTitle}
                            </h6>
                            <div className="Notification-Menu-Description-p m-0 inner_title_color">
                              {value.notificationDesc}
                            </div>
                          </div>
                        </MenuItem>
                      );
                    }
                  })
                )}
              </Tabs.TabPane>
            </Tabs>
          </div>
        </Spinner>
      </Menu>
    </>
  );
}
