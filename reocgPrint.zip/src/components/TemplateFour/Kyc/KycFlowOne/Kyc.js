import React, { useState, useEffect, useReducer } from "react";
import { Row, Col } from "react-bootstrap";
import {
  Form,
  Input,
  Select,
  notification,
  Upload,
  Button,
  DatePicker,
  message,
  AutoComplete,
} from "antd";
import {
  CameraOutlined,
  DeleteOutlined,
  FilePdfOutlined,
  LoadingOutlined,
} from "@ant-design/icons";
import moment from "moment";
import { useLocation, useNavigate } from "react-router-dom";
import { useDispatch, useSelector } from "react-redux";
import { ProfileAPI } from "../../../../apis/ProfileAPI";
import { GuestAPI } from "../../../../apis/GuestAPI";
import { TransactionAPI } from "../../../../apis/TransactionAPI";
import Lottie from "react-lottie";
import * as kycLottie from "../../../../assets/images/XR/KYC-under-review.json";
import useHttp from "../../../../hooks/useHttp";
import { inputValidations } from "../../../../services/validations/validations";
import Spinner from "../../../../reusable/Spinner";
import { setUserKyc } from "../../../../reducers/userReducer";
import CustomInput from "../../../../reusable/CustomInput";

const { Option } = Select;
const { TextArea } = Input;

const _XRIdProofList = [
  {
    docName: "Driving License",
    docId: "2",
    docType: "DL",
  },

  {
    docName: "Passport",
    docId: "1",
    docType: "PP",
  },
];

export default function Kyc(props) {
  const [form] = Form.useForm();
  const [IdproofForm, setIdProofForm] = useState(true);
  const [AddProofForm, setAddProofForm] = useState(false);
  const [completeKycState, setcompleteKycState] = useState(false);
  const [addproofId, setAddProofId] = useState("");
  const [value, setValue] = useState({});
  let navigate = useNavigate();
  const AuthReducer = useSelector((state) => state.user);
  const ConfigReducer = useSelector((state) => state.user);
  const dispatch = useDispatch();
  const { inputFields } = ConfigReducer.groupIdSettings.kyc;
  const [frontDoc, setFrontDoc] = useState("");
  const [backDoc, setBackDoc] = useState("");
  const [addProofDoc, setAddProofDoc] = useState("");
  const [loading, setLoading] = useState();
  const [spinner, setSpinner] = useState(false);
  const [imageUrl, setImageUrl] = useState();
  const [imageUrl1, setImageUrl1] = useState();
  const [imageUrl2, setImageUrl2] = useState();
  const [passFileNo, setPassFileNo] = useState();
  const location = useLocation();

  const [state, setState] = useReducer(
    (state, newState) => ({ ...state, ...newState }),
    {
      userID: AuthReducer.userID,
      nationalities: [],
      additionalInfo2: "",
      occupationLists: [],
      sourceOFFundLists: [],
      // uniqueIdentifierLists: [],
      idProofLists: [],
      addressProofLists: [],
      stateLists: [],
      cityLists: [],
      profileData: [],
      stateListsIssuer: [],
      issuerCountryList: [],
      sourceFundOther: "",
      occupationOther: "",
      idIssuer: "",
      redirectPage: "",
      redirectPageState: [],
      DocPdf: false,
      DocPdf1: false,
      DocPdf2: false,
    }
  );

  const hookGetNationality = useHttp(GuestAPI.getNationality);
  const hookGetProfile = useHttp(ProfileAPI.getProfile);
  const hookEditProfile = useHttp(ProfileAPI.editProfile);
  const hookUserDocUpload = useHttp(ProfileAPI.userDocUpload);
  const hookGetOccupationLists = useHttp(GuestAPI.occupationLists);
  const hookGetUniqueIdentifierList = useHttp(GuestAPI.uniqueIdentifierList);
  const hookGetCountryStates = useHttp(GuestAPI.countryStates);
  const hookGetCountryLists = useHttp(GuestAPI.countryList);
  const hookGetSendingCountryLists = useHttp(GuestAPI.sendingCountryList);
  const hookGetStateCities = useHttp(GuestAPI.stateCities);
  const hookGetSourceOFFundLists = useHttp(TransactionAPI.sourceOFFundLists);

  useEffect(async () => {
    if (location.pathname === "/profile") {
      // getUserProfile();
      if (AuthReducer.userKYC == "DOB") {
        setIdProofForm(true);
        setAddProofForm(false);
      } else {
        setIdProofForm(false);
        setAddProofForm(true);
      }
    }
    window.scrollTo({ top: 0, behavior: "smooth" });
    getSourceOFFundLists();
    getUserProfile();
    getNationality();
    getOccupationLists();
    getUniqueIdentifierNames();
    getStateLists();
    getIssuerCountryList();
    setState({
      redirectPage: location.state?.fromPage,
      redirectPageState: location.state?.fromPageState,
    });
    form.setFieldsValue({ country: "UK" });
  }, []);

  useEffect(() => {
    if (location.pathname === "/profile") {
      setAddProofId(state.profileData.uniqueIdentifierType);
      form.setFieldsValue({
        addressidtype: state.profileData.uniqueIdentifierType,
        address: state.profileData.address1,
        address2: state.profileData.address2,
        commPostalCode: state.profileData.commPostalCode,
        state: state.profileData.state,
        city: state.profileData.city,
      });
    }
  }, [state.profileData]);

  const getIssuerCountryList = async () => {
    let payload = {
      requestType: "COUNTRYLIST",
    };

    hookGetSendingCountryLists.sendRequest(payload, function (data) {
      if (data.status === "S") {
        setState({ issuerCountryList: data.responseData });
      }
    });
  };
  const getNationality = async () => {
    const payload = {
      requestType: "NATIONALITYLIST",
      keyword: "",
    };

    hookGetNationality.sendRequest(payload, function (data) {
      if (data.status == "S") {
        setState({ nationalities: data.responseData });
      } else {
        notification.error({ message: data.errorMessage });
      }
    });
  };

  const getUserProfile = async () => {
    setSpinner(true);
    let payload = {
      requestType: "USERPROFILE",
      userId: state.userID,
    };
    hookGetProfile.sendRequest(payload, function (data) {
      if (data.status === "S") {
        setState({ profileData: data });
        setSpinner(false);
      }
    });
  };
  const onSelectStateHandler = async (stateCode) => {
    const cityPayload = {
      requestType: "CITILIST",
      countryCode: AuthReducer.sendCountryCode,
      stateCode: stateCode,
    };

    hookGetStateCities.sendRequest(cityPayload, function (data) {
      if (data.status === "S") {
        setState({
          cityLists: data.responseData,
        });
      }
    });
  };

  const getOccupationLists = async () => {
    let payload = {
      requestType: "LEAD",
    };

    hookGetOccupationLists.sendRequest(payload, function (data) {
      if (data.status === "S") {
        data.responseData.push({
          displayOrder: "18",
          occupationDesc: "Other",
          occupationId: "100",
          occupationName: "Other",
        });
        setState({ occupationLists: data.responseData });
      }
    });
  };

  const getUniqueIdentifierNames = async () => {
    let payload = {
      requestType: "UNNAMESLIST",
      idFor: "RECV",
    };

    hookGetUniqueIdentifierList.sendRequest(payload, function (data) {
      if (data.status === "S") {
        const docListArray = data.responseData;

        // ID proof list
        const disableIDList = ["BS", "TB"];
        const idProofListArray = docListArray.reduce(function (prev, current) {
          if (!disableIDList.includes(current.docType)) {
            prev.push(current);
          }
          return prev;
        }, []);

        // Address proof list
        const disableAddressProofList = ["RC", "PP"];
        const addressProofListArray = docListArray.reduce(function (
          prev,
          current
        ) {
          if (!disableAddressProofList.includes(current.docType)) {
            prev.push(current);
          }
          return prev;
        },
        []);
        setState({ idProofLists: idProofListArray });
        setState({ addressProofLists: addressProofListArray });
        if (location.pathname === "/profile") {
          setState({ addressProofLists: docListArray });
        }
      }
    });
  };

  const getStateLists = async () => {
    let payload = {
      requestType: "STATELIST",
      countryCode: AuthReducer.sendCountryCode,
      keyword: "",
    };

    hookGetCountryStates.sendRequest(payload, function (data) {
      if (data.status === "S") {
        setState({ stateLists: data.responseData });
        const stateIssuerArray = [...data.responseData];
        setState({ stateListsIssuer: stateIssuerArray });
      }
    });
  };

  const getSourceOFFundLists = () => {
    const payload = {
      requestType: "FUNDSOURCELIST",
    };

    hookGetSourceOFFundLists.sendRequest(payload, function (data) {
      if (data.status == "S") {
        setState({ sourceOFFundLists: data.responseData });
      }
    });
  };

  const submitHandler = (value) => {
    setSpinner(true);
    let nationalityCode = "";
    state.nationalities.find((i) => {
      if (i.nationality == value.nationality) {
        nationalityCode = i.countryCode;
      }
    });
    let occupationCode = "";
    state.occupationLists.find((i) => {
      if (i.occupationName == value.occupation) {
        occupationCode = i.occupationId;
      }
    });
    let sourcefundVal = "";
    state.sourceOFFundLists.find((i) => {
      if (value.sourcefund == i.sourceOfFund) {
        sourcefundVal = i.sourceFundId;
      }
    });

    let editProfilePayload = {
      requestType: "EDITPROFILE",
      userId: AuthReducer.userID,
      gender: state.profileData.gender,
      dob: state.profileData.dob,
      address1: window.btoa(value.address.trim()),
      address2: window.btoa(value.address2.trim()),
      address3: "",
      address4: "",
      address5: "",
      state: window.btoa(value.state),
      city: window.btoa(value.city),
      sendCountry: "GB",
      zipCode: value.commPostalCode.replace(/\s/g, ""),
      occupation: occupationCode,
      profession: "1",
      citizenship:
        location.pathname === "/profile"
          ? AuthReducer.userKYC == "DOB"
            ? nationalityCode
            : state.profileData.citizenship
          : nationalityCode,
      pageName: "EDITPROFILE",
      income: "1",
      commAddress1: window.btoa(value.address.trim()),
      commAddress2: window.btoa(value.commAddress2),
      commCity: value.city,
      commStateProvince: value.state,
      commPostalCode: value.commPostalCode.replace(/\s/g, ""),
      commCountry: value.country,
      companyName: value.companyName,
      nationality: nationalityCode,
      isSameCommAddressFlag: "N",
      extraInfoRequire: "Y",
      uniqueIdentifierType: value.idtype,
      uniqueIdentifierValue: value.documentidnumber,
      sourceOfFund: sourcefundVal,
      additionalInfo1: state.idIssuer,
      additionalInfo2: state.additionalInfo2, //for ID Exipiry
      additionalInfo3: value.companyAddress, //for Company Address
      additionalInfo4: value.passportfilenumber, //for ID Exipiry
      additionalInfo5: value.remittance_freq, //for Remintence Frequencey
      // additionalInfo6: value.sourcefund, //for Source of Fund
      sin: "",
    };
    hookEditProfile.sendRequest(editProfilePayload, function (data) {
      if (data.status == "S") {
        userDocUpload({ docType: editProfilePayload.uniqueIdentifierType });
        userDocUpload1({ docType: editProfilePayload.uniqueIdentifierType });
        userDocUpload2({ docType: addproofId });
        dispatch(setUserKyc("KycDone"));
        if (location.pathname === "/profile") {
          props.getProfile();
        }
      } else {
        setSpinner(false);
        let errors = [];
        data.errorList.forEach((error, i) => {
          let errorData = {
            name: error.field,
            errors: [error.error],
          };
          errors.push(errorData);
        });

        if (errors.length > 0) form.setFields(errors);
      }
    });
  };

  const userDocUpload = async (docData) => {
    let docPayload = {
      requestType: "USERDOCUPLOAD",
      docType: docData.docType,
      docName: frontDoc.fileName,
      docExtension: frontDoc.fileName.split(".").pop(),
      userId: AuthReducer.userID,
      document: frontDoc.docUrl,
    };

    hookUserDocUpload.sendRequest(docPayload, function (data) {
      if (data.status == "S") {
        setAddProofForm(false);
        setcompleteKycState(true);
        setSpinner(false);
      } else {
        setSpinner(false);
      }
    });
  };
  const userDocUpload1 = async (docData) => {
    let docPayload = {
      requestType: "USERDOCUPLOAD",
      docType: docData.docType,
      docName: backDoc.fileName1,
      docExtension: backDoc.fileName1.split(".").pop(),
      userId: AuthReducer.userID,
      document: backDoc.docUrl1,
    };

    hookUserDocUpload.sendRequest(docPayload, function (data) {
      if (data.status == "S") {
        setAddProofForm(false);
        setcompleteKycState(true);
        setSpinner(false);
      } else {
        setSpinner(false);
      }
    });
  };

  const userDocUpload2 = async (docData) => {
    let docPayload = {
      requestType: "USERDOCUPLOAD",
      docType: docData.docType,
      docName: addProofDoc.fileName2,
      docExtension: addProofDoc.fileName2.split(".").pop(),
      userId: AuthReducer.userID,
      document: addProofDoc.docUrl2,
    };

    hookUserDocUpload.sendRequest(docPayload, function (data) {
      if (data.status == "S") {
        setAddProofForm(false);
        setcompleteKycState(true);
        setSpinner(false);
      } else {
        setSpinner(false);
      }
    });
  };

  const normFile = (e) => {
    if (Array.isArray(e)) {
      return e;
    }
    return e && e.fileList;
  };
  const normFile1 = (e) => {
    if (Array.isArray(e)) {
      return e;
    }
    return e && e.fileList;
  };
  const normFile2 = (e) => {
    if (Array.isArray(e)) {
      return e;
    }
    return e && e.fileList;
  };

  const onChangeIssuerID = (value, type) => {
    if (value === "Other") {
    } else {
      setState({
        idIssuer: value,
      });
      if (type === "ISSUER_STATE") {
      }
    }
  };
  const handleChange = (info) => {
    if (info.file.status === "uploading") {
      setLoading(true);
      return;
    }
    if (info.file.status === "done") {
      getBase64(info.file.originFileObj, (imageUrl) => {
        setLoading(false);
      });
    }
  };

  function getBase64(img, callback) {
    const reader = new FileReader();
    reader.addEventListener("load", () => callback(reader.result));
    reader.readAsDataURL(img);
  }

  return (
    <>
      <>
        {IdproofForm && (
          <>
            <div className="mb-3">
              <h2>Complete Your KYC</h2>
            </div>
            <div className="d-flex mb-4">
              <button className="btn btn-info me-3">ID Proof</button>
              <button className="btn btn-info" disabled={true}>
                Address Proof
              </button>
            </div>
            <Form
              form={form}
              autoComplete="none"
              onFinish={(values) => {
                if (frontDoc == "") {
                  form.setFields([{ name: "document", errors: ["Please upload document"] }]);
                }

                if (frontDoc) {
                  setValue(values);
                  setIdProofForm(false);
                  setAddProofForm(true);
                }
              }}
            >
              <Row>
                <Col className="pe-3">
                  <Row>
                    <CustomInput
                      wrapperCol={{ span: 24 }}
                      className="form-item w-100"
                      name="idtype"
                      label="Document Type"
                      showLabel={false}
                      type="select"
                      onChange={(e) => {
                        setPassFileNo(e);
                      }}
                      placeholder="Select Document Type"
                      required
                    >
                      {state.idProofLists.map((uiRow, i) => {
                        return <Option key={i} value={uiRow.docType}>{`${uiRow.docName}`}</Option>;
                      })}
                    </CustomInput>
                     
                  </Row>
                  <div className="row mb-3">
                    <div className="col-6 text-center">
                      <CustomInput className="mb-2" wrapperCol={{ span: 24 }} name="document" valuePropName="fileList" getValueFromEvent={normFile} required labele="upload Document" showLabel={false} multiple={false}>
                        <Upload
                          name="logo"
                          listType="picture-card"
                          className="avatar-uploader"
                          accept="image/jpg, image/jpeg, image/png,application/pdf"
                          showUploadList={false}
                          beforeUpload={(file) => {
                            setState({
                              DocPdf: file.type.includes("application/pdf"),
                            });
                            const isLt3MB = file.size;
                            if (isLt3MB >= "3000000") {
                              message.error("Document upload size limit maximum of 3MB!");
                              return false;
                            } else {
                              const fileName = file.name;
                              const fileType = file.type;
                              const reader = new FileReader();
                              reader.onload = (e) => {
                                setFrontDoc({
                                  fileName,
                                  fileType,
                                  docUrl: e.target.result,
                                });
                                setImageUrl(e.target.result);
                              };
                              reader.readAsDataURL(file);

                              return false;
                            }
                          }}
                          onChange={handleChange}
                        >
                          {imageUrl ? (
                            <>{state.DocPdf ? <FilePdfOutlined /> : <img src={imageUrl} alt="avatar" width="100%" height="100%" />}</>
                          ) : (
                            <div>
                              {loading ? <LoadingOutlined /> : <CameraOutlined />}
                              <div className="mt-8">Upload</div>
                              <div>Front</div>
                            </div>
                          )}
                        </Upload>
                      </CustomInput>
                      
                      {imageUrl && (
                        <DeleteOutlined
                          onClick={() => {
                            setImageUrl("");
                            setFrontDoc("");
                          }}
                        />
                      )}
                    </div>
                    <div className="col-6 text-center">
                      <CustomInput className="mb-2" wrapperCol={{ span: 24 }} name="document2" valuePropName="fileList" getValueFromEvent={normFile1} required label="Upload Document" showLabel={false} multiple={false}>
                        <Upload
                          name="logo1"
                          listType="picture-card"
                          className="avatar-uploader"
                          accept="image/jpg, image/jpeg, image/png, application/pdf"
                          showUploadList={false}
                          beforeUpload={(file) => {
                            setState({
                              DocPdf1: file.type.includes("application/pdf"),
                            });
                            const isLt3MB = file.size;
                            if (isLt3MB >= "3000000") {
                              message.error("Document upload size limit maximum of 3MB!");
                              return false;
                            } else {
                              const fileName1 = file.name;
                              const fileType1 = file.type;
                              const reader = new FileReader();

                              reader.onload = (e) => {
                                setBackDoc({
                                  fileName1,
                                  fileType1,
                                  docUrl1: e.target.result,
                                });
                                setImageUrl1(e.target.result);
                              };
                              reader.readAsDataURL(file);

                              return false;
                            }
                          }}
                          onChange={handleChange}
                        >
                          {imageUrl1 ? (
                            <>{state.DocPdf1 ? <FilePdfOutlined /> : <img src={imageUrl1} alt="avatar" width="100%" height="100%" />}</>
                          ) : (
                            <div>
                              {loading ? <LoadingOutlined /> : <CameraOutlined />}
                              <div>Upload</div>
                              <div>Back</div>
                            </div>
                          )}
                        </Upload>
                      </CustomInput>
                      
                      {imageUrl1 && (
                        <DeleteOutlined
                          onClick={() => {
                            setImageUrl1("");
                            setBackDoc("");
                          }}
                        />
                      )}
                    </div>
                  </div>

                  <p>
                    <small className="opacity-50">
                      Supported formats: JPG, PNG, BMP, PDF
                      <br />
                      File size limit 3MB
                    </small>
                  </p>
                </Col>

                <Col md={8} className="b_left  ps-md-3">
                  <Row>
                    <Col md={4}>
                      <label>Document ID / Number</label>
                    </Col>
                    <Col md={8}>
                      <CustomInput
                        name="documentidnumber"
                        label="Document ID / Number"
                        showLabel={false}
                        min={3}
                        max={100}
                        required
                        autoComplete="none"
                        validationRules={[
                          {
                            pattern: /^[a-z0-9]+([-_\s]{1}[a-z0-9]+)*$/i,
                            message: "Id number must be numeric & alphanumeric without special charecter",
                          },
                        ]}
                      />
                      
                    </Col>
                  </Row>
                  <Row>
                    <Col md={4}>
                      <label>Issue Country</label>
                    </Col>
                    <Col md={8}>
                      <CustomInput
                        className="form-item w-"
                        name="idissuer"
                        label="Issue Country"
                        showLabel={false}
                        required
                        type="select"
                        onChange={(value) => {
                          onChangeIssuerID(value, "ISSUER_COUNTRY");
                        }}
                        showSearch
                      >
                        {state.issuerCountryList.map((uiRow, i) => {
                          return <Option key={i} value={uiRow.countryName}>{`${uiRow.countryName}`}</Option>;
                        })}
                      </CustomInput>
                     
                    </Col>
                  </Row>
                  <Row>
                    <Col md={4}>
                      <label>Valid Till</label>
                    </Col>
                    <Col md={8}>
                      <CustomInput name="expiryDate" label="Valid Till" showLabel={false} required>
                        <DatePicker
                          className="w-100"
                          disabledDate={(current) => {
                            let customDate = moment().format("YYYY-MM-DD");
                            return current && current < moment(customDate, "YYYY-MM-DD");
                          }}
                          onChange={(value, dateString) => {
                            let formatedDate = moment(dateString).format("MM/DD/YYYY");
                            value !== null
                              ? setState({
                                  additionalInfo2: formatedDate,
                                })
                              : setState({ additionalInfo2: "" });
                          }}
                        />
                      </CustomInput>
                      
                    </Col>
                  </Row>
                  <Row>
                    <Col md={4}>
                      <label>Nationality</label>
                    </Col>
                    <Col md={8}>
                      <CustomInput className="form-item w-100" name="nationality" label="Nationality" showLabel={false} required type="select" showSearch>
                        {state.nationalities.map((nationality, i) => {
                          return (
                            <Option key={i} value={nationality.nationality}>
                              {nationality.nationality}
                            </Option>
                          );
                        })}
                      </CustomInput>
                     
                    </Col>
                  </Row>
                  {passFileNo == "PP" && (
                    <Row>
                      <Col md={4}>
                        <label>Passport File Number</label>
                      </Col>
                      <Col md={8}>
                        <CustomInput
                          name="passportfilenumber"
                          label="Passport File Number"
                          showLabel={false}
                          required
                          min={3}
                          max={100}
                          validationRules={[
                            {
                              pattern: /^[a-z0-9]+([-_\s]{1}[a-z0-9]+)*$/i,
                              message: "Id number must be numeric & alphanumeric without special charecter",
                            },
                          ]}
                        >
                          <div className="text-end opacity-50">
                            <small>Optional for Passport Selection</small>
                          </div>
                        </CustomInput>
                         
                      </Col>
                    </Row>
                  )}
                  <Row>
                    {!inputFields?.sourceOfFund?.hidden && (
                      <Col md={6}>
                        <label className="form-label">Source of fund</label>
                        <CustomInput
                          className="form-item w-100"
                          name="sourcefund"
                          onChange={(value) => {
                            setState({ sourceFundOther: value });
                          }}
                          type="select"
                          label="Source of fund"
                          showLabel={false}
                          placeholder="Select Source of fund"
                          showSearch
                          required
                        >
                          {state.sourceOFFundLists.map((sList, i) => {
                            return (
                              <Option key={i} value={sList.sourceOfFund}>
                                {sList.sourceOfFund}
                              </Option>
                            );
                          })}
                        </CustomInput>
                         
                      </Col>
                    )}
                    {!inputFields?.remittanceFrequency?.hidden && (
                      <Col md={6}>
                        <label className="form-label">Remittance Frequency</label>
                        <CustomInput className="form-item w-100" name="remittance_freq" label="Remittance Frequency" showLabel={false} placeholder="Select Remittance Frequency" showSearch type="select" required>
                          <Option value="WEEKLY">Weekly</Option>
                          <Option value="MONTHLY">Monthly</Option>
                          <Option value="QUARTERLY">Quarterly</Option>
                          <Option value="ANNUALLY">Annually</Option>
                          <Option value="ONE_OFF">One-Off</Option>
                        </CustomInput>
                        
                      </Col>
                    )}
                  </Row>
                  {state.sourceFundOther == "Other" && (
                    <Row>
                      <Col md={6}>
                        <CustomInput name="sourceFundOther" placeholder="Enter Source of Fund" label="Source Of Fund" showLabel={false} required />
                        
                      </Col>
                    </Row>
                  )}
                  <Row>
                    <Col md={6}>
                      <label className="form-label">Occupation</label>
                      <CustomInput
                        className="form-item w-100"
                        name="occupation"
                        onChange={(value) => {
                          setState({ occupationOther: value });
                        }}
                        placeholder="Select Occupation"
                        type="select"
                        label="Occupation"
                        showLabel={false}
                        showSearch
                        required
                      >
                        {state.occupationLists.map((ocRow, i) => {
                          return <Option key={i} value={ocRow.occupationName}>{`${ocRow.occupationName}`}</Option>;
                        })}
                      </CustomInput>
                      
                    </Col>
                  </Row>
                  <Row>
                    {state.occupationOther == "Other" && (
                      <Col md={6}>
                        <CustomInput name="occupationOther" placeholder="Enter Your Occupation" label="Occupation" showLabel={false} required />
                        
                      </Col>
                    )}
                  </Row>
                </Col>
              </Row>
              <div className="d-flex justify-content-end">
                <p
                  className="btn btn-link mb-3 me-3 text-primary"
                  onClick={() => {
                    props.setIsModalVisible(false);
                  }}
                >
                  I'll do this later
                </p>
                <button className="btn btn-primary text-white mb-3" htmlType="submit">
                  Confirm
                </button>
              </div>
            </Form>
          </>
        )}

        {AddProofForm && (
          <Spinner spinning={spinner}>
            <>
              {location.pathname === "/profile" ? (
                AuthReducer.userKYC == "DOB" ? (
                  <>
                    <div className="mb-3">
                      <h2>Complete Your KYC</h2>
                    </div>
                    <div className="d-flex mb-4">
                      <button className="btn btn-info me-3" disabled={true}>
                        Id Proof
                      </button>
                      <button className="btn btn-info">Address Proof</button>
                    </div>
                  </>
                ) : (
                  <>
                    <div className="mb-3">
                      <h2>Edit Address</h2>
                    </div>
                  </>
                )
              ) : (
                <>
                  <div className="mb-3">
                    <h2>Complete Your KYC</h2>
                  </div>
                  <div className="d-flex mb-4">
                    <button className="btn btn-info me-3" disabled={true}>
                      Id Proof
                    </button>
                    <button className="btn btn-info">Address Proof</button>
                  </div>
                </>
              )}

              <Form
                form={form}
                autoComplete="none"
                onFinish={(values) => {
                  if (addProofDoc == "") {
                    form.setFields([{ name: "document3", errors: ["Please upload document"] }]);
                  } else {
                    let letestVariable = { ...value, ...values };
                    submitHandler(letestVariable);
                  }
                }}
              >
                <Row>
                  <Col md={5} className="pe-3">
                    <Row>
                      <CustomInput wrapperCol={{ span: 24 }} className="form-item w-100" name="addressidtype" placeholder="Select Document Type" onSelect={(e) => setAddProofId(e)} label="Document Type" showLabel={false} required type="select">
                        {state.addressProofLists.map((uiRow, i) => {
                          return <Option key={i} value={uiRow.docType}>{`${uiRow.docName}`}</Option>;
                        })}
                      </CustomInput>
                       
                    </Row>
                    <Row className="mb-5">
                      <CustomInput wrapperCol={{ span: 24 }} className=" mb-2" name="document3" valuePropName="fileList" getValueFromEvent={normFile2} multiple={false} required label="upload document" showLabel={false}>
                        <Upload
                          name="logo2"
                          listType="picture-card"
                          className="avatar-uploader"
                          accept="image/jpg, image/jpeg, image/png, application/pdf"
                          showUploadList={false}
                          beforeUpload={(file) => {
                            setState({
                              DocPdf2: file.type.includes("application/pdf"),
                            });
                            const isLt3MB = file.size;
                            if (isLt3MB >= "3000000") {
                              message.error("Document upload size limit maximum of 3MB!");
                              return false;
                            } else {
                              const fileName2 = file.name;
                              const fileType2 = file.type;
                              const reader = new FileReader();

                              reader.onload = (e) => {
                                setAddProofDoc({
                                  fileName2,
                                  fileType2,
                                  docUrl2: e.target.result,
                                });
                                setImageUrl2(e.target.result);
                              };
                              reader.readAsDataURL(file);

                              return false;
                            }
                          }}
                          onChange={handleChange}
                        >
                          {imageUrl2 ? (
                            <>{state.DocPdf2 ? <FilePdfOutlined /> : <img src={imageUrl2} alt="avatar" width="100%" height="100%" />}</>
                          ) : (
                            <div>
                              {loading ? <LoadingOutlined /> : <CameraOutlined />}
                              <div>Upload</div>
                            </div>
                          )}
                        </Upload>
                      </CustomInput>
                       
                      {imageUrl2 && (
                        <DeleteOutlined
                          onClick={() => {
                            setImageUrl2("");
                            setAddProofDoc("");
                          }}
                        />
                      )}
                    </Row>
                    <p>
                      <small className="opacity-50">
                        Supported formats: JPG, PNG, BMP, PDF
                        <br />
                        File size limit 3MB
                      </small>
                    </p>
                  </Col>
                  <Col md={7} className="b_left ps-3">
                    <Row>
                      <Col md={2}>
                        <label>Address</label>
                      </Col>
                      <Col md={10}>
                        <CustomInput name="address" label="Address" showLabel={false} required min={1} max={100}>
                          <TextArea autoComplete="none" />
                        </CustomInput>
                         
                      </Col>
                    </Row>
                    <Row>
                      <Col md={2}>
                        <label>Street / Line 1</label>
                      </Col>
                      <Col md={10}>
                        <CustomInput className="form-item" name="address2" label="Street / Line 1" showLabel={false} required min={3} max={50} placeholder="Street / Line 1" autoComplete="none" />
                        
                      </Col>
                    </Row>
                    <Row>
                      <Col md={2}>
                        <label>Pin Code</label>
                      </Col>
                      <Col md={4}>
                        <CustomInput name="commPostalCode" label="Pin Code" showLabel={false} autoComplete="none" validationRules={[...inputValidations.zipCode(AuthReducer.sendCountryCode)]} required />
                        
                      </Col>
                      <Col md={2}>
                        <label>State</label>
                      </Col>
                      <Col md={4}>
                        <CustomInput name="state" label="State" showLabel={false} required>
                          <AutoComplete autoComplete="none" className="w-100" onSelect={onSelectStateHandler} filterOption={(inputValue, option) => option.value.toUpperCase().indexOf(inputValue.toUpperCase()) !== -1}>
                            {state.stateLists.map((st, i) => {
                              return <Option key={i} value={st.state}>{`${st.state}`}</Option>;
                            })}
                          </AutoComplete>
                        </CustomInput>
                         
                      </Col>
                    </Row>
                    <Row>
                      <Col md={2}>
                        <label>City</label>
                      </Col>
                      <Col md={4}>
                        <CustomInput name="city" label="City" showLabel={false} required>
                          <AutoComplete autoComplete="none" className="w-100" filterOption={(inputValue, option) => option.value.toUpperCase().indexOf(inputValue.toUpperCase()) !== -1}>
                            {state.cityLists.map((st, i) => {
                              return <Option key={i} value={st.city}>{`${st.city}`}</Option>;
                            })}
                          </AutoComplete>
                        </CustomInput>
                         
                      </Col>
                      <Col md={2}>
                        <label>Country</label>
                      </Col>
                      <Col md={4}>
                        <CustomInput className="w-100" name="country" type="select" label="Country" showLabel={false} required>
                          <Option value="UK">UK</Option>
                        </CustomInput>
                         
                      </Col>
                    </Row>
                  </Col>
                </Row>
                <div className="d-flex justify-content-end">
                  <button
                    className="btn btn-link mb-3 me-3 text-primary"
                    onClick={() => {
                      props.setIsModalVisible(false);
                    }}
                  >
                    I'll do this later
                  </button>
                  <button className="btn btn-primary text-white mb-3" htmlType="submit">
                    Confirm
                  </button>
                </div>
              </Form>
            </>
          </Spinner>
        )}
        {completeKycState && (
          <>
            <div className="d-flex flex-column justify-content-center align-items-center">
              <Lottie
                height={300}
                width={300}
                options={{
                  loop: false,
                  autoplay: true,
                  animationData: kycLottie,
                  rendererSettings: {
                    preserveAspectRatio: "xMidYMid slice",
                  },
                }}
              />
              <h3 className="text-primary fw-800">Your KYC is now Complete</h3>
            </div>
            <div className="text-end">
              <button
                className="btn btn-primary text-white mb-3"
                onClick={() => {
                  location.pathname === "/kyc" ? navigate("/new-transaction") : props.setIsModalVisible(false);
                }}
              >
                Back
              </button>
            </div>
          </>
        )}
      </>
    </>
  );
}
