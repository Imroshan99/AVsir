// import PaymentSuccess from "../../../assets/images/click2remit/Paymentsuccess.svg";
// import BackArrow from "../../../assets/images/click2remit/Back_arrow.svg";
import { useNavigate } from "react-router-dom";
import { useEffect } from "react";

export default function JumioSuccess() {
  const navigate = useNavigate();
  useEffect(() => {
    // Send the message "Hello" to the parent window
    // ...if the domain is still "davidwalsh.name'"
    setTimeout(() => {
      const plaidData = window.parent.postMessage(
        {
          data: "JUMIO_SUCCESS",
        },
        "*" //or "www.parentpage.com"
      );
    }, 1000);
  }, []);
  return (
    <>
      {" "}
      <div className="container h-100">
        <div className="row h-100">
          <form>
            <div className="col-md-6 col-sm-12 col-lg-6 offset-md-3 align-self-center">
              <div className="CR-otp-form">
                <ul className="row list-unstyled">
                  <li className="back-arrow-nav d-xs-block d-done">
                    {/* <img src={BackArrow} alt="" /> */}
                  </li>
                  <li className="text-center">
                    {/* <img src={PaymentSuccess} style={{ marginBottom: "30px" }} alt="" /> */}
                  </li>
                  <li className="col-md-12 col-sm-12 col-lg-12 mb-4">
                    <h4 className="text-black text-center">Jumio Successful</h4>
                  </li>
                  <li className="col-md-12 col-sm-12 col-lg-12">
                    <p className="text-center"></p>
                  </li>
                  {/* <button
                      onClick={() => {
                        navigate("/signin");
                      }}
                      className="btn btn-primary CR-primary-btn"
                      // style={{ width: "100px", margin: "0 !important" }}
                    >
                      Go to
                    </button> */}
                </ul>
              </div>
            </div>
          </form>
        </div>
      </div>
    </>
  );
}
