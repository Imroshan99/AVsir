import React, { useEffect } from "react";
import { useSelector } from "react-redux";

import Dashboard from "../Layouts/Dashboard";
import { useOutletContext } from "react-router-dom";
import RequestMoneyFlowOne from "./RequestMoneyFlowOne/RequestMoneyFlowOne";
// import DashboardTemplate1 from "../Layouts/Dashboard/DashboardTemplate1";

const RequestMoney = (props) => {
  const { setTitle } = useOutletContext();
  const AuthReducer = useSelector((state) => state.user);
  //   const temp = AuthReducer.groupIdSettings?.theme?.SIGN;
  const templateFlow = AuthReducer.groupIdSettings?.recipientModule?.AddRecipientForm?.flow;

  useEffect(() => {
    setTitle("Request Money");
  }, []);
  return (
    <>
      {templateFlow === "FLOW1" && (
        <RequestMoneyFlowOne appState={props.appState} manageAuth={props.manageAuth} />
      )}
      {templateFlow === "FLOW2" && (
        <RequestMoneyFlowOne appState={props.appState} manageAuth={props.manageAuth} />
      )}
    </>
  );
};

export default RequestMoney;
