import React, { useEffect } from 'react';
import { config } from '../../../../config';
import { RealexHpp } from './../../../../services/RXPJS';
import { Row, Col } from 'antd';

function Checkout(props) {

    useEffect(() => {

        const globalpayDataJson = props.state.globalpayData[0];
        // const globalpayDataJson = {
        //     "SHIPPING_CODE": "Mytholmes Lane",
        //     "MERCHANT_RESPONSE_URL": `${config.API_URL}/services/intg/IUK/globalpay-callback-response`,
        //     "GlobalPayId": "2623",
        //     "VAR_REF": "",
        //     "CUSTOM_FIELD_NAME": "",
        //     "HPP_CUSTOMER_PHONENUMBER_MOBILE": "44|7898739638",
        //     "HPP_SHIPPING_STREET3": "",
        //     "HPP_SHIPPING_STREET1": "Mytholmes Lane",
        //     "HPP_SHIPPING_STREET2": "Haworth",
        //     "AUTO_SETTLE_FLAG": "1",
        //     "BILLING_CODE": "Mytholmes Lane",
        //     "ACCOUNT": "internet",
        //     "AMOUNT": "20200",
        //     "TIMESTAMP": "20220201132445",
        //     "HPP_BILLING_STREET3": "",
        //     "HPP_ADDRESS_MATCH_INDICATOR": "FALSE",
        //     "HPP_BILLING_STREET2": "Haworth",
        //     "PROD_ID": "SKU1000054",
        //     "HPP_BILLING_STREET1": "Mytholmes Lane",
        //     "CURRENCY": "GBP",
        //     "HPP_BILLING_CITY": "Keighley",
        //     "HPP_SHIPPING_COUNTRY": "826",
        //     "HPP_CHANNEL": "ECOM",
        //     "HPP_SHIPPING_POSTALCODE": "BD22 8EZ",
        //     "HPP_BILLING_POSTALCODE": "BD22 8EZ",
        //     "HPP_BILLING_COUNTRY": "826",
        //     "HPP_LANG": "en",
        //     "HPP_CHALLENGE_REQUEST_INDICATOR": "NO_PREFERENCE",
        //     "COMMENT1": "Mobile Channel",
        //     "HPP_SHIPPING_CITY": "Keighley",
        //     "SHA1HASH": "e7d22deaa097f9ed4e9ed351f29151b374825c64",
        //     "ORDER_ID": "55341408240019",
        //     "HPP_SHIPPING_STATE": "GB",
        //     "BILLING_CO": "GB",
        //     "CUST_NUM": "",
        //     "HPP_VERSION": "2",
        //     "HPP_CUSTOMER_EMAIL": "TESTFLOWUK@YOPMAIL.COM",
        //     "SHIPPING_CO": "US",
        //     "MERCHANT_ID": "dev337674357500184411"
        // };

        RealexHpp.setHppUrl(`${config.realexpayment_url}/pay`);
        RealexHpp.embedded.init(
            'autoload',
            'targetIframe',
            (gpResponse, close) => navigateToThankYouPage(gpResponse, close),
            globalpayDataJson
        );

    }, []);

    const navigateToThankYouPage = (gpresponse, close) => {
        console.log("gp response", gpresponse)
        // console.log("gp close", close)
        props.globalpayResponse(gpresponse)
    }

    return (
        <div>
            {/* <Row>
                <Col span={12}> */}
            <iframe
                title="card-payment"
                id="targetIframe"
                width="100%"
                height="650px"
            ></iframe>
            {/* </Col>
            </Row> */}
        </div>
    );
}

export default Checkout;
