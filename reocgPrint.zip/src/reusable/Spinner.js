// import { LoadingOutlined } from "@ant-design/icons";
import { Spin } from "antd";
import { useSelector } from "react-redux";
import Lottie from "react-lottie";
import * as xrSpinnerLottie from "../assets/images/XR/XR_spinner.json";

export default function Spinner(props) {
  const AuthReducer = useSelector((state) => state.user);
  // const customLoader = (
  //   <LoadingOutlined style={{ fontSize: 24, color: "#10E7DC" }} spin />
  // );
  const { size } = props;

  switch (AuthReducer.groupId) {
    case "XR":
      const antIcon = (
        <Lottie
          height={size === "medium" ? 60 : 120}
          width={size === "medium" ? 60 : 120}
          options={{
            loop: true,
            autoplay: true,
            animationData: xrSpinnerLottie,
            rendererSettings: {
              preserveAspectRatio: "xMidYMid slice",
            },
          }}
        />
      );
      return (
        <Spin indicator={antIcon} spinning={props.spinning} {...props}>
          {props.children}
        </Spin>
      );
    case "MCPP":
      const MCPP_spinner = (
        <div className="lds-ring">
          <div></div>
          <div></div>
          <div></div>
          <div></div>
        </div>
      );
      return (
        <Spin indicator={MCPP_spinner} spinning={props.spinning} {...props}>
          {props.children}
        </Spin>
      );
    default:
      return (
        <Spin spinning={props.spinning} {...props}>
          {props.children}
        </Spin>
      );
  }
}

Spinner.defaultProps = {
  size: "medium",
};
