/* eslint-disable no-template-curly-in-string */
import React from "react";
import { Select, Input, Form } from "antd";
// const { Option } = Select;
const VALIDATION_MESSAGE = {
  required: "${label} is required",
  email: "Please enter a valid email address",
  len: "${label} must be exact ${len} characters",
  min: "${label} must be at least ${min} characters",
  max: "${label} cannot be longer than ${max} characters",
  range: "${label} must be between ${min} and ${max} characters",
};

const CustomInput = (props) => {
  const {
    label,
    showLabel = true,
    type,
    name,
    value,
    placeholder,
    required,
    className,
    inputClassName, //for input box
    validationRules = [],
    min,
    max,
    len,
    range,
    maxLength,
    children,
    // disabled,
    // onChange,
    // size,
    ...otherProps
  } = props;

  const inputValidationRules = () => {
    const vr = [];
    required &&
      vr.push({ required: required, message: VALIDATION_MESSAGE.required });

    type === "email" &&
      vr.push({ type: "email", message: VALIDATION_MESSAGE.email });

    min && vr.push({ min: min, message: VALIDATION_MESSAGE.min });
    max && vr.push({ max: max, message: VALIDATION_MESSAGE.max });
    len && vr.push({ len: len, message: VALIDATION_MESSAGE.len });
    validationRules && vr.push(...validationRules);

    return vr;
  };

  const CustomSelectInput =
    type === "select" ? (
      <Select
        className={inputClassName}
        placeholder={placeholder}
        // size={size}
        {...otherProps}
      >
        {children}
      </Select>
    ) : children ? (
      children
    ) : (
      <Input
        className={inputClassName}
        type={type}
        placeholder={placeholder}
        value={value}
        maxLength={maxLength}
        {...otherProps}
        // disabled={disabled}
        // onChange={onChange}
        // size={size}
      />
    );

  return (
    <div className="FormInput">
      {showLabel && <label className="form-label">{label}</label>}
      <Form.Item
        messageVariables={{ label: label }}
        name={name}
        className={`form-item ${className}`}
        rules={inputValidationRules()}
      >
        {CustomSelectInput}
      </Form.Item>
    </div>
  );
};
CustomInput.defaultProps = {
  type: "text",
};

export default CustomInput;
