export const passwordValidate = (groupId) => {
  switch (groupId) {
    case "XR":
      return [
        {
          pattern:
            /^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[#?!@$%^&*-]).{8,20}$/,
          message:
            "Password should be alphanumeric value with one upper case and have atleast one special character",
        },
        {
          min: 8,
          max: 20,
          message: "Password should be between 8 and 20 characters long.",
        },
      ];

    default:
      return [
        {
          pattern:
            /^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[#?!@$%^&*-]).{10,20}$/,
          message:
            "Password should be alphanumeric value with one upper case and have atleast one special character",
        },
        {
          min: 10,
          max: 20,
          message: "Password should be between 10 and 20 characters long.",
        },
      ];
  }
};
