export const GroupSettings = {
  KCB: {
    title: "KCB Remit",
    template: "TEMPLATE_FOUR",
    theme: {
      SIGN: "AuthTemp2",
    },
    default: { sendModeCode: "ACH", programCode: "FER" },
    signInForm: {
      twoFA: "Y",
    },
    signUpForm: {
      formType: "REGULAR", // formType: "REGULAR" | STEPS,
    },
    recipientModule: {
      recipientList: {
        columns: {
          status: "DISABLED", //disable status column
        },
      },
      AddRecipientForm: {
        recipientBankBranchRadio: false,
        defaultRecipientBranch: "LOCATION", //LOCATION or IFSC
        twoFA: "N",
      },
    },
    profileModule: {
      // addressApi : 'ADDRESSNOW',
      twoFA: "N",
      inputFields: {},
    },
    kyc: {
      inputFields: {
        sourceOfFund: { hidden: true },
        remittanceFrequency: { hidden: true },
      },
    },
    settings: {
      rightClick: false,
      selectText: false,
    },
  },
  XR: {
    title: "XMONIES",
    template: "TEMPLATE_FOUR",
    default: {
      sendModeCode: "CIP",
      programCode: "FER",
      sendCountryCode: "GB",
      sendCurrencyCode: "GBP",
      recvCountryCode: "IN",
      recvCurrencyCode: "INR",
    },
    theme: {
      favIcon: "", //favicon
      logo: "",  // logo
      banner: "", //home page banner
      SIGN: "AuthTemp7",
      Header: "Header6",
    },
    bankAccount: {
      addBankAccount: {
        flow: "FLOW1",
      },
      bankAccountList: {
        flow: "FLOW1",
      },
      viewBankDetails: {
        flow: "FLOW1",
      },
    },

    signInForm: {
      twoFA: "N",
    },
    signUpForm: {
      flow: "FLOW3",
      formType: "REGULAR", // formType: "REGULAR" | STEPS,
    },
    recipientModule: {
      recipientList: {
        flow: "FLOW2",
        columns: {
          // status: "DISABLED", //disable status column
        },
      },
      RecipientInfo: {
        flow: "FLOW2",
      },
      AddRecipientForm: {
        flow: "FLOW2",
        recipientBankBranchRadio: false,
        defaultRecipientBranch: "LOCATION", //LOCATION or IFSC
        twoFA: "N",
        modal: {
          modal: true,
        },
      },
    },
    sendMoneyModule: {
      flow: "FLOW2",
      transactionList: {
        flow: "FLOW1",
      },
    },
    profileModule: {
      flow: "FLOW2",
      twoFA: "N",
      // addressApi : 'ADDRESSNOW',
      inputFields: {},
    },
    kyc: {
      flow: "FLOW2",
      inputFields: {
        ssn: { hidden: true },
      },
    },
    changePasswordForm: {
      flow: "FLOW2",
      // inputFields: {
      //   ssn: { hidden: true },
      // },
    },
    settings: {
      rightClick: true,
      selectText: true,
    },
  },

  MF: {
    title: "Muthoot Finance Remit",
    template: "TEMPLATE_ONE",
    theme: {
      SIGN: "AuthTemp4",
    },
    default: { sendModeCode: "CIP", programCode: "FER" },
    signInForm: {
      twoFA: "N",
    },
    signUpForm: {
      formType: "REGULAR", // formType: "REGULAR" | STEPS,
    },
    recipientModule: {
      recipientList: {
        columns: {
          status: "DISABLED", //disable status column
        },
      },
      AddRecipientForm: {
        recipientBankBranchRadio: false,
        defaultRecipientBranch: "LOCATION", //LOCATION or IFSC
        twoFA: "N",
      },
    },
    profileModule: {
      // addressApi : 'ADDRESSNOW',
      twoFA: "N",
      inputFields: {},
    },
    kyc: {
      inputFields: {
        sourceOfFund: { hidden: true },
        remittanceFrequency: { hidden: true },
      },
    },
    settings: {
      rightClick: false,
      selectText: false,
    },
  },
  CSB: {
    title: "CSB Bank Remit",
    template: "TEMPLATE_ONE",
    theme: {
      SIGN: "AuthTemp1",
    },
    default: { sendModeCode: "CIP", programCode: "FER" },
    signInForm: {
      twoFA: "N",
    },
    signUpForm: {
      formType: "REGULAR", // formType: "REGULAR" | STEPS,
    },
    recipientModule: {
      recipientList: {
        columns: {
          status: "DISABLED", //disable status column
        },
      },
      AddRecipientForm: {
        recipientBankBranchRadio: false,
        defaultRecipientBranch: "LOCATION", //LOCATION or IFSC
        twoFA: "N",
      },
    },
    profileModule: {
      // addressApi : 'ADDRESSNOW',
      twoFA: "N",
      inputFields: {},
    },
    kyc: {
      inputFields: {
        sourceOfFund: { hidden: true },
        remittanceFrequency: { hidden: true },
      },
    },
    settings: {
      rightClick: false,
      selectText: false,
    },
  },
  MCPP: {
    title: "Mastercard BizPay",
    template: "TEMPLATE_FOUR",
    default: {
      sendModeCode: "CIP",
      programCode: "FER",
      sendCountryCode: "GB",
      sendCurrencyCode: "GBP",
      recvCountryCode: "IN",
      recvCurrencyCode: "INR",
    },
    theme: {
      favIcon: "", //favicon
      logo: "",  // logo
      banner: "", //home page banner
      Auth: "AuthTemp6",
      Header: "Header4",
    },
  
    bankAccount: {
      addBankAccount: {
        flow: "FLOW1",
      },
      bankAccountList: {
        flow: "FLOW1",
      },
      viewBankDetails: {
        flow: "FLOW1",
      },
    },

    signInForm: {
      twoFA: "N",
    },
    signUpForm: {
      flow: "FLOW3",
      formType: "REGULAR", // formType: "REGULAR" | STEPS,
    },
    recipientModule: {
      recipientList: {
        flow: "FLOW1",
        columns: {
          // status: "DISABLED", //disable status column
        },
      },
      RecipientInfo: {
        flow: "FLOW2",
      },
      AddRecipientForm: {
        flow: "FLOW2",
        recipientBankBranchRadio: false,
        defaultRecipientBranch: "LOCATION", //LOCATION or IFSC
        twoFA: "N",
        modal: {
          modal: true,
        },
      },
    },
    sendMoneyModule: {
      flow: "FLOW2",
      transactionList: {
        flow: "FLOW1",
      },
    },
    profileModule: {
      flow: "FLOW3",
      twoFA: "N",
      // addressApi : 'ADDRESSNOW',
      inputFields: {},
    },
    kyc: {
      flow: "FLOW2",
      inputFields: {
        ssn: { hidden: true },
      },
    },
    changePasswordForm: {
      flow: "FLOW1",
      // inputFields: {
      //   ssn: { hidden: true },
      // },
    },
    changeEmail: {
      flow: "FLOW1",
      acive: true,
      // inputFields: {
      //   ssn: { hidden: true },
      // },
    },
    contact: {
      flow: "FLOW1",
      acive: true,
      // inputFields: {
      //   ssn: { hidden: true },
      // },
    },
    feedback: {
      flow: "FLOW1",
      acive: true,
      // inputFields: {
      //   ssn: { hidden: true },
      // },
    },
    raiseIssue: {
      flow: "FLOW1",
      acive: true,
      // inputFields: {
      //   ssn: { hidden: true },
      // },
    },
    settings: {
      rightClick: true,
      selectText: true,
      refreshPage: false,
    },
  },
  C2R: {
    title: "Click2Remit",
    template: "CLICK2REMIT",
    default: {
      sendModeCode: "CIP",
      programCode: "FER",
      sendCountryCode: "",
      sendCurrencyCode: "",
      recvCountryCode: "",
      recvCurrencyCode: "",
    },
    theme: {
      favIcon: "favicon.ico", //favicon
      logo: "",  // logo
      banner: "", //home page banner
      Auth: "AuthTemp6",
      Header: "Header4",
    },
  
    bankAccount: {
      addBankAccount: {
        flow: "FLOW1",
      },
      bankAccountList: {
        flow: "FLOW1",
      },
      viewBankDetails: {
        flow: "FLOW1",
      },
    },

    signInForm: {
      twoFA: "N",
    },
    signUpForm: {
      flow: "FLOW3",
      formType: "REGULAR", // formType: "REGULAR" | STEPS,
    },
    recipientModule: {
      recipientList: {
        flow: "FLOW1",
        columns: {
          // status: "DISABLED", //disable status column
        },
      },
      RecipientInfo: {
        flow: "FLOW2",
      },
      AddRecipientForm: {
        flow: "FLOW2",
        recipientBankBranchRadio: false,
        defaultRecipientBranch: "LOCATION", //LOCATION or IFSC
        twoFA: "N",
        modal: {
          modal: true,
        },
      },
    },
    sendMoneyModule: {
      flow: "FLOW2",
      transactionList: {
        flow: "FLOW1",
      },
    },
    profileModule: {
      flow: "FLOW3",
      twoFA: "N",
      // addressApi : 'ADDRESSNOW',
      inputFields: {},
    },
    kyc: {
      flow: "FLOW2",
      inputFields: {
        ssn: { hidden: true },
      },
    },
    changePasswordForm: {
      flow: "FLOW1",
      // inputFields: {
      //   ssn: { hidden: true },
      // },
    },
    changeEmail: {
      flow: "FLOW1",
      acive: true,
      // inputFields: {
      //   ssn: { hidden: true },
      // },
    },
    contact: {
      flow: "FLOW1",
      acive: true,
      // inputFields: {
      //   ssn: { hidden: true },
      // },
    },
    feedback: {
      flow: "FLOW1",
      acive: true,
      // inputFields: {
      //   ssn: { hidden: true },
      // },
    },
    raiseIssue: {
      flow: "FLOW1",
      acive: true,
      // inputFields: {
      //   ssn: { hidden: true },
      // },
    },
    settings: {
      rightClick: true,
      selectText: true,
      refreshPage: false,
    },
  },
};
