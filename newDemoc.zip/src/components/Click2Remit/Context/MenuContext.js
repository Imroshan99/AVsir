import React, { useState } from "react";

export const MenuContext = React.createContext({
  isVisible: false,
  toggleMenu: () => {}
});

export default function MenuContextProvider(props) {
    const [showMobileMenu, setShowMobileMenu] = useState(false);
  const toggleMenuHandler = (value) => {
    setShowMobileMenu(value);
  };
  return (
    <MenuContext.Provider
      value={{ isVisible: showMobileMenu, toggleMenu: toggleMenuHandler }}
    >
      {props.children}
    </MenuContext.Provider>
  );
}
