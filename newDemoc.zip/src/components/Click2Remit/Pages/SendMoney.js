import React from "react";
import Main from "../Layouts/Main";
import BackArrow from "../../../assets/images/click2remit/Back_arrow.svg";
import CreateRemitterAccount from "../BankAccounts/CreateRemitterAccount";
import CreateAccountStepper from "../Registration/CreateAccountStepper";
import CustomInput from "../../../reusable/CustomInput";
import FloatInput from "../../../reusable/FloatInput";
import "./sendmoney.scss";
import { Card, Checkbox, Col, Row } from "antd";
const SendMoney = () => {
  return (
    <Main>
      <div className="container h-100">
        <div className="row h-100 justify-content-center">
          <form>
            <div className="align-self-center col-lg-7 col-md-7 col-sm-12 mx-auto">
              <div className="CR-default-box CR-max-width-620">
                <div style={{ height: "367px", backgroundColor: " #FAFBFC ", borderRadius: "8px 8px 0px 0px" }}>
                  <li className="col-md-12 col-sm-12 col-lg-12 d-flex align-items-baseline justify-content-between">
                    <h4 className="text-black CR-font-28 mb-1  p-5 ">Transfer Amount</h4>
                    <CustomInput className="p-5" showLabel={false} name="fullname" label="Full Name" required>
                      <FloatInput type="select" placeholder="Full Name" className="CR-blue-link" />
                    </CustomInput>
                  </li>

                  <div className="bgposition"></div>
                  <div className="">
                    <div className="ticket">
                      <CustomInput className="p-3" showLabel={false} name="fullname" label="Full Name" required>
                        <FloatInput type="text" placeholder="Full Name" className="CR-blue-link" />
                      </CustomInput>
                      <div className="line"></div>
                      <CustomInput className="p-3" showLabel={false} name="fullname" label="Full Name" required>
                        <FloatInput type="text" placeholder="Full Name" className="CR-blue-link" />
                      </CustomInput>
                    </div>
                  </div>
                  <div className="bgposition1"></div>
                </div>
                <div className="container mt-3">
                  <CustomInput className="" showLabel={false} name="serviceprovider" label="select service provider" required>
                    <FloatInput type="select" placeholder="Select beneficiary" className="CR-blue-link" />
                  </CustomInput>
                  <CustomInput className="" showLabel={false} name="serviceprovider" label="select service provider" required>
                    <FloatInput type="select" placeholder="Select remitter account" className="CR-blue-link" />
                  </CustomInput>
                  <Checkbox>
                    I accept all the <a href="#"> TERMS & CONDITIONS</a>
                  </Checkbox>
                </div>
                <div className="bgcolor mt-4 p-3">
                  <sapn>
                    For list of partners in diffrent countries <a href="#">TAP HERE</a>
                  </sapn>
                </div>

                <div className="sliderbg mt-4">
                  <div className="container positionabs mt-5  ">
                    <h5>How its Work</h5>
                    <div className="site-card-wrapper  ">
                      <Row gutter={16} className="">
                        <Col span={8}>
                          <Card title="Step 1" bordered={false}>
                            Select the country you wish to remit from.
                          </Card>
                        </Col>
                        <Col span={8}>
                          <Card title="Step 2" bordered={false}>
                            Enter your details
                          </Card>
                        </Col>
                        <Col span={8}>
                          <Card title="Step 3" bordered={false}>
                            Initiate remittance process
                          </Card>
                        </Col>
                      </Row>
                    </div>
                  </div>
                </div>

                <div className="bottom_panel">
                  <div className="d-flex align-items-baseline justify-content-between ">
                    <p className="btn-enable-row"> </p>
                    <button type="button" className="btn btn-primary CR-primary-btn" style={{ width: "150px", margin: "0 !important", right: 0 }}>
                      GET STARTED
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </form>
        </div>
      </div>
    </Main>
  );
};

export default SendMoney;
