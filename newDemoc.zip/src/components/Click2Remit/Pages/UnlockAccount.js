import React, { useState, useEffect, useReducer } from "react";
import Box from "@mui/material/Box";
import Grid from "@mui/material/Grid";
import Container from "react-bootstrap/Container";
import { Link, useNavigate } from "react-router-dom";
import { Form, Input, Checkbox, Select, Radio, DatePicker, notification, Spin } from "antd";
import moment from "moment";
import { AuthAPI } from "../../../apis/AuthAPI";
import { GuestAPI } from "../../../apis/GuestAPI";
import OTPBox from "../../../containers/OTPBox";
import ExchangeRate from "../../../containers/ExchangeRate";
import { config } from "../../../config";
import { useSelector } from "react-redux";
import { encrypt, decrypt, publickey } from "../../../helpers/makeHash";

import Tab from "@mui/material/Tab";
import TabContext from "@mui/lab/TabContext";
import TabList from "@mui/lab/TabList";
import TabPanel from "@mui/lab/TabPanel";
import { Stack } from "@mui/material";
import SetNewPassword from "./SetNewPassword";
import useHttp from "../../../hooks/useHttp";
import VerifyOtp from "../containers/VerifyOtp";
import CustomInput from "../../../reusable/CustomInput";
import FloatInput from "../../../reusable/FloatInput";
import Back_arrow from "../../../assets/images/click2remit/Back_arrow.svg";
import Main from "../Layouts/Main";
import { validateEmailId } from "../../../services/validations/email";

const { Option } = Select;
export default function UnlockAccount(props) {
  let navigate = useNavigate();

  const ConfigReducer = useSelector((state) => state);

  const [form] = Form.useForm();
  const [form1] = Form.useForm();
  const [loading, setLoader] = useState(false);
  const [isSelectMarketingCommunication, setisSelectMarketingCommunication] = useState("N");

  const [state, setState] = useReducer((state, newState) => ({ ...state, ...newState }), {
    isModalVisible: false,
    verificationToken: "",
    verifiedToken: "",
    clientId: ConfigReducer.clientId,
    groupId: ConfigReducer.groupId,
    twofa: ConfigReducer.twofa,
    sessionId: ConfigReducer.sessionId,
    formData: {},
    dob: "",
    loginId: "",
    _isShowOTPBOX: false,
    otpType: "UL",
    otpExpiryTime: "",
  });

  const hookUnlockUserid = useHttp(AuthAPI.unlockUserid);
  const hookUnlockAccount = useHttp(AuthAPI.unlockAccount);

  useEffect(() => {
    window.scrollTo({ top: 0, behavior: "smooth" });
  }, []);

  const unlockUserIdHandler = (value) => {
    setState({
      loginId: value.loginId,
    });

    let unlockUseridPayload = {
      requestType: "UNLOCKUSERID",
      loginId: value.loginId,
      dob: state.dob,
      verifyType: value.verifyType,
      otpService: "EMAIL",
      otpType: "UL",
    };

    setLoader(true);
    hookUnlockUserid.sendRequest(unlockUseridPayload, function (data) {
      if (data.status == "S") {
        notification.success({ message: "OTP has been sent to your registered email address." });
        setState({ otpExpiryTime: data.otpExpiryTime });
        if (value.verifyType === "O") {
          setState({ verificationToken: data.verificationToken });

          setState({
            _isShowOTPBOX: true,
            isModalVisible: true,
            formData: value,
          });
        }
        if (value.verifyType === "L") {
          notification.success({ message: data.message });
          navigate("/signin");
        }
      } else {
        notification.error({
          message: data.errorMessage ? data.errorMessage : "Unlock user id failed.",
        });

        if (data.errorList) {
          let errors = [];
          data.errorList.forEach((error, i) => {
            let errorData = {
              name: error.field,
              errors: [error.error],
            };
            errors.push(errorData);
          });

          if (errors.length > 0) {
            if (value.verifyType === "O") {
              form.setFields(errors);
            }
            if (value.verifyType === "L") {
              form1.setFields(errors);
            }
          }
        }
      }
      setLoader(false);
    });
  };

  const onUnlockAccountHandler = () => {
    let unlockAccountPayload = {
      requestType: "UNLOCKACCOUNT",
      loginId: state.loginId,
      dob: state.dob,
      // verifyType: value.verifyType,
    };

    setLoader(true);
    hookUnlockAccount.sendRequest(unlockAccountPayload, function (data) {
      if (data.status == "S") {
        // setState({
        //   _isShowOTPBOX: false,
        //   isModalVisible: false,
        // });

        notification.success({ message: data.message });
        navigate("/signin");
      } else {
        notification.error({
          message: data.errorMessage ? data.errorMessage : "Unlock account failed.",
        });

        if (data.errorList) {
          let errors = [];
          data.errorList.forEach((error, i) => {
            let errorData = {
              name: error.field,
              errors: [error.error],
            };
            errors.push(errorData);
          });

          if (errors.length > 0) {
            form.setFields(errors);
          }
        }
      }
      setLoader(false);
    });
  };

  return (
    <Main sidebar={false}>
      <div className="container h-100 d-flex justify-content-center w-100">
        {state._isShowOTPBOX ? (
          <VerifyOtp
            state={state}
            setState={setState}
            otpType={state.otpType}
            useFor="unlock_account"
            onUnlockAccountHandler={onUnlockAccountHandler}
            appState={props.appState}
          />
        ) : (
          <Spin spinning={loading} delay={500}>
            <Form form={form} initialValues={{ verifyType: "O" }} onFinish={unlockUserIdHandler}>
              <div className="CR-otp-form-parent" style={{ minHeight: "0px" }}>
                <div className="CR-otp-form-child">
                  <ul className="row d-flex flex-column align-items-center">
                    <li className="col-md-12 col-sm-12 col-lg-12 mb-4">
                      <h4 className="text-black text-center">Unlock Account</h4>
                    </li>
                    {/* <li className="col-md-12 col-sm-12 col-lg-12">
                      <p className="text-center">
                        A 6 digit OTP will be sent to your registered email id
                      </p>
                    </li> */}
                    <li className="col-md-12 col-sm-12 col-lg-12">
                      <CustomInput
                        showLabel={false}
                        name="loginId"
                        label="Email address"
                        validationRules={[
                          ({ getFieldValue }) => ({
                            validator(rule, value) {
                              let message = "";
                              let obj = validateEmailId(value ? value : "");
                              message = obj.message;
                              if (obj.status === "S") {
                                return Promise.resolve();
                              }
                              return Promise.reject(message);
                            },
                          }),
                        ]}
                      >
                        <FloatInput placeholder="Email address" />
                      </CustomInput>
                    </li>
                    <li className="col-md-12 col-sm-12 col-lg-12">
                      <CustomInput showLabel={false} name="dob" label="Dob" required>
                        <FloatInput
                          type="datepicker"
                          placeholder="Select dob"
                          defaultPickerValue={moment().subtract(18, "years")}
                          disabledDate={(d) =>
                            !d ||
                            d.isAfter(moment().subtract(18, "years")) ||
                            d.isSameOrBefore("1900-01-01")
                          }
                          onChange={(value, dateString) => {
                            value !== null
                              ? setState({
                                  dob: dateString,
                                })
                              : setState({ dob: "" });
                          }}
                        />
                      </CustomInput>
                    </li>
                    <li className="col-md-12 col-sm-12 col-lg-12">
                      <Form.Item name="verifyType" hidden={true}>
                        <Input type={"hidden"} />
                      </Form.Item>
                    </li>
                  </ul>
                </div>
                <div className="bottom_panel">
                  <div className="d-flex justify-content-between align-items-center gap-3 gap-md-5">
                    <div
                      className="Back_arrow d-flex align-items-center"
                      onClick={() => {
                        navigate("/signin");
                      }}
                    >
                      <img src={Back_arrow} alt="backArrow" /> Back
                    </div>
                    <button style={{ maxWidth: "17rem" }} className="CR-primary-btn ">
                      Send OTP
                    </button>
                  </div>
                </div>
              </div>
            </Form>
          </Spin>
        )}
      </div>
    </Main>
  );
}
//wip
