import c2r_logo from "../../../assets/images/click2remit/C2R_logo_pre1.png";

export default function PrivacyPolicy() {
  return (
    <>
      <body className="privacyPolicy">
        <table width="600" border="0" align="center" cellpadding="0" cellspacing="0">
          <tr>
            <td
              align="center"
              valign="top"
              style={{
                borderTop: "1px solid #656565",
                borderBottom: "1px solid #656565",
                borderLeft: "1px solid #656565",
                borderRight: "1px solid #656565",
              }}
            >
              <table border="0" align="center" cellpadding="0" cellspacing="0">
                <tr>
                  <td
                    align="center"
                    valign="top"
                    class="outerpadding"
                    style={{ paddingTop: "20px" }}
                  >
                    <table width="560" border="0" align="center" cellpadding="0" cellspacing="0">
                      <tr>
                        <td
                          align="center"
                          valign="top"
                          style={{ paddingBottom: "20px", textAlign: "left" }}
                        >
                          <img
                            src={c2r_logo}
                            width="300px"
                            height="58.9px"
                            style={{ display: "block !important" }}
                            class="toplogo1"
                            border="0"
                          />
                        </td>
                      </tr>
                    </table>
                  </td>
                </tr>
                <tr>
                  <td align="center" valign="top" class="outerpadding">
                    <table width="560" border="0" align="center" cellpadding="0" cellspacing="0">
                      <tr>
                        <td
                          align="center"
                          valign="top"
                          style={{
                            paddingBottom: "30px",
                            paddingLeft: "15px",
                            paddingRight: "15px",
                          }}
                        >
                          <table
                            width="560"
                            border="0"
                            align="center"
                            cellpadding="0"
                            cellspacing="0"
                          >
                            <tr>
                              <td
                                align="center"
                                valign="top"
                                style={{
                                  fontFamily: "Roboto,sans-serif",
                                  fontSize: "14px",
                                  lineHeight: "24px",
                                  color: "#323232",
                                  textAlign: "left",
                                  paddingBottom: "12px",
                                  paddingTop: "10px",
                                }}
                              >
                                You agree that we may use Customer Information for the purpose of
                                statistical analysis and for creation of data ("Statistical
                                Information"), which does not contain individual Customer
                                Information. In addition to the information that the Bank elicits
                                from you, you are free to volunteer any other information that you
                                feel that the Bank needs to know, but the security and
                                confidentiality as per this Policy is guaranteed only to the
                                information that the Bank directly asks from you.{" "}
                              </td>
                            </tr>
                            <tr>
                              <td
                                align="center"
                                valign="top"
                                style={{
                                  fontFamily: "Roboto,sans-serif",
                                  fontSize: "14px",
                                  lineHeight: "24px",
                                  color: "#323232",
                                  textAlign: "left",
                                  paddingBottom: "8px",
                                }}
                              >
                                This Policy holds true for a non-customer who has provided
                                information to the Bank, by any means, with the intentions of
                                establishing a relationship, of whatsoever nature, with the Bank. By
                                divulging any information to us, you agree to the terms and
                                conditions of this Policy.{" "}
                              </td>
                            </tr>
                            <tr>
                              <td
                                align="center"
                                valign="top"
                                style={{
                                  fontFamily: "Roboto,sans-serif",
                                  fontSize: "14px",
                                  lineHeight: "24px",
                                  color: "#323232",
                                  textAlign: "left",
                                  paddingBottom: "8px",
                                }}
                              >
                                <strong>
                                  Use of Customer Information / Statistical Information{" "}
                                </strong>
                              </td>
                            </tr>
                            <tr>
                              <td
                                align="center"
                                valign="top"
                                style={{
                                  fontFamily: "Roboto,sans-serif",
                                  fontSize: "14px",
                                  lineHeight: "24px",
                                  color: "#323232",
                                  textAlign: "left",
                                  paddingBottom: "10px",
                                }}
                              >
                                We may use the Customer Information for, among other things,
                                customer verification, provision of products and services, for
                                personalisation of products or services, marketing or promotion of
                                our financial services or related products or that of our associates
                                and affiliates; for creation of Statistical Information, statistical
                                analysis or credit scoring, enforcement of your obligations, any
                                other purpose that will help us in providing you with optimal and
                                high quality services.{" "}
                              </td>
                            </tr>
                            <tr>
                              <td
                                align="center"
                                valign="top"
                                style={{
                                  fontFamily: "Roboto,sans-serif",
                                  fontSize: "14px",
                                  lineHeight: "24px",
                                  color: "#323232",
                                  textAlign: "left",
                                  paddingBottom: "8px",
                                }}
                              >
                                <strong>Security </strong>
                              </td>
                            </tr>
                            <tr>
                              <td
                                align="center"
                                valign="top"
                                style={{
                                  fontFamily: "Roboto,sans-serif",
                                  fontSize: "14px",
                                  lineHeight: "24px",
                                  color: "#323232",
                                  textAlign: "left",
                                  paddingBottom: "10px",
                                }}
                              >
                                We have taken reasonable measures to protect security and
                                confidentiality of the Customer Information and its transmission
                                through the World Wide Web. You are required to follow the Terms and
                                Conditions while using this Website including the instructions
                                stated therein in respect of security and confidentiality of your
                                Log-in and Password.{" "}
                              </td>
                            </tr>
                            <tr>
                              <td
                                align="center"
                                valign="top"
                                style={{
                                  fontFamily: "Roboto,sans-serif",
                                  fontSize: "14px",
                                  lineHeight: "24px",
                                  color: "#323232",
                                  textAlign: "left",
                                  paddingBottom: "8px",
                                }}
                              >
                                <strong> Disclosure </strong>
                              </td>
                            </tr>
                            <tr>
                              <td align="center" valign="top">
                                <table
                                  width="560"
                                  align="center"
                                  border="0"
                                  cellpadding="0"
                                  cellspacing="0"
                                >
                                  <tr>
                                    <td align="center" valign="top" width="20">
                                      &bull;
                                    </td>
                                    <td
                                      align="center"
                                      valign="top"
                                      style={{
                                        fontFamily: "Roboto,sans-serif",
                                        fontSize: "14px",
                                        lineHeight: "24px",
                                        color: "#323232",
                                        textAlign: "left",
                                        paddingBottom: "10px",
                                      }}
                                    >
                                      We shall not be held liable for disclosure of the Customer
                                      Information or Statistical Information in accordance with this
                                      Privacy Commitment or in terms of any other agreements with
                                      you.
                                    </td>
                                  </tr>
                                </table>
                              </td>
                            </tr>
                            <tr>
                              <td align="center" valign="top">
                                <table
                                  width="560"
                                  align="center"
                                  border="0"
                                  cellpadding="0"
                                  cellspacing="0"
                                >
                                  <tr>
                                    <td align="center" valign="top" width="20">
                                      &bull;
                                    </td>
                                    <td
                                      align="center"
                                      valign="top"
                                      style={{
                                        fontFamily: "Roboto,sans-serif",
                                        fontSize: "14px",
                                        lineHeight: "24px",
                                        color: "#323232",
                                        textAlign: "left",
                                        paddingBottom: "10px",
                                      }}
                                    >
                                      We may disclose the Statistical Information to any person,
                                      without any limitation and you hereby give your consent for
                                      the same.
                                    </td>
                                  </tr>
                                </table>
                              </td>
                            </tr>
                            <tr>
                              <td align="center" valign="top">
                                <table
                                  width="560"
                                  align="center"
                                  border="0"
                                  cellpadding="0"
                                  cellspacing="0"
                                >
                                  <tr>
                                    <td align="center" valign="top" width="20">
                                      &bull;
                                    </td>
                                    <td
                                      align="center"
                                      valign="top"
                                      style={{
                                        fontFamily: "Roboto,sans-serif",
                                        fontSize: "14px",
                                        lineHeight: "24px",
                                        color: "#323232",
                                        textAlign: "left",
                                        paddingBottom: "10px",
                                      }}
                                    >
                                      We may disclose Customer Information to any of our associates
                                      and affiliates, without any limitation and you hereby give
                                      your consent for the same.
                                    </td>
                                  </tr>
                                </table>
                              </td>
                            </tr>
                            <tr>
                              <td align="center" valign="top">
                                <table
                                  width="560"
                                  align="center"
                                  border="0"
                                  cellpadding="0"
                                  cellspacing="0"
                                >
                                  <tr>
                                    <td align="center" valign="top" width="20">
                                      &bull;
                                    </td>
                                    <td
                                      align="center"
                                      valign="top"
                                      style={{
                                        fontFamily: "Roboto,sans-serif",
                                        fontSize: "14px",
                                        lineHeight: "24px",
                                        color: "#323232",
                                        textAlign: "left",
                                        paddingBottom: "10px",
                                      }}
                                    >
                                      We may disclose the Customer Information to third parties for
                                      following, among other purposes, and will make reasonable
                                      efforts to bind them to obligation to keep the same secure and
                                      confidential and an obligation to use the information for the
                                      purpose for which the same is disclosed, and you hereby give
                                      your consent for the same: -
                                    </td>
                                  </tr>
                                </table>
                              </td>
                            </tr>
                            <tr>
                              <td align="center" valign="top">
                                <table
                                  width="560"
                                  align="center"
                                  border="0"
                                  cellpadding="0"
                                  cellspacing="0"
                                >
                                  <tr>
                                    <td align="center" valign="top" width="20">
                                      &bull;
                                    </td>
                                    <td
                                      align="center"
                                      valign="top"
                                      style={{
                                        fontFamily: "Roboto,sans-serif",
                                        fontSize: "14px",
                                        lineHeight: "24px",
                                        color: "#323232",
                                        textAlign: "left",
                                        paddingBottom: "10px",
                                      }}
                                    >
                                      For advertising. or
                                    </td>
                                  </tr>
                                </table>
                              </td>
                            </tr>
                            <tr>
                              <td align="center" valign="top">
                                <table
                                  width="560"
                                  align="center"
                                  border="0"
                                  cellpadding="0"
                                  cellspacing="0"
                                >
                                  <tr>
                                    <td align="center" valign="top" width="20">
                                      &bull;
                                    </td>
                                    <td
                                      align="center"
                                      valign="top"
                                      style={{
                                        fontFamily: "Roboto,sans-serif",
                                        fontSize: "14px",
                                        lineHeight: "24px",
                                        color: "#323232",
                                        textAlign: "left",
                                        paddingBottom: "10px",
                                      }}
                                    >
                                      For facilitating joint product promotion campaigns. or
                                    </td>
                                  </tr>
                                </table>
                              </td>
                            </tr>
                            <tr>
                              <td align="center" valign="top">
                                <table
                                  width="560"
                                  align="center"
                                  border="0"
                                  cellpadding="0"
                                  cellspacing="0"
                                >
                                  <tr>
                                    <td align="center" valign="top" width="20">
                                      &bull;
                                    </td>
                                    <td
                                      align="center"
                                      valign="top"
                                      style={{
                                        fontFamily: "Roboto,sans-serif",
                                        fontSize: "14px",
                                        lineHeight: "24px",
                                        color: "#323232",
                                        textAlign: "left",
                                        paddingBottom: "10px",
                                      }}
                                    >
                                      We may disclose the Customer Information, to third parties,
                                      without limitation, for the following reasons;
                                    </td>
                                  </tr>
                                </table>
                              </td>
                            </tr>
                            <tr>
                              <td align="center" valign="top">
                                <table
                                  width="560"
                                  align="center"
                                  border="0"
                                  cellpadding="0"
                                  cellspacing="0"
                                >
                                  <tr>
                                    <td align="center" valign="top" width="20">
                                      &bull;
                                    </td>
                                    <td
                                      align="center"
                                      valign="top"
                                      style={{
                                        fontFamily: "Roboto,sans-serif",
                                        fontSize: "14px",
                                        lineHeight: "24px",
                                        color: "#323232",
                                        textAlign: "left",
                                        paddingBottom: "10px",
                                      }}
                                    >
                                      To comply with legal requirements, legal process, legal or
                                      regulatory directive/instruction. or
                                    </td>
                                  </tr>
                                </table>
                              </td>
                            </tr>
                            <tr>
                              <td align="center" valign="top">
                                <table
                                  width="560"
                                  align="center"
                                  border="0"
                                  cellpadding="0"
                                  cellspacing="0"
                                >
                                  <tr>
                                    <td align="center" valign="top" width="20">
                                      &bull;
                                    </td>
                                    <td
                                      align="center"
                                      valign="top"
                                      style={{
                                        fontFamily: "Roboto,sans-serif",
                                        fontSize: "14px",
                                        lineHeight: "24px",
                                        color: "#323232",
                                        textAlign: "left",
                                        paddingBottom: "10px",
                                      }}
                                    >
                                      To enforce the Terms and Conditions of the products or
                                      services. or
                                    </td>
                                  </tr>
                                </table>
                              </td>
                            </tr>
                            <tr>
                              <td align="center" valign="top">
                                <table
                                  width="560"
                                  align="center"
                                  border="0"
                                  cellpadding="0"
                                  cellspacing="0"
                                >
                                  <tr>
                                    <td align="center" valign="top" width="20">
                                      &bull;
                                    </td>
                                    <td
                                      align="center"
                                      valign="top"
                                      style={{
                                        fontFamily: "Roboto,sans-serif",
                                        fontSize: "14px",
                                        lineHeight: "24px",
                                        color: "#323232",
                                        textAlign: "left",
                                        paddingBottom: "10px",
                                      }}
                                    >
                                      To protect or defend our rights, interests and property or
                                      that of our associates and affiliates, or that of our or our
                                      Affiliate's employees, consultants etc. or
                                    </td>
                                  </tr>
                                </table>
                              </td>
                            </tr>
                            <tr>
                              <td align="center" valign="top">
                                <table
                                  width="560"
                                  align="center"
                                  border="0"
                                  cellpadding="0"
                                  cellspacing="0"
                                >
                                  <tr>
                                    <td align="center" valign="top" width="20">
                                      &bull;
                                    </td>
                                    <td
                                      align="center"
                                      valign="top"
                                      style={{
                                        fontFamily: "Roboto,sans-serif",
                                        fontSize: "14px",
                                        lineHeight: "24px",
                                        color: "#323232",
                                        textAlign: "left",
                                        paddingBottom: "10px",
                                      }}
                                    >
                                      For fraud prevention purposes. or
                                    </td>
                                  </tr>
                                </table>
                              </td>
                            </tr>
                            <tr>
                              <td align="center" valign="top">
                                <table
                                  width="560"
                                  align="center"
                                  border="0"
                                  cellpadding="0"
                                  cellspacing="0"
                                >
                                  <tr>
                                    <td align="center" valign="top" width="20">
                                      &bull;
                                    </td>
                                    <td
                                      align="center"
                                      valign="top"
                                      style={{
                                        fontFamily: "Roboto,sans-serif",
                                        fontSize: "14px",
                                        lineHeight: "24px",
                                        color: "#323232",
                                        textAlign: "left",
                                        paddingBottom: "10px",
                                      }}
                                    >
                                      As permitted or required by law.
                                    </td>
                                  </tr>
                                </table>
                              </td>
                            </tr>
                            <tr>
                              <td align="center" valign="top">
                                <table
                                  width="560"
                                  align="center"
                                  border="0"
                                  cellpadding="0"
                                  cellspacing="0"
                                >
                                  <tr>
                                    <td align="center" valign="top" width="20">
                                      &bull;
                                    </td>
                                    <td
                                      align="center"
                                      valign="top"
                                      style={{
                                        fontFamily: "Roboto,sans-serif",
                                        fontSize: "14px",
                                        lineHeight: "24px",
                                        color: "#323232",
                                        textAlign: "left",
                                        paddingBottom: "10px",
                                      }}
                                    >
                                      For participation in any telecommunication or electronic
                                      clearing network. or
                                    </td>
                                  </tr>
                                </table>
                              </td>
                            </tr>
                            <tr>
                              <td align="center" valign="top">
                                <table
                                  width="560"
                                  align="center"
                                  border="0"
                                  cellpadding="0"
                                  cellspacing="0"
                                >
                                  <tr>
                                    <td align="center" valign="top" width="20">
                                      &bull;
                                    </td>
                                    <td
                                      align="center"
                                      valign="top"
                                      style={{
                                        fontFamily: "Roboto,sans-serif",
                                        fontSize: "14px",
                                        lineHeight: "24px",
                                        color: "#323232",
                                        textAlign: "left",
                                        paddingBottom: "10px",
                                      }}
                                    >
                                      For participation in any telecommunication or electronic
                                      clearing network. or
                                    </td>
                                  </tr>
                                </table>
                              </td>
                            </tr>
                            <tr>
                              <td align="center" valign="top">
                                <table
                                  width="560"
                                  align="center"
                                  border="0"
                                  cellpadding="0"
                                  cellspacing="0"
                                >
                                  <tr>
                                    <td align="center" valign="top" width="20">
                                      &bull;
                                    </td>
                                    <td
                                      align="center"
                                      valign="top"
                                      style={{
                                        fontFamily: "Roboto,sans-serif",
                                        fontSize: "14px",
                                        lineHeight: "24px",
                                        color: "#323232",
                                        textAlign: "left",
                                        paddingBottom: "10px",
                                      }}
                                    >
                                      For availing of the support services from third parties e.g.
                                      collecting subscription fees, and notifying or contacting you
                                      regarding any problem with, or the expiration of, any services
                                      availed by you.
                                    </td>
                                  </tr>
                                </table>
                              </td>
                            </tr>
                            <tr>
                              <td align="center" valign="top">
                                <table
                                  width="560"
                                  align="center"
                                  border="0"
                                  cellpadding="0"
                                  cellspacing="0"
                                >
                                  <tr>
                                    <td align="center" valign="top" width="20">
                                      &bull;
                                    </td>
                                    <td
                                      align="center"
                                      valign="top"
                                      style={{
                                        fontFamily: "Roboto,sans-serif",
                                        fontSize: "14px",
                                        lineHeight: "24px",
                                        color: "#323232",
                                        textAlign: "left",
                                        paddingBottom: "10px",
                                      }}
                                    >
                                      For the purposes of credit reporting, verification and risk
                                      management to/with clearing house centers or credit
                                      information bureau and the like.
                                    </td>
                                  </tr>
                                </table>
                              </td>
                            </tr>
                            <tr>
                              <td align="center" valign="top">
                                <table
                                  width="560"
                                  align="center"
                                  border="0"
                                  cellpadding="0"
                                  cellspacing="0"
                                >
                                  <tr>
                                    <td align="center" valign="top" width="20">
                                      &bull;
                                    </td>
                                    <td
                                      align="center"
                                      valign="top"
                                      style={{
                                        fontFamily: "Roboto,sans-serif",
                                        fontSize: "14px",
                                        lineHeight: "24px",
                                        color: "#323232",
                                        textAlign: "left",
                                        paddingBottom: "10px",
                                      }}
                                    >
                                      For sharing with third-parties information obtained with your
                                      consent, from your mobile device like device location, device
                                      information (including storage, model, installed apps, Wi-Fi,
                                      mobile network) transactional and promotional SMS,
                                      communication information including contacts and call logs,
                                      for statistical modelling, credit scoring and any other
                                      purpose that will help us in providing you with optimal and
                                      high quality services.
                                    </td>
                                  </tr>
                                </table>
                              </td>
                            </tr>
                            <tr>
                              <td
                                align="center"
                                valign="top"
                                style={{
                                  fontFamily: "Roboto,sans-serif",
                                  fontSize: "14px",
                                  lineHeight: "24px",
                                  color: "#323232",
                                  textAlign: "left",
                                  paddingBottom: "8px",
                                }}
                              >
                                <strong> Grievances </strong>
                              </td>
                            </tr>
                            <tr>
                              <td
                                align="center"
                                valign="top"
                                style={{
                                  fontFamily: "Roboto,sans-serif",
                                  fontSize: "14px",
                                  lineHeight: "24px",
                                  color: "#323232",
                                  textAlign: "left",
                                  paddingBottom: "10px",
                                }}
                              >
                                For discrepancies and grievances pertaining to processing of
                                Information, you shall get in touch with our Grievance Officer, Ms.
                                M. Raju at 
                                <a
                                  href="mailto:nodalofficer@kotak.com"
                                  target="_blank"
                                  style={{ textDecoration: "none", color: "#E32631" }}
                                >
                                  <strong>nodalofficer@kotak.com.</strong>
                                </a>
                              </td>
                            </tr>
                            <tr>
                              <td
                                align="center"
                                valign="top"
                                style={{
                                  fontFamily: "Roboto,sans-serif",
                                  fontSize: "14px",
                                  lineHeight: "24px",
                                  color: "#323232",
                                  textAlign: "left",
                                  paddingBottom: "8px",
                                }}
                              >
                                <strong> Cookie Policy </strong>
                              </td>
                            </tr>
                            <tr>
                              <td
                                align="center"
                                valign="top"
                                style={{
                                  fontFamily: "Roboto,sans-serif",
                                  fontSize: "14px",
                                  lineHeight: "24px",
                                  color: "#323232",
                                  textAlign: "left",
                                  paddingBottom: "10px",
                                }}
                              >
                                A cookie is a simple text file that is stored on your computer or
                                mobile device by a website’s server and only that server will be
                                able to retrieve or read the contents of that cookie. Every cookie
                                is unique to your particular web browser. It will contain some
                                anonymous information such as a unique identifier and the site name
                                with some digits and numbers. It allows the website to remember your
                                browsing behaviour &amp; show you relevant ads based on the browsing
                                pattern. The cookies also allow the website to limit the number of
                                ads shown.{" "}
                              </td>
                            </tr>
                            <tr>
                              <td
                                align="center"
                                valign="top"
                                style={{
                                  fontFamily: "Roboto,sans-serif",
                                  fontSize: "14px",
                                  lineHeight: "24px",
                                  color: "#323232",
                                  textAlign: "left",
                                  paddingBottom: "8px",
                                }}
                              >
                                <strong> How does Kotak.com use Cookies? </strong>
                              </td>
                            </tr>
                            <tr>
                              <td
                                align="center"
                                valign="top"
                                style={{
                                  fontFamily: "Roboto,sans-serif",
                                  fontSize: "14px",
                                  lineHeight: "24px",
                                  color: "#323232",
                                  textAlign: "left",
                                  paddingBottom: "8px",
                                }}
                              >
                                Kotak.com uses cookies to capture following information –
                              </td>
                            </tr>
                            <tr>
                              <td align="center" valign="top">
                                <table
                                  width="560"
                                  align="center"
                                  border="0"
                                  cellpadding="0"
                                  cellspacing="0"
                                >
                                  <tr>
                                    <td align="center" valign="top" width="20">
                                      &bull;
                                    </td>
                                    <td
                                      align="center"
                                      valign="top"
                                      style={{
                                        fontFamily: "Roboto,sans-serif",
                                        fontSize: "14px",
                                        lineHeight: "24px",
                                        color: "#323232",
                                        textAlign: "left",
                                        paddingBottom: "10px",
                                      }}
                                    >
                                      Source of visit to the website
                                    </td>
                                  </tr>
                                </table>
                              </td>
                            </tr>
                            <tr>
                              <td align="center" valign="top">
                                <table
                                  width="560"
                                  align="center"
                                  border="0"
                                  cellpadding="0"
                                  cellspacing="0"
                                >
                                  <tr>
                                    <td align="center" valign="top" width="20">
                                      &bull;
                                    </td>
                                    <td
                                      align="center"
                                      valign="top"
                                      style={{
                                        fontFamily: "Roboto,sans-serif",
                                        fontSize: "14px",
                                        lineHeight: "24px",
                                        color: "#323232",
                                        textAlign: "left",
                                        paddingBottom: "10px",
                                      }}
                                    >
                                      Time spent on the website
                                    </td>
                                  </tr>
                                </table>
                              </td>
                            </tr>
                            <tr>
                              <td align="center" valign="top">
                                <table
                                  width="560"
                                  align="center"
                                  border="0"
                                  cellpadding="0"
                                  cellspacing="0"
                                >
                                  <tr>
                                    <td align="center" valign="top" width="20">
                                      &bull;
                                    </td>
                                    <td
                                      align="center"
                                      valign="top"
                                      style={{
                                        fontFamily: "Roboto,sans-serif",
                                        fontSize: "14px",
                                        lineHeight: "24px",
                                        color: "#323232",
                                        textAlign: "left",
                                        paddingBottom: "10px",
                                      }}
                                    >
                                      Pages viewed on the website
                                    </td>
                                  </tr>
                                </table>
                              </td>
                            </tr>
                            <tr>
                              <td align="center" valign="top">
                                <table
                                  width="560"
                                  align="center"
                                  border="0"
                                  cellpadding="0"
                                  cellspacing="0"
                                >
                                  <tr>
                                    <td align="center" valign="top" width="20">
                                      &bull;
                                    </td>
                                    <td
                                      align="center"
                                      valign="top"
                                      style={{
                                        fontFamily: "Roboto,sans-serif",
                                        fontSize: "14px",
                                        lineHeight: "24px",
                                        color: "#323232",
                                        textAlign: "left",
                                        paddingBottom: "10px",
                                      }}
                                    >
                                      Ad clicks
                                    </td>
                                  </tr>
                                </table>
                              </td>
                            </tr>
                            <tr>
                              <td
                                align="center"
                                valign="top"
                                style={{
                                  fontFamily: "Roboto,sans-serif",
                                  fontSize: "14px",
                                  lineHeight: "24px",
                                  color: "#323232",
                                  textAlign: "left",
                                  paddingBottom: "10px",
                                }}
                              >
                                In addition to analysing anonymous user behaviour on Kotak.com,
                                aforementioned data also allows us to pre-empt requirements of
                                prospects and existing account holders (by capturing their CRN
                                number) &amp; pitch relevant services through display advertising or
                                tele calling.{" "}
                              </td>
                            </tr>
                            <tr>
                              <td
                                align="center"
                                valign="top"
                                style={{
                                  fontFamily: "Roboto,sans-serif",
                                  fontSize: "14px",
                                  lineHeight: "24px",
                                  color: "#323232",
                                  textAlign: "left",
                                  paddingBottom: "10px",
                                }}
                              >
                                Please note that the scope of this tracking is limited to the
                                kotak.com domain. User activity on other third-party websites is not
                                tracked by Kotak.com cookies.{" "}
                              </td>
                            </tr>
                            <tr>
                              <td
                                align="center"
                                valign="top"
                                style={{
                                  fontFamily: "Roboto,sans-serif",
                                  fontSize: "14px",
                                  lineHeight: "24px",
                                  color: "#323232",
                                  textAlign: "left",
                                  paddingBottom: "8px",
                                }}
                              >
                                <strong> Further information about cookies </strong>
                              </td>
                            </tr>
                            <tr>
                              <td
                                align="center"
                                valign="top"
                                style={{
                                  fontFamily: "Roboto,sans-serif",
                                  fontSize: "14px",
                                  lineHeight: "24px",
                                  color: "#323232",
                                  textAlign: "left",
                                  paddingBottom: "10px",
                                }}
                              >
                                If you’d like to learn more about cookies in general and how to
                                manage them, visit 
                                <a
                                  href="http://www.aboutcookies.org"
                                  target="_blank"
                                  style={{ textDecoration: "none", color: "#E32631" }}
                                >
                                  <strong>www.aboutcookies.org.</strong>
                                </a>{" "}
                              </td>
                            </tr>
                            <tr>
                              <td
                                align="center"
                                valign="top"
                                style={{
                                  fontFamily: "Roboto,sans-serif",
                                  fontSize: "14px",
                                  lineHeight: "24px",
                                  color: "#323232",
                                  textAlign: "left",
                                  paddingBottom: "8px",
                                }}
                              >
                                <strong> Changes to this policy </strong>
                              </td>
                            </tr>
                            <tr>
                              <td
                                align="center"
                                valign="top"
                                style={{
                                  fontFamily: "Roboto,sans-serif",
                                  fontSize: "14px",
                                  lineHeight: "24px",
                                  color: "#323232",
                                  textAlign: "left",
                                  paddingBottom: "10px",
                                }}
                              >
                                The above may change at any time. We will endeavour to notify you of
                                any major changes but you may wish to check it each time you visit
                                our website.{" "}
                              </td>
                            </tr>
                          </table>
                        </td>
                      </tr>
                    </table>
                  </td>
                </tr>
              </table>
            </td>
          </tr>
        </table>
      </body>
    </>
  );
}
