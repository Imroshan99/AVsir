import Menu from "@mui/material/Menu";
import MenuItem from "@mui/material/MenuItem";
import { useEffect, useReducer, useState } from "react";
import { useSelector } from "react-redux";
import { ProfileAPI } from "../../../apis/ProfileAPI";
import { config } from "../../../config";
import useHttp from "../../../hooks/useHttp";
import { Spin } from "antd";
import { NavLink } from "react-router-dom";
import { Link, Outlet, useLocation, useNavigate } from "react-router-dom";

export default function UserMenu(props) {
  const AuthReducer = useSelector((state) => state.user);
  const templateFlow = AuthReducer.groupIdSettings?.kyc?.flow;
  return (
    <>
      <Menu
        anchorEl={props.anchorElUser}
        id="account-menu"
        open={Boolean(props.anchorElUser)}
        onClose={props.handleCloseUserMenu}
        PaperProps={{
          elevation: 0,
          sx: {
            overflow: "visible",
            filter: "drop-shadow(0px 2px 8px rgba(0,0,0,0.32))",
            mt: 1.5,
            "& .MuiAvatar-root": {
              width: 32,
              height: 32,
              ml: -0.5,
              mr: 1,
            },
            "&:before": {
              content: '""',
              display: "block",
              position: "absolute",
              top: 0,
              right: 14,
              width: 10,
              height: 10,
              bgcolor: "background.paper",
              transform: "translateY(-50%) rotate(45deg)",
              zIndex: 0,
            },
          },
        }}
        transformOrigin={{ horizontal: "right", vertical: "top" }}
        anchorOrigin={{ horizontal: "right", vertical: "bottom" }}
      >
        <div className="User-Menu">
          {[
            <MenuItem
              key="menu2"
              onClick={props.handleCloseUserMenu}
              component={Link}
              to={"/my-beneficiary"}
            >
              My Beneficiary
            </MenuItem>,
            <MenuItem
              key="menu3"
              onClick={props.handleCloseUserMenu}
              component={Link}
              to={"/manage-remitter-accounts"}
            >
              Remitter account
            </MenuItem>,
            <MenuItem
              key="menu4"
              onClick={props.handleCloseUserMenu}
              component={Link}
              to={"/profile"}
            >
              Profile
            </MenuItem>,
            <MenuItem
              key="menu5"
              onClick={props.handleCloseUserMenu}
              component={Link}
              to={"/transactions"}
            >
              Transactions
            </MenuItem>,
            <MenuItem
              key="menu6"
              onClick={props.handleCloseUserMenu}
              component={Link}
              to={"/reset-password"}
            >
              Reset Password
            </MenuItem>,
            <MenuItem key="menu6" onClick={props.handleCloseUserMenu} component={Link} to={"/kyc"}>
              KYC
            </MenuItem>,
            <MenuItem
              key="menu7"
              onClick={props.handleCloseUserMenu}
              component={Link}
              to={"/help-support"}
            >
              Help & Support
            </MenuItem>,
            <MenuItem
              key="menu8"
              onClick={props.handleCloseUserMenu}
              component={Link}
              to={"/user-doc-upload"}
            >
              User Doc Upload
            </MenuItem>,
            <MenuItem
              key="menu99"
              onClick={() => props.handleCloseUserMenu("Logout")}
              component={Link}
              to={"/"}
            >
              Logout
            </MenuItem>,
          ]}
        </div>
      </Menu>
    </>
  );
}
