import { useState } from "react";
import { Button } from "antd";

export default function CookiePolicy() {
  const [showMore, setShowMore] = useState(false);

  return (
    <>
      <p>
        Cookies are small text file stored on your computer or internet-enabled
        device when you visit a website. This enables the website to recognise
        you should you re-visit the site at a later date.
      </p>
      <p>
        <strong>How does XMONIES web site use cookies?</strong>
      </p>
      <p>
        When you visit any of our websites, we use cookies to remember
        preferences that you chose when browsing the site in order to provide
        you with the best experience possible and to count and study the
        visitors and patterns of people visiting our site which enable us to
        update and approve our websites based on user behaviour and preferences.
      </p>
      <p>
        <strong>
          Our Site uses the following types of cookies for the purposes set out
          below:
        </strong>
      </p>

      <p>
        <strong>Type of cookie | Purpose</strong>
      </p>
      <p>
        <strong>Essential Cookies</strong>
      </p>
      <p>
        These cookies are essential to provide you with services available
        through our Site and to enable you to use some of its features. For
        example, they allow you to log in to secure areas of our Site and help
        the content of the pages you request load quickly. Without these
        cookies, the services that you have asked for cannot be provided, and we
        only use these cookies to provide you with those services.
      </p>
      {showMore && (
        <div>
          <p>
            <strong>Functionality Cookies</strong>
          </p>
          <p>
            These cookies allow our Site to remember choices you make when you
            use our Site, such as remembering your language preferences,
            remembering your login details and remembering the changes you make
            to other parts of our Site which you can customize. The purpose of
            these cookies is to provide you with a more personal experience and
            to avoid you having to re-enter your preferences every time you
            visit our Site.
          </p>

          <p>
            <strong>Analytics and Performance Cookies</strong>
          </p>
          <p>
            These cookies are used to collect information about traffic to our
            Site and how users use our Site. The information gathered does not
            identify any individual visitor. The information is aggregated and
            anonymous. It includes the number of visitors to our Site, in
            limited circumstances, where we have a relationship with the
            referring site, the websites that referred them to our Site, the
            pages they visited on our Site, what time of day they visited our
            Site, whether they have visited our Site before, and other similar
            information. We use this information to help operate our Site more
            efficiently, to gather broad demographic information and to monitor
            the level of activity on our Site.
          </p>
          <p>
            <strong>Cookie Purpose</strong>
          </p>
          <p>Analytics _fbp: Facebook analytics</p>
          <p>_ga: Google Analytics cookie</p>
          <p>_gat_UA-85995080-5: Google Analytics cookie</p>
          <p>
            _adroll_fpc: analytical cookie used to optimise and analyse website
            performance and is a retargeting network that allows us to show ads
            to visitors who’ve landed on our site while browsing the web
          </p>
          <p>
            _ar_v4: double click advertising Google cookie used to track
            conversion rates
          </p>
          <p>Trustpilot third party cookie uk.trustpilot.com</p>
          <p>
            Functional and Essential Firstaccess: checks to see if this is the
            first time user has accessed portal
          </p>
          <p>
            Firstlogin: checks to see if a user has logged in for the first time
          </p>
          <p>
            PLG: this is a functional cookie that lets us keep the language of
            the user across the site.
          </p>
          <p>
            Lastlogged: cookie that stores the amount of time since a user has
            last logged into the system
          </p>
          <p>
            Affcode: cookie to store the affiliate code from the marketing sites
            affiliate landing pages
          </p>
          <p>
            Campaign: cookie that stores CTA tracking information when a user
            clicks it.
          </p>
          <p>
            sourceTrack: Similar to the campaign cookie except this is for
            Google search tracking
          </p>
          <p>
            subcod: Additional affiliate tracking, e.g. if there is two landing
            pages, identifies which page they came from.
          </p>
          <p>Has_js: checks whether javascript is enabled on browser</p>
          <p>
            Drupal.visitor.fromCountry: checks which country you are accessing
            from and changes the language of the website to your local language
          </p>
          <p>
            Cookie preference Cookieconsent_status: remembers your cookie
            preference Overall, cookies help us provide you with a better
            website, by enabling us to monitor which pages you find useful and
            which you do not. A cookie in no way gives us access to your
            computer or any information about you, other than the data you
            choose to share with us.
          </p>
          <p>
            Further information concerning cookies and how to manage them to
            suit your preferences can be found by visiting www.aboutcookies.org
            or www.allaboutcookies.org.
          </p>
          <p></p>
          <p>
            <strong>
              How can you control the use of cookies from our website?
            </strong>
          </p>

          <p>
            You have the right to turn off cookies before using our website or
            at any time while browsing our Site. You can typically remove or
            reject cookies via your browser settings. In order to do this,
            follow the instructions provided by your browser (usually located
            within the “settings,” “help” “tools” or “edit” facility). Many
            browsers are set to accept cookies until you change your settings.
            However, this may prevent you from taking full advantage of the
            website.
          </p>
        </div>
      )}
      <button
        className="showmore-button"
        onClick={() => setShowMore(!showMore)}
      >
        {showMore ? "View Less" : "View More"}
      </button>
     
    </>
  );
}
