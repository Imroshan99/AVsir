import React from "react";
import { useSelector } from "react-redux";
// import HomeXr from "./XR"
// import HomeKcb from "./KCB"

const ISG = React.lazy(() => import("./ISG"));
const CGPN = React.lazy(() => import("./CGPN"));
const CSB = React.lazy(() => import("./CSB"));

const HomePage = () => {
  const AuthReducer = useSelector((state) => state.user);
  switch (AuthReducer.groupId) {
    case "ISG":
      return <ISG />;
    case "CGPN":
      return <CGPN />;
    case "CSB":
      return <CSB />;
    case "C2R":
      return <CGPN />;
    case "HDFC":
      return <CGPN />;

    default:
      return <div>Home Page not found</div>;
  }
};

export default HomePage;
