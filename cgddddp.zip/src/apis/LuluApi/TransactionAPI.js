import axios from "axios";
import { config } from "../../config";

export const LuluTransactionAPI = {
  createQuote: async (data, token) => {
    var axosConfig = {
      method: "post",
      url: `${config.API_URL}/services/lulu/create-quote`,
      headers: {
        Authorization: `AuthToken ${token}`,
        "Content-Type": "application/json",
      },      
      data: data,
    };
    return await axios(axosConfig);
  },
  confirmTransaction: async (data, token) => {
    var axosConfig = {
      method: "post",
      url: `${config.API_URL}/services/lulu/confirm-transaction`,
      headers: {
        Authorization: `AuthToken ${token}`,
        "Content-Type": "application/json",
      },
      data: data,
    };

    return await axios(axosConfig);
  },
  enquireTransaction: async (data, token) => {
    var axosConfig = {
      method: "post",
      url: `${config.API_URL}/services/lulu/enquire-transaction`,
      headers: {
        Authorization: `AuthToken ${token}`,
        "Content-Type": "application/json",
      },
      data: data,
    };

    return await axios(axosConfig);
  },
};