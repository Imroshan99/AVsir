import axios from "axios";
import { config } from "../../config";

export const ViAmericaJumioAPI = {
  viaJumioInit: async (data, token) => {
    var axosConfig = {
      method: "post",
      url: `${config.API_URL}/services/verification/via-jumio-init`,
      headers: {
        Authorization: `AuthToken ${token}`,
        "Content-Type": "application/json",
      },
      data: data,
    };

    return await axios(axosConfig);
  },
  viaJumioStatus: async (data, token) => {
    var axosConfig = {
      method: "post",
      url: `${config.API_URL}/services/verification/via-jumio-status`,
      headers: {
        Authorization: `AuthToken ${token}`,
        "Content-Type": "application/json",
      },
      data: data,
    };

    return await axios(axosConfig);
  },
};
