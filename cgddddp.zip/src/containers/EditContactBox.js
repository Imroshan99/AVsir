import React, { useState, useEffect } from "react";
import { Form, Input, Select, Modal, notification, Spin } from "antd";
import { config } from "../config";
import { encrypt, decrypt, publickey } from "../helpers/makeHash";
import { Row, Col } from "react-bootstrap";

const { Option } = Select;

export default function EditContactBox(props) {
  const [form] = Form.useForm();
  const [loading, setLoader] = useState(false);

  useEffect(() => {
    form.setFieldsValue({
      mobilePhoneCode: props.state.mobilePhoneCode,
      mobileNo: props.state.mobileNo,
      communicationEmailID: props.state.emailId,
    });
    props.setState({
      editableMobileNo: props.state.mobileNo,
    });
  }, []);

  useEffect(() => {
    if (props.state.senderContactDetailsErrors) {
      let errors = [];
      props.state.senderContactDetailsErrors.forEach((error, i) => {
        let errorData = {
          name: error.field,
          errors: [error.error],
        };
        errors.push(errorData);
      });
      form.setFields(errors);
    } else {
      form.setFields([{ name: "mobileNo", errors: [] }]);
    }
  }, [props.state.senderContactDetailsErrors]);

  const onFinish = (value) => {
    // props.sendOTP("CU", "Edit_Contact");
    if (props.state.twofa === "Y") {
      props.sendOTP("CU", "Edit_Contact");
    } else {
      props.editSenderContactdtls("");
    }
  };

  return (
    <div>
      <Modal
        centered
        title="Contact details"
        visible={props.state._isShowContactEditModel}
        onCancel={() => props.setState({ _isShowContactEditModel: false })}
        footer={null}
      >
        <Form
          form={form}
          onFinish={onFinish}
          initialValues={{ mobileNo: props.state.mobileNo }}
        >
          <div className="d-flex justify-content-center align-items-center">
            <Row className="justify-content-center">
              <Col md={6}>
                <label className="form-label">Country Code</label>
                <Form.Item
                  className="form-item"
                  name="mobilePhoneCode"
                  rules={[
                    {
                      required: true,
                      message: "Please select your Country Code.",
                    },
                  ]}
                >
                  <Select
                    size="large"
                    className="w-100"
                    placeholder="Select Country Code"
                    showSearch
                    onSelect={(v) =>
                      props.setState({ editablemobilePhoneCode: v })
                    }
                  >
                    {props.state.countryPhoneCodes.map((list, i) => {
                      return (
                        <Option key={i} value={list.countryPhoneCode}>
                          {list.countryPhoneCode}
                        </Option>
                      );
                    })}
                  </Select>
                </Form.Item>
              </Col>

              <Col md={6}>
                <label className="form-label">Mobile</label>
                <Form.Item
                  className="form-item"
                  name="mobileNo"
                  rules={[
                    {
                      required: true,
                      message: "Please input your Mobile Number.",
                    },
                    {
                      min: 10,
                      max: 10,
                      message: "Mobile number must be 10 digit.",
                    },
                    {
                      pattern: /^[0-9\b]+$/,
                      message: "Only Numbers allowed",
                    },
                  ]}
                >
                  <Input
                    onChange={(e) =>
                      props.setState({ editableMobileNo: e.target.value })
                    }
                    size="large"
                    placeholder="Enter your Mobile"
                  />
                </Form.Item>
              </Col>

              <Col md={12}>
                <label className="form-label">Communication Email ID</label>
                <Form.Item
                  className="form-item"
                  name="communicationEmailID"
                  rules={[
                    {
                      required: true,
                      message: "Please input your Communication Email ID.",
                    },
                    {
                      type: "email",
                      message: "Please input your valid email.",
                    },
                  ]}
                >
                  <Input
                    size="large"
                    placeholder="Enter your Communication Email ID"
                    onChange={(e)=>props.setState({emailId:e.target.value})}
                  />
                </Form.Item>
              </Col>

              <Spin spinning={loading} delay={500}>
                <div className="d-grid gap-2 d-flex justify-content-between mt-4">
                  <button
                    className="btn btn-danger btn-block btn-sm px-4"
                    onClick={() =>
                      props.setState({ _isShowContactEditModel: false })
                    }
                    type="button"
                  >
                    Cancel
                  </button>
                  <button className="btn btn-primary btn-sm text-white px-4 btn-sm">
                    Submit
                  </button>
                </div>
              </Spin>
            </Row>
          </div>
        </Form>
      </Modal>
    </div>
  );
}
