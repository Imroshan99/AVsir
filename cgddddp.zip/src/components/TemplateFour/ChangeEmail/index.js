import { useSelector } from "react-redux";
import Dashboard from "../Layouts/Dashboard";
import ChangeEmailFlowOne from "./ChangeEmailFlowOne/ChangeEmailFlowOne";
import { useOutletContext } from "react-router-dom";
import { useEffect } from "react";
const ChangeEmail = (props) => {
  const { setTitle } = useOutletContext();
  const AuthReducer = useSelector((state) => state.user);
  const temp = AuthReducer.groupIdSettings?.theme?.SIGN;
  const templateFlow = AuthReducer.groupIdSettings?.changeEmail?.flow;

  useEffect(() => {
    setTitle("Change Email");
  }, []);
  return (
    <>
      {templateFlow === "FLOW1" && (
        <ChangeEmailFlowOne
          appState={props.appState}
          manageAuth={props.manageAuth}
        />
      )}
      {templateFlow === "FLOW2" && (
        <ChangeEmailFlowOne
          appState={props.appState}
          manageAuth={props.manageAuth}
        />
      )}
    </>
  );
};

export default ChangeEmail;
