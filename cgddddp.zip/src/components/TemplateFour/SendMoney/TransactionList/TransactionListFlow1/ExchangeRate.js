import React, { useEffect, useReducer, useState } from "react";
import { useSelector } from "react-redux";
import { GuestAPI } from "../../../../../apis/GuestAPI";
import { Form, Input, Select, notification, Spin, Space, Radio } from "antd";
import useHttp from "../../../../../hooks/useHttp";

const { Option } = Select;

const exchangeRateOptions = [
  { code: "FER", name: "From Bank" },
  { code: "FERINST", name: "From Payment Gateway" },
];

const senderCountryList = [{ code: "GB", name: "United Kingdom" }];

const receiverCountryList = [{ code: "IN", name: "India" }];

const ExchangeRate = (props) => {
  const ConfigReducer = useSelector((state) => state.user);
  const AuthReducer = useSelector((state) => state.user);
  const [rateLoader, setRateLoader] = React.useState(false);
  const [form] = Form.useForm();

  const defaultSettings = ConfigReducer.groupIdSettings.default;
  const [timeoutId, setTimeoutId] = React.useState("");
  const [amount, setAmount] = useState({
    sendAmount: 1000,
    recvAmount: 0,
  });

  const [state, setState] = useReducer(
    (state, newState) => ({ ...state, ...newState }),
    {
      clientId: ConfigReducer.clientId,
      groupId: ConfigReducer.groupId,
      twofa: ConfigReducer.twofa,
      sessionId: ConfigReducer.sessionId,
      sendModeCode: defaultSettings.sendModeCode,
      programCode: defaultSettings.programCode,
      totalFee: 0,
      serviceCharge: 0,
      exRate: 0,
      amountPayable: 0,
      expectedDeliveryDate: "",
      transferFee: "",
      serviceCharge: "",
      tax: "",
    }
  );

  const hookPostExchangeRate = useHttp(GuestAPI.postExchangeRate);

  useEffect(() => {
    form.setFieldsValue({
      exchangePromgramCode: "FER",
      senderCountry: "GB",
      receiverCountry: "IN",
    });
    loadExhangeRateHandler(1000, AuthReducer.sendCurrencyCode, "FER");
  }, []);

  // useEffect(() => {
  //   loadExhangeRateHandler(1000, AuthReducer.sendCurrencyCode, "FER");
  // }, [state.programCode]);

  const loadExhangeRateHandler = (valueSendAmount, __currency, prgmCode) => {
    let payload = {
      requestType: "EXCHANGERATE",
      pageName: "PRELOGIN",
      amount: valueSendAmount,
      recvNickName: "NEWRECV_SB",
      recvModeCode: "DC",
      // sendModeCode: "ACH",
      sendModeCode: state.sendModeCode,
      programCode: prgmCode,
      paymentMode1: "",
      paymentMode2: "",
      promoCode: "",
      loyaltyPoints: "",
      recvCountryCode: AuthReducer.recvCountryCode,
      recvCurrencyCode: AuthReducer.recvCurrencyCode,
      sendCountryCode: AuthReducer.sendCountryCode,
      sendCurrencyCode: AuthReducer.sendCurrencyCode,
      // enteredAmtCurrency: "GBP",
      enteredAmtCurrency: __currency,
    };
    setRateLoader(true);
    hookPostExchangeRate.sendRequest(payload, function (data) {
      setRateLoader(false);
      if (data.status == "S") {
        let expectedDeliveryDateStr = data.expectedDeliveryDate;
        let expectedDeliveryDate = expectedDeliveryDateStr.substring(
          0,
          expectedDeliveryDateStr.lastIndexOf(" ") + 1
        );

        setAmount({
          ...amount,
          sendAmount:
            __currency === "GBP" ? data.enteredAmount : data.amountPayable,
          recvAmount:
            __currency === "INR" ? data.enteredAmount : data.recvAmount,
        });
        form.setFieldsValue({
          sendAmount:
            __currency === "GBP" ? data.enteredAmount : data.amountPayable,
          recvAmount:
            __currency === "INR" ? data.enteredAmount : data.recvAmount,
        });
        setState({
          // sendAmount: data.sendAmount,
          // recvAmount: data.recvAmount,
          amountPayable: data.sendAmount,
          totalFee: data.totalFee,
          serviceCharge: data.serviceCharge,
          exRate: data.exRate,
          expectedDeliveryDate: expectedDeliveryDate,

          transferFee: data.totalFee,
          serviceCharge: data.serviceCharge,
          tax: data.serviceTax,
        });
      } else {
        if (data.errorList) {
          notification.error({ message: data.errorList[0].error });
        } else {
          notification.error({ message: data.errorMessage });
        }
        setAmount({
          ...amount,
          recvAmount: 0,
        });
        setState({
          totalFee: 0,
          exRate: 0,
        });
      }
    });
  };

  const sendAmountHandler = (e, __currency) => {
    // setState({ sendAmount: e.target.value })
    clearTimeout(timeoutId);
    if (e.target.value) {
      setAmount({
        ...amount,
        sendAmount: e.target.value,
        // recvAmount: e.target.value,
      });

      const valueSendAmount = e.target.value;
      let valueTimeOutId = setTimeout(
        () =>
          loadExhangeRateHandler(
            valueSendAmount,
            __currency,
            state.programCode
          ),
        500
      );
      setTimeoutId(valueTimeOutId);
    } else {
      setAmount({
        ...amount,
        sendAmount: "",
        recvAmount: "",
      });
    }
  };

  const recvAmountHandler = (e) => {
    clearTimeout(timeoutId);
    if (e.target.value) {
      setAmount({
        ...amount,
        // sendAmount: e.target.value,
        recvAmount: e.target.value,
      });

      const valueSendAmount = e.target.value;
      let valueTimeOutId = setTimeout(
        () => loadExhangeRateHandler(valueSendAmount, "INR", state.programCode),
        500
      );
      setTimeoutId(valueTimeOutId);
    } else {
      setAmount({
        ...amount,
        recvAmount: "",
        sendAmount: "",
      });
    }
  };

  const handleChangeRadio = (e) => {
    const prgmCode = e.target.value;
    loadExhangeRateHandler(
      amount.sendAmount,
      AuthReducer.sendCurrencyCode,
      prgmCode
    );
    setState({ programCode: prgmCode });
  };

  const handleSenderCountry = (data) => {
    console.log("data", data);
  };

  const handleReceivingCountry = (data) => {
    console.log("data", data);
  };

  return (
    <div className="main">
      <Form form={form}>
        <div className="container sendmoney__page py-3">
          <div className="row my-5 ">
            <div className="col-12 col-md-6">
              <Form.Item
                className="form-item"
                name="exchangePromgramCode"
                rules={[
                  {
                    required: true,
                    message: "Please select your transfer options.",
                  },
                ]}
              >
                <Radio.Group
                  // value=""
                  onChange={handleChangeRadio}
                >
                  <Space direction="horizontal">
                    {exchangeRateOptions.map((clist, i) => {
                      return (
                        <Radio key={i} value={clist.code}>
                          {clist.name}
                        </Radio>
                      );
                    })}
                  </Space>
                </Radio.Group>
              </Form.Item>
            </div>
            <div className="col-12 col-md-6">
              <p className="text-info text-end">
                Exchange Rate : {state.exRate} {AuthReducer.recvCurrencyCode}
              </p>
            </div>
            <div></div>

            {/* left */}
            <div className="col-12 col-md-5">
              <div className="row">
                <div className="col-12 col-md-6">
                  <Form.Item
                    className="form-item"
                    name="senderCountry"
                    rules={[
                      {
                        required: true,
                        message: "Please select sender country.",
                      },
                    ]}
                  >
                    <Select
                      size="large"
                      className="w-100"
                      placeholder="Select Sender Country"
                      onChange={handleSenderCountry}
                    >
                      {senderCountryList.map((clist, i) => {
                        return (
                          <Option key={i} value={clist.code}>
                            <div className="d-flex align-items-center">
                              <img
                                src={require("../../../../../assets/images/flags/GB.png")}
                                height={"24px"}
                                className="me-2"
                              />
                              <span>{clist.name}</span>
                            </div>
                          </Option>
                        );
                      })}
                    </Select>
                  </Form.Item>
                </div>
                <div className="col-12 col-md-6 d-flex justify-content-start">
                  <Form.Item
                    name="sendAmount"
                    className="w-100"
                    rules={[
                      {
                        required: true,
                        message: "Please input your amount.",
                      },
                    ]}
                  >
                    <Input
                      size="large"
                      className="exchange_amount_input"
                      addonBefore="GBP"
                      type="text"
                      defaultValue={amount.sendAmount}
                      value={amount.sendAmount}
                      onChange={(e) =>
                        sendAmountHandler(e, AuthReducer.sendCurrencyCode)
                      }
                    />
                  </Form.Item>
                </div>
              </div>
            </div>

            {/* RIGHT  */}
            <div className="col-12 col-md-1 text-light text-center mb-3 mb-md-0">
              to
            </div>
            <div className="col-12 col-md-5">
              <div className="row">
                <div className="col-12 col-md-6">
                  <Form.Item
                    className="form-item"
                    name="receiverCountry"
                    rules={[
                      {
                        required: true,
                        message: "Please select receiver country.",
                      },
                    ]}
                  >
                    <Select
                      size="large"
                      className="w-100"
                      placeholder="Select Receiver Country"
                      onChange={handleReceivingCountry}
                    >
                      {receiverCountryList.map((clist, i) => {
                        return (
                          <Option key={i} value={clist.code}>
                            <div className="d-flex align-items-center">
                              <img
                                src={require("../../../../../assets/images/flags/IN.png")}
                                height={"24px"}
                                className="me-2"
                              />
                              <span>{clist.name}</span>
                            </div>
                          </Option>
                        );
                      })}
                    </Select>
                  </Form.Item>
                </div>
                <div className="col-12 col-md-6 d-flex justify-content-start">
                  <Form.Item
                    name="recvAmount"
                    className="w-100"
                    rules={[
                      {
                        required: true,
                        message: "Please input your amount.",
                      },
                    ]}
                  >
                    <Input
                      size="large"
                      className="exchange_amount_input"
                      addonBefore="INR"
                      type="text"
                      defaultValue={amount.recvAmount}
                      value={amount.recvAmount}
                      onChange={(e) => recvAmountHandler(e)}
                    />
                  </Form.Item>
                </div>
              </div>
            </div>
            {/* bottom */}
            {/* <div className="col-12 col-md-6 text-light mt-3">
              <div className="row">
                <div className="col-7 py-2 px-3">Transfer Fee :</div>
                <div className="col-5 py-2 px-3">
                  {AuthReducer.sendCurrencyCode} {state.transferFee}
                </div>
              </div>
              <div className="row">
                <div className="col-7 py-2 px-3">Service Charge :</div>
                <div className="col-5 py-2 px-3">
                  {AuthReducer.recvCurrencyCode} {state.serviceCharge}
                </div>
              </div>
              <div className="row">
                <div className="col-7 py-2 px-3">Tax :</div>
                <div className="col-5 py-2 px-3">
                  {AuthReducer.recvCurrencyCode} {state.tax}
                </div>
              </div>
            </div> */}
          </div>
        </div>
      </Form>
    </div>
  );
};

export default ExchangeRate;
