import { Route } from "react-router-dom";
import Dashboard from "../Layouts/Dashboard";

import SendMoney from "./../SendMoney/index";
import RecipientList from "./../RecipientList";
import AddRecipient from "./../AddRecipient/index";

import EditRecipient from "./../EditRecipient";
import BankAccountList from "./../BankAccounts/BankAccountList";
import AddBankAccount from "./../BankAccounts/AddBankAccount";
import TransactionList from "./../SendMoney/TransactionList";

import RepeatTranscation from "./../RepeatTranscation";
import Kyc from "./../Kyc";
import Profile from "./../Profile";
import ChangePassword from "./../Change Password";
import ChangeEmail from "./../ChangeEmail";
import TrackTransfer from "./../TrackTransfer";
import UploadAdditonalDoc from "./../UploadAdditonalDoc";

import Contact from "./../Contact";
import Feedback from "./../Feedback";
import RaiseIssue from "./../RaiseAnIssue";
import { PrivateRoute } from "../../../Routes/PrivateRoute";
import { useSelector } from "react-redux";
import PageNotFound from "../PageNotFound";
import RequestMoney from "../RequestMoney";
import RecipientRequestList from "../RequestMoney/RequestMoneyFlowOne/RecipientRequestList";
import PlaidFail from "../PlaidPages/PlaidFail";
import PlaidSuccess from "../PlaidPages/PlaidSuccess";
import JumioFail from "../../JumioPages/JumioFail";
import JumioSuccess from "../../JumioPages/JumioSuccess";

const DashboardRoutes = (state, manageAuth) => {
  const AuthReducer = useSelector((state) => state.user);
  const aciveEmail = AuthReducer.groupIdSettings?.title;
  const aciveContact = AuthReducer.groupIdSettings?.contact?.acive;
  const aciveFeedback = AuthReducer.groupIdSettings?.feedback?.acive;
  const aciveRaiseIssue = AuthReducer.groupIdSettings?.raiseIssue?.acive;
  return (
    <Route element={<Dashboard />}>
      <Route
        path="/new-transaction"
        element={
          <PrivateRoute>
            <SendMoney />
          </PrivateRoute>
        }
      />
      <Route
        path="/repeat-transaction"
        element={
          <PrivateRoute>
            <RepeatTranscation />
          </PrivateRoute>
        }
      />
      <Route
        path="/my-recipient"
        element={
          <PrivateRoute>
            <RecipientList />
          </PrivateRoute>
        }
      />
      <Route
        path="/add-recipient"
        element={
          <PrivateRoute>
            <AddRecipient />
          </PrivateRoute>
        }
      />
      <Route
        path="/edit-recipient"
        element={
          <PrivateRoute>
            <EditRecipient />
          </PrivateRoute>
        }
      />
      <Route
        path="/my-bank-accounts"
        element={
          <PrivateRoute>
            <BankAccountList />
          </PrivateRoute>
        }
      />
      <Route
        path="/add-bank-account"
        element={
          <PrivateRoute>
            <AddBankAccount />
          </PrivateRoute>
        }
      />
      <Route
        path="/my-transaction"
        element={
          <PrivateRoute>
            <TransactionList />
          </PrivateRoute>
        }
      />

      <Route
        path="/track-money-transfer"
        element={
          <PrivateRoute>
            <TrackTransfer />
          </PrivateRoute>
        }
      />
      <Route
        path="/request-money"
        element={
          // <PrivateRoute>
          <RequestMoney />
          // </PrivateRoute>
        }
      />
      <Route
      path="/recipient-request-list"
      element={
        <RecipientRequestList
          // appState={state}
          // manageRefreshToken={manageRefreshToken}
        />
      }
      />
      <Route
      path="/plaid-fail"
      element={
          <PlaidFail appState={state} manageAuth={manageAuth} />
      }
    />
    <Route
      path="/plaid-success"
      element={
          <PlaidSuccess appState={state} manageAuth={manageAuth} />
      }
    />
     <Route
            path="/jumio-fail"
            element={
                <JumioFail appState={state} manageAuth={manageAuth} />
            }
          />
          <Route
            path="/jumio-success"
            element={
                <JumioSuccess appState={state} manageAuth={manageAuth} />
            }
          />
      <Route
        path="/kyc"
        element={
          <PrivateRoute>
            <Kyc />
          </PrivateRoute>
        }
      />
      <Route
        path="/Profile"
        element={
          <PrivateRoute>
            <Profile />
          </PrivateRoute>
        }
      />
      <Route
        path="/change-password"
        element={
          <PrivateRoute>
            <ChangePassword />
          </PrivateRoute>
        }
      />
      <Route
        path="/upload-doc"
        element={
          <PrivateRoute>
            <UploadAdditonalDoc />
          </PrivateRoute>
        }
      />
      {aciveEmail && (
        <Route
          path="/change-email"
          element={
            <PrivateRoute>
              <ChangeEmail />
            </PrivateRoute>
          }
        />
      )}
      {aciveContact && <Route path="/contact" element={<Contact />} />}
      {aciveFeedback && <Route path="/feedback" element={<Feedback />} />}
      {aciveRaiseIssue && <Route path="/raise-issue" element={<RaiseIssue />} />}
      <Route path="*" element={<PageNotFound />} />
    </Route>
  );
};

export default DashboardRoutes;
