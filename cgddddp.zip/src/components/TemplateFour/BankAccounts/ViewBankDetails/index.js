import React from "react";
import { useSelector } from "react-redux";
import Dashboard from "../../Layouts/Dashboard";
import ViewBankDetailsFlow1 from "./ViewBankDetailsFlow1/ViewBankDetails";
// import DashboardTemplate1 from "../Layouts/Dashboard/DashboardTemplate1";

const ViewBankDetails = (props) => {
  const AuthReducer = useSelector((state) => state.user);
  const temp = AuthReducer.groupIdSettings?.theme?.SIGN;
  const templateFlow =
    AuthReducer.groupIdSettings?.bankAccount?.viewBankDetails?.flow;

  return (
    <>
      <Dashboard>
        {templateFlow === "FLOW1" && (
          <ViewBankDetailsFlow1
            appState={props.appState}
            manageAuth={props.manageAuth}
          />
        )}
        {/* {templateFlow === "FLOW2" && (
          <AddBankAccountFlow2
            appState={props.appState}
            manageAuth={props.manageAuth}
          />
        )} */}
      </Dashboard>
    </>
  );
};

export default ViewBankDetails;
