import React, { useEffect } from "react";
import { useSelector } from "react-redux";
import AddBankAccountFlow1 from "./AddBankAccountFlow1/AddBankAccount";
import AddBankAccountFlow2 from "./AddBankAccountFlow2/AddBankAccount";
import Dashboard from "../../Layouts/Dashboard";
import { useOutletContext } from "react-router-dom";
import { getProcessingPartner } from "../../../../services/utility/group";
import Plaid from "./Plaid";

const AddBankAccount = (props) => {
  const { setTitle } = useOutletContext();
  const AuthReducer = useSelector((state) => state.user);
  const temp = AuthReducer.groupIdSettings?.theme?.SIGN;
  const templateFlow =
    AuthReducer.groupIdSettings?.bankAccount?.addBankAccount?.flow;

  useEffect(() => {
    setTitle("Add Bank Account");
  }, []);

  if (getProcessingPartner(AuthReducer.sendCountryCode) === "VIAMERICAS") {
    return <Plaid {...props} />;
  }
  return (
    <>
      {templateFlow === "FLOW1" && (
        <AddBankAccountFlow1
          appState={props.appState}
          manageAuth={props.manageAuth}
          accountsList={props.accountsList}
          setVisible={props.setVisible}
          visible={props.visible}
        />
      )}
      {templateFlow === "FLOW2" && (
        <AddBankAccountFlow2
          appState={props.appState}
          manageAuth={props.manageAuth}
        />
      )}
    </>
  );
};

export default AddBankAccount;
