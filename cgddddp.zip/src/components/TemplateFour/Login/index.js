import React, { useState, useReducer } from "react";
import { useNavigate } from "react-router-dom";
import { Form, notification } from "antd";
import LoginForm from "../Login/LoginForm";

import { setSessionStorage } from "../../../services/utility/storage";
import { login, setAdditionalAuthRequired, setUserKyc } from "../../../reducers/userReducer";
import { AuthAPI } from "../../../apis/AuthAPI";
import { useDispatch, useSelector } from "react-redux";
import { ProfileAPI } from "../../../apis/ProfileAPI";
import useHttp from "../../../hooks/useHttp";
import { ViAmericaAuthAPI } from "../../../apis/ViAmericaApi/Auth";
import { getProcessingPartner } from "../../../services/utility/group";
import ViaVerifyOTP from "../../../containers/ViaVerifyOTP.js";
import { LuluAuthAPI } from "../../../apis/LuluApi/Auth";

const Login = (props) => {
  const websiteSettings = useSelector((state) => state.user.groupIdSettings.settings);
  const dispatch = useDispatch();
  const [form] = Form.useForm();
  const [loading, setLoader] = useState(false);
  const navigate = useNavigate();

  const [state, setState] = useReducer((state, newState) => ({ ...state, ...newState }), {
    loginData: {},
    profileData: null, //for lulu
    nextAction: "",
    verifyViaOTP: false,
    _isViaSendOTP: false,

    twofa: "N",
    // _showSignInForm: true,
    // otpType: "LG",
    onFinishData: {},
  });

  const hookLoginViAmerica = useHttp(ViAmericaAuthAPI.login);
  const hookUserRiskProfile = useHttp(ProfileAPI.userRiskProfile);
  const hookLogin = useHttp(AuthAPI.login);
  const hookViaSendOTP = useHttp(ViAmericaAuthAPI.viaSendOTP);
  const hookGetSenderKycDetails = useHttp(ProfileAPI.getSenderKycDetails);
  const hookLookup = useHttp(LuluAuthAPI.lookup);
  const hookGetProfile = useHttp(ProfileAPI.getProfile);

  const onFinish = (value) => {
    setState({ onFinishData: value });

    const payload = {
      requestType: "LOGIN",
      loginId: value.loginId,
      password: value.loginpassword,
      noofAttempts: "1",
      custType: "SEND",
      referer: "",
    };

    setLoader(true);
    hookLogin.sendRequest(payload, function (data) {
      if (data.status == "S") {
        console.log("data.regCountryCode", data.regCountryCode);
        console.log(
          "getProcessingPartner(data.regCountryCode)",
          getProcessingPartner(data.regCountryCode)
        );
        if (getProcessingPartner(data.regCountryCode) === "VIAMERICAS") {
          loginViaAmerica({ ...data, emailid: value.loginId });
        } else {
          userRiskProfile(data);
          storeLoginData({ ...data, emailid: value.loginId });
          //   userRiskProfile(data);
          // storeLoginData(data);
        }
      } else {
        setLoader(false);
        if (data.errorList) {
          notification.error({ message: data.errorList[0].error });

          let errors = [];
          data.errorList.forEach((error, i) => {
            let errorData = {
              name: error.field,
              errors: [error.error],
            };
            errors.push(errorData);
          });

          if (errors.length > 0) form.setFields(errors);
        } else {
          notification.error({ message: data.errorMessage });
        }
      }
    });
  };

  const userRiskProfile = (loginData) => {
    const userRiskProfilePayload = {
      requestType: "RISKPROFILE",
      userId: loginData.userId,
      ___token: loginData.token,
    };

    setLoader(true);
    hookUserRiskProfile.sendRequest(userRiskProfilePayload, function (data) {
      if (data.status == "S") {
        if (getProcessingPartner(loginData.regCountryCode) === "LULU") {
          getUserProfile(loginData);
        }
        setState({ nextAction: data.nextAction });
        dispatch(setUserKyc(data.nextAction));
      }
      setLoader(false);
    });
  };


  const getUserProfile = async (loginData) => {
    setLoader(true);
    let payload = {
      requestType: "USERPROFILE",
      userId: loginData.userId,
      ___token: loginData.token,
    };
    hookGetProfile.sendRequest(payload, function (data) {
      if (data.status === "S") {
        if (!data?.uniqueIdentifierValue) {
          navigate("/kyc");
        } else {
          lookupWithLulu({ ...payload, ...data });
        }
        setState({ profileData: data });
        setLoader(false);
      }
    });
  };

  const lookupWithLulu = async (lookupDetails) => {
    let lookupPayload = {
      requestType: "LULULOOKUP",
      userId: lookupDetails.userID,
      idType: "4",
      idNumber: lookupDetails?.uniqueIdentifierValue,
      mobilePhoneCode: state.profileData?.mobilePhoneCode,
      mobileNumber: state.profileData?.phone,
    };

    hookLookup.sendRequest(lookupPayload, function (data) {
      if (data.status == "S") {
        let lookupObjectData = data?.resultData?.data ? JSON.parse(data?.resultData?.data) : {};
        if (lookupObjectData?.aml_scan_status == "Accepted" && lookupObjectData?.id_status == "Active" && lookupObjectData?.customer_status == "ACTIVE") {
          setLoader(false);
          navigate("/new-transaction");
        } else {
          notification.error({ message: data.errorMessage });
          window.location.href = "/";
        }
      } else {
        setLoader(false);
        notification.error({ message: data.errorMessage });
        setTimeout(() => {
          window.location.href = "/";
        }, 3000);
      }
    });
  };

  const storeLoginData = (loginData) => {
    // notification.success({
    //   message: `WELCOME ${loginData.firstName} ${loginData.lastName}`,
    // });
    const objLoginData = { ...loginData, ...websiteSettings };
    saveUser(objLoginData, state.nextAction);
    props.manageAuth("logintoken", loginData);
    // navigate("/my-recipient");
    // if (state.nextAction == "KYC_COMPLETE") {
    //   setTimeout(() => {}, 500);
    // } else {
    //   // can comment this line, not usable at all
    //   setTimeout(() => {
    //     navigate("/new-transactionss");
    //   }, 500);
    // }
    if (state.nextAction == "KYC_COMPLETE") {
      setTimeout(() => {}, 500);
    } else {
      // can comment this line, not usable at all
      // setTimeout(() => {
      //   navigate("/new-transaction");
      // }, 500);
    }
  };

  const saveUser = (data, nextAction) => {
    // for session storage
    if (getProcessingPartner(data.regCountryCode) === "VIAMERICAS") {
      dispatch(setAdditionalAuthRequired(true));
    }
    if (data.refreshPage) {
      setSessionStorage("accessToken", data.token);
      setSessionStorage("isLoggedIn", true);
      setSessionStorage("regCountryCode", data.regCountryCode);

      setSessionStorage("userID", data.userId);
      setSessionStorage("userFullName", data.firstName + " " + data.lastName);
    } else {
      dispatch(
        login({
          lastLogin: data.lastLoginTimeIST,
          userID: data.userId,
          userLoginId: data.emailid,
          userFullName: data.firstName + " " + data.lastName,
          accessToken: data.token,
          isLoggedIn: true,
          regCountryCode: data.regCountryCode,
        })
      );
      // dispatch(setLastLogin(data.lastLoginTimeIST));
      // dispatch(setUserId(data.userId));
      // dispatch(setUserKyc(nextAction));
      // dispatch(setUserFullName(data.firstName + " " + data.lastName));
      // dispatch(setToken(data.token));
      // dispatch(setIsLoggedIn(true));
    }
    if (getProcessingPartner(data.regCountryCode) === "VIAMERICAS") {
      getSenderKycDetails(data);
    }
  };
  const getSenderKycDetails = (data) => {
    const payload = {
      requestType: "SENDERKYCDTLS",
      userId: data.userId,
    };
    setLoader(true);
    hookGetSenderKycDetails.sendRequest(payload, function (dataV) {
      setLoader(false);
      // let dataV = { ...dataB, isMobileVerified: "N" }; //bypass
      if (dataV.status == "S") {
        if (dataV.isMobileVerified == "N") {
          //actual N
          viaSendOTP(data);
        } else {
          // getCRNDetails(data);
          dispatch(setAdditionalAuthRequired(false));
          notification.success({
            message: `WELCOME ${data.firstName} ${data.lastName}`,
          });
          // navigate("/new-transaction");
        }
      }
    });
  };
  const viaSendOTP = (data) => {
    const payload = {
      requestType: "VIASENDOTP",
      userId: data.userId,
      otpType: "SEND",
      optionID: "phone", //pass email or phone
    };
    setLoader(false);
    hookViaSendOTP.sendRequest(payload, function (dataV) {
      setLoader(false);
      if (dataV.status == "S") {
        notification.success({ message: "OTP has been sent to your registered mobile number" });
        setState({ verifyViaOTP: true, eventId: dataV.eventId, _isViaSendOTP: false });
      } else {
        notification.error({
          message: dataV.errorMessage ? dataV.errorMessage : "Via send OTP failed",
        });
      }
    });
  };
  const loginViaAmerica = (data) => {
    setLoader(true);
    const payload = {
      requestType: "LOGIN",
      userId: data.userId,
    };
    hookLoginViAmerica.sendRequest(payload, function (dataV) {
      notification.destroy();
      setLoader(false);
      // let dataV = { ...dataB, message: "OTP Sent", eventId: "S" }; //bypass
      if (dataV.message == "OTP Sent" && dataV.eventId) {
        notification.success({
          message: "OTP has been sent to your registered mobile number",
        });
        setState({
          userId: data.userId,
          _isViaSendOTP: true,
          // _showSignInForm: false,
          verifyViaOTP: true,
          eventId: dataV.eventId,
        });
      } else {
        if (dataV.status === "S") {
          setState({ loginData: data });

          if (state.twofa === "N") {
            userRiskProfile(data);
            storeLoginData(data);
          } else {
            userRiskProfile(data);
            storeLoginData(data);
            // sendOTP(data);
          }

          window.sessionStorage.setItem("loginTokenId", dataV.loginTokenId);
          window.sessionStorage.setItem("idSenderGlobal", dataV.idSenderGlobal);
        } else {
          notification.error({ message: dataV.errorMessage });
        }
      }
    });
  };
  return (
    <>
      {state.verifyViaOTP && (
        <ViaVerifyOTP
          state={state}
          setState={setState}
          useFor="login"
          otpType="SMS"
          submitHandler={onFinish}
        />
      )}

      <LoginForm loading={loading} onFinish={onFinish} form={form} />
    </>
  );
};

export default Login;
