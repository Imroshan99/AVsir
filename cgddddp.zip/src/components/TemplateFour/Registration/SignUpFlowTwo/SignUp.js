import React, { useState, useEffect, useReducer } from "react";
import Container from "react-bootstrap/Container";
import { Link } from "react-router-dom";
import { Form, Input, Checkbox, Select, Radio, DatePicker, notification, Spin } from "antd";
import moment from "moment";
import OTPBox from "../../../../containers/OTPBox";
import ExchangeRate from "../../../../containers/ExchangeRate";
import { config } from "../../../../config";
import { useSelector } from "react-redux";
import TCModal from "../../../../containers/ModalBox/TCModal";
import SetPasswordFlowTwo from "./SetPasswordFlowTwo";
import useHttp from "../../../../hooks/useHttp";
import { GuestAPI } from "../../../../apis/GuestAPI";
import { AuthAPI } from "../../../../apis/AuthAPI";
import CustomInput from "../../../../reusable/CustomInput";

const { Option } = Select;
export default function SignUp(props) {
  const ConfigReducer = useSelector((state) => state.user);

  const [form] = Form.useForm();
  const [loading, setLoader] = useState(false);
  const [isSelectMarketingCommunication, setisSelectMarketingCommunication] = useState("N");
  const [state, setState] = useReducer((state, newState) => ({ ...state, ...newState }), {
    phoneCodes: [],
    sendCountryList: [],
    isModalVisible: false,
    tcModalVisible: false,
    verificationToken: "",
    verifiedToken: "",
    clientId: ConfigReducer.clientId,
    groupId: ConfigReducer.groupId,
    twofa: ConfigReducer.twofa,
    sessionId: ConfigReducer.sessionId,
    dob: "",
    formData: {},
    _isShowOTPBOX: false,
    _isShowSetPassword: false,
  });

  const hookGetCountryPhoenCodes = useHttp(GuestAPI.getCountryPhoneCodes);
  const hookGetSendingCountryList = useHttp(GuestAPI.sendingCountryList);
  const hookSaveLeads = useHttp(AuthAPI.saveLeads);
  const hookCheckDedupe = useHttp(AuthAPI.checkDedupe);

  useEffect(() => {
    window.scrollTo({ top: 0, behavior: "smooth" });
    setLoader(true);
    const countryPayload = {
      requestType: "COUNTRYPHONECODE",
    };

    hookGetCountryPhoenCodes.sendRequest(countryPayload, function (data) {
      if (data.status === "S") {
        setState({ phoneCodes: data.responseData });
        setLoader(false);
      }
    });

    //   send country list
    const dataCountry = {
      requestId: config.requestId,
      requestType: "SENDCOUNTRYLIST",
      channelId: config.channelId,
      clientId: state.clientId,
      groupId: state.groupId,
      sessionId: state.sessionId,
      ipAddress: "127.0.0.1",
    };
    hookGetSendingCountryList.sendRequest(dataCountry, function (data) {
      if (data.status === "S") {
        setState({ sendCountryList: data.responseData });
        setLoader(false);
      }
    });
  }, []);

  const onCreateLead = (value) => {
    form.setFields([
      { name: "country", errors: [] },
      { name: "firstName", errors: [] },
      { name: "middleName", errors: [] },
      { name: "lastName", errors: [] },
      { name: "mobilePhoneCode", errors: [] },
      { name: "mobileNo", errors: [] },
      { name: "dob", errors: [] },
      { name: "emailId", errors: [] },
    ]);

    var marketingCommunication = "";
    if (value.isSameCommAddressFlag == "Y") {
      var marketingCommunication = "";
      value.marketingCommunicationMedia.forEach((data) => {
        marketingCommunication = marketingCommunication + "~" + data;
      });

      marketingCommunication = marketingCommunication + "~";
    }

    let leadData = {
      requestType: "LEAD",
      firstName: value.firstName,
      middleName: value.middleName,
      lastName: value.lastName,
      gender: state.gender,
      loginId: value.emailId,
      emailId: value.emailId,
      sendCountry: value.country,
      mobilePhoneCode: value.mobilePhoneCode,
      mobileNo: value.mobileNo,
      dob: state.dob,
      lpID: "",
      pageReferer: "savsa",
      custType: "INDIVITUAL",
      periodicUpdate: "N", //if yes then marketingCommunication pass
      marketingCommunication: marketingCommunication,
      otpFlag: state.twofa,
    };

    hookSaveLeads.sendRequest(leadData, function (data) {
      value.leadId = data.leadId;

      if (data.status == "S") {
        setState({ verificationToken: data.verificationToken });

        if (state.twofa == "N") {
          setState({
            _isShowSetPassword: true,
            isModalVisible: true,
            formData: value,
          });
        } else {
          setState({
            _isShowOTPBOX: true,
            isModalVisible: true,
            formData: value,
          });
        }
      } else {
        notification.error({ message: data.errorMessage });
        let errors = [];
        data.errorList.forEach((error, i) => {
          let errorData = {
            name: error.field,
            errors: [error.error],
          };
          errors.push(errorData);
        });

        if (errors.length > 0) form.setFields(errors);
      }
      setLoader(false);
    });
  };

  const checkDedupe = () => {
    let payload = {
      requestType: "DEDUPECHECK",
      firstName: state.formData.firstName,
      lastName: state.formData.lastName,
      emailId: state.formData.emailId,
      mobilePhoneCode: state.formData.mobilePhoneCode,
      mobileNo: state.formData.mobileNo,
      dob: state.dob,
      countryCode: ConfigReducer.sendCountryCode,
    };
    hookCheckDedupe.sendRequest(payload, function (data) {
      setState({ _isShowSetPassword: true });
      // if (res.data.status == "S") {
      //     console.log('suceess')
      //     setState({_isShowSetPassword: true})
      // } else {
      //     console.log('failed')
      //     notification.error({ message: res.data.errorMessage })
      // }
      setLoader(false);
    });
  };

  const handleRecvCountry = (value) => {
    // alert(value)
    const arcountryPhoneCode = state.phoneCodes.filter((v, i) => v.countryCode === value);
    // console.log(arcountryPhoneCode[0].countryPhoneCode);
    form.setFieldsValue({
      mobilePhoneCode: arcountryPhoneCode[0].countryPhoneCode,
    });
  };

  const handleTcModal = () => {
    setState({ tcModalVisible: true });
  };

  return (
    <div className="d-flex w-100 h-100">
      <div>
        {state._isShowOTPBOX && <OTPBox state={state} setState={setState} checkDedupe={checkDedupe} otpType="UL" useFor="signup" appState={props.appState} />}
        {state.tcModalVisible && <TCModal state={state} setState={setState} />}

        {state._isShowSetPassword == false ? (
          <div>
            <h1 className="title mb-4">Sign Up</h1>
            <Spin spinning={loading} delay={500}>
              <Form form={form} onFinish={onCreateLead} initialValues={{ country: ConfigReducer.sendCountryCode, mobilePhoneCode: "44" }}>
                <div className="">
                  <label className="form-label">Sending money from</label>
                  <div>
                    {/* <Form.Item
                      className="form-item"
                      name="country"
                      rules={[
                        {
                          required: true,
                          message: "Please select country.",
                        },
                      ]}
                    >
                      <Select size="large" className="w-100" placeholder="Select Country " onChange={handleRecvCountry} disabled={true}>
                        {state.sendCountryList.map((clist, i) => {
                          return <Option key={i} value={clist.sendCountry}>{`${clist.countryName}`}</Option>;
                        })}
                      </Select>
                    </Form.Item> */}
                    <CustomInput name="country" showLabel={false} label="Country" type="select" size="large" className="w-100" placeholder="Select Country" onChange={handleRecvCountry} disabled={true} required>
                      {state.sendCountryList.map((clist, i) => {
                        return <Option key={i} value={clist.sendCountry}>{`${clist.countryName}`}</Option>;
                      })}
                    </CustomInput>
                  </div>
                </div>
                <div className="row">
                  <div className="col">
                    <div className="">
                      {/* <label className="form-label">First Name</label>
                      <Form.Item
                        className="form-item"
                        name="firstName"
                        rules={[
                          {
                            required: true,
                            message: "Please input your First Name.",
                          },
                          {
                            min: 3,
                            message: "First Name should be between 3 and 40 characters long",
                          },
                          {
                            max: 40,
                            message: "First Name should be between 3 and 40 characters long",
                          },
                          {
                            pattern: /^[a-zA-Z]+$/,
                            message: "Please enter valid name",
                          },
                        ]}
                      >
                        <Input size="large" placeholder="Enter your First Name" />
                      </Form.Item> */}
                      <CustomInput
                        name="firstName"
                        placeholder="Enter your First Name"
                        size="large"
                        label="First Name"
                        validationRules={[
                          {
                            pattern: /^[a-zA-Z]+$/,
                            message: "Please enter valid name",
                          },
                        ]}
                        min={3}
                        max={40}
                        required
                      ></CustomInput>
                    </div>
                  </div>
                  <div className="col-5">
                    <div className="">
                      {/* <label className="form-label">Middle Name</label>
                      <Form.Item
                        className="form-item"
                        name="middleName"
                        rules={[
                          {
                            min: 3,
                            message: "Middle Name should be between 3 and 40 characters long",
                          },
                          {
                            max: 40,
                            message: "Middle Name should be between 3 and 40 characters long",
                          },
                        ]}
                      >
                        <Input size="large" placeholder="Enter your Middle Name" />
                      </Form.Item> */}
                      <CustomInput min={3} max={40} label="Middle Name" name="middleName" size="large" placeholder="Enter your Middle Name"></CustomInput>
                    </div>
                  </div>
                  <div className="col">
                    <div className="">
                      {/* <label className="form-label">Last Name</label>
                      <Form.Item
                        className="form-item"
                        name="lastName"
                        rules={[
                          {
                            required: true,
                            message: "Please input your Last Name.",
                          },
                          {
                            min: 3,
                            message: "Last Name should be between 3 and 40 characters long",
                          },
                          {
                            max: 40,
                            message: "Last Name should be between 3 and 40 characters long",
                          },
                          {
                            pattern: /^[a-zA-Z]+$/,
                            message: "Please enter valid name",
                          },
                        ]}
                      >
                        <Input size="large" placeholder="Enter your Last Name" />
                      </Form.Item> */}
                      <CustomInput
                        size="large"
                        placeholder="Enter your Last Name"
                        name="lastName"
                        validationRules={[
                          {
                            pattern: /^[a-zA-Z]+$/,
                            message: "Please enter valid name",
                          },
                        ]}
                        min={3}
                        max={40}
                        label="Last Name"
                        required
                      ></CustomInput>
                    </div>
                  </div>
                </div>
                <div className="">
                  {/* <label className="form-label">Gender</label> */}
                  <div>
                    {/* <Form.Item
                      name="gender"
                      rules={[
                        {
                          required: true,
                          message: "Please select gender!",
                        },
                      ]}
                    >
                      <Radio.Group>
                        <Radio value="M">Male</Radio>
                        <Radio value="F">Female</Radio>
                      </Radio.Group>
                    </Form.Item> */}
                    <CustomInput label="Gender" name="gender" required>
                      <Radio.Group>
                        <Radio value="M">Male</Radio>
                        <Radio value="F">Female</Radio>
                      </Radio.Group>
                    </CustomInput>
                  </div>
                </div>
                <div className="row">
                  <div className="col-5">
                    <div className="">
                      {/* <label className="form-label">Country Code</label> */}
                      <div>
                        {/* <Form.Item
                          className="form-item"
                          name="mobilePhoneCode"
                          rules={[
                            {
                              required: true,
                              message: "Please select your Country Code.",
                            },
                          ]}
                        >
                          <Select size="large" className="w-100" placeholder="Select Country Code" disabled={true}>
                            {state.phoneCodes.map((phoneCode, i) => {
                              return <Option key={i} value={phoneCode.countryPhoneCode}>{`${phoneCode.countryPhoneCode} (${phoneCode.countryName})`}</Option>;
                            })}
                          </Select>
                        </Form.Item> */}
                        <CustomInput type="select" label="Country Code" size="large" className="w-100" placeholder="Select Country Code" disabled={true} name="mobilePhoneCode" required>
                          {state.phoneCodes.map((phoneCode, i) => {
                            return <Option key={i} value={phoneCode.countryPhoneCode}>{`${phoneCode.countryPhoneCode} (${phoneCode.countryName})`}</Option>;
                          })}
                        </CustomInput>
                      </div>
                    </div>
                  </div>
                  <div className="col">
                    <div className="">
                      {/* <label className="form-label">Mobile Number</label>
                      <Form.Item
                        className="form-item"
                        name="mobileNo"
                        rules={[
                          {
                            required: true,
                            message: "Please input your Mobile Number.",
                          },
                          {
                            min: 10,
                            max: 10,
                            message: "Mobile number must be 10 digit.",
                          },
                          {
                            pattern: /^[0-9\b]+$/,
                            message: "Only Numbers allowed",
                          },
                          // { pattern: new RegExp("^[6]{1}[0-9]*$"), message: "Mobile number must start with 6" }
                        ]}
                      >
                        <Input size="large" placeholder="123456789" maxLength={10} />
                      </Form.Item> */}
                      <CustomInput
                        validationRules={[
                          {
                            pattern: /^[0-9\b]+$/,
                            message: "Only Numbers allowed",
                          },
                          // { pattern: new RegExp("^[6]{1}[0-9]*$"), message: "Mobile number must start with 6" }
                        ]}
                        min={10}
                        max={10}
                        label="Mobile Number"
                        name="mobileNo"
                        size="large"
                        placeholder="123456789"
                        maxLength={10}
                        required
                      ></CustomInput>
                    </div>
                  </div>
                </div>

                <div className="">
                  {/* <label className="form-label">Date Of Birth</label> */}
                  <div>
                    {/* <Form.Item
                      className="form-item"
                      name="dob"
                      rules={[
                        {
                          required: true,
                          message: "Please input your Date Of Birth.",
                        },
                      ]}
                    >
                      <DatePicker
                        size="large"
                        className="w-100"
                        defaultPickerValue={moment().subtract(18, "years")}
                        disabledDate={(d) => !d || d.isAfter(moment().subtract(18, "years")) || d.isSameOrBefore("1900-01-01")}
                        onChange={(value, dateString) => {
                          value !== null ? setState({ dob: dateString }) : setState({ dob: "" });
                        }}
                      />
                    </Form.Item> */}
                    <CustomInput label="Date of Birth" name="dob" required>
                      <DatePicker
                        size="large"
                        className="w-100"
                        defaultPickerValue={moment().subtract(18, "years")}
                        disabledDate={(d) => !d || d.isAfter(moment().subtract(18, "years")) || d.isSameOrBefore("1900-01-01")}
                        onChange={(value, dateString) => {
                          value !== null ? setState({ dob: dateString }) : setState({ dob: "" });
                        }}
                      />
                    </CustomInput>
                  </div>
                </div>
                <div className="">
                  {/* <label className="form-label">Email Address</label>
                  <Form.Item
                    className="form-item"
                    name="emailId"
                    rules={[
                      {
                        required: true,
                        message: "Please input your Email ID.",
                      },
                      {
                        type: "email",
                        message: "Please input valid Email ID.",
                      },
                      // {
                      //   pattern: /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/,
                      //   message: "Please enter valid email address",
                      // },
                    ]}
                  >
                    <Input
                      size="large"
                      placeholder="Enter Email ID"
                      onPaste={(e) => {
                        e.preventDefault();
                        return false;
                      }}
                      onCopy={(e) => {
                        e.preventDefault();
                        return false;
                      }}
                      onCut={(e) => {
                        e.preventDefault();
                        return false;
                      }}
                    />
                  </Form.Item> */}
                  <CustomInput
                    name="emailId"
                    type="email"
                    label="Email Address"
                    size="large"
                    placeholder="Enter Email ID"
                    onPaste={(e) => {
                      e.preventDefault();
                      return false;
                    }}
                    onCopy={(e) => {
                      e.preventDefault();
                      return false;
                    }}
                    onCut={(e) => {
                      e.preventDefault();
                      return false;
                    }}
                    required
                  ></CustomInput>
                </div>

                <div className="">
                  <label className="form-label">How did you hear about us</label>
                   
                  <CustomInput
                    showLabel={false}
                    size="large"
                    className="w-100"
                    placeholder="Select"
                    type="select"
                    name="hear_about_us"
                    validationRules={[
                      {
                        required: true,
                        message: "Please select one.",
                      },
                    ]}
                  >
                    <Option key="ive_1" value="Internet">
                      Internet
                    </Option>
                    <Option key="ive_2" value="Newspaper">
                      Newspaper
                    </Option>
                    <Option key="ive_3" value="Other">
                      Other
                    </Option>
                  </CustomInput>
                </div>
                <div className="">
                  <CustomInput
                    name="readTermsConditions"
                    valuePropName="checked"
                    validationRules={[
                      {
                        validator: (_, value) => (value ? Promise.resolve() : Promise.reject(new Error("Please confirm terms and conditions."))),
                      },
                    ]}
                  >
                    <Checkbox>By clicking on the "Register Me" button below, I agree to the Terms &amp; Conditions of KCB Remit.</Checkbox>
                  </CustomInput>
                   
                  <div>
                    <a onClick={handleTcModal} href="#!">
                      Read Terms and Conditions
                    </a>
                  </div>
                </div>

                {/* <div className="">
                          <p>
                            I agree to receive marketing communications from
                            ICICI Bank Money2India UK about their offerings.
                          </p>
                          <Form.Item
                            className="form-item"
                            name="isSameCommAddressFlag"
                            rules={[
                              {
                                required: true,
                                message:
                                  "Please select marketing communication consent.",
                              },
                            ]}
                          >
                            <Radio.Group>
                              <Radio
                                value={"Y"}
                                onClick={() =>
                                  setisSelectMarketingCommunication("Y")
                                }
                              >
                                Yes
                              </Radio>
                              <Radio
                                value={"N"}
                                onClick={() =>
                                  setisSelectMarketingCommunication("N")
                                }
                              >
                                No
                              </Radio>
                            </Radio.Group>
                          </Form.Item>
                        </div>

                        {isSelectMarketingCommunication == "Y" && (
                          <div className="">
                            <Form.Item
                              className="form-item"
                              name="marketingCommunicationMedia"
                              rules={[
                                {
                                  required: true,
                                  message:
                                    "Please select where you want to recieve updates and marketing communication consent.",
                                },
                              ]}
                            >
                              <Checkbox.Group>
                                <Checkbox value="eMail">E-mail</Checkbox>
                                <Checkbox value="sms">SMS</Checkbox>
                                <Checkbox value="socialMedia">
                                  Social Media
                                </Checkbox>
                                <Checkbox value="cell">Call</Checkbox>
                              </Checkbox.Group>
                            </Form.Item>
                          </div>
                        )} */}

                <div className="d-grid">
                  <button className="btn btn-primary text-white">{state.twofa == "Y" ? "Verify With OTP" : "Verify Without OTP"}</button>
                </div>
                <div className="d-flex justify-content-lg-center mt-3">
                  <p className="text-muted text-center mb-0 me-2">Already have an account?</p>
                  <Link to={"/signin"} className="btn-link text-primary">
                    Log In
                  </Link>
                </div>
              </Form>
            </Spin>
          </div>
        ) : (
          <SetPasswordFlowTwo state={state} setState={setState} appState={props.appState} />
        )}
      </div>
    </div>
  );
}
