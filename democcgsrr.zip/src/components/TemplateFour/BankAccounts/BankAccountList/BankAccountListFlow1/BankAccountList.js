import React, { useState, useEffect, useReducer, Fragment } from "react";
import { Table, Button, Modal } from "antd";
import { DeleteOutlined } from "@ant-design/icons";
import moment from "moment";
import { BankAccountAPI } from "../../../../../apis/BankAccountAPI";
import { useSelector } from "react-redux";
// import SubHeader from "../../../layout/SubHeader";
import ViewBankDetails from "../../ViewBankDetails/ViewBankDetailsFlow1/ViewBankDetails";
import Swal from "sweetalert2";
import useHttp from "../../../../../hooks/useHttp";
import AddBankAccount from "../../AddBankAccount";
import Spinner from "../../../../../reusable/Spinner";
import { useNavigate } from "react-router-dom";
import AddBankAccountModal from "../../AddBankAccount/Modal";
function BankAccountList(props) {
  const navigate = useNavigate();
  const [tableRender, settableRender] = useState(false);
  const [contentRender, setContentRender] = useState(false);
  const AuthReducer = useSelector((state) => state.user);
  const [loading, setLoader] = useState(false);
  const [visible, setVisible] = useState(false);
  const [addBankAccountModal, setAddBankAccountModal] = useState(false);

  const [state, setState] = useReducer(
    (state, newState) => ({ ...state, ...newState }),
    {
      bankAccountList: [],
      clientId: AuthReducer.clientId,
      groupId: AuthReducer.groupId,
      sessionId: AuthReducer.sessionId,
      userID: AuthReducer.userID,
      isModalVisible: false,
      modalAccountDetails: {},
    }
  );
  const templateFlow =
    AuthReducer.groupIdSettings?.bankAccount?.addBankAccount?.flow;

  const hookBankAccountList = useHttp(BankAccountAPI.bankAccountList);

  const hookViewBankAccountDetails = useHttp(
    BankAccountAPI.viewBankAccountDetails
  );
  const hookDeleteBankAccountDetails = useHttp(
    BankAccountAPI.deleteBankAccountDetails
  );

  useEffect(() => {
    accountsList();
  }, []);

  const accountsList = () => {
    const payload = {
      requestType: "SENDERACCOUNTLIST",
      userId: state.userID,
      countryCode: AuthReducer.sendCountryCode,
      favouriteFlag: "1",
      startIndex: "0",
      recordsPerRequest: "",
    };
    setLoader(true);
    hookBankAccountList.sendRequest(payload, function (data) {
      if (data.status == "S") {
        settableRender(true);
        let resData = [];
        data.responseData.forEach((detail, i) => {
          let newData = {
            key: i,
            sendAccId: `${detail.sendAccId}`,
            recordToken: `${detail.recordToken}`,
            bankName: `${detail.bankName}`,
            accountNo: `${detail.accountNo}`,
            bankClearingCode: `${detail.sortCode}`,
            dateAdded: moment(detail.createdDate).format("MM-DD-YYYY"),
            status: detail.accountStatus,
          };
          resData.push(newData);
        });
        setState({
          bankAccountList: resData,
        });
        setLoader(false);
        setContentRender(true);
      } else {
        setLoader(false);
        settableRender(false);
        setContentRender(true);
      }
    });
  };

  const viewDetailsHandlerClick = (row) => {
    setState({ isModalVisible: true });
    const payload = {
      requestType: "SENDERACCOUNT",
      userId: state.userID,
      sendAccId: row.sendAccId,
      recordToken: row.recordToken,
    };
    hookViewBankAccountDetails.sendRequest(payload, function (data) {
      if (data.status == "S") {
        setState({
          modalAccountDetails: data,
        });
      }
    });
  };

  const deleteAccountHandler = (row) => {
    Swal.fire({
      text: "Are you sure you want to delete this bank account?",
      showCancelButton: true,
      confirmButtonText: "Confirm",
      denyButtonText: `Cancel`,
      confirmButtonColor: "#FFFFFF",
      color: "#FFFFFF",
      background: "#003153",
      customClass: {
        confirmButton: "btn btn-primary text-white ",
        cancelButton: "btn btn-secondary",
      },
    }).then((result) => {
      if (result.isConfirmed) {
        const payload = {
          requestType: "SENDERACCOUNT",
          userId: state.userID,
          sendAccId: row.sendAccId,
          recordToken: row.recordToken,
        };
        setLoader(true);
        hookDeleteBankAccountDetails.sendRequest(payload, function (data) {
          if (data.status == "S") {
            accountsList();
          } else {
            setLoader(false);
          }
        });
      } else if (result.isDenied) {
        Swal.fire("Changes are not saved", "", "info");
        setLoader(false);
      }
    });
  };

  return (
    <Fragment>
      {/* <SubHeader title="Account Summary" /> */}

      {/*       
        <AddBankAccount
          appState={props.state}
          visible={visible}
          accountsList={accountsList}
          setVisible={setVisible}
           
        /> */}
      <AddBankAccountModal
        visible={addBankAccountModal}
        setVisible={setAddBankAccountModal}
        accountsList={accountsList}
      ></AddBankAccountModal>

      <Spinner spinning={loading}>
        <div className="d-flex justify-content-end">
          <button
            className="btn btn-primary mb-4"
            onClick={() => {
              templateFlow === "FLOW1"
                ? setAddBankAccountModal(true)
                : navigate("/add-bank-account");
            }}
          >
            Add Bank Accounts
          </button>
        </div>
        {contentRender && tableRender && (
          <Table
            columns={[
              {
                title: "Bank Name",
                dataIndex: "bankName",
              },
              {
                title: "Account No",
                dataIndex: "accountNo",
              },
              {
                title: "Bank Clearing Code",
                dataIndex: "bankClearingCode",
              },
              {
                title: "Date Added",
                dataIndex: "dateAdded",
              },
              {
                title: "Status",
                dataIndex: "status",
                render: (text, record, index) => {
                  if (record.status.toUpperCase() === "R") {
                    return (
                      <span className="badge bg-success fs-8">Verified</span>
                    );
                  } else {
                    return (
                      <span className="badge bg-danger fs-8">Rejected</span>
                    );
                  }
                },
              },
              {
                title: "",
                dataIndex: "",
                key: "x",
                render: (text, record, index) => {
                  return (
                    <a i={index} onClick={() => viewDetailsHandlerClick(text)}>
                      View Details
                    </a>
                  );
                },
              },
              {
                title: "",
                dataIndex: "",
                key: "y",
                render: (text, record, index) => {
                  return (
                    <DeleteOutlined
                      i={index}
                      onClick={() => deleteAccountHandler(text)}
                    />
                  );
                },
              },
            ]}
            dataSource={state.bankAccountList}
            pagination={false}
          />
        )}
        {contentRender && !tableRender && (
          <div className="d-flex justify-content-center mt-5">
            <h4 className="text-white">No added bank detail.</h4>
          </div>
        )}

        <ViewBankDetails state={state} setState={setState} />
      </Spinner>
    </Fragment>
  );
}

export default BankAccountList;
