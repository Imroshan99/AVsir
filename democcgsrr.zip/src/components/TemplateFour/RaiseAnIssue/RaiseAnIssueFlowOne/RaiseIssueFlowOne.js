import React, { useEffect, useReducer, useState } from "react";
import { message, notification, Tabs, Upload } from "antd";
import { Row, Col, Container } from "react-bootstrap";
import { Button, Checkbox, Form, Input, Select } from "antd";
import { CameraOutlined, DeleteOutlined, FilePdfOutlined, LoadingOutlined, UploadOutlined } from "@ant-design/icons";
import Swal from "sweetalert2";
import { useNavigate } from "react-router-dom";
import { useSelector } from "react-redux";
import Spinner from "../../../../reusable/Spinner";
import useHttp from "../../../../hooks/useHttp";
import { GuestAPI } from "../../../../apis/GuestAPI";
import { ProfileAPI } from "../../../../apis/ProfileAPI";
import CustomInput from "../../../../reusable/CustomInput";

const { TabPane } = Tabs;
const { Option } = Select;
const { TextArea } = Input;

export default function RaiseIssueFlowOne(props) {
  const [form] = Form.useForm();
  const [form1] = Form.useForm();
  const navigate = useNavigate();
  const AuthReducer = useSelector((state) => state.user);
  const [state, setState] = useReducer((state, newState) => ({ ...state, ...newState }), {
    loader: false,
    phoneCodes: [],
  });
  const [frontDoc, setFrontDoc] = useState("");
  const [imageUrl, setImageUrl] = useState();
  const hookRaiseIssuePostLogin = useHttp(GuestAPI.contactUsPostLogin);
  const hookRaiseIssuePreLogin = useHttp(GuestAPI.contactUsPreLogin);
  const hookUserDocUpload = useHttp(ProfileAPI.userDocUpload);
  const hookGetCountryPhoenCodes = useHttp(GuestAPI.getCountryPhoneCodes);

  useEffect(() => {
    getCountryPhoneCode();
  }, []);
  const getCountryPhoneCode = () => {
    const countryPayload = {
      requestType: "COUNTRYPHONECODE",
    };
    setState({ loader: true });
    hookGetCountryPhoenCodes.sendRequest(countryPayload, function (data) {
      setState({ loader: false });
      if (data.status === "S") {
        const phoneCodeStatic = [
          { countryPhoneCode: 44, countryName: "United Kingdom" },
          { countryPhoneCode: 91, countryName: "India" },
        ];
        setState({ phoneCodes: phoneCodeStatic });
      }
    });
  };
  const normFile = (e) => {
    if (Array.isArray(e)) {
      return e;
    }
    return e && e.fileList;
  };
  const submitHandlerPostLogin = (value) => {
    let docPayload = {
      requestType: "USERDOCUPLOAD",
      docType: "RAID",
      docName: frontDoc.fileName,
      docExtension: frontDoc.fileName.split(".").pop(),
      userId: AuthReducer.userID,
      document: frontDoc.docUrl,
    };
    setState({ loader: true });
    hookUserDocUpload.sendRequest(docPayload, function (data) {
      if (data.status == "S") {
        let payload = {
          requestType: "POSTCONTACTUS",
          category: value.category,
          comments: value.comments.trim(),
          userId: AuthReducer.userID,
          pageFrom: "POST",
          identifier: "RI",
        };
        hookRaiseIssuePostLogin.sendRequest(payload, function (data) {
          setState({ loader: false });
          if (data.status === "S") {
            Swal.fire({
              title: "Success",
              text: data.message,
              icon: "success",
              confirmButtonColor: "#2dbe60",
            }).then((result) => {
              if (result.isConfirmed) {
                navigate("/new-transaction");
              }
            });
          } else {
            notification.error({ message: data.errorMessage });
            let errors = [];
            data.errorList.forEach((error, i) => {
              let errorData = {
                name: error.field,
                errors: [error.error],
              };
              errors.push(errorData);
            });
            if (errors.length > 0) form.setFields(errors);
          }
        });
      } else {
        setState({ loader: false });
      }
    });
  };

  const submitHandlerPreLogin = (value) => {
    let payload = {
      requestType: "PRECONTACTUS",
      category: value.category,
      fullName: value.fullName.trim(),
      mobilePhoneCode: value.mobilePhoneCode,
      mobileNo: value.mobileNo,
      emailId: value.emailId,
      comments: value.comments.trim(),
      pageFrom: "PRE",
      identifier: "RI",
    };
    setState({ loader: true });
    hookRaiseIssuePreLogin.sendRequest(payload, function (data) {
      setState({ loader: false });
      if (data.status === "S") {
        Swal.fire({
          title: "Success",
          text: data.message,
          icon: "success",
          confirmButtonColor: "#2dbe60",
        }).then((result) => {
          if (result.isConfirmed) {
            navigate("/");
          }
        });
      } else {
        notification.error({ message: data.errorMessage });
        let errors = [];
        data.errorList.forEach((error, i) => {
          let errorData = {
            name: error.field,
            errors: [error.error],
          };
          errors.push(errorData);
        });
        if (errors.length > 0) form.setFields(errors);
      }
    });
  };
  const submitHandlerPostLoginWithoutDoc = (value) => {
    let payload = {
      requestType: "POSTCONTACTUS",
      category: value.category,
      comments: value.comments.trim(),
      userId: AuthReducer.userID,
      pageFrom: "POST",
      identifier: "RI",
    };
    setState({ loader: true });
    hookRaiseIssuePostLogin.sendRequest(payload, function (data) {
      setState({ loader: false });
      if (data.status === "S") {
        Swal.fire({
          title: "Success",
          text: data.message,
          icon: "success",
          confirmButtonColor: "#2dbe60",
        }).then((result) => {
          if (result.isConfirmed) {
            navigate("/new-transaction");
          }
        });
      } else {
        notification.error({ message: data.errorMessage });
        let errors = [];
        data.errorList.forEach((error, i) => {
          let errorData = {
            name: error.field,
            errors: [error.error],
          };
          errors.push(errorData);
        });
        if (errors.length > 0) form.setFields(errors);
      }
    });
  };
  return (
    <React.Fragment>
      <Spinner spinning={state.loader}>
        <div className="template2__main raise_an_issue_page">
          <div className="sendmoney__page preloginform">
            <div className="container">
              <div>
                {AuthReducer.isLoggedIn ? (
                  <Form
                    form={form}
                    onFinish={(value) => {
                      if (imageUrl) {
                        submitHandlerPostLogin(value);
                      } else {
                        submitHandlerPostLoginWithoutDoc(value);
                      }
                    }}
                  >
                    <Row>
                      <Col>
                        <Row>
                          <CustomInput label="Select category" name={"category"} type="select" placeholder="Select" size="large" required>
                            <Option value="Money Transfer">Money Transfer</Option>
                            <Option value="Safety &amp; Security Concern">Safety &amp; Security Concern</Option>
                            <Option value="Data Privacy Concern">Data Privacy Concern</Option>
                            <Option value="Web Page not working">Web Page not working</Option>
                            <Option value="Any Other">Any Other</Option>
                          </CustomInput>
                        </Row>
                        <Row>
                          <CustomInput name={"comments"} label="Describe your Issue" required>
                            <TextArea className="bg-secondary-light" style={{ resize: "none", height: "12.2rem" }} autoComplete="none" />
                          </CustomInput>
                        </Row>
                      </Col>
                      <Col md={1}></Col>
                      <Col>
                        <label className="step-label">Add Attachments</label>
                        <Form.Item
                          className="mb-2"
                          wrapperCol={{ span: 24 }}
                          name="document"
                          valuePropName="fileList"
                          getValueFromEvent={normFile}
                          multiple={false}
                          rules={[
                            {
                              required: false,
                              message: "Please upload document.",
                            },
                          ]}
                        >
                          <Upload
                            name="logo"
                            listType="picture-card"
                            className="avatar-uploader"
                            accept="image/jpg, image/jpeg, image/png,application/pdf"
                            showUploadList={false}
                            beforeUpload={(file) => {
                              const isLt3MB = file.size;
                              if (isLt3MB >= "3145728") {
                                message.error("Document upload size limit maximum of 3MB!");
                                return false;
                              } else {
                                const fileName = file.name;
                                const fileType = file.type;
                                const reader = new FileReader();
                                reader.onload = (e) => {
                                  setFrontDoc({
                                    fileName,
                                    fileType,
                                    docUrl: e.target.result,
                                  });
                                  setImageUrl(e.target.result);
                                };
                                reader.readAsDataURL(file);

                                return false;
                              }
                            }}
                          >
                            {imageUrl ? (
                              <>
                                (
                                <img src={imageUrl} alt="avatar" width="100%" height="100%" />)
                              </>
                            ) : (
                              <div>
                                {false ? <LoadingOutlined /> : <UploadOutlined />}
                                <div className="mt-8">Upload</div>
                              </div>
                            )}
                          </Upload>
                        </Form.Item>
                        {imageUrl && (
                          <div className="text-center">
                            <DeleteOutlined
                              onClick={() => {
                                setImageUrl("");
                              }}
                            />
                          </div>
                        )}
                        <p>
                          <small className="opacity-50">
                            Supported formats: JPEG, PNG, BMP
                            <br />
                            File size limit 500kb
                          </small>
                        </p>
                      </Col>
                    </Row>
                    <div className="col-12 text-end">
                      <button className="btn btn-sm btn-light text-primary px-3" htmlType="submit">
                        Submit
                      </button>
                    </div>
                  </Form>
                ) : (
                  <Form form={form1} onFinish={(value) => submitHandlerPreLogin(value)}>
                    <Row>
                      <Col>
                        <Row>
                          <CustomInput
                            name="fullName"
                            className="form-item"
                            label="Your Name"
                            size="large"
                            placeholder="Enter your Name"
                            required
                            validationRules={[
                              {
                                pattern: /^([\w]{1,})+\s+([\w\s]{1,})+$/i,
                                message: "Please enter valid name.",
                              },
                              {
                                pattern: /^([^0-9]*)$/,
                                message: "Number not allow in full name",
                              },
                            ]}
                          />
                        </Row>
                        <Row>
                          <CustomInput label="Email address" className="form-item" name="emailId" type="email" size="large" placeholder="Enter your email address" required />
                        </Row>
                        <Row>
                          <label className="step-label   mb-1">Mobile Number</label>
                          <div className="d-flex group_input">
                            <div className="w-25 ">
                              {/* <Form.Item
                                className="form-item"
                                name="mobilePhoneCode"
                                rules={[
                                  {
                                    required: true,
                                    message: "Please select your Country Code.",
                                  },
                                ]}
                              >
                                <Select placeholder="Select phone Code" size="large" className="w-100">
                                  {state.phoneCodes.map((phoneCode, i) => {
                                    return <Option key={i} value={phoneCode.countryPhoneCode}>{`+${phoneCode.countryPhoneCode} (${phoneCode.countryName})`}</Option>;
                                  })}
                                </Select>
                              </Form.Item> */}
                              <CustomInput placeholder="Select phone Code" type="select" className="form-item" name="mobilePhoneCode" showLabel={false} required label="Country Code">
                                {state.phoneCodes.map((phoneCode, i) => {
                                  return <Option key={i} value={phoneCode.countryPhoneCode}>{`+${phoneCode.countryPhoneCode} (${phoneCode.countryName})`}</Option>;
                                })}
                              </CustomInput>
                            </div>
                            <div className="w-75">
                              {/* <Form.Item
                                name="mobileNo"
                                rules={[
                                  {
                                    required: true,
                                    message: "Please enter your mobile number",
                                  },
                                  {
                                    pattern: /^[0-9\b]+$/,
                                    message: "Only numbers allowed",
                                  },
                                  {
                                    min: 10,
                                    max: 10,
                                    message: "Mobile Number must be 10 digits",
                                  },
                                ]}
                              >
                                <Input placeholder="Enter your mobile number" size="large" />
                              </Form.Item> */}
                              <CustomInput
                                className="form-item"
                                name="mobileNo"
                                showLabel={false}
                                label="Mobile Number"
                                validationRules={[
                                  {
                                    pattern: /^[0-9\b]+$/,
                                    message: "Only numbers allowed",
                                  },
                                ]}
                                min={10}
                                max={10}
                                placeholder="Enter your mobile number"
                                size="large"
                                required
                              />
                            </div>
                          </div>
                        </Row>
                      </Col>
                      <Col>
                        <Row>
                          {/* <label className="step-label">Select category</label>
                          <Form.Item
                            name={"category"}
                            rules={[
                              {
                                required: true,
                                message: "Select category",
                              },
                            ]}
                          >
                            <Select placeholder="Select" size="large">
                              <Option value="Money Transfer">Money Transfer</Option>
                              <Option value="Safety &amp; Security Concern">Safety &amp; Security Concern</Option>
                              <Option value="Data Privacy Concern">Data Privacy Concern</Option>
                              <Option value="Web Page not working">Web Page not working</Option>
                              <Option value="Any Other">Any Other</Option>
                            </Select>
                          </Form.Item> */}
                          <CustomInput type="select" label="Select category" name={"category"} placeholder="Select" size="large" required>
                            <Option value="Money Transfer">Money Transfer</Option>
                            <Option value="Safety &amp; Security Concern">Safety &amp; Security Concern</Option>
                            <Option value="Data Privacy Concern">Data Privacy Concern</Option>
                            <Option value="Web Page not working">Web Page not working</Option>
                            <Option value="Any Other">Any Other</Option>
                          </CustomInput>
                        </Row>
                        <Row>
                          {/* <label className="step-label">Describe your Issue </label>
                          <Form.Item
                            name={"comments"}
                            rules={[
                              {
                                required: true,
                                message: "Enter Describtion",
                              },
                            ]}
                          >
                            <TextArea className="bg-secondary-light" style={{ resize: "none", height: "12.2rem" }} autoComplete="none" />
                          </Form.Item> */}
                          <CustomInput label="Describe your Issue" name={"comments"} required>
                            <TextArea className="bg-secondary-light" style={{ resize: "none", height: "12.2rem" }} autoComplete="none" />
                          </CustomInput>
                        </Row>
                      </Col>
                    </Row>
                    <div className="col-12 text-end">
                      <button className="btn btn-sm btn-light text-primary px-3" htmlType="submit">
                        Submit
                      </button>
                    </div>
                  </Form>
                )}
              </div>
            </div>
          </div>
        </div>
      </Spinner>
    </React.Fragment>
  );
}
