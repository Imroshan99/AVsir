import { useSelector } from "react-redux";
import Dashboard from "../Layouts/Dashboard";
import RaiseIssueFlowOne from "./RaiseAnIssueFlowOne/RaiseIssueFlowOne";
import { useOutletContext } from "react-router-dom";
import { useEffect } from "react";
const RaiseIssue = (props) => {
  const AuthReducer = useSelector((state) => state.user);
  const temp = AuthReducer.groupIdSettings?.theme?.SIGN;
  const templateFlow = AuthReducer.groupIdSettings?.raiseIssue?.flow;
  const { setTitle } = useOutletContext();
  useEffect(() => {
    setTitle("Raise Issue");
  }, []);
  return (
    <>
      {templateFlow === "FLOW1" && (
        <RaiseIssueFlowOne
          appState={props.appState}
          manageAuth={props.manageAuth}
        />
      )}
      {templateFlow === "FLOW2" && (
        <RaiseIssueFlowOne
          appState={props.appState}
          manageAuth={props.manageAuth}
        />
      )}
    </>
  );
};

export default RaiseIssue;
