import React, { useState, useEffect, useReducer, Fragment } from "react";
import { Table, Spin } from "antd";
import { DeleteOutlined, EditOutlined } from "@ant-design/icons";
import { Link, useNavigate } from "react-router-dom";
import { ReceiverAPI } from "../../../../apis/ReceiverAPI";
import Swal from "sweetalert2";
import { config } from "../../../../config";
import { useSelector } from "react-redux";
import { encrypt, decrypt, publickey } from "../../../../helpers/makeHash";
import useHttp from "../../../../hooks/useHttp";
import RecipientInfo2 from "../../RecipientInfo/RecipientInfoFlow2/RecipientInfo";
import RecipientInfo1 from "../../RecipientInfo/RecipientInfoFlow1/RecipientInfo";

function RecipientList(props) {
  const navigate = useNavigate();
  const AuthReducer = useSelector((state) => state.user);
  const ConfigReducer = useSelector((state) => state.user);
  // console.log(ConfigReducer)
  const recipientListConfig =
    ConfigReducer.groupIdSettings.recipientModule.recipientList;
  const templateFlow =
    AuthReducer.groupIdSettings?.recipientModule?.RecipientInfo?.flow;
  const [loading, setLoader] = useState(false);
  const [state, setState] = useReducer(
    (state, newState) => ({ ...state, ...newState }),
    {
      receiverLists: [],
      clientId: AuthReducer.clientId,
      groupId: AuthReducer.groupId,
      sessionId: AuthReducer.sessionId,
      userID: AuthReducer.userID,
      isModalVisible: false,
      modalRecipientsDetails: {},
    }
  );

  const hookGetReceiverLists = useHttp(ReceiverAPI.receiverLists);
  const hookViewRecipientsDetails = useHttp(ReceiverAPI.viewRecipientsDetails);
  const hookDeleteReceiver = useHttp(ReceiverAPI.deleteReceiver);

  useEffect(async () => {
    getReceiverLists();
  }, []);

  const getReceiverLists = () => {
    const payload = {
      requestType: "GETRECVLIST",
      userId: state.userID,
      favouriteFlag: "",
      startIndex: "0",
      recordsPerRequest: "",
      search: "",
      statusFlag: "",
    };

    setLoader(true);
    hookGetReceiverLists.sendRequest(payload, function (data) {
      if (data.status == "S") {
        let resData = [];
        data.responseData.forEach((detail, i) => {
          let data = {
            key: i,
            name: `${detail.firstName} ${detail.lastName}`,
            bankName: `${detail.bankName}`,
            accountNo: `${detail.accountNo}`,
            status: `${detail.status}`,
            recordToken: `${detail.recordToken}`,
            nickName: `${detail.nickName}`,
            bankName: `${detail.bankName}`,
            bankBranch: `${detail.bankBranch}`,
            city: `${detail.city}`,
          };

          resData.push(data);
        });

        setState({
          receiverLists: data.responseData,
        });
      }
      setLoader(false);
    });
  };

  const viewDetailsHandlerClick = (row) => {
    setState({ isModalVisible: true });
    console.log(row);
    const payload = {
      requestType: "RECEIVERINFO",
      userId: state.userID,
      nickName: row.nickName,
      recordToken: row.recordToken,
    };

    setLoader(true);
    hookViewRecipientsDetails.sendRequest(payload, function (data) {
      if (data.status === "S") {
        setState({
          modalRecipientsDetails: data,
        });
        setLoader(false);
      }
    });
  };

  const deleteReceiverHandler = (row) => {
    console.log(row);
    Swal.fire({
      text: "Are you sure you want to delete this receiver?",
      showCancelButton: true,
      denyButtonText: `Cancel`,
      confirmButtonText: "Confirm",
      confirmButtonColor: "#2dbe60",
    }).then((result) => {
      /* Read more about isConfirmed, isDenied below */
      if (result.isConfirmed) {
        // Swal.fire('Saved!', '', 'success')
        const payload = {
          requestType: "GETRECVLIST",
          userId: state.userID,
          nickName: row.nickName,
          recordToken: row.recordToken,
        };

        setLoader(true);
        hookDeleteReceiver.sendRequest(payload, function (data) {
          if (data.status == "S") {
            getReceiverLists();
            setLoader(false);
          }
        });
      } else if (result.isDenied) {
        Swal.fire("Changes are not saved", "", "info");
      }
    });
  };

  const editReceiverHandler = (row) => {
    const payload = {
      requestType: "RECEIVERINFO",
      userId: state.userID,
      nickName: row.nickName,
      recordToken: row.recordToken,
    };
    setLoader(true);
    hookViewRecipientsDetails.sendRequest(payload, function (data) {
      if (data.status === "S") {
        navigate("/edit-recipient", { state: { editRecipientData: data } });
        setLoader(false);
      }
    });
  };

  return (
    <Fragment>
      <Spin spinning={loading} delay={100}>
        <div className="d-flex justify-content-end">
          <Link to={"/add-recipient"} className="btn btn-primary mb-3">
            Add Recipient
          </Link>
        </div>
        {
          <Table
            columns={[
              {
                title: "Name",
                dataIndex: "name",
                render: (text, record, index) => {
                  return `${record.firstName} ${record.lastName}`;
                },
              },
              {
                title: "Bank Name / Wallet",
                dataIndex: "bankName",
              },
              {
                title: "Account No",
                dataIndex: "accountNo",
              },
              {
                title: "Bank Branch",
                dataIndex: "bankBranch",
              },
              {
                title: "City",
                dataIndex: "city",
              },
              {
                title: `Status `,
                dataIndex: "status",
                className: `${
                  recipientListConfig.columns.status == "DISABLED" &&
                  "hide__column"
                }`,
              },
              {
                title: "",
                dataIndex: "",
                key: "x",
                render: (text, record, index) => {
                  return (
                    <a i={index} onClick={() => viewDetailsHandlerClick(text)}>
                      View Details
                    </a>
                  );
                },
              },
              {
                title: "",
                dataIndex: "",
                key: "y",
                render: (text, record, index) => {
                  return (
                    <>
                      <span className="px-2">
                        <EditOutlined
                          i={index}
                          onClick={() => editReceiverHandler(text)}
                        />
                      </span>
                      <span>
                        <DeleteOutlined
                          i={index}
                          onClick={() => deleteReceiverHandler(text)}
                        />
                      </span>
                    </>
                  );
                },
              },
            ]}
            dataSource={state.receiverLists}
            pagination={false}
          />
        }
        {templateFlow === "FLOW1" ? (
          <RecipientInfo1
            // afterClose={afterClose}
            state={state}
            // spinner={spinner}
            setState={setState}
          />
        ) : (
          <RecipientInfo2 state={state} setState={setState} />
        )}
      </Spin>
    </Fragment>
  );
}

export default RecipientList;
