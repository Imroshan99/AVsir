import { useSelector } from "react-redux";
import Dashboard from "../Layouts/Dashboard";
import FeedbackFlowOne from "./FeedbackFlowOne/FeedbackFlowOne";
import { useOutletContext } from "react-router-dom";
import { useEffect } from "react";
const Feedback = (props) => {
  const AuthReducer = useSelector((state) => state.user);
  const temp = AuthReducer.groupIdSettings?.theme?.SIGN;
  const templateFlow = AuthReducer.groupIdSettings?.feedback?.flow;
  const { setTitle } = useOutletContext();
  useEffect(() => {
    setTitle("Feedback");
  }, []);
  return (
    <>
      {templateFlow === "FLOW1" && (
        <FeedbackFlowOne
          appState={props.appState}
          manageAuth={props.manageAuth}
        />
      )}
      {templateFlow === "FLOW2" && (
        <FeedbackFlowOne
          appState={props.appState}
          manageAuth={props.manageAuth}
        />
      )}
    </>
  );
};

export default Feedback;
