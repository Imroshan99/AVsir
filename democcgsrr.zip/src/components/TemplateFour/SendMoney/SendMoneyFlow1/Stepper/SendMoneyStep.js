import React, { useState, useEffect, useReducer } from "react";
import { Steps, Button, message, notification, Form } from "antd";
import SendTo from "./SendTo";
import Receiver from "./Receiver";
import Confirm from "./Confirm";
import TransactionSuccess from "./TransactionSuccess";
import Container from "@mui/material/Container";
import Paper from "@mui/material/Paper";
import { createTheme, ThemeProvider } from "@mui/material/styles";
import { useNavigate } from "react-router-dom";
import { useSelector } from "react-redux";
import useHttp from "../../../../../hooks/useHttp";
import { TransactionAPI } from "../../../../../apis/TransactionAPI";
import { GuestAPI } from "../../../../../apis/GuestAPI";
// import SubHeader from "../../../layout/SubHeader";
import { useLocation } from "react-router-dom";
import Spinner from "../../../../../reusable/Spinner";
const theme = createTheme();

const { Step } = Steps;

const SendMoneyStep = () => {
  const navigate = useNavigate();
  const repeatTransactionData = useLocation();
  const [bookingPage, setBookingPage] = useState();
  const AuthReducer = useSelector((state) => state.user);
  const ConfigReducer = useSelector((state) => state.user);
  const defaultSettings = ConfigReducer.groupIdSettings.default;
  const [form] = Form.useForm();
  const [state, setState] = useReducer(
    (state, newState) => ({ ...state, ...newState }),
    {
      clientId: AuthReducer.clientId,
      groupId: AuthReducer.groupId,
      sessionId: AuthReducer.sessionId,
      userID: AuthReducer.userID,
      activeStep: 0, //New for template 2
      receiverCountryLists: [], //New for template 2
      sendCountryList: [], //New for template 2
      deliveryOptionsList: [], //New for template 2
      amountSaved: "", //New for template 2

      isStep: 1,
      innerTitle: "Send Money",
      transactionLists: [],
      favouriteTransactionLists: [],
      receiverLists: [],
      bankAccountLists: [],
      sourceOFFundLists: [],
      purposeLists: [],
      subPurposeLists: [],
      globalpayData: [],
      categoryPromoLists: [],
      paymentOptionsList: [],

      promoCode: "",
      programCode: defaultSettings.programCode,
      tempSendAmount: 0,
      sendAmount: 0,
      repeatSendAmount: 0,
      recvAmount: 0,
      transferFee: 0,
      totalFee: 0,
      amountPayable: 0,
      displayExRate: 0,
      netRecvAmount: 0,
      isDenefit: false,
      applyPromoCode: false,
      isSelectedBankTransfer: true,
      receiverName: "",
      purposeID: "",
      purposeName: "",
      subPurposeID: "",
      subPurposeName: "",
      sendAccId: "",
      achAccId: "",
      accountNo: "",
      senderName: "",
      sourceFundId: "",
      sourceOfFund: "",
      exRateToken: "",
      txnId: "",
      txnRefno: "",
      rpId: "",
      rptRefNo: "",
      globalPayId: "",
      order_id: "",
      initiateDate: "",
      expectedDeliveryDate: "",
      txnReceiptDetails: {},
      nickName: "NEWRECV",
      promoValueWithDesc: "",
      exRateWithPromo: 0,
      promoValue: 0,
      _isScheduleTransaction: false,
      scheduleTransactionDate: "",
      rgtn: "",

      // for transcation book
      isTransactionBook: false,
      loading: false, //spinner,
      exchangeRate: "",

      // repeat transaction
      purposeOfSending: "",
      totalDeliveredAmount: "",
    }
  );
  const [timeoutId, setTimeoutId] = React.useState("");

  const hookGetCategoryPromoLists = useHttp(TransactionAPI.categoryPromoLists);

  const hookGetReceiverLists = useHttp(TransactionAPI.receiverLists);
  const hookGetReceiverCountryLists = useHttp(GuestAPI.receiverCountryList);
  const hookGetSendingCountryList = useHttp(GuestAPI.sendingCountryList);
  const hookGetPaymentOption = useHttp(GuestAPI.paymentOption);
  const hookGetDefaultTransactionList = useHttp(
    TransactionAPI.defaultTransactionList
  );
  const hookGetComputeExchangeRates = useHttp(
    TransactionAPI.computeExchangeRates
  );
  const hookGetDeliveryOptions = useHttp(GuestAPI.deliveryOptions);
  const hookGetPurposeLists = useHttp(TransactionAPI.purposeLists);
  const hookGetBankAccountLists = useHttp(TransactionAPI.getBankAccountLists);
  const hookGetAchAccountLists = useHttp(TransactionAPI.getAchAccountLists);

  const hookGetGlobalpayData = useHttp(TransactionAPI.getGlobalpayData);
  const hookBookTransaction = useHttp(TransactionAPI.bookTransaction);
  const hookTransactionReceiptDetails = useHttp(
    TransactionAPI.transactionReceiptDetails
  );

  const hookGetRepeatTranscationDeatils = useHttp(
    TransactionAPI.repeatTranscationDeatils
  );

  useEffect(() => {
    getCategoryPromoLists();
    getReceiverNameLists();
    getReceiverCountryLists();
    getSendingCountryList();
    getSendingTransferOptionsList();
    getDeliveryOptions();
    getBankAccountLists();
    getPurposeLists();
    if (repeatTransactionData.state == null) {
      getSendingAmountList();
    }
  }, []);

  useEffect(() => {
    if (state.sendingAmount > 0) {
      getComputeExchange(state.sendingAmount);
    }
  }, [state.programCode, state.promoCode]);

  const getCategoryPromoLists = async () => {
    let defaultTransactiondata = {
      requestType: "CATEGORYPROMOLISTS",
      recvCountryCode: AuthReducer.recvCountryCode,
      recvCurrencyCode: AuthReducer.recvCurrencyCode,
      promoAmount: "1000",
      recvModeCode: "DC",
      sendModeCode: "CIP",
      programCode: state.programCode,
      // sendCountryCode: state.groupId == 'ICA' ? "CA" : "GB",
      // sendCurrencyCode: state.groupId == 'ICA' ? "CAD" : "GBP",
      sendCountryCode: AuthReducer.sendCountryCode,
      sendCurrencyCode: AuthReducer.sendCurrencyCode,
      userId: state.userID,
    };

    setState({ loading: true });
    hookGetCategoryPromoLists.sendRequest(
      defaultTransactiondata,
      function (data) {
        if (data.status == "S") {
          setState({ categoryPromoLists: data.responseData });
          setState({ loading: false });
        }
      }
    );
  };

  const getReceiverNameLists = () => {
    const payload = {
      requestType: "GETRECVLIST",
      userId: state.userID,
      favouriteFlag: "",
      startIndex: "0",
      recordsPerRequest: "",
      search: "",
      statusFlag: "VALID",
    };

    setState({ loading: true });
    hookGetReceiverLists.sendRequest(payload, function (data) {
      if (data.status == "S") {
        setState({ receiverLists: data.responseData });
        setState({ loading: false });
      }
    });
  };

  const getReceiverCountryLists = () => {
    const payload = {
      requestType: "RECVCOUNTRYLIST",
      sendCountry: "GB",
      sendCurrency: "GBP",
    };

    setState({ loading: true });
    hookGetReceiverCountryLists.sendRequest(payload, function (data) {
      if (data.status == "S") {
        setState({ receiverCountryLists: data.responseData });
        setState({ loading: false });
      }
    });
  };

  const getSendingCountryList = () => {
    const payload = {
      requestType: "SENDCOUNTRYLIST",
      userId: state.userID,
      favouriteFlag: "",
      startIndex: "0",
      recordsPerRequest: "",
      search: "",
      statusFlag: "VALID",
    };

    setState({ loading: true });
    hookGetSendingCountryList.sendRequest(payload, function (data) {
      if (data.status == "S") {
        setState({ sendCountryList: data.responseData });
        setState({ loading: false });
      }
    });
  };

  const getSendingTransferOptionsList = () => {
    const payload = {
      requestType: "PAYMENTOPTION",
      amount: "1000",
      sendCountryCode: "GB",
      sendCountryCurrency: "GBP",
      recvCountryCode: "IN",
      recvCountryCurrency: "INR",
    };

    setState({ loading: true });
    hookGetPaymentOption.sendRequest(payload, function (data) {
      if (data.status == "S") {
        setState({ paymentOptionsList: data.responseData });
        setState({ loading: false });
      }
    });
  };

  // CIP Mode
  const getBankAccountLists = () => {
    const payload = {
      requestType: "SENDERACCOUNTLIST",
      countryCode: AuthReducer.sendCountryCode,
      countryId: undefined,
      favouriteFlag: "1",
      recordsPerRequest: "15",
      startIndex: "0",
      userId: state.userID,
    };

    setState({ loading: true });
    hookGetBankAccountLists.sendRequest(payload, function (data) {
      if (data.status == "S") {
        setState({ bankAccountLists: data.responseData });
        setState({ loading: false });
      }
    });
  };

  // ACH Mode
  // const getCipSenderNameList = () => {
  //   const payload = {
  //     requestType: "ACHAccountLists",
  //     userId: state.userID,
  //     countryCode: "GB",
  //     recordsPerRequest: "15",
  //     startIndex: "0",
  //   };

  //   hookGetAchAccountLists.sendRequest(payload, function (data) {
  //     if (data.status == "S") {
  //       setState({ senderNameList: data.responseData });
  //     }
  //   });
  // };

  const getSendingAmountList = () => {
    const payload = {
      requestType: "DEFAULTTXNDTLS",
      recvNickName: state.nickName,
      sendCountryCode: "",
      sendModeCode: "",
      programCode: "",
      userId: state.userID,
    };

    setState({ loading: true });
    hookGetDefaultTransactionList.sendRequest(payload, function (data) {
      if (data.status == "S") {
        setState({ sendingAmount: data.txnAmount });
        getComputeExchange(data.txnAmount);
        setState({ loading: false });
      }
    });
  };

  const handleSendingAmount = (value) => {
    if (value > 0) {
      getComputeExchange(value);
      setState({ sendingAmount: value });
    }
  };

  const getComputeExchange = (data, txnType = "FORWARD") => {
    clearTimeout(timeoutId);

    let valueTimeOutId = setTimeout(
      () => getComputeExchangeRate(data, (txnType = "FORWARD")),
      500
    );
    setTimeoutId(valueTimeOutId);
  };

  const getComputeExchangeRate = (
    data,
    txnType = "FORWARD",
    pageName = "SENDMONEY"
  ) => {
    setState({ loading: true });

    const payload = {
      requestType: "EXCHANGERATE",
      userId: state.userID,
      sendCountryCode: AuthReducer.sendCountryCode,
      sendCurrencyCode: AuthReducer.sendCurrencyCode,
      recvCountryCode: AuthReducer.recvCountryCode,
      recvCurrencyCode: AuthReducer.recvCurrencyCode,
      recvModeCode: "DC",
      recvNickName: state.nickName,
      promoCode: state.promoCode,
      amount: data, //dynamic amount
      sendModeCode: defaultSettings.sendModeCode,
      programCode: state.programCode,
      enteredAmtCurrency:
        txnType === "FORWARD"
          ? AuthReducer.sendCurrencyCode
          : AuthReducer.recvCurrencyCode,
      paymentMode1: "",
      paymentMode2: "",
      pageName: pageName,
    };

    hookGetComputeExchangeRates.sendRequest(payload, function (data) {
      setState({ loading: false });
      if (data.status == "S") {
        setState({
          amountSaved: data.benefit,
          sendAmount: data.sendAmount,
          recvAmount: data.recvAmount,
          transferFee: data.fee,
          displayExRate: data.displayExRate,
          totalDelivered: data.recvAmount,
          sendingCurrencyCode: data.enteredAmtCurrency,
          receivingCurrencyCode: data.recvCurrencyCode,
          exRateToken: data.exRateToken,
          // sendingCurrencyCode: data.sendCurrencyCode,
          initiateDate: data.initiateDate,

          sendCurrencyCode: data.sendCurrencyCode,
          recvCurrencyCode: data.recvCurrencyCode,
          exchangeRate: data.displayExRate,
          expectedDeliveryDate: data.expectedDeliveryDate,
          totalDeliveredAmount: data.amountPayable,
          promoValueWithDesc: data.promoValueWithDesc,
        });
      } else {
        notification.error({ message: data.errorMessage });
      }
    });
  };

  const getDeliveryOptions = () => {
    const payload = {
      requestType: "RECVMODE",
      countryCode: "IN",
    };

    setState({ loading: true });
    hookGetDeliveryOptions.sendRequest(payload, function (data) {
      if (data.status == "S") {
        setState({ deliveryOptionsList: data.responseData });
        setState({ loading: false });
      }
    });
  };

  const getPurposeLists = (nickName) => {
    const payload = {
      requestType: "PurposeList",
      keyword: "",
      nickName: nickName || state.nickName,
      recvCountryCode: AuthReducer.recvCountryCode,
      userId: state.userID,
    };

    setState({ loading: true });
    hookGetPurposeLists.sendRequest(payload, function (data) {
      if (data.status == "S") {
        setState({ purposeLists: data.responseData });
        setState({ loading: false });
      }
    });
  };

  // Submit Functionality start
  const getGlobalpayData = (txnId) => {
    const payload = {
      requestType: "GLOBALPAYDATA",
      rgtn: txnId,
      userId: state.userID,
    };

    setState({ loading: true });
    hookGetGlobalpayData.sendRequest(payload, function (data) {
      if (data.status == "S") {
        setState({
          globalPayId: data.responseData[0].GlobalPayId,
          order_id: data.responseData[0].ORDER_ID,
          isStep: 5,
          globalpayData: data.responseData,
        });
        setState({ loading: false });
      } else {
        notification.error({ message: data.errorMessage });
      }
    });
  };

  const transactionReceiptDetails = (txnRefno) => {
    const payload = {
      requestType: "TXNDETAILS",
      rgtn: "",
      txnRefNo: txnRefno,
      userId: state.userID,
    };

    setState({ loading: true });
    hookTransactionReceiptDetails.sendRequest(payload, function (data) {
      if (data.status == "S") {
        setState({
          isStep: 6,
          txnRefNumber: data.txnRefNumber,
          txnAccountName: data.receiverName,
          txnAccountNumber: data.recvAccNumber,
          txnAccountAddress: data.recvAddress,
          txnSendAmount: data.sendAmount,
        });
        setState({ loading: false });
      } else {
        notification.error({ message: data.errorMessage });
      }
    });
  };

  const bookTransaction = () => {
    setState({
      loading: true,
    });
    const payload = {
      requestType: "BOOKTRANSACTION",
      amount: state.sendingAmount,
      // amount: state.recvAmount,
      corrBankId: "ICIC",
      endDate: "",
      enteredAmtCurrency: AuthReducer.sendCurrencyCode,
      exRateToken: state.exRateToken,
      exchangeRate: "",
      frequency: "",
      methodType: "NOT",
      noOfTransactions: "0",
      outwardFlag: "N",
      paymentMode1: "",
      paymentMode2: "",
      personalMessage: "",
      personalMsg: "",
      premiumCharge: "0.0",
      programCode: state.programCode,
      promoCode: state.promoCode,
      rateBlockFlag: "N",
      recvCountryCode: AuthReducer.recvCountryCode,
      recvCountryCurrency: AuthReducer.recvCurrencyCode,
      recvCurrencyCode: AuthReducer.recvCurrencyCode,
      recvModeCode: "DC",
      recvNickName: state.nickName,
      // achAccId: state.achAccId,
      sendCountryCurrency: AuthReducer.sendCurrencyCode,
      sendCountryCode: AuthReducer.sendCountryCode,
      sendCurrencyCode: AuthReducer.sendCurrencyCode,
      // sendModeCode: "ACH",
      sendModeCode: "CIP",
      sendAccId: state.senderAccId,
      // sendAccId: state.sendAccId,
      sourceOfFunds: "",
      startDate: "",
      transferType: "O",
      twofa: "N",
      txnPurposeDesc: state.purposeOfSending,
      txnPurposeId: state.purposeId,
      txnSubPurposeDesc: "",
      txnSubPurposeId: "",
      txnSubSurposeId: "",
      txnType: "TxnPage",
      userId: state.userID,
    };

    setState({ loading: true });
    hookBookTransaction.sendRequest(payload, function (data) {
      setState({
        loading: false,
      });
      if (data.status == "S") {
        if (state.isSelectedBankTransfer) {
          setState({
            txnId: data.txnId,
            txnRefno: data.txnRefno,
            isStep: 6,
          });
          setBookingPage(true);
          transactionReceiptDetails(data.txnRefno);
          setState({ loading: false });
        } else {
          setState({
            txnId: data.txnId,
            txnRefno: data.txnRefno,
            isStep: 5,
          });
          getGlobalpayData(data.txnId);
          setState({ loading: false });
        }
      } else {
        notification.error({ message: data.errorMessage });
      }
    });
  };

  const handleSubmit = () => {
    if (state.activeStep == 2) {
      bookTransaction();
      // setBookingPage(true);
    }
  };

  const steps = [
    {
      title: "Add Details",
      content: (
        <SendTo
          state={state}
          setState={setState}
          getReceiverNameLists={getReceiverNameLists}
          handleSendingAmount={handleSendingAmount}
          defaultSendingAmount={state.sendingAmount}
          getPurposeLists={getPurposeLists}
          getComputeExchange={getComputeExchange}
          getBankAccountLists={getBankAccountLists}
          // callComputeExchange={callComputeExchange}
        />
      ),
    },
    {
      title: "Review",
      content: <Receiver state={state} setState={setState} />,
    },
    {
      title: "Confirm",
      content: (
        <Confirm
          state={state}
          setState={setState}
          handleSubmit={handleSubmit}
          transactionReceiptDetails={transactionReceiptDetails}
          getComputeExchangeRate={getComputeExchangeRate}
        />
      ),
    },
  ];

  return (
    <React.Fragment>
      {/* <SubHeader
        isTransactionBook={state.isTransactionBook}
        txnRefNumber={state.txnRefNumber}
      /> */}
      <div className="template2__main">
        <div className="sendmoney__page">
          <ThemeProvider theme={theme}>
            {bookingPage ? (
              ""
            ) : (
              <div className="sendmoney_page_stepper">
                <div className="container">
                  <Steps current={state.activeStep}>
                    {steps.map((item) => (
                      <Step key={item.title} title={item.title} />
                    ))}
                  </Steps>
                </div>
              </div>
            )}
            <Spinner spinning={state.loading}>
              <div>
                {bookingPage ? (
                  <TransactionSuccess state={state} setState={setState} />
                ) : (
                  <div className="p-3">
                    <div className="steps-content">
                      {steps[state.activeStep].content}
                    </div>
                    <br />
                  </div>
                )}
              </div>
            </Spinner>
          </ThemeProvider>
        </div>
      </div>
    </React.Fragment>
  );
};

export default SendMoneyStep;
