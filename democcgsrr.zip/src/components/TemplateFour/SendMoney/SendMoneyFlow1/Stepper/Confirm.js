import React, { useState, useEffect, useReducer } from "react";
import Typography from "@mui/material/Typography";
import List from "@mui/material/List";
import ListItem from "@mui/material/ListItem";
import ListItemText from "@mui/material/ListItemText";
import {
  Form,
  Checkbox,
  Input,
  Button,
  Select,
  Space,
  Radio,
  Modal,
  notification,
} from "antd";
import { Link } from "react-router-dom";
import { useNavigate } from "react-router-dom";
import { useSelector } from "react-redux";
import useHttp from "../../../../../hooks/useHttp";
import { TransactionAPI } from "../../../../../apis/TransactionAPI";
import ViewTransactionDetails from "./ViewTransactionDetails";
import Swal from "sweetalert2";
import CustomInput from "../../../../../reusable/CustomInput";
// import KYCModal from "../../../auth/KYCModal";

const { Option } = Select;

export default function Confirm(props) {
  const [form] = Form.useForm();
  const AuthReducer = useSelector((state) => state.user);
  const [viewDetails, setViewDetails] = useState(false);
  const [promoCode, setPromoCode] = useState("");
  const [isModalVisible, setIsModalVisible] = useState(false);

  const column1 = [
    {
      name: "Sending Mode:",
      price: props.state.selectedPaymentMethod,
    },
    {
      name: "Sending Amount",
      price: props.state.sendingAmount + " " + props.state.sendingCurrencyCode,
    },
    {
      name: "Transfer Fee",
      price: props.state.transferFee + " " + props.state.sendingCurrencyCode,
    },
    {
      name: "Total Delivered",
      price: props.state.sendAmount + " " + props.state.sendingCurrencyCode,
    },
  ];

  const column2 = [
    {
      name: "Fixed Exchange Rate:",
      price: `1 ${props.state.sendCurrencyCode} = ${props.state.displayExRate} ${props.state.recvCurrencyCode}`,
    },
    {
      name: "Exchange Rate As On:",
      price: props.state.initiateDate,
    },
    {
      name: "Receiving Amount:",
      price: props.state.recvAmount + " " + props.state.recvCurrencyCode,
    },
  ];

  const hookGetComputeExchangeRates = useHttp(
    TransactionAPI.computeExchangeRates
  );
  const hookApplyPromoLists = useHttp(TransactionAPI.promoLists);

  const handleTermsCondition = () => {
    props.getComputeExchangeRate(
      props.state.sendingAmount,
      "FORWARD",
      "TXNREVIEW"
    );
  };

  const onFinishAccount = (value) => {
    if (AuthReducer.userKYC === "DOB") {
      Swal.fire({
        title: "Failed",
        text: "Complete your KYC for transcation",
        icon: "warning",
        confirmButtonColor: "#2dbe60",
        allowOutsideClick: false,
        confirmButtonText: `Complete your KYC`,
      }).then((result) => {
        if (result.isConfirmed) {
          setIsModalVisible(true);
        }
      });
    } else {
      props.handleSubmit();
    }
  };

  const handleCouponCodeRadio = (code) => {
    props.setState({ couponCode: false });
    // FinalComputeExchangeRate(code.target.value);
    props.setState({ promoCode: "" });
  };

  const handleCouponCodeText = (e) => {
    setPromoCode(e.target.value);
  };

  const applyPromoCode = (e) => {
    e.preventDefault();
    props.setState({ couponCode: false, loading: true });

    if (promoCode) {
      const payload = {
        requestType: "PROMOLISTS",
        programCode: "FERINST",
        promoAmount: props.state.sendingAmount,
        promoCode: promoCode,
        recvCountryCode: "IN",
        recvCurrencyCode: "INR",
        recvModeCode: "DC",
        sendCountryCode: AuthReducer.sendCountryCode,
        sendCurrencyCode: AuthReducer.sendCurrencyCode,
        sendModeCode: "CIP",
        userId: props.state.userID,
      };

      hookApplyPromoLists.sendRequest(payload, function (data) {
        props.setState({ loading: false });
        if (data.status == "S") {
          props.setState({
            promoCode: promoCode,
          });
        } else {
          notification.error({ message: data.errorMessage });
        }
      });
    } else {
      alert("please enter promo code!");
    }
  };

  return (
    <React.Fragment>
      {/* <KYCModal
        isModalVisible={isModalVisible}
        setIsModalVisible={setIsModalVisible}
      /> */}

      <Modal className="primary" centered visible={viewDetails} onCancel={() => setViewDetails(false)} width={1000} footer={null}>
        <ViewTransactionDetails state={props.state} />
      </Modal>

      <Form form={form} onFinish={onFinishAccount}>
        <h4>Transaction summary</h4>
        <br />
        <div className="row">
          <div className="col col-xs-12 col-sm-6">
            <List disablePadding>
              {column1.map((product) => (
                <ListItem key={product.name} sx={{ py: 1, px: 0 }}>
                  <ListItemText primary={product.name} />
                  <Typography variant="body2">{product.price}</Typography>
                </ListItem>
              ))}
            </List>
          </div>
          <div className="col col-xs-12 col-sm-6">
            <List disablePadding>
              {column2.map((product) => (
                <ListItem key={product.name} sx={{ py: 1, px: 0 }}>
                  <ListItemText primary={product.name} />
                  <Typography variant="body2">{product.price}</Typography>
                </ListItem>
              ))}
            </List>
            <br />
            <br />
            <div className="text-end">
              <span className="text-info" onClick={() => setViewDetails(true)}>
                <u>Know more</u>
              </span>
            </div>
          </div>
        </div>
        <br />
        <div className="row">
          <div className="col col-xs-12 col-sm-6">
            <label className="step-label">Coupon Code / Gift Voucher</label>

            <CustomInput name="couponCode" label="Coupon Code / Gift Voucher" showLabel={false} max={30}>
              <Radio.Group value={props.state.value} onChange={handleCouponCodeRadio}>
                <Space direction="vertical">
                  {props.state.categoryPromoLists.map((clist, i) => {
                    return (
                      <Radio key={i} value={clist.promoCode}>
                        {clist.promoDesc}
                      </Radio>
                    );
                  })}
                </Space>
              </Radio.Group>
              <br />
              <br />
              <Input className="w-50" type="text" onChange={handleCouponCodeText} value={promoCode} />
              <button className="btn btn-secondary ms-3" onClick={applyPromoCode}>
                <span>Apply</span>
              </button>
            </CustomInput>
            {/* <Form.Item
              name="couponCode"
              rules={[
                {
                  required: false,
                  message: "Please input your coupon code.",
                },
                {
                  max: 30,
                  message: "coupon code must be maximum 30 characters.",
                },
              ]}
            >
              <Radio.Group
                value={props.state.value}
                onChange={handleCouponCodeRadio}
              >
                <Space direction="vertical">
                  {props.state.categoryPromoLists.map((clist, i) => {
                    return (
                      <Radio key={i} value={clist.promoCode}>
                        {clist.promoDesc}
                      </Radio>
                    );
                  })}
                </Space>
              </Radio.Group>
              <br />
              <br />
              <Input className="w-50"
                type="text"
                onChange={handleCouponCodeText}
                value={promoCode}
              />
              <button className="btn btn-secondary ms-3" onClick={applyPromoCode}>
                <span>Apply</span>
              </button>
            </Form.Item> */}
            {props.state.promoValueWithDesc !== "" && <p className="text-info">{props.state.promoValueWithDesc}</p>}
          </div>
          <div className="col col-xs-12 col-sm-6">
            <Form.Item
              className="form-item"
              name="readTermsConditions"
              valuePropName="checked"
              onChange={handleTermsCondition}
              rules={[
                {
                  validator: (_, value) => (value ? Promise.resolve() : Promise.reject(new Error("Please confirm terms and conditions."))),
                },
              ]}
            >
              <Checkbox>
                I accept and agree to the{" "}
                <Link to="/terms-and-conditions" target="_blank">
                  <u>Terms and Conditions</u>
                </Link>
              </Checkbox>
            </Form.Item>

            <Form.Item
              className="form-item"
              name="paymentService"
              valuePropName="checked"
              // onChange={handleTermsCondition}
              rules={[
                {
                  validator: (_, value) => (value ? Promise.resolve() : Promise.reject(new Error("Please confirm terms and conditions."))),
                },
              ]}
            >
              <Checkbox>
                I agree &amp; understand that the Payment Services provided through the website URL www.xmonies.com in United Kingdom will be processed by our compliance partner Rational Foreign Exchange Ltd. Rational Foreign Exchange Ltd is authorised by the Financial Conduct Authority (FRN: 507958) under the Payment Services Regulations 2009, for the provision of payment services. Issued by HM Revenue &amp; Customs (HMRC) Rational Foreign Exchange Ltd trading as RationalFX is a registered
                Money Service Business (MSB) - Money Laundering Regulation number: 12206957.
              </Checkbox>
            </Form.Item>
          </div>
        </div>

        <div className="row">
          <div className="col-6">
            <button className="btn btn-primary-light me-2" onClick={() => props.setState({ activeStep: 1 })}>
              Back
            </button>
          </div>
          <div className="col-6 text-end">
            <button htmlType="submit" className="btn btn-primary">
              Confirm
            </button>
          </div>
        </div>
      </Form>
    </React.Fragment>
  );
}
