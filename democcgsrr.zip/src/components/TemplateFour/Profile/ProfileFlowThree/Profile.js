import React, { useEffect, useReducer } from "react";
import { config } from "../../../../config";
import { useSelector } from "react-redux";
import { Collapse, Row, Col, notification, Tabs } from "antd";
import EditMarketingBox from "../../../../containers/EditMarketingBox";
import { ProfileAPI } from "../../../../apis/ProfileAPI";
import useHttp from "../../../../hooks/useHttp";
import { GuestAPI } from "../../../../apis/GuestAPI";
import OTPBox from "../../../../containers/OTPBox";
import EditAddressBox from "../../../../containers/EditAddressBox";
import EditContactBox from "../../../../containers/EditContactBox"; //same in folder
 

const { Panel } = Collapse;

function Profile(props) {
  const AuthReducer = useSelector((state) => state.user);
  const ConfigReducer = useSelector((state) => state.user);
  const profileConfig = ConfigReducer.groupIdSettings.profileModule;
  // alert(profileConfig.twoFA)
  const [state, setState] = useReducer(
    (state, newState) => ({ ...state, ...newState }),
    {
      clientId: AuthReducer.clientId,
      groupId: AuthReducer.groupId,
      sessionId: AuthReducer.sessionId,
      userID: AuthReducer.userID,
      twofa: profileConfig.twoFA,
      firstName: "",
      middleName: "",
      lastName: "",
      emailId: "",
      dob: "",
      editableMobileNo: "",
      editablemobilePhoneCode: "",
      mobilePhoneCode: "",
      mobileNo: "",
      gender: "",
      citizenship: "",
      citizenshipDesc: "",
      nationality_id: "",
      nationalityDesc: "",
      occupation_id: "",
      occupationDesc: "",
      profession_id: "",
      professionDesc: "",
      isSameCommAddressFlag: "",
      marketCommunication: "",
      address1: "",
      address3: "",
      city: "",
      state: "",
      country: AuthReducer.sendCountryCode,
      zip: "",
      income_id: "",
      incomeDesc: "",
      countryPhoneCodes: [],
      occupationLists: [],
      professionLists: [],
      incomeLists: [],
      _isShowAddressEditModel: false,
      _isShowContactEditModel: false,
      _isShowMarketingEditModel: false,
      _isShowAddressOTPBOX: false,
      _isShowContactOTPBOX: false,
      _isShowMarketingOTPBOX: false,
      isModalVisible: false,
      verificationToken: "",
      verifiedToken: "",

      senderContactDetailsErrors: [],
      // formSubmit: false,
    }
  );

  const hookGetProfile = useHttp(ProfileAPI.getProfile);
  const hookGetIncomeLists = useHttp(ProfileAPI.incomeLists);
  const hookSendOTP = useHttp(ProfileAPI.sendOTP);
  const hookEditProfile = useHttp(ProfileAPI.editProfile);
  const hookEditSenderContactdtls = useHttp(ProfileAPI.editSenderContactdtls);
  const hookGetCountryPhoenCodes = useHttp(GuestAPI.getCountryPhoneCodes);
  const hookGetOccupationLists = useHttp(GuestAPI.occupationLists);
  const hookGetProfessionLists = useHttp(GuestAPI.professionLists);

  useEffect(async () => {
    getProfile();
    countryPhoneCodes();
    incomeLists();
    occupationLists();
    professionLists();
  }, []);

  const getProfile = () => {
    let payload = {
      requestType: "LEAD",
      userId: state.userID,
    };

    hookGetProfile.sendRequest(payload, function (data) {
      if (data.status == "S") {
        setState({
          firstName: data.firstName,
          middleName: data.middleName,
          lastName: data.lastName,
          emailId: data.emailId,
          dob: data.dob,
          mobileNo: data.mobileNo,
          gender: data.gender,
          mobilePhoneCode: data.mobilePhoneCode,
          citizenship: data.citizenship,
          citizenshipDesc: data.citizenshipDesc,
          nationality_id: data.nationality,
          nationalityDesc: data.nationalityDesc,
          occupation_id: data.occupation,
          occupationDesc: data.occupationDesc,
          profession_id: data.profession,
          professionDesc: data.professionDesc,
          address1: data.address1,
          address3: data.address3,
          city: data.city,
          state: data.state,
          zip: data.zip,
          income_id: data.income,
          incomeDesc: data.incomeDesc,
          isSameCommAddressFlag: data.isSameCommAddressFlag,
          marketCommunication: data.marketCommunication,
        });
      }
    });
  };

  const countryPhoneCodes = () => {
    let payload = {
      requestType: "LEAD",
    };

    hookGetCountryPhoenCodes.sendRequest(payload, function (data) {
      if (data.status === "S") {
        setState({ phoneCodes: data.responseData });
      }
    });
  };

  const occupationLists = () => {
    let payload = {
      requestType: "LEAD",
    };

    hookGetOccupationLists.sendRequest(payload, function (data) {
      if (data.status === "S") {
        setState({ occupationLists: data.responseData });
      }
    });
  };

  const professionLists = () => {
    let payload = {
      requestType: "LEAD",
    };

    hookGetProfessionLists.sendRequest(payload, function (data) {
      if (data.status == "S") {
        setState({ professionLists: data.responseData });
      }
    });
  };

  const incomeLists = () => {
    let payload = {
      requestType: "LEAD",
      userId: state.userID,
    };

    hookGetIncomeLists.sendRequest(payload, function (data) {
      if (data.status === "S") {
        setState({ incomeLists: data.responseData });
      }
    });
  };

  const sendOTP = (otpType, otpFor) => {
    const OTPData = {
      requestType: "SENDOTP",
      mobilePhoneCode: state.mobilePhoneCode,
      mobileNo:
        state.editableMobileNo == "" ? state.mobileNo : state.editableMobileNo,
      emailId: state.emailId,
      otpType: otpType,
      senderName: "",
      // userId: otpFor == "Edit_Contact" ? undefined : state.userID,
      userId: state.userID,
    };

    hookSendOTP.sendRequest(OTPData, function (data) {
      if (data.status == "S") {
        setState({
          verificationToken: data.verificationToken,
        });
        setTimeout(() => {
          if (otpFor == "Edit_Address") {
            setState({
              _isShowAddressOTPBOX: true,
              _isShowContactOTPBOX: false,
              _isShowMarketingOTPBOX: false,
              isModalVisible: true,
            });
          } else if (otpFor == "Edit_Contact") {
            setState({
              _isShowAddressOTPBOX: false,
              _isShowContactOTPBOX: true,
              _isShowMarketingOTPBOX: false,
              isModalVisible: true,
            });
          } else if (otpFor == "Edit_Marketing") {
            setState({
              _isShowAddressOTPBOX: false,
              _isShowContactOTPBOX: false,
              _isShowMarketingOTPBOX: true,
              isModalVisible: true,
            });
          }
        }, 100);
      } else {
        notification.error({ message: data.errorMessage });
      }
    });
  };

  const editProfile = (verifiedToken) => {
    const editProfileData = {
      requestType: "EDITPROFILE",
      SIN: undefined,
      address1: window.btoa(state.address1),
      address2: "",
      address3: window.btoa(state.address3),
      address4: "",
      address5: "",
      citizenship: state.citizenship,
      city: window.btoa(state.city),
      commAddress1: "",
      commAddress2: "",
      commCity: "",
      commCountry: "",
      commPostalCode: "",
      commStateProvince: "",
      companyName: "",
      dob: state.dob,
      gender: state.gender,
      homePhoneNo: "",
      income: state.income_id,
      industry: "",
      periodicUpdate: state.isSameCommAddressFlag,
      isSameCommAddressFlag: state.isSameCommAddressFlag,
      marketCommunication: state.marketCommunication,
      motherMaidenName: "",
      nationality: state.nationality_id,
      occupation: state.occupation_id,
      pageName: "EDITPROFILE",
      pep: "",
      primaryBusinessFunction: "",
      profession: state.profession_id === "" ? "1" : state.profession_id,
      salutation: "",
      sendCountry: AuthReducer.sendCountryCode,
      state: window.btoa(state.state),
      tnc: "",
      zipCode: state.zip,
      userId: state.userID,
    };

    hookEditProfile.sendRequest(editProfileData, function (data) {
      if (data.status == "S") {
        setState({
          _isShowAddressEditModel: false,
          _isShowContactEditModel: false,
          _isShowMarketingEditModel: false,
          _isShowAddressOTPBOX: false,
          _isShowContactOTPBOX: false,
          _isShowMarketingOTPBOX: false,
          isModalVisible: false,
        });
        notification.success({ message: data.message });
      } else {
        setState({
          isModalVisible: false,
        });
        notification.error({ message: data.errorMessage });
      }
      getProfile();
    });
  };

  const editSenderContactdtls = (verifiedToken) => {
    const contactData = {
      requestType: "editContactProfile",
      areaCode: "",
      emailId: state.emailId,
      mobilePhoneCode: state.mobilePhoneCode,
      mobileNo: state.editableMobileNo,
      phoneNo: "",
      sendCountryCode: AuthReducer.sendCountryCode,
      verifiedToken: verifiedToken,
      userId: state.userID,
      twofa: state.twofa, //for otp
    };

    hookEditSenderContactdtls.sendRequest(contactData, function (data) {
      if (data.status == "S") {
        setState({
          _isShowAddressEditModel: false,
          _isShowContactEditModel: false,
          _isShowMarketingEditModel: false,
          _isShowAddressOTPBOX: false,
          _isShowContactOTPBOX: false,
          _isShowMarketingOTPBOX: false,
          isModalVisible: false,
          mobilePhoneCode: state.editablemobilePhoneCode,
          mobileNo: state.editableMobileNo,
          editablemobilePhoneCode: "",
          editableMobileNo: "",
        });
        notification.success({ message: data.message });
      } else {
        setState({
          isModalVisible: false,
        });

        notification.error({ message: data.errorMessage });
        setState({
          senderContactDetailsErrors: data.errorList,
        });
      }
      getProfile();
    });
  };

  const renderGender = () => {
    if (state.gender === "M") {
      return "Male";
    } else if (state.gender === "F") {
      return "Female";
    } else {
      return state.gender;
    }
  };

  return (
    <div className="mt-4">
      {/* <DefaultLayout
        accessToken={props.appState.accessToken}
        isLoggedIn={props.appState.isLoggedIn}
        publicKey={props.appState.publicKey}
      > */}

      <div className="card p-4 mb-4 profile-tab">
        {/* {state.profession_id} */}
        <Tabs defaultActiveKey="1"  >
          <Tabs.TabPane   tab="Personal Information" key="1">
            <Row justify="space-between">
              <Col span={12}>
                <h6>First Name</h6>
                <p>{state.firstName}</p>
              </Col>
              <Col span={12}>
                <h6>Last Name</h6>
                <p>{state.lastName}</p>
              </Col>
            </Row>
            <Row justify="space-between">
              <Col span={12}>
                <h6>Date Of Birth</h6>
                <p>{state.dob}</p>
              </Col>
              <Col span={12}>
                <h6>Gender</h6>
                <p>{renderGender()}</p>
              </Col>
            </Row>
          </Tabs.TabPane>
          <Tabs.TabPane tab="Current Address" key="2">
            <Row justify="space-between">
              <Col span={12} className="d-block">
                <h6>Country</h6>
                <p>{state.country}</p>
              </Col>
              <Col span={12} className="text-end ">
                <h6>District</h6>
                <p>{state.state} </p>
              </Col>
            </Row>
            <Row justify="space-between">
              <Col span={12} className="d-block">
                <h6>Address</h6>
                <p>{state.address1}</p>
              </Col>
              <Col span={12} className="text-end ">
                <h6>Citizenship</h6>
                <p>{state.citizenshipDesc}</p>
              </Col>
            </Row>
            <Row justify="space-between">
              {/* <Col span={12} className="d-block">
            <h6>House/ Building Name</h6>
            <p>{state.address3}</p>
          </Col> */}
              {/* <Col span={24} className="text-end ">
            <h6>Citizenship</h6>
            <p>{state.citizenshipDesc}</p>
          </Col> */}
            </Row>
            {/* <Row justify="space-between">
          <Col span={12} className="d-block">
            <h6>Street Name</h6>
            <p>{state.address1}</p>
          </Col>
          <Col span={12} className="text-end ">
            <h6>Annual Income</h6>
            <p>{state.incomeDesc}</p>
          </Col>
        </Row> */}

            <Row justify="space-between">
              <Col span={12} className="d-block">
                <h6>Post Town</h6>
                <p>{state.city}</p>
              </Col>
              <Col span={12} className="text-end ">
                <h6>Postcode</h6>
                <p>{state.zip}</p>
              </Col>
            </Row>
            <Row justify="space-between">
              <Col span={12} className="d-block">
                <h6>Occupation</h6>
                <p>{state.occupationDesc}</p>
              </Col>
              {/* <Col span={12} className="text-end ">
            <h6>Employment Status</h6>
            <p>{state.professionDesc}</p>
          </Col> */}
            </Row>

            <Row justify="space-between">
              <Col span={12}>
                <button
                  className="btn btn-primary text-white px-5 mx-4 my-4"
                  onClick={() => setState({ _isShowAddressEditModel: true })}
                >
                  Edit
                </button>
              </Col>
            </Row>
          </Tabs.TabPane>
          <Tabs.TabPane tab="Contact details" key="3">
            <Row justify="space-between">
              <Col span={12}>
                <h6>Country Code</h6>
                <p>+{state.mobilePhoneCode}</p>
              </Col>
              <Col span={12}>
                <h6>Mobile</h6>
                <p>{state.mobileNo}</p>
              </Col>
            </Row>
            <Row justify="space-between">
              <Col span={12}>
                <h6>Communication Email ID</h6>
                <p>{state.emailId}</p>
              </Col>
            </Row>

            <Row justify="space-between">
              <Col span={12}>
                <button
                  className="btn btn-primary text-white px-5 mx-4 my-4"
                  onClick={() => setState({ _isShowContactEditModel: true })}
                >
                  Edit
                </button>
              </Col>
            </Row>
          </Tabs.TabPane>
          <Tabs.TabPane tab="Acount details" key="4">
            <Row justify="space-between">
              <Col span={24}>
                <h6>User ID</h6>
                <p>{state.emailId}</p>
              </Col>
            </Row>
          </Tabs.TabPane>
        </Tabs>
      </div>
      {/* </DefaultLayout> */}

      {state._isShowAddressEditModel && (
        <EditAddressBox
          state={state}
          setState={setState}
          sendOTP={sendOTP}
          editProfile={editProfile}
        />
      )}

      {state._isShowAddressOTPBOX && (
        <OTPBox
          state={state}
          setState={setState}
          otpType="EP"
          useFor="Edit_Address"
          appState={props.appState}
          editProfile={editProfile}
        />
      )}

      {state._isShowContactEditModel && (
        <EditContactBox
          state={state}
          setState={setState}
          sendOTP={sendOTP}
          editSenderContactdtls={editSenderContactdtls}
        />
      )}

      {state._isShowContactOTPBOX && (
        <OTPBox
          state={state}
          setState={setState}
          otpType="CU"
          useFor="Edit_Contact"
          appState={props.appState}
          editSenderContactdtls={editSenderContactdtls}
        />
      )}

      {state._isShowMarketingEditModel && (
        <EditMarketingBox state={state} setState={setState} sendOTP={sendOTP} />
      )}

      {state._isShowMarketingOTPBOX && (
        <OTPBox
          state={state}
          setState={setState}
          otpType="EP"
          useFor="Edit_Marketing"
          appState={props.appState}
          editProfile={editProfile}
        />
      )}
    </div>
  );
}

export default Profile;
