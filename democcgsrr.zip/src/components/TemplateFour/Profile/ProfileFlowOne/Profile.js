import React, { useEffect, useReducer, useState } from "react";
import { ProfileAPI } from "../../../../apis/ProfileAPI";
import { useSelector } from "react-redux";
import { Row, Col, notification, Input, Form, Select } from "antd";
import { Modal } from "antd";
import EditAddressBox from "../../containers/EditAddressBox";
import EditContactBox from "../../containers/EditContactBox";

import { useNavigate } from "react-router-dom";
import KycModalFlowOne from "../../Kyc/KycFlowOne/KycModalFlowOne";
import Spinner from "../../../../reusable/Spinner";
import useHttp from "../../../../hooks/useHttp";
import { GuestAPI } from "../../../../apis/GuestAPI";
import { TransactionAPI } from "../../../../apis/TransactionAPI";
import EditDetailsBox from "../../containers/EditDetailsBox";
import EditAdress from "./EditAddressModal";
import CustomInput from "../../../../reusable/CustomInput";

function Profile(props) {
  const [form] = Form.useForm();
  const AuthReducer = useSelector((state) => state.user);
  const ConfigReducer = useSelector((state) => state.user);
  const [loader, setLoader] = useState(false);
  const navigate = useNavigate();
  const [isModalVisible, setIsModalVisible] = useState(false);
  const [isModalVisible1, setIsModalVisible1] = useState(false);
  const profileConfig = ConfigReducer.groupIdSettings.profileModule;
  // alert(profileConfig.twoFA)
  const [state, setState] = useReducer(
    (state, newState) => ({ ...state, ...newState }),
    {
      clientId: AuthReducer.clientId,
      groupId: AuthReducer.groupId,
      sessionId: AuthReducer.sessionId,
      userID: AuthReducer.userID,
      twofa: profileConfig.twoFA,
      firstName: "",
      middleName: "",
      lastName: "",
      emailId: "",
      dob: "",
      editableMobileNo: "",
      editablemobilePhoneCode: "",
      mobilePhoneCode: "",
      mobileNo: "",
      phoneNo: "",
      gender: "",
      citizenship: "",
      citizenshipDesc: "",
      nationality_id: "",
      nationalityDesc: "",
      occupation_id: "",
      occupationDesc: "",
      occupationName: "",
      sourceFundId: "",
      sourceOfFund: "",
      frequency: "",
      profession_id: "",
      professionDesc: "",
      isSameCommAddressFlag: "",
      marketCommunication: "",
      address1: "",
      address3: "",
      city: "",
      state: "",
      country:
        AuthReducer.sendCountryCode == "GB"
          ? "United Knigdom"
          : AuthReducer.sendCountryCode,
      zip: "",
      income_id: "",
      incomeDesc: "",
      countryPhoneCodes: [],
      occupationLists: [],
      professionLists: [],
      address2: "",
      incomeLists: [],
      _isShowAddressEditModel: false,
      _isShowContactEditModel: false,
      _isShowMarketingEditModel: false,
      _isShowAddressOTPBOX: false,
      _isShowContactOTPBOX: false,
      _isShowMarketingOTPBOX: false,
      _isEditPhoneModal: false,
      _isShowEditDetailModal: false,
      isModalVisible: false,
      _editAddressBoxBtn: false,
      verificationToken: "",
      verifiedToken: "",
      citizenshipLists: [],
      senderContactDetailsErrors: [],
      stateLists: [],
      cityLists: [],
      newStateList: [],
      editContactTab: "",
      sourceOfFundList: [],
      sourceOfFundId: "",
      otpBoxEmail: false,
      otpVerfiedToken: "",
      twofaAuth: "",
      OTPVerifed: false,
      emailId1: "",
      disabled: false,
      uniqueIdentifierType: "",
    }
  );

  const hookGetProfile = useHttp(ProfileAPI.getProfile);
  const hookGetIncomeLists = useHttp(ProfileAPI.incomeLists);
  const hookSendOTP = useHttp(ProfileAPI.sendOTP);
  const hookEditProfile = useHttp(ProfileAPI.editProfile);
  const hookEditSenderContactdtls = useHttp(ProfileAPI.editSenderContactdtls);
  const hookGetCountryPhoenCodes = useHttp(GuestAPI.getCountryPhoneCodes);
  const hookGetOccupationLists = useHttp(GuestAPI.occupationLists);
  const hookGetProfessionLists = useHttp(GuestAPI.professionLists);
  const hookGetCitizenshipLists = useHttp(GuestAPI.citizenshipLists);
  const hookGetCountryStates = useHttp(GuestAPI.countryStates);
  const hookGetStateCities = useHttp(GuestAPI.stateCities);
  const hookGetSourceOFFundLists = useHttp(TransactionAPI.sourceOFFundLists);

  useEffect(() => {
    getProfile();
    countryPhoneCodes();
    // incomeLists();
    occupationLists();
    getSourceOFFundLists();
    // professionLists();
    // citizenshipLists();
    getStateLists();
  }, []);
  useEffect(() => {
    if (state._editAddressBoxBtn) {
      editProfile(state);
      setState({ _editAddressBoxBtn: false });
    }
  }, [state._editAddressBoxBtn]);
  useEffect(() => {
    occupationLists();
    getSourceOFFundLists();
  }, [state.occupation_id, state.sourceFundId]);

  useEffect(() => {
    if (state.twofaAuth == "N") {
      editSenderContactdtls("");
    }
  }, [state.twofaAuth]);

  const getProfile = () => {
    setLoader(true);
    let payload = {
      requestType: "LEAD",
      userId: state.userID,
    };

    hookGetProfile.sendRequest(payload, function (data) {
      if (data.status == "S") {
        setLoader(false);
        const homePhoneNo = data.homePhoneNo;
        const homePhoneNoArray = homePhoneNo.split("-");

        form.setFieldsValue({
          phoneCountryCode: homePhoneNoArray[0]
            ? homePhoneNoArray[0].replace("+", "")
            : "",
        });
        form.setFieldsValue({
          phoneNo: homePhoneNoArray[1] ? homePhoneNoArray[1] : "",
        });

        setState({
          firstName: data.firstName,
          middleName: data.middleName,
          lastName: data.lastName,
          emailId: data.emailId,
          dob: data.dob,
          mobileNo: data.mobileNo,
          phoneNo: data.homePhoneNo,
          gender: data.gender,
          mobilePhoneCode: data.mobilePhoneCode,
          citizenship: data.citizenship,
          citizenshipDesc: data.citizenshipDesc,
          nationality_id: data.nationality,
          nationalityDesc: data.nationalityDesc,
          occupation_id: data.occupation,
          frequency: data.additionalInfo5,
          sourceFundId: data.sourceOfFundName,
          occupationDesc: data.occupationDesc,
          profession_id: data.profession,
          professionDesc: data.professionDesc,
          address1: data.address1,
          address2: data.address2,
          address3: data.address3,
          city: data.city,
          state: data.state,
          zip: data.zip,
          income_id: data.income,
          incomeDesc: data.incomeDesc,
          isSameCommAddressFlag: data.isSameCommAddressFlag,
          marketCommunication: data.marketCommunication,
          uniqueIdentifierType: data.uniqueIdentifierType,
        });
      } else {
        setLoader(false);
      }
    });
  };
  const getStateLists = async () => {
    let payload = {
      requestType: "STATELIST",
      countryCode: AuthReducer.sendCountryCode,
      keyword: "",
    };

    hookGetCountryStates.sendRequest(payload, function (data) {
      if (data.status === "S") {
        setState({ stateLists: data.responseData });
        const newStateList = [
          ...data.responseData,
          {
            stateCode: "OTHER",
            state: "Other",
          },
        ];
        setState({ newStateList: newStateList });
      }
    });
  };
  const onSelectStateHandler = async (stateCode) => {
    const cityPayload = {
      requestType: "CITILIST",
      countryCode: AuthReducer.sendCountryCode,
      stateCode: stateCode,
    };

    hookGetStateCities.sendRequest(cityPayload, function (data) {
      if (data.status === "S") {
        setState({
          cityLists: data.responseData,
        });
      }
    });
  };

  const editProfile = (value) => {
    const editProfileData = {
      requestType: "EDITPROFILE",
      SIN: undefined,
      address1: window.btoa(state.address1),
      address2: "",
      address3: window.btoa(state.address3),
      address4: "",
      address5: "",
      citizenship: state.citizenship,
      city: window.btoa(state.city),
      commAddress1: "",
      commAddress2: "",
      commCity: "",
      commCountry: "",
      commPostalCode: "",
      commStateProvince: "",
      companyName: "",
      dob: state.dob,
      gender: state.gender,
      homePhoneNo: value.phoneCountryCode
        ? "+" + value.phoneCountryCode + "-" + value.phoneNo
        : state.phoneNo,
      income: state.income_id,
      industry: "",
      periodicUpdate: state.isSameCommAddressFlag,
      isSameCommAddressFlag: state.isSameCommAddressFlag,
      marketCommunication: state.marketCommunication,
      motherMaidenName: "",
      nationality: state.nationality_id,
      occupation: state.occupation_id,
      pageName: "EDITPROFILE",
      pep: "",
      primaryBusinessFunction: "",
      profession: state.profession_id === "" ? "1" : state.profession_id,
      salutation: "",
      sendCountry: AuthReducer.sendCountryCode,
      state: window.btoa(state.state),
      tnc: "",
      zipCode: state.zip,
      userId: state.userID,
      additionalInfo5: state.frequency,
      sourceOfFund: state.sourceOfFundId,
    };
    setLoader(true);
    hookEditProfile.sendRequest(editProfileData, function (data) {
      if (data.status == "S") {
        setLoader(false);
        setState({
          _isShowAddressEditModel: false,
          _isShowEditDetailModal: false,
          _isShowContactEditModel: false,
          _isShowMarketingEditModel: false,
          _isShowAddressOTPBOX: false,
          _isShowContactOTPBOX: false,
          _isShowMarketingOTPBOX: false,
          isModalVisible: false,
          _isEditPhoneModal: false,
        });
        notification.success({ message: data.message });
      } else {
        setLoader(false);
        setState({
          isModalVisible: false,
        });
        setState({ _isEditPhoneModal: false });
        notification.error({ message: data.errorMessage });
      }
      getProfile();
    });
  };
  const citizenshipLists = () => {
    let payload = {
      requestType: "LEAD",
    };

    hookGetCitizenshipLists.sendRequest(payload, function (data) {
      if (data.status == "S") {
        setState({ citizenshipLists: data.responseData });
      }
    });
  };
  const countryPhoneCodes = () => {
    let payload = {
      requestType: "LEAD",
    };

    hookGetCountryPhoenCodes.sendRequest(payload, function (data) {
      if (data.status === "S") {
        setState({ phoneCodes: data.responseData });
      }
    });
  };

  const occupationLists = () => {
    setLoader(true);
    let payload = {
      requestType: "LEAD",
    };

    hookGetOccupationLists.sendRequest(payload, function (data) {
      if (data.status === "S") {
        setState({ occupationLists: data.responseData });
        data.responseData.find((i) => {
          if (i.occupationId == state.occupation_id) {
            setState({ occupationName: i.occupationName });
            setLoader(false);
          }
        });
      }
    });
  };
  const getSourceOFFundLists = () => {
    setLoader(true);
    const payload = {
      requestType: "FUNDSOURCELIST",
    };

    hookGetSourceOFFundLists.sendRequest(payload, function (data) {
      if (data.status == "S") {
        setState({ sourceOfFundList: data.responseData });
        data.responseData.find((i) => {
          if (i.sourceFundId == state.sourceFundId) {
            setState({ sourceOfFund: i.sourceOfFund });
            setLoader(false);
          }
        });
      }
    });
  };

  const professionLists = () => {
    let payload = {
      requestType: "LEAD",
    };

    hookGetProfessionLists.sendRequest(payload, function (data) {
      if (data.status == "S") {
        setState({ professionLists: data.responseData });
      }
    });
  };

  const incomeLists = () => {
    let payload = {
      requestType: "LEAD",
      userId: state.userID,
    };

    hookGetIncomeLists.sendRequest(payload, function (data) {
      if (data.status === "S") {
        setState({ incomeLists: data.responseData });
      }
    });
  };
  const editAddressHandler = () => {
    if (AuthReducer.userKYC == "DOB") {
      setIsModalVisible(true);
    } else {
      setIsModalVisible1(true);
    }
  };
  const sendOTP = (otpType, otpFor) => {
    setLoader(true);
    const OTPData = {
      requestType: "SENDOTP",
      mobilePhoneCode: state.mobilePhoneCode,
      mobileNo:
        state.editableMobileNo == "" ? state.mobileNo : state.editableMobileNo,
      emailId: state.emailId1,
      otpType: otpType,
      senderName: "",
      otpFor: otpFor,
      // userId: otpFor == "Edit_Contact" ? undefined : state.userID,
      userId: state.userID,
    };

    hookSendOTP.sendRequest(OTPData, function (data) {
      if (data.status == "S") {
        notification.success({
          // message: data.message,
          message: "OTP sent to registered mail ID",
        });
        setLoader(false);

        setState({
          verificationToken: data.verificationToken,
        });
        setState({ disabled: true });
        setState({ otpBoxEmail: true });
        setTimeout(() => {
          if (otpFor == "Edit_Address") {
            setState({
              _isShowAddressOTPBOX: true,
              _isShowContactOTPBOX: false,
              _isShowMarketingOTPBOX: false,
              isModalVisible: true,
            });
          } else if (otpFor == "Edit_Contact") {
            setState({
              _isShowAddressOTPBOX: false,
              _isShowContactOTPBOX: true,
              _isShowMarketingOTPBOX: false,
              isModalVisible: true,
            });
          } else if (otpFor == "Edit_Marketing") {
            setState({
              _isShowAddressOTPBOX: false,
              _isShowContactOTPBOX: false,
              _isShowMarketingOTPBOX: true,
              isModalVisible: true,
            });
          }
        }, 100);
      } else {
        setLoader(false);

        notification.error({ message: data.errorMessage });
      }
    });
  };

  const editSenderContactdtls = (verifiedToken) => {
    setLoader(true);
    const contactData = {
      requestType: "editContactProfile",
      areaCode: "",
      emailId:
        state.emailId == state.emailId1
          ? state.emailId
          : state.emailId1 == ""
          ? state.emailId
          : state.emailId1,
      mobilePhoneCode: state.editablemobilePhoneCode,
      mobileNo: state.editableMobileNo,
      // phoneNo: state.phoneNo,
      //   altMobileNo: state.phoneNo,
      sendCountryCode: AuthReducer.sendCountryCode,
      verifiedToken: verifiedToken,
      userId: state.userID,
      twofa: state.twofaAuth, //for otp
    };

    hookEditSenderContactdtls.sendRequest(contactData, function (data) {
      if (data.status == "S") {
        setState({ disabled: false });
        setState({ otpBoxEmail: false });
        setState({ OTPVerifed: false });
        setLoader(false);
        setState({
          _isShowAddressEditModel: false,
          _isShowContactEditModel: false,
          _isShowMarketingEditModel: false,
          _isShowAddressOTPBOX: false,
          _isShowContactOTPBOX: false,
          _isShowMarketingOTPBOX: false,
          isModalVisible: false,
          mobilePhoneCode: state.editablemobilePhoneCode,
          mobileNo: state.editableMobileNo,
          editablemobilePhoneCode: "",
          editableMobileNo: "",
          emailId1: "",
        });
        notification.success({ message: data.message });
      } else {
        setLoader(false);
        setState({
          isModalVisible: false,
        });

        notification.error({ message: data.errorMessage });
        setState({
          senderContactDetailsErrors: data.errorList,
        });
      }
      getProfile();
    });
  };
  const onFinish = (value) => {
    editProfile(value);
  };

  const renderGender = () => {
    if (state.gender === "M") {
      return "Male";
    } else if (state.gender === "F") {
      return "Female";
    } else {
      return state.gender;
    }
  };

  return (
    <>
      <Spinner spinning={loader}>
        <div className="profile-container template2__main">
          <div className="container _profile_page">
            <Row className="my-4">
              <h2>{AuthReducer.userFullName}</h2>
            </Row>
            <Row className="d-flex justify-content-between">
              <Col>
                <label className="form-label ">Email</label>
                <div className="d-flex">
                  <Input disabled value={state.emailId}></Input>
                  <button
                    onClick={() =>
                      // setState({
                      //   _isShowContactEditModel: true,
                      //   editContactTab: "3",
                      // })
                      navigate("/change-email")
                    }
                    className="btn btn-info btn-sm ms-3"
                  >
                    Edit
                  </button>
                </div>
              </Col>
              <Col className="d-flex justify-content-between">
                <div>
                  <label className="form-label ">Gender</label>
                  <Input size="large" disabled value={renderGender()}></Input>
                </div>
                <div>
                  <label className="form-label ">Date of Birth</label>
                  <Input size="large" disabled value={state.dob}></Input>
                </div>
              </Col>
            </Row>
            <Row className="my-4">
              <h2>Address</h2>
              <button onClick={() => editAddressHandler()} className="btn btn-info btn-sm ms-3">
                Edit
              </button>
            </Row>
            <Row className="d-flex justify-content-between my-3">
              <label className="form-label  m-0 pb-2">Building No. / Name</label>
              <p className="m-0">{state.address1}</p>
            </Row>
            <Row className="d-flex justify-content-between my-3">
              <Col className="d-flex justify-content-between">
                <label className="form-label  m-0 pb-2">City:</label>
                <p className="m-0">{state.city}</p>
              </Col>
              <Col className="d-flex justify-content-between">
                <label className="form-label  m-0 pb-2">State</label>
                <p className="m-0">{state.state}</p>
              </Col>
            </Row>
            <Row className="d-flex justify-content-between my-3">
              <Col className="d-flex justify-content-between">
                <label className="form-label  m-0">Postal Code</label>
                <p className="m-0">{state.zip}</p>
              </Col>
              <Col className="d-flex justify-content-between">
                <label className="form-label  m-0">Country</label>
                <p className="m-0">{state.country}</p>
              </Col>
            </Row>
            <Row className="my-3">
              <h2>Contact Details</h2>
            </Row>
            <Row className="d-flex justify-content-between">
              <Col>
                <label className="form-label ">Mobile Number</label>
                <div className="d-flex">
                  <Input size="large" disabled value={"+" + state.mobilePhoneCode + "-" + state.mobileNo}></Input>
                  <button
                    onClick={() =>
                      setState({
                        _isShowContactEditModel: true,
                        editContactTab: "1",
                      })
                    }
                    className="btn btn-info btn-sm ms-3"
                  >
                    Edit
                  </button>
                </div>
              </Col>
              <Col>
                <label className="form-label  ">Phone Number</label>
                <div className="d-flex">
                  <Input size="large" disabled value={state.phoneNo}></Input>
                  <button
                    onClick={() =>
                      setState({
                        _isEditPhoneModal: true,
                      })
                    }
                    className="btn btn-info btn-sm ms-3"
                  >
                    Edit
                  </button>
                </div>
              </Col>
            </Row>
            <Row className="my-4">
              <h2>Other Details</h2>
              <button className="btn btn-info btn-sm ms-3" onClick={() => setState({ _isShowEditDetailModal: true })}>
                Edit
              </button>
            </Row>
            <Row className="d-flex justify-content-between my-3">
              <label className="form-label  m-0 pb-2">Occupation</label>
              <p className="m-0">{state.occupationName}</p>
            </Row>
            <Row className="d-flex justify-content-between my-3">
              <label className="form-label  m-0 pb-2">Frequency</label>
              <p className="m-0">{state.frequency}</p>
            </Row>
            <Row className="d-flex justify-content-between my-3">
              <label className="form-label  m-0 pb-2">Source of Fund</label>
              <p className="m-0">{state.sourceOfFund}</p>
            </Row>
          </div>
          {state._isShowContactEditModel && <EditContactBox state={state} setState={setState} sendOTP={sendOTP} editSenderContactdtls={editSenderContactdtls} loader={loader} setLoader={setLoader} />}
          {state._isShowAddressEditModel && <EditAddressBox state={state} setState={setState} sendOTP={sendOTP} loader={loader} editAddressBoxTab={state.editAddressBoxTab} onSelectStateHandler={onSelectStateHandler} />}
          {state._isShowEditDetailModal && <EditDetailsBox state={state} setState={setState} loader={loader} />}
          {state._isEditPhoneModal && (
            <Modal centered className="primary" width={500} visible={state._isEditPhoneModal} onCancel={() => setState({ _isEditPhoneModal: false })} footer={null}>
              <Form form={form} onFinish={onFinish}>
                <Spinner spinning={loader}>
                  <div className="p-0 mb-4">
                    <h4 className="">Contact details</h4>
                  </div>
                  <div className="row justify-content-center">
                    <div className="col-12 col-md-4">
                      <label className="form-label">Country Code</label>
                      <CustomInput className="form-item w-100" name="phoneCountryCode" size="large" placeholder="Select Country Code" showSearch optionFilterProp="children" label="Country Code" showLabel={false} required type="select">
                        {state.phoneCodes.map((list, i) => {
                          return (
                            <Select.Option key={i} value={list.countryPhoneCode}>
                              +{list.countryPhoneCode} ( {list.countryName})
                            </Select.Option>
                          );
                        })}
                      </CustomInput>
                    </div>
                    <div className="col-12 col-md-8">
                      <label className="form-label">Phone Number</label>
                      <CustomInput
                        className="form-item"
                        name="phoneNo"
                        size="large"
                        placeholder="Enter your Phone Number"
                        min={10}
                        max={12}
                        validationRules={[
                          {
                            pattern: /^[0-9\b]+$/,
                            message: "Only Numbers allowed",
                          },
                        ]}
                      />
                       
                    </div>
                  </div>
                  <div className="d-grid gap-2 d-flex justify-content-between mt-4">
                    <button className="btn btn-danger btn-block px-4" onClick={() => setState({ _isEditPhoneModal: false })} type="button">
                      Cancel
                    </button>
                    <button className="btn btn-secondary px-4">Submit</button>
                  </div>
                </Spinner>
              </Form>
            </Modal>
          )}
          <KycModalFlowOne getProfile={getProfile} isModalVisible={isModalVisible} setIsModalVisible={setIsModalVisible} />
          <EditAdress getProfile={getProfile} isModalVisible={isModalVisible1} setIsModalVisible={setIsModalVisible1} state={state} />
        </div>
      </Spinner>
    </>
  );
}

export default Profile;
