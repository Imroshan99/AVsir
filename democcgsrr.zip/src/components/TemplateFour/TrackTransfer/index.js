import React, { useEffect } from "react";
import { useSelector } from "react-redux";

import Dashboard from "../Layouts/Dashboard";
import TrackMoneyTransfer from "./Flow1/TrackMoneyTransfer";
import { useOutletContext } from "react-router-dom";

const TrackTransfer = (props) => {
  const AuthReducer = useSelector((state) => state.user);
  const templateFlow =
    AuthReducer.groupIdSettings?.sendMoneyModule?.trackTransfer?.flow;
  const { setTitle } = useOutletContext();
  useEffect(() => {
    setTitle("Track Transfer");
  }, []);
  return (
    <>
      {templateFlow === "FLOW1" && (
        <TrackMoneyTransfer
          appState={props.appState}
          manageAuth={props.manageAuth}
        />
      )}
    </>
  );
};

export default TrackTransfer;
