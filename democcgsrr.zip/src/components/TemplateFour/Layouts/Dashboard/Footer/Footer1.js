import { useSelector } from "react-redux";
import { getProcessingPartner } from "../../../../../services/utility/group";

export default function Footer1() {
  const groupConfig = useSelector((state) => state.user);
  let poweredBy = "";
  if (getProcessingPartner(groupConfig.sendCountryCode) === "VIAMERICAS") {
    poweredBy = (
      <div className="row">
        <div className="col-12 col-md-12">
          <span className="powered_by">Powered by</span>
          <br />
          <img
            src={`images/partners-logo/via.png`}
            height={"32px"}
            alt="VIAMERICAS Logo"
          />
        </div>
        <div className="col-12 col-md-12 mt-3">
          <ul className="footer-menu">
            <li>
              <a
                target="_blank"
                rel="noopener noreferrer"
                href="https://corporate.viamericas.com/about/"
              >
                About us
              </a>
            </li>
            <li>
              <a
                target="_blank"
                rel="noopener noreferrer"
                href="https://corporate.viamericas.com/contact/"
              >
                Contact us
              </a>
            </li>
            <li>
              <a
                target="_blank"
                rel="noopener noreferrer"
                href="https://corporate.viamericas.com/state-licensing-information/"
              >
                State Licensing
              </a>
            </li>
            <li>
              <a
                target="_blank"
                rel="noopener noreferrer"
                href="https://s3.amazonaws.com/cdn.govianex.com/privacy-policy/www/viamericas_privacy-policy.pdf"
              >
                Privacy Policy
              </a>
            </li>
            <li>
              <a
                target="_blank"
                rel="noopener noreferrer"
                href="https://corporate.viamericas.com/file-a-complaint/"
              >
                File a Complaint
              </a>
            </li>
            <li>
              <a
                target="_blank"
                rel="noopener noreferrer"
                href="https://s3.amazonaws.com/cdn.govianex.com/terms-and-conditions/www/viamericas_terms-and-conditions.pdf"
              >
                Terms and Conditions
              </a>
            </li>
          </ul>
        </div>
      </div>
    );
  }
  return (
    <div className="bg-white">
      <div className="container mt-5 py-5">
        <div className="row justify-content-center text-center">
          <div className="col-12 col-md-12 mb-3">{poweredBy}</div>
          <div className="col-12 col-md-12">
            © {groupConfig.groupIdSettings.title}
          </div>
        </div>
      </div>
    </div>
  );
}
