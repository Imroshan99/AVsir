import { useSelector } from "react-redux";
import Dashboard from "../Layouts/Dashboard";
import UploadAdditonalDocFlowOne from "./UploadAdditionalDocFlowOne/UploadAdditonalDocFlowOne";
import { useOutletContext } from "react-router-dom";
import { useEffect } from "react";

const UploadAdditonalDoc = (props) => {
  const AuthReducer = useSelector((state) => state.user);

  const templateFlow = AuthReducer.groupIdSettings?.kyc?.flow;
  const { setTitle } = useOutletContext();
  useEffect(() => {
    setTitle("Upload Additional Document");
  }, []);
  return (
    <>
      {templateFlow === "FLOW1" && (
        <UploadAdditonalDocFlowOne
          appState={props.appState}
          manageAuth={props.manageAuth}
        />
      )}
    </>
  );
};

export default UploadAdditonalDoc;
