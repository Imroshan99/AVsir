import { useSelector } from "react-redux";
import { Navigate } from "react-router-dom";
import { getSessionStorage } from "../services/utility/storage";

export const PublicRoute = ({ auth, children }) => {
  // const isAllowed = auth.isLoggedIn;
  const config = useSelector((state) => state.user);
  const { isLoggedIn, additionalAuthRequired, groupIdSettings } = config;
  console.log("groupIdSettings", groupIdSettings);
  const isAllowed = groupIdSettings.settings.refreshPage
    ? getSessionStorage("isLoggedIn")
    : isLoggedIn;

  if (isAllowed && !additionalAuthRequired) {
  // if (isAllowed) {
    return <Navigate to="/new-transaction" replace />;
  }

  return children;
};
