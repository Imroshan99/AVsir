import axios from "axios";
import { config } from "../../config";

export const LuluAuthAPI = {
  checkEmpAvailablity: async (data, token) => {
    var axosConfig = {
      method: "post",
      url: `${config.API_URL}/services/lulu/check-availablity`,
      headers: {
        Authorization: `AuthToken ${token}`,
        "Content-Type": "application/json",
      },
      data: data,
    };

    return await axios(axosConfig);
  },
  onboarding: async (data, token) => {
    var axosConfig = {
      method: "post",
      url: `${config.API_URL}/services/lulu/onboarding-v2`,
      headers: { Authorization: `AuthToken ${token}`, "Content-Type": "application/json" },
      data: data,
    };

    return await axios(axosConfig);
  },
  requestEkyc: async (data, token) => {
    var axosConfig = {
      method: "post",
      url: `${config.API_URL}/services/lulu/request-ekyc`,
      headers: {
        Authorization: `AuthToken ${token}`,
        "Content-Type": "application/json",
      },
      data: data,
    };

    return await axios(axosConfig);
  },
  lookup: async (data, token) => {
    var axosConfig = {
      method: "post",
      url: `${config.API_URL}/services/lulu/lookup-v2`,
      headers: {
        Authorization: `AuthToken ${token}`,
        "Content-Type": "application/json",
      },
      data: data,
    };

    return await axios(axosConfig);
  },
};