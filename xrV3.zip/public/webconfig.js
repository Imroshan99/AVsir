window.___webConfig = {
  API_URL: "https://qaone.remit.in",
  IS_ENC: false,

  // for prod use only
  // API_URL: "https://ms1.remit.in", //For production
  // IS_ENC: true, //true for prod
};
