import React from "react";
import { useSelector } from "react-redux";
// import HomeXr from "./XR"
// import HomeKcb from "./KCB"

const HomeXr = React.lazy(() => import("./XR"));
const HomeKcb = React.lazy(() => import("./KCB"));
const HomeMF = React.lazy(() => import("./MF"));
const HomeCSB = React.lazy(() => import("./CSB"));

const HomePage = () => {
  const AuthReducer = useSelector((state) => state);
  switch (AuthReducer.groupId) {
    case "MF":
      return <HomeMF />;
    case "CSB":
      return <HomeCSB />;

    case "KCB":
      return <HomeKcb />;

    case "XR":
      return <HomeXr />;

    default:
      return <div>Home Page not found</div>;
  }
};

export default HomePage;
