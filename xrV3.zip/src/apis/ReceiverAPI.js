import axios from "axios";
import { config } from "../config";
// import { AuthService } from "../services/AuthService";

export const ReceiverAPI = {
    checkDuplicateReceiver: async (data, token) => {
        var axosConfig = {
            method: 'post',
            url: `${config.API_URL}/services/usr/recv/check-duplicate-receiver`,
            headers: {
                'Authorization': `AuthToken ${token}`,
                'Content-Type': 'application/json'
            },
            data: data
        };

        return await axios(axosConfig);
    },
    addReceiver: async (data, token) => {
        var axosConfig = {
            method: 'post',
            url: `${config.API_URL}/services/usr/recv/add-receiver`,
            headers: {
                'Authorization': `AuthToken ${token}`,
                'Content-Type': 'application/json'
            },
            data: data
        };

        return await axios(axosConfig);
    },
    editReceiver: async (data, token) => {
        var axosConfig = {
            method: 'post',
            url: `${config.API_URL}/services/usr/recv/edit-receiver`,
            headers: {
                'Authorization': `AuthToken ${token}`,
                'Content-Type': 'application/json'
            },
            data: data
        };

        return await axios(axosConfig);
    },
    receiverLists: async (data, token) => {
        var axosConfig = {
            method: 'post',
            url: `${config.API_URL}/services/usr/recv/receiver-lists`,
            headers: {
                'Authorization': `AuthToken ${token}`,
                'Content-Type': 'application/json'
            },
            data: data
        };

        return await axios(axosConfig);
    },
    validateReceiverDetails: async (data, token) => {
        var axosConfig = {
            method: 'post',
            url: `${config.API_URL}/services/usr/recv/validate-receiver-details`,
            headers: {
                'Authorization': `AuthToken ${token}`,
                'Content-Type': 'application/json'
            },
            data: data
        };

        return await axios(axosConfig);
    },
    viewRecipientsDetails: async (data, token) => {
        var axosConfig = {
            method: 'post',
            url: `${config.API_URL}/services/usr/recv/receiver-info`,
            headers: {
                'Authorization': `AuthToken ${token}`,
                'Content-Type': 'application/json'
            },
            data: data
        };

        return await axios(axosConfig);
    },
    bankLists: async (data, token) => {
        var axosConfig = {
            method: 'post',
            url: `${config.API_URL}/services/usr/recv/bank-lists`,
            headers: {
                'Authorization': `AuthToken ${token}`,
                'Content-Type': 'application/json'
            },
            data: data
        };

        return await axios(axosConfig);
    },
    bankStateCities: async (data, token) => {
        var axosConfig = {
            method: 'post',
            url: `${config.API_URL}/services/usr/recv/bank-state-cities`,
            headers: {
                'Authorization': `AuthToken ${token}`,
                'Content-Type': 'application/json'
            },
            data: data
        };

        return await axios(axosConfig);
    },
    bankBranches: async (data, token) => {
        var axosConfig = {
            method: 'post',
            url: `${config.API_URL}/services/usr/recv/bank-branches`,
            headers: {
                'Authorization': `AuthToken ${token}`,
                'Content-Type': 'application/json'
            },
            data: data
        };

        return await axios(axosConfig);
    },
    deleteReceiver: async (data, token) => {
        var axosConfig = {
            method: 'post',
            url: `${config.API_URL}/services/usr/recv/delete-receiver`,
            headers: {
                'Authorization': `AuthToken ${token}`,
                'Content-Type': 'application/json'
            },
            data: data
        };

        return await axios(axosConfig);
    },
    requestMoney : async (data, token) => {
        var axosConfig = {
            method: 'post',
            url: `${config.API_URL}/services/usr/recv/recipient-request`,
            headers: {
                'Authorization': `AuthToken ${token}`,
                'Content-Type': 'application/json'
            },
            data: data
        };

        return await axios(axosConfig);
    },

    recipientRequestLists : async (data, token) => {
        var axosConfig = {
            method: 'post',
            url: `${config.API_URL}/services/usr/recv/recipient-request-lists`,
            headers: {
                'Authorization': `AuthToken ${token}`,
                'Content-Type': 'application/json'
            },
            data: data
        };

        return await axios(axosConfig);
    },

    checkRecvNickName : async (data, token) => {
        var axosConfig = {
            method: 'post',
            url: `${config.API_URL}/services/usr/recv/check-recv-nickname`,
            headers: {
                'Authorization': `AuthToken ${token}`,
                'Content-Type': 'application/json'
            },
            data: data
        };

        return await axios(axosConfig);
    },

    recipientRequestApprove : async (data, token) => {
        var axosConfig = {
            method: 'post',
            url: `${config.API_URL}/services/usr/recv/recipient-request-approve`,
            headers: {
                'Authorization': `AuthToken ${token}`,
                'Content-Type': 'application/json'
            },
            data: data
        };

        return await axios(axosConfig);
    },
}