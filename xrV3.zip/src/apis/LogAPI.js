import axios from "axios";
import { config } from "../config";

export const LogAPI = {
  kycLog: async (data, token) => {
    var axosConfig = {
      method: "post",
      url: `${config.API_URL}/services/remit/log`,
      headers: {
        "Content-Type": "application/json",
      },
      data: data,
    };

    return await axios(axosConfig);
  },
};
