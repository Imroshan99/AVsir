import thunk from "redux-thunk";
import { createStore, combineReducers, applyMiddleware } from "redux";
import { composeWithDevTools } from "redux-devtools-extension";
// import profileReducer from './reducers/profileReducer';
import {
  getToken,
  getUserID,
  getLastLogin,
  getUserLogin,
  getUserFullName,
  getUserKYC,
  getUserKYCBoolean,
  getUserKYCStatus,
} from "./reducers/AuthReducer";
import {
  getClientId,
  getGroupId,
  getSendCountryCode,
  getSendCurrencyCode,
  getRecvCountryCode,
  getRecvCurrencyCode,
  getRegCountryCode,
  getRecvCountyList,
  getSessionId,
  getTwofa,
  getPubKey,
  getGroupIdSettings,
} from "./reducers/ConfigReducer";
import { setNotificationCount } from "./reducers/NotificationReducer";

const masterReducer = combineReducers({
  accessToken: getToken,
  userID: getUserID,
  lastLogin: getLastLogin,
  userKYC: getUserKYC,
  userKYCBoolean:getUserKYCBoolean,
  userKYCStatus:getUserKYCStatus,
  userFullName: getUserFullName,
  isLoggedIn: getUserLogin,
  clientId: getClientId,
  groupId: getGroupId,
  groupIdSettings: getGroupIdSettings,
  twofa: getTwofa,
  pubkey: getPubKey,
  sessionId: getSessionId,
  sendCountryCode: getSendCountryCode,
  sendCurrencyCode: getSendCurrencyCode,
  recvCountryCode: getRecvCountryCode,
  recvCurrencyCode: getRecvCurrencyCode,
  regCountryCode: getRegCountryCode,
  recvCountryList: getRecvCountyList,
  // notification reducer
  notificationCount: setNotificationCount,
});

const store = createStore(
  masterReducer,
  composeWithDevTools(applyMiddleware(thunk))
);

export { store };
