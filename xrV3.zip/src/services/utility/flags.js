export const flags = {
    'IN' : 'IN.png',
    'US' : 'US.png',
    'GB' : 'GB.png',
    'CA' : 'CA.png',
    'KE' : 'KE.png',
    'AE' : 'AE.png',
}