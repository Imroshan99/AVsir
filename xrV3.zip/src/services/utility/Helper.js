export function passwordStrength(e) {
  let strongPassword = new RegExp("(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[^A-Za-z0-9])(?=.{8,})");
  let mediumPassword = new RegExp(
    "((?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[^A-Za-z0-9])(?=.{6,}))|((?=.*[a-z])(?=.*[A-Z])(?=.*[^A-Za-z0-9])(?=.{8,}))",
  );
  if (strongPassword.test(e)) {
    return "Strong";
  } else if (mediumPassword.test(e)) {
    return "Medium";
  } else {
    return "Weak";
  }
}

export function removeSpecilaChars(str) {
  const filteredStr =  str.replace(/[^a-zA-Z0-9]/g, "");
  return filteredStr.trim();
}



export function dynamicSort(property, type = "string") {
  var sortOrder = 1;
  if (property[0] === "-") {
    sortOrder = -1;
    property = property.substr(1);
  }
  return function (a, b) {
    /* next line works with strings and numbers,
     * and you may want to customize it to your needs
     */

    let i, j;
    if (type === "number") {
      i = parseInt(a[property]);
      j = parseInt(b[property]);
    } else {
      i = a[property];
      j = b[property];
    }
    var result = i < j ? -1 : i > j ? 1 : 0;
    return result * sortOrder;
  };
}