export function validateBankBranch(textbox) {

  var validStr = " abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ.0123456789/-?()\",+#&_[]";
  var inputValue = textbox;
  for (let i = 0; i <= textbox.length - 1; i++) {
    if (validStr.indexOf(inputValue.charAt(i)) == -1) {
      return {
        status: "F",
        message: "Please enter valid branch name.",
      };
    }
  }


  return {
    status: "S",
    message: "Success",
  };
}
