const ONLY_NUMBER_OR_ALPHANUMBER = /^[a-zA-Z0-9]*$/;
const ONLY_ALPHA_OR_ALPHANUMBER = /^(?!^[0-9]+$)[a-zA-Z0-9]+$/;


const zipCode = (countryCode, groupId = "") => {
  switch (countryCode) {
    case "US":
      return [
        {
          min: 3,
          message: "Minimum 3 Digits",
        },
        {
          max: 5,
          message: "Maximum 5 Digits",
        },
        {
          pattern: /^[0-9\b]+$/,
          message: "Only Numbers allowed",
        },
      ];
    case "IN":
      return [
        {
          min: 6,
          message: "Minimum 6 Digits",
        },
        {
          max: 6,
          message: "Maximum 6 Digits",
        },
        {
          pattern: /^[0-9\b]+$/,
          message: "Only Numbers allowed",
        },
      ];
    case "KE":
      return [
        {
          min: 3,
          message: "Minimum 3 Digits",
        },
        {
          max: 5,
          message: "Maximum 5 Digits",
        },
        {
          pattern: /^[0-9\b]+$/,
          message: "Only Numbers allowed",
        },
      ];
    case "GB":
      return [
        {
          min: 5,
          max: 9,
          message: "Minimum 5 and Maximum 9 alphanumeric value",
        },
        {
          pattern: /^[A-Za-z0-9\s?]+$/,
          message: "Only alphanumeric allowed",
        },
      ];

    case "BD":
      return [
        {
          min: 4,
          message: "Minimum 4 and Maximum 4 digits allowed",
        },
        {
          max: 4,
          message: "Minimum 4 and Maximum 4 digits allowed",
        },
        {
          pattern: /^[0-9\b]+$/,
          message: "Only Numbers allowed",
        },
      ];

      case "LK":
      case "ID":
      case "TH":
        return [
          {
            min: 5,
            message: "Minimum 5 and Maximum 5 digits allowed",
          },
          {
            max: 5,
            message: "Minimum 5 and Maximum 5 digits allowed",
          },
          {
            pattern: /^[0-9\b]+$/,
            message: "Only Numbers allowed",
          },
        ];

    case "PH":
      return [
        {
          min: 4,
          message: "Minimum 4 and Maximum 4 digits allowed",
        },
        {
          max: 4,
          message: "Minimum 4 and Maximum 4 digits allowed",
        },
        {
          pattern: /^[0-9\b]+$/,
          message: "Only Numbers allowed",
        },
      ];
    default:
      return [
        {
          min: 6,
          message: "Minimum 6 Digits",
        },
        {
          max: 6,
          message: "Maximum 6 Digits",
        },
        {
          pattern: /^[0-9\b]+$/,
          message: "Only Numbers allowed",
        },
      ];
  }
};

const accountNumber = (countryCode, groupId = "") => {
  switch (countryCode) {
    case "GB":
      return [
        {
          min: 5,
          message: "Account Number should be between 5 and 34 digits",
        },
        {
          max: 34,
          message: "Account Number should be between 5 and 34 digits",
        },
        {
          pattern: /^([0-9\b])|[A-Za-z0-9\b]+$/,
          message: "Only Numbers Or Alphanumeric account number allowed",
        },
      ];
    case "KE":
      return [
        {
          min: 8,
          max: 16,
          message: "Account Number should be between 8 and 16 digits",
        },
        {
          pattern: /^[0-9\b]+$/,
          message: "Only Numbers allowed",
        },
      ];
    case "US":
      return [
        {
          min: 8,
          max: 25,
          message: "Account Number should be between 8 and 25 digits",
        },
        {
          pattern: /^[0-9\b]+$/,
          message: "Only Numbers allowed",
        },
      ];
    case "IN":
      if (groupId === "MF") {
        return [
          {
            min: 8,
            max: 25,
            message: "Account Number should be between 8 and 25 characters",
          },
          {
            pattern: /^(?=.*[0-9])(?=.*[a-zA-Z])([a-zA-Z0-9]+)$/,
            message: "Account number must be alphanumeric.",
          },
        ];
      }

      return [
        {
          min: 5,
          max: 20,
          // eslint-disable-next-line no-template-curly-in-string
          message: "Account Number should be between ${min} and ${max} digit",
          // get message() {
          //   return `Account Number should be between ${this.min} and ${this.max} digit`;
          // },
        },
        {
          pattern: /^[0-9\b]+$/,
          message: "Only Numbers allowed",
        },
      ];
    case "BD":
      return [
        {
          min: 5,
          message: "Account Number should be between 5 and 20 characters",
        },
        {
          max: 20,
          message: "Account Number should be between 5 and 20 characters",
        },
        {
          pattern: /^[0-9\b]+$/,
          message: "Only Numbers allowed",
        },
      ];

    case "PH":
      return [
        {
          min: 5,
          message: "Account Number should be between 5 and 20 characters",
        },
        {
          max: 20,
          message: "Account Number should be between 5 and 20 characters",
        },
        {
          pattern: /^[0-9\b]+$/,
          message: "Only Numbers allowed",
        },
      ];
    default:
      return [
        {
          min: 8,
          max: 25,
          message: "Account Number should be between 8 and 25 digits",
        },
        {
          pattern: /^[0-9\b]+$/,
          message: "Only Numbers allowed",
        },
      ];
  }
};
const mobileNumber = (countryCode, groupId = "") => {
  switch (countryCode) {
    case "KE":
      return [
        {
          min: 9,
          max: 10,
          message: "Mobile Number should be between 9 and 10 digits",
        },
        {
          pattern: /^[0-9\b]+$/,
          message: "Only Numbers allowed",
        },
      ];
    case "IN":
      return [
        {
          min: 10,
          message: "Mobile Number should be 10 digits",
        },
        {
          max: 10,
          message: "Mobile Number should be 10 digits",
        },
        {
          pattern: /^[0-9\b]+$/,
          message: "Only Numbers allowed",
        },
      ];

    default:
      return [
        {
          min: 10,
          message: "Mobile Number should be 10 digits",
        },
        {
          max: 10,
          message: "Mobile Number should be 10 digits",
        },
        {
          pattern: /^[0-9\b]+$/,
          message: "Only Numbers allowed",
        },
      ];
  }
};
const swiftCode = (countryCode, groupId = "") => {
  switch (countryCode) {
    case "BD":
      return [
        {
          min: 8,
          message: "Swift Code should be between 8 and 11 characters",
        },
        {
          max: 11,
          message: "Swift Code should be between 8 and 11 characters",
        },
        {
          pattern: /^(?=.*[0-9])(?=.*[a-zA-Z])([a-zA-Z0-9]+)$/,
          message: "Only Alphanumeric Swift Code allowed",
        },
      ];
    default:
      return [
        {
          min: 8,
          message: "Swift Code should be between 8 and 11 characters",
        },
        {
          max: 11,
          message: "Swift Code should be between 8 and 11 characters",
        },
        {
          pattern: /^(?=.*[0-9])(?=.*[a-zA-Z])([a-zA-Z0-9]+)$/,
          message: "Only Alphanumeric Swift Code allowed",
        },
      ];
  }
};
const bankAddress = (countryCode, groupId = "") => {
  switch (countryCode) {
    case "BD":
      return [
        {
          min: 10,
          message: "Bank Address should be between 10 and 300 characters",
        },
        {
          max: 300,
          message: "Bank Address should be between 10 and 300 characters",
        },
        // {
        //   pattern: /^([0-9\b])|[A-Za-z0-9\b]+$/,
        //   message: "Only Alphanumeric Bank Address allowed",
        // },
      ];
    default:
      return [
        {
          min: 10,
          message: "Bank Address should be between 10 and 300 characters",
        },
        {
          max: 300,
          message: "Bank Address should be between 10 and 300 characters",
        },
        // {
        //   pattern: /^([0-9\b])|[A-Za-z0-9\b]+$/,
        //   message: "Only Alphanumeric Bank Address allowed",
        // },
      ];
  }
};
const bankSortCode = (countryCode, groupId = "") => {
  switch (countryCode) {
    case "BD":
      return [
        {
          min: 8,
          message: "Bank sort code should be between 8 and 11 characters",
        },
        {
          max: 11,
          message: "Bank sort code should be between 8 and 11 characters",
        },
        {
          pattern: /^(?=.*[0-9])(?=.*[a-zA-Z])([a-zA-Z0-9]+)$/,
          message: "Only Alphanumeric Bank sort code allowed",
        },
      ];
    default:
      return [
        {
          min: 8,
          message: "Bank sort code should be between 8 and 11 characters",
        },
        {
          max: 11,
          message: "Bank sort code should be between 8 and 11 characters",
        },
        {
          pattern: /^(?=.*[0-9])(?=.*[a-zA-Z])([a-zA-Z0-9]+)$/,
          message: "Only Alphanumeric Bank sort code allowed",
        },
      ];
  }
};
const interSwiftCode = (countryCode, groupId = "") => {
  switch (countryCode) {
    case "BD":
      return [
        {
          min: 8,
          message: "Intermediary Bank Swift code should be between 8 and 11 characters",
        },
        {
          max: 11,
          message: "Intermediary Bank Swift code should be between 8 and 11 characters",
        },
        {
          pattern: /^(?=.*[0-9])(?=.*[a-zA-Z])([a-zA-Z0-9]+)$/,
          message: "Only Alphanumeric Intermediary Bank Swift code allowed",
        },
      ];
    default:
      return [
        {
          min: 8,
          message: "Intermediary Bank Swift code should be between 8 and 11 characters",
        },
        {
          max: 11,
          message: "Intermediary Bank Swift code should be between 8 and 11 characters",
        },
        {
          pattern: /^(?=.*[0-9])(?=.*[a-zA-Z])([a-zA-Z0-9]+)$/,
          message: "Only Alphanumeric Intermediary Bank Swift code allowed",
        },
      ];
  }
};
const interBankName = (countryCode, groupId = "") => {
  switch (countryCode) {
    case "BD":
      return [
        {
          min: 2,
          message: "Intermediary Bank Name should be between 2 and 60 characters",
        },
        {
          max: 60,
          message: "Intermediary Bank Name should be between 2 and 60 characters",
        },
        {
          pattern: /^[a-z]+$/i,
          message: "Only Alphabetical Intermediary Bank Name allowed",
        },
      ];
    default:
      return [
        {
          min: 2,
          message: "Intermediary Bank Name should be between 2 and 60 characters",
        },
        {
          max: 60,
          message: "Intermediary Bank Name should be between 2 and 60 characters",
        },
        {
          pattern: /^[a-z]+$/i,
          message: "Only Alphabetical Intermediary Bank Name allowed",
        },
      ];
  }
};
const interBankAddress = (countryCode, groupId = "") => {
  switch (countryCode) {
    case "BD":
      return [
        {
          min: 10,
          message: "Intermediary Bank Address should be between 10 and 300 characters",
        },
        {
          max: 300,
          message: "Intermediary Bank Address should be between 10 and 300 characters",
        },
        // {
        //   pattern: /^([0-9\b])|[A-Za-z0-9\b]+$/,
        //   message: "Only Alphanumeric Intermediary Bank Address allowed",
        // },
      ];
    default:
      return [
        {
          min: 10,
          message: "Intermediary Bank Address should be between 10 and 300 characters",
        },
        {
          max: 300,
          message: "Intermediary Bank Address should be between 10 and 300 characters",
        },
        // {
        //   pattern: /^([0-9\b])|[A-Za-z0-9\b]+$/,
        //   message: "Only Alphanumeric Intermediary Bank Address allowed",
        // },
      ];
  }
};

const bankBranchNo = (countryCode, groupId = "") => {
  switch (countryCode) {
    case "BD":
      return [
        {
          min: 1,
          message: "Bank Branch Number should be between 1 and 20 characters",
        },
        {
          max: 20,
          message: "Bank Branch Number should be between 1 and 20 characters",
        },
        {
          pattern: ONLY_NUMBER_OR_ALPHANUMBER,
          message: "Only Alphanumeric Bank Branch Number allowed",
        },
      ];
    default:
      return [
        {
          min: 1,
          message: "Bank Branch Number should be between 1 and 20 characters",
        },
        {
          max: 20,
          message: "Bank Branch Number should be between 1 and 20 characters",
        },
        {
          pattern: ONLY_NUMBER_OR_ALPHANUMBER,
          message: "Only Alphanumeric Bank Branch Number allowed",
        },
      ];
  }
};

const bankBICCode = (countryCode, groupId = "") => {
  switch (countryCode) {
    case "BD":
      return [
        {
          min: 8,
          message: "BIC Code should be between 8 and 11 characters",
        },
        {
          max: 11,
          message: "BIC Code should be between 8 and 11 characters",
        },
        {
          pattern: ONLY_ALPHA_OR_ALPHANUMBER,
          message: "Only Alphanumeric BIC Code allowed",
        },
      ];
    default:
      return [
        {
          min: 8,
          message: "BIC Code should be between 8 and 11 characters",
        },
        {
          max: 11,
          message: "BIC Code should be between 8 and 11 characters",
        },
        {
          pattern: ONLY_ALPHA_OR_ALPHANUMBER,
          message: "Only Alphanumeric BIC Code allowed",
        },
      ];
  }
};


const bankCode = (countryCode, groupId = "") => {
  switch (countryCode) {
    case "LK":
      return [
        {
          min: 4,
          message: "Bank Code should be 4 digits",
        },
        {
          max: 4,
          message: "Bank Code should be 4 digits",
        },
        {
          pattern: /^[0-9\b]+$/,
          message: "Only Numbers allowed",
        },
      ];
    default:
      return [
        {
          min: 8,
          message: "Bank Code should be between 8 and 11 characters",
        },
        {
          max: 11,
          message: "Bank Code should be between 8 and 11 characters",
        },
        {
          pattern: ONLY_ALPHA_OR_ALPHANUMBER,
          message: "Only Alphanumeric BIC Code allowed",
        },
      ];
  }
};

export const inputValidations = {
  zipCode,
  accountNumber,
  mobileNumber,
  swiftCode,
  bankAddress,
  bankSortCode,
  interSwiftCode,
  interBankName,
  interBankAddress,
  bankBranchNo,
  bankBICCode,
  bankCode
};
