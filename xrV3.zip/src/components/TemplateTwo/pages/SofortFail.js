import { useEffect } from "react";
import { useSearchParams } from "react-router-dom";
import { LogAPI } from "../../../apis/LogAPI";
import { TransactionAPI } from "../../../apis/TransactionAPI";
import useHttp from "../../../hooks/useHttp";
import SubHeader from "../layout/SubHeader";

export default function SofortFail() {
  const hookUpdateSofortDetails = useHttp(TransactionAPI.updateSofortDetails);
  const [searchParams, setSearchParams] = useSearchParams();
  const msg = searchParams.get("msg");
  const transId = searchParams.get("transId");
  useEffect(() => {
    window.localStorage.setItem(transId, "FAILED");
    let logPayload = {
      groupId: "XR",
      logText: `SOFORT FAIL: ${transId}`,
      callerFileName: "XR_SOFORT.js",
      logFileName: "XR_SOFORT_LOG",
      stackTrace: "",
      msgLevel: "INFO",
    };
    LogAPI.kycLog(logPayload).then((res) => {
      const payloadUpdateSofortDetails = {
        requestType: "UPDATESOFRT",
        tranStatus: `SOFORT ${msg.toUpperCase()}`,
        reason: `TRANSACTION ${msg.toUpperCase()}`,
        transactionId: transId,
      };
      hookUpdateSofortDetails.sendRequest(payloadUpdateSofortDetails, function (data) {
        window.close("", "_parent", "");
      });
    });
  }, []);

  const onClickWindowCloseHandler = () => {
    window.close("", "_parent", "");
  };
  return (
    <div>
      <SubHeader title="Transaction Failed." />
      <div className="text-center">
        <button className="btn btn-primary text-light mt-5" onClick={onClickWindowCloseHandler}>
          close window
        </button>
      </div>
    </div>
  );
}
