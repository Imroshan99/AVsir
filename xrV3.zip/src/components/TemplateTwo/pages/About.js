import React from "react";
import SubHeader from "../layout/SubHeader";
import { useNavigate } from "react-router-dom";
import { Footer } from "../../../pages/LandingPage/XR";

export default function AboutUs() {
  const navigate = useNavigate();
  return (
    <React.Fragment>
      <SubHeader title="About Us" />
      <div className="template2__main about_us_page py-5">
        <div className="sendmoney__page">
          <div className="container contactus">
            <div>
              <p className="f2">
                Xmonies, is a International/ Cross Border Remittance and
                Payments Platform and fully owned by XeOPAR Fintech Private
                Limited, a company registered in India under The Companies Act
                2013 [CIN U67100UP2018PTC107164] and whose registered and Head
                Office is at H -187, Sector 63, Noida, Gautam Buddha Nagar,
                U.P., India.
              </p>
              <p className="f1 mt-4">Background</p>
              <p className="f3">
                At XeOPAR, we understand the issues and concerns of the overseas
                workforce and their remittance requirements who are underserved.
                We are focused on Micro-Small-Medium transactions however Banks
                are focused on the high-value transactions and HNI customer
                experience, while blue and grey migrants' experience is sub-par.<br/>
                XMonies caters to support these customers to send money
                remittances to their families as and when required. We firmly
                believe that there should be no geographical limitations when it
                comes to bringing a smile to your loved ones’ faces.
              </p>
              <p className="f1 mt-4">The Platform:</p>
              <p className="f3">
                Borne forth on solid technology and compliance partnerships,
                XMONIES brings remittance services focused on Micro-Small-Medium
                transactions or low-value fund transfers. We make cross border
                fund transfers cost-effective, transparent, and hassle-free
                without any hidden charges.
              </p>
              <p className="f1 mt-4">Our Mission:</p>
              <p className="f3">
                At XeOPAR ‘’We Understand Human Values’’ and our mission is to
                bring smiles to your loved ones' faces regardless of their
                geographical location. We don’t discriminate amongst our clients
                no matter how big or small i the transaction amount.
              </p>
              <p className="f1 mt-4">The Platform:</p>
              <p className="f3">
                Borne forth on solid technology and compliance partnerships,
                XMONIES brings remittance services focused on Micro-Small-Medium
                transactions or low-value fund transfers. We make cross border
                fund transfers cost-effective, transparent, and hassle-free
                without any hidden charges.
              </p>
              <p className="f1 mt-4">Our Vision:</p>
              <p className="f3">
                Our Vision is to make international remittances, payments and
                transfers made simple and create an unforgettable customer
                experience.
              </p>
              <p className="f1 mt-4">Our foundation:</p>
              <p className="f3">When it comes to sending money, we believe</p>
              <p className="f4">• Real-time exchange rates:</p>
              <p className="f3">
                Real Time exchange rates are only ones that are fair, & you get
                them with XMONIES. We provide you live rate that you can book
                for next 24 hours.
              </p>
              <p className="f4">• No hidden cost:</p>
              <p className="f3">We show all our fees upfront.</p>
              <p className="f4">• No minimum amount set:</p>
              <p className="f3">
                There is no limit on the minimum transaction amount! So, you
                only remit what you desire.
              </p>
              <p className="f4">• Transparent and accessible fees</p>

              <div className="col-12 text-end mt-5">
                <button
                  onClick={() => navigate("/")}
                  className="btn btn-sm btn-light  text-primary px-3 btn-goback"
                >
                  Go Back
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
      <Footer />
    </React.Fragment>
  );
}
