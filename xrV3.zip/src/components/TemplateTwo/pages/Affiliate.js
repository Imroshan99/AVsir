
import React from "react";
import { Footer } from "../../../pages/LandingPage/XR";
import SubHeader from "../layout/SubHeader";

export default function Affiliate() {
  return (
    <React.Fragment>
      <SubHeader title="Become an Affiliate" />
      <div className="profile-container template2__main">
        <div className="container _profile_page py-5 pt-0">
          <div className="affiliate">
            <h2 className="fs-2r">How it Works</h2>
            <div style={{ marginTop: "27px" }}>
              <p className="mb-4">
                <strong className="text-info">
                  Welcome to XMONIES Affiliate Program
                </strong>
              </p>
              <p>
                No matter if you are an individual or business entity, XMONIES
                Affiliate Program gives an opportunity to earn money by
                promoting XMONIES International Money transfer services.
              </p>
              <p>
                <strong className="text-info">What You Get:</strong>
              </p>
              <p className="mb-4">
                - As an Affiliate, you earn for every customer who transact with
                us.
                <br />
                - special payout if your referred user is a business user.
                <br />- Special Promotional offers time to time and country to
                country to earn more
              </p>
              <p>
                <strong className="text-info">What your customer get:</strong>
              </p>
              <p className="mb-4">
                - will save on hefty transfer fee and conversion charges. <br />
                - will get seemless experience to transfer money
                <br />- easy interface and quick delivery
              </p>
              <p>
                <strong className="text-info">How Program works -</strong>
              </p>
              <p className="mb-4">
                1. Register - Provide your personal/company details <br />
                2. Provide details (website/blog etc.) how you will promote us.
                <br />
                3. Our Marketing team will send you details of API or tracking
                link along with creatives.
                <br />
                4. Start Promoting
              </p>
            </div>
            <button
              className="btn btn-sm btn-light text-primary px-4 fw-700"
              onClick={() =>
                window.open("https://affiliate.xmonies.com/", "_blank")
              }
            >
              Affiliate Program
            </button>
          </div>
        </div>
      </div>
      <Footer />
    </React.Fragment>
  );
}
