/* eslint-disable react-hooks/exhaustive-deps */
import moment from "moment";
import { useEffect, useReducer } from "react";
import { useSelector } from "react-redux";
import { BankAccountAPI } from "../../../../apis/BankAccountAPI";
import { ProfileAPI } from "../../../../apis/ProfileAPI";
import useHttp from "../../../../hooks/useHttp";
import AddBankAccount from "./bankaccounts/AddBankAccount";
import BankAccountList from "./bankaccounts/BankAccountList";
import SenderDetails from "./SenderDetails";

export default function RequestMoney() {
  const AuthReducer = useSelector((state) => state);
  const [state, setState] = useReducer((state, newState) => ({ ...state, ...newState }), {
    isStep: 0,
    bankLists: [],
    bankAccountList: [],
    recvBankDetails: null,
    recvProfileDetails: {},
    recvAccountDetails: {},
    loader: false,
    senderEmail: "",
    senderEmailMsg: 0,
    confirmationModal: false,
    senderName: "",
    sendAmount: "",
    sendCountry: "",
    senderState: "",
    sendCurrency: "",
    countryStateList: [],
    senderCountryList:
      AuthReducer.sendCountryCode === "GB"
        ? [{ countryName: "United States of America", countryCode: "US", currencyCode: "USD" }]
        : [{ countryName: "United Kingdom", countryCode: "GB", currencyCode: "GBP" }],
  });
  const hookBankAccountList = useHttp(BankAccountAPI.bankAccountList);

  useEffect(() => {
    if (state.isStep === 0) {
      accountsList();
    }
  }, [state.isStep]);

  const accountsList = () => {
    const payload = {
      requestType: "SENDERACCOUNTLIST",
      userId: AuthReducer.userID,
      countryCode: AuthReducer.sendCountryCode,
      favouriteFlag: "1",
      startIndex: "0",
      recordsPerRequest: "",
    };
    setState({ loader: true });
    hookBankAccountList.sendRequest(payload, function (data) {
      setState({ loader: false });
      if (data.status == "S") {
        let resData = [];
        data.responseData.forEach((detail, i) => {
          let newData = {
            key: i,
            sendAccId: `${detail.sendAccId}`,
            accountHolderName: `${detail.accountHolderName}`,
            recordToken: `${detail.recordToken}`,
            bankName: `${detail.bankName}`,
            accountNo: `${detail.accountNo}`,
            bankClearingCode: `${detail.sortCode}`,
            dateAdded: moment(detail.createdDate).format("MM-DD-YYYY"),
            status: detail.accountStatus.toUpperCase() === "R" ? "Verified" : "Rejected",
          };
          resData.push(newData);
        });
        setState({
          bankAccountList: resData,
        });
      }
    });
  };

  return (
    <div className="Request-Money">
      {state.isStep === 0 && <BankAccountList state={state} setState={setState} />}
      {state.isStep === 1 && <AddBankAccount state={state} setState={setState} />}
      {state.isStep === 2 && <SenderDetails state={state} setState={setState} />}
    </div>
  );
}
