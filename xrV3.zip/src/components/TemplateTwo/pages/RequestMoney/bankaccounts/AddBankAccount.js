import { AutoComplete, Form, Input, notification, Select } from "antd";
import { useEffect, useState } from "react";
import { Col, Row } from "react-bootstrap";
import { useSelector } from "react-redux";
import { BankAccountAPI } from "../../../../../apis/BankAccountAPI";
import { ReceiverAPI } from "../../../../../apis/ReceiverAPI";
import useHttp from "../../../../../hooks/useHttp";
import Spinner from "../../../../../reusable/Spinner";
import { COUNTRY } from "../../../../../services/Country";
import SubHeader from "../../../layout/SubHeader";

export default function AddBankAccount(props) {
  const AuthReducer = useSelector((state) => state);
  const { state, setState } = props;
  const [form] = Form.useForm();
  const [loader, setLoader] = useState(0);
  useEffect(() => {
    getBankList();
  }, []);

  const hookGetBankLists = useHttp(ReceiverAPI.bankLists);
  const hookCheckDuplicateBankAccount = useHttp(BankAccountAPI.checkDuplicateBankAccount);
  const hookAddBankAccount = useHttp(BankAccountAPI.addBankAccount);

  const addBankAccount = (value) => {
    let payload = {
      requestType: "SENDERACCOUNTADD",
      userId: AuthReducer.userID,
      countryCode: AuthReducer.sendCountryCode,
      currencyCode: COUNTRY[AuthReducer.sendCountryCode].countryCurrency,
      accountHolder: AuthReducer.userFullName,
      bankCode: value.bankSortCode,
      bankNumber: "",
      bankName: value.bankName.toUpperCase().trim(),
      accountNo: value.accountNo,
      accountType: "S",
      accCurrencyCode: COUNTRY[AuthReducer.sendCountryCode].countryCurrency,
      sortCode: value.bankSortCode,
      bankCountry: AuthReducer.sendCountryCode,
      ifsc: "",
      branchCode: "",
      bankBranch: "",
      bankCity: "",
      bankState: "",
      isDefaultAcc: "",
      tncAgree: "",
      processType: "",
      routingNumber: "",
      processingPartner: "",
      processingMode: "",
      remark: "",
      isSwiftCodeValid: "",
      noOfAttempts: "",
      transitNumber: "",
      swiftCode: "",
      iban: "",
      bsbCode: "",
    };
    setLoader((prevState) => prevState + 1);
    hookAddBankAccount.sendRequest(payload, function (data) {
      setLoader((prevState) => prevState - 1);
      if (data.status === "S") {
        setState({ isStep: 0 });
        notification.success({ message: data.message });
      } else {
        notification.error({ message: data.errorMessage });
        let errors = [];
        data.errorList.forEach((error, i) => {
          let errorData = {
            name: error.field,
            errors: [error.error],
          };
          errors.push(errorData);
        });
        if (errors.length > 0) form.setFields(errors);
      }
    });
  };

  const checkDupeBank = (value) => {
    let payload = {
      requestType: "CHECKDUPLICATE",
      userId: AuthReducer.userID,
      bankName: value.bankName.trim(),
      accountNo: value.accountNo,
    };
    setLoader((prevState) => prevState + 1);
    hookCheckDuplicateBankAccount.sendRequest(payload, function (data) {
      setLoader((prevState) => prevState - 1);
      if (data.status === "S") {
        addBankAccount(value);
        notification.success({ message: data.message });
      } else {
        notification.error({ message: data.errorMessage });
      }
    });
  };

  const getBankList = () => {
    const payload = {
      requestType: "BANKLIST",
      countryCode: AuthReducer.regCountryCode,
      userId: AuthReducer.userID,
    };
    setLoader((prevState) => prevState + 1);
    hookGetBankLists.sendRequest(payload, function (data) {
      setLoader((prevState) => prevState - 1);
      setLoader(false);
      if (data.status === "S") {
        setState({
          bankLists: data.responseData,
        });
      }
    });
  };
  return (
    <div>
      <SubHeader title="Add a Bank Account" />
      <Spinner spinning={loader}>
        <div className="template2__main py-5">
          <div className="sendmoney__page">
            <div className="container">
              <Form form={form} autoComplete="off" onFinish={checkDupeBank}>
                <Row className="justify-content-center">
                  <Col md={12}>
                    <div className="">
                      <label className="form-label text-white">Bank Sort Code</label>
                      <Form.Item
                        className="form-item"
                        name="bankSortCode"
                        rules={[
                          {
                            required: true,
                            message: "Please input your Bank Sort Code.",
                          },
                          {
                            min: 6,
                            max: 6,
                            message: "Bank Sort Code must be 6 digit only.",
                          },
                          {
                            pattern: /^[0-9\b]+$/,
                            message: "Only Numbers allowed",
                          },
                        ]}
                      >
                        <Input
                          // onBlur={onChangeBankSortCode}
                          placeholder="Bank Sort Code"
                          autoComplete="off"
                        />
                      </Form.Item>
                    </div>
                  </Col>
                  <Col md={12}>
                    <div className="">
                      <label className="form-label text-white">Bank Name</label>
                      <Form.Item
                        className="form-item"
                        name="bankName"
                        rules={[
                          {
                            required: true,
                            message: "Please select your Bank.",
                          },
                        ]}
                      >
                        {/* <Input placeholder="Bank Name" /> */}
                        <AutoComplete
                          className="w-100"
                          placeholder="Select your Bank"
                          filterOption={(inputValue, option) =>
                            option.value.toUpperCase().indexOf(inputValue.toUpperCase()) !== -1
                          }
                          showSearch
                        >
                          {state?.bankLists?.map((bank, i) => {
                            return (
                              <Select.Option key={i} value={bank.bankName}>
                                {bank.bankName}
                              </Select.Option>
                            );
                          })}
                        </AutoComplete>
                      </Form.Item>
                    </div>
                  </Col>
                  <Col md={12}>
                    <div className="">
                      <label className="form-label text-white">Account Number</label>
                      <Form.Item
                        className="form-item"
                        name="accountNo"
                        rules={[
                          {
                            required: true,
                            message: "Please input your Account Number.",
                          },
                          {
                            min: 5,
                            message: "Account Number should be between 5 and 34 digits",
                          },
                          {
                            max: 34,
                            message: "Account Number should be between 5 and 34 digits",
                          },
                          {
                            pattern: /^[0-9\b]+$/,
                            message: "Only Numbers allowed",
                          },
                        ]}
                      >
                        <Input.Password placeholder="Enter your Account Number" />
                      </Form.Item>
                    </div>
                  </Col>
                  <Col md={12}>
                    <div className="">
                      <label className="form-label text-white">Confirm Account Number</label>
                      <Form.Item
                        className="form-item"
                        name="accConNum"
                        rules={[
                          {
                            required: true,
                            message: "Please input your Confirm Account Number.",
                          },
                          ({ getFieldValue }) => ({
                            validator(rule, value) {
                              if (!value || getFieldValue("accountNo") === value) {
                                return Promise.resolve();
                              }
                              return Promise.reject(
                                "The two account number that you entered do not match!",
                              );
                            },
                          }),
                        ]}
                      >
                        <Input.Password placeholder="Enter your Confirm Account Number" />
                      </Form.Item>
                    </div>
                  </Col>

                  <Col md={12}>
                    <Row>
                      <Col md={6}>
                        <button
                          onClick={() => setState({ isStep: 0 })}
                          style={{ width: "200px", height: "42px", fontWeight: 700 }}
                          className="btn-2"
                          type="button"
                        >
                          Back
                        </button>
                      </Col>
                      <Col md={6} className="d-flex justify-content-end mt-3 mt-md-0">
                        <button
                          style={{ width: "200px", height: "42px", fontWeight: 700 }}
                          className="btn-1"
                          type="submit"
                        >
                          Next
                        </button>
                      </Col>
                    </Row>
                  </Col>
                </Row>
              </Form>
            </div>
          </div>
        </div>
      </Spinner>
    </div>
  );
}
