import { ConfigProvider, Table } from "antd";
import { useEffect } from "react";
import { useState } from "react";
import { Col, Row } from "react-bootstrap";
import { useSelector } from "react-redux";
import { useNavigate } from "react-router-dom";
import { BankAccountAPI } from "../../../../../apis/BankAccountAPI";
import { ProfileAPI } from "../../../../../apis/ProfileAPI";
import useHttp from "../../../../../hooks/useHttp";

import Spinner from "../../../../../reusable/Spinner";
import SubHeader from "../../../layout/SubHeader";

export default function BankAccountList(props) {
  const AuthReducer = useSelector((state) => state);
  const [selectedRowKeys, setSelectedRowKeys] = useState([null]);
  const { state, setState } = props;
  const navigate = useNavigate();

  const hookGetProfile = useHttp(ProfileAPI.getProfile);
  const hookViewBankAccountDetails = useHttp(BankAccountAPI.viewBankAccountDetails);

  useEffect(() => {
    getProfile();
  }, []);

  const getProfile = () => {
    let payload = {
      requestType: "LEAD",
      userId: AuthReducer.userID,
    };
    setState({ loader: true });
    hookGetProfile.sendRequest(payload, function (data) {
      if (data.status == "S") {
        setState({ recvProfileDetails: data });
      }
    });
  };
  const viewDetailsHandlerClick = (row) => {
    setState({ isModalVisible: true });
    const payload = {
      requestType: "SENDERACCOUNT",
      userId: AuthReducer.userID,
      sendAccId: row.sendAccId,
      recordToken: row.recordToken,
    };
    setState({ loader: true });
    hookViewBankAccountDetails.sendRequest(payload, function (data) {
      setState({ loader: false });
      if (data.status == "S") {
        setState({
          isStep: 2,
          recvAccountDetails: data,
        });
      }
    });
  };

  const renderEmpty = () => (
    <div className="RenderEmpty">
      <h5>No Bank Accounts found</h5>
      <div>
        <p>No Bank accounts are linked to your xmonies account.</p>
        <p>Select "Add a Bank Account" to add a new bank account for sending or receiving money.</p>
      </div>
      <div className="d-flex flex-column align-items-center gap-3">
        <button className="btn-1" type="button" onClick={() => setState({ isStep: 1 })}>
          Add a Bank Account
        </button>
        <button className="btn-2" type="button" onClick={() => navigate("/new-transaction")}>
          Back
        </button>
      </div>
    </div>
  );
  return (
    <div>
      <SubHeader title="Select a Bank Account" />
      <Spinner spinning={state.loader}>
        <div className="template2__main py-5">
          <div className="sendmoney__page">
            <div className="container">
              <Row>
                <ConfigProvider renderEmpty={renderEmpty}>
                  <Table
                    onRow={(record, rowIndex) => {
                      return {
                        onClick: () => {
                          setSelectedRowKeys([record.key]);
                          setState({ recvBankDetails: record });
                          viewDetailsHandlerClick(record);
                        },
                      };
                    }}
                    rowSelection={{
                      type: "radio",
                      selectedRowKeys,
                      selections: [
                        Table.SELECTION_ALL,
                        Table.SELECTION_INVERT,
                        Table.SELECTION_NONE,
                        {
                          key: "odd",
                          text: "Select Odd Row",
                          onSelect: (changableRowKeys) => {
                            let newSelectedRowKeys = [];
                            newSelectedRowKeys = changableRowKeys.filter((_, index) => {
                              if (index % 2 !== 0) {
                                return false;
                              }
                              return true;
                            });
                            setSelectedRowKeys(newSelectedRowKeys);
                          },
                        },
                        {
                          key: "even",
                          text: "Select Even Row",
                          onSelect: (changableRowKeys) => {
                            let newSelectedRowKeys = [];
                            newSelectedRowKeys = changableRowKeys.filter((_, index) => {
                              if (index % 2 !== 0) {
                                return true;
                              }
                              return false;
                            });
                            setSelectedRowKeys(newSelectedRowKeys);
                          },
                        },
                      ],
                    }}
                    columns={[
                      {
                        title: "Account Name",
                        dataIndex: "accountHolderName",
                        key: "accountHolderName",
                      },
                      { title: "Bank Name", dataIndex: "bankName", key: "bankName" },
                      { title: "Account Number", dataIndex: "accountNo", key: "accountNo" },
                      {
                        title: "Sort Code",
                        dataIndex: "bankClearingCode",
                        key: "bankClearingCode",
                      },
                      { title: "Account Status", dataIndex: "status", key: "status" },
                    ]}
                    pagination={false}
                    dataSource={state.bankAccountList}
                  />
                </ConfigProvider>
              </Row>
              {state.bankAccountList.length !== 0 && (
                <div className="ant-table-wrapper">
                  <div className="ant-table">
                    <Row>
                      <Col md={6} className="mb-md-0 mb-3">
                        <button
                          onClick={() => navigate("/new-transaction")}
                          style={{
                            width: "200px",
                            height: "42px",
                            fontWeight: 700,
                            fontSize: "1rem",
                          }}
                          className="btn-2 mt-4 mt-md-0"
                          type="button"
                        >
                          Back
                        </button>
                      </Col>
                      <Col md={6} className="d-flex justify-content-end mb-md-0 mb-3">
                        <button
                          onClick={() => setState({ isStep: 1 })}
                          style={{
                            width: "200px",
                            height: "42px",
                            fontWeight: 700,
                            fontSize: "1rem",
                          }}
                          className="btn-1"
                          type="button"
                        >
                          Add a Bank Account
                        </button>
                      </Col>
                    </Row>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </Spinner>
    </div>
  );
}
