import RequestMoneyPreLogin from "./request-money";
// import RequestMoneyPostLogin from "./request-money-post-login";
import RequestMoneyNewFlow from "./RequestMoney";

export default function RequestMoney(props) {
  const isLoggedIn = props.appState.isLoggedIn;

  return isLoggedIn ? <RequestMoneyNewFlow /> : <RequestMoneyPreLogin />;
}
