/* eslint-disable react-hooks/exhaustive-deps */
/* eslint-disable jsx-a11y/alt-text */
import { Button, Form, Input, Modal, notification, Select, Spin } from "antd";
import { useEffect, useState } from "react";
import { Col, Row } from "react-bootstrap";
import { useSelector } from "react-redux";
import SubHeader from "../../layout/SubHeader";
import useHttp from "../../../../hooks/useHttp";
import { AuthAPI } from "../../../../apis/AuthAPI";
import Spinner from "../../../../reusable/Spinner";
import Lottie from "react-lottie";
import * as xrSpinnerLottie from "../../../../assets/images/XR/XR_spinner.json";
import bluetick from "../../../../assets/images/svg/bluetick.svg";
import redcross from "../../../../assets/images/svg/redcross.svg";
import { COUNTRY } from "../../../../services/Country";
import { GuestAPI } from "../../../../apis/GuestAPI";
import { ReceiverAPI } from "../../../../apis/ReceiverAPI";
import Swal from "sweetalert2";
import { useNavigate } from "react-router-dom";
import { validateEmailId } from "../../../../services/validations/email";

export default function BankAccountList(props) {
  const navigate = useNavigate("");
  const AuthReducer = useSelector((state) => state);
  const [loader, setLoader] = useState(false);
  const [spinner, setSpinner] = useState(false);

  const { state, setState } = props;
  const [form] = Form.useForm();
  const emailRegEx =
    /^[^<>()[\]\\,;:\%#^\s@\"$&!@]+@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z0-9]+\.)+[a-zA-Z]{2,}))$/;

  const hookcheckLoginId = useHttp(AuthAPI.checkLoginId);
  const hookGetCountryStates = useHttp(GuestAPI.countryStates);
  const hookRequestMoney = useHttp(ReceiverAPI.requestMoney);

  useEffect(() => {
    if (state.sendCountry) {
      getCountryStateList();
    }
  }, [state.sendCountry]);

  const requestMoneyHandler = () => {
    const bankPayload = {};
    if (AuthReducer.regCountryCode === "GB" || "US") {
      bankPayload.bankBranch = state.recvAccountDetails.sortCode;
      bankPayload.bankAddress = AuthReducer.regCountryCode;
      bankPayload.bankCity = AuthReducer.regCountryCode;
      bankPayload.bankState = AuthReducer.regCountryCode;
      bankPayload.bankCode = state.recvAccountDetails.sortCode;
      bankPayload.isSameBank = "N";
      // accountType: value.accountType,
      bankPayload.accountType = "S";
      bankPayload.bankName = state.recvAccountDetails.bankName;
    }
    let randomDigits = Math.floor(1000 + Math.random() * 9000);
    let payload = {
      requestType: "REQRECIPIENT",
      nickName: `${state.recvProfileDetails.firstName}${randomDigits}`,
      recvFirstName: state.recvProfileDetails.firstName,
      recvMiddleName: "",
      recvLastName: state.recvProfileDetails.lastName,
      dob: "",
      receiverType: "INDIVIDUAL",
      accountNo: state.recvAccountDetails.accountNo,
      relationship: "SELF",
      gender: "M",
      address1: state.recvProfileDetails.address1.trim(),
      address2: state.recvProfileDetails.address2.trim(),
      state: state.recvProfileDetails.state,
      stateOther: "",
      city: state.recvProfileDetails.city,
      cityOther: "",
      zipcode: state.recvProfileDetails.zip,
      emailId: "",
      mobileCountryCode: state.recvProfileDetails.mobilePhoneCode,
      mobileNo: state.recvProfileDetails.mobileNo,
      altPhone: "",
      fax: "",
      recvModeCode: "DC",
      accountHolderName: state.recvAccountDetails.accountHolder,
      purpose: "SAVINGS",
      purposeCode: "P1301",
      remark: "",
      nearestLogisticCity: "",
      sendAmount: state.sendAmount,
      sendCountryCode: state.sendCountry,
      sendCurrencyCode: state.sendCurrency,
      sendFirstName: state.recvProfileDetails.firstName,
      sendLastName: state.recvProfileDetails.lastName,
      sendMobilePhoneCode: state.recvProfileDetails.mobilePhoneCode,
      sendMobileNo: state.recvProfileDetails.mobileNo,
      countryCode: AuthReducer.sendCountryCode,
      currencyCode: AuthReducer.sendCurrencyCode,
      uniqueIdentifierType: "",
      uniqueIdentifierValue: "",
      senderLoginid: state.senderEmail,
      recvLoginid: state.recvProfileDetails.emailId,
      ...bankPayload,
    };
    hookRequestMoney.sendRequest(payload, (res) => {
      setLoader(false);
      if (res.status == "S") {
        Swal.fire({
          title: "Success",
          text: "Request submitted successfully",
          icon: "success",
          confirmButtonColor: "#2dbe60",
          allowOutsideClick: false,
        }).then((result) => {
          if (result.isConfirmed) {
            navigate("/new-transaction");
          }
        });
      } else {
        notification.error({ message: res.errorMessage });
        let errors = [];
        res.errorList.forEach((error, i) => {
          let errorData = {
            name: error.field,
            errors: [error.error],
          };
          errors.push(errorData);
        });
        if (errors.length > 0) form.setFields(errors);
      }
    });
  };

  const getCountryStateList = () => {
    let payload = {
      requestType: "STATELIST",
      countryCode: state.sendCountry,
      keyword: "",
    };
    setLoader(true);
    hookGetCountryStates.sendRequest(payload, function (data) {
      setLoader(false);
      if (data.status === "S") {
        setState({ countryStateList: data.responseData });
      }
    });
  };

  const checkSenderEmail = () => {
    if (state.senderEmail.length !== 0) {
      let payload = {
        requestType: "CHECKLOGINID",
        loginId: state.senderEmail,
      };
      setSpinner(true);
      hookcheckLoginId.sendRequest(payload, function (data) {
        setSpinner(false);
        if (data.status === "F") {
          setState({ senderEmailMsg: 1 });
        } else {
          setState({ senderEmailMsg: 2 });
        }
      });
    }
  };
  const backHandler = () => {
    setState({
      isStep: 0,
      senderEmailMsg: 0,
      sendAmount: "",
      sendCurrency: "",
      senderState: "",
      sendCountry: "",
      senderName: "",
      senderEmail: "",
      confirmationModal: false,
    });
  };
  const submitHandler = (value) => {
    setState({ confirmationModal: true });
  };
  const antIcon = (
    <Lottie
      height={39}
      width={15}
      options={{
        loop: true,
        autoplay: true,
        animationData: xrSpinnerLottie,
        rendererSettings: {
          preserveAspectRatio: "xMidYMid slice",
        },
      }}
    />
  );
  const verifyButton = (
    <span className="AddonAfter">
      {spinner ? (
        <p style={{ cursor: "pointer", color: "#0030536e" }} onClick={checkSenderEmail}>
          Checking
        </p>
      ) : (
        state.senderEmailMsg !== 1 &&
        emailRegEx.test(state.senderEmail) && (
          <p
            style={{ cursor: "pointer", color: "#003153", fontWeight: 700, fontSize: "0.8rem" }}
            onClick={checkSenderEmail}
          >
            Verify
          </p>
        )
      )}
      <Spin spinning={spinner} indicator={antIcon}></Spin>
    </span>
  );
  const currencyContainer = (
    <span className="AddonBefore">
      {state.sendCurrency && (
        <p style={{ cursor: "pointer", color: "#003153", fontWeight: 700, fontSize: "1rem" }}>
          {COUNTRY[state.sendCountry]?.currencySymbol}
        </p>
      )}
    </span>
  );

  return (
    <div className="SenderDetails">
      <SubHeader title="Add Sender Details" />
      <Spinner spinning={loader}>
        <div className="template2__main py-5">
          <div className="sendmoney__page">
            <div className="container">
              <Modal
                className="req-mon-modal"
                visible={state.confirmationModal}
                footer={null}
                closable={false}
                centered
                width={410}
              >
                <Row>
                  <p className="para-1">
                    Are you sure you want to request {COUNTRY[state?.sendCountry]?.currencySymbol}{" "}
                    {Number(state?.sendAmount).toLocaleString()} from {state?.senderName}?
                  </p>
                </Row>
                <Row>
                  <p className="para-2">
                    If you select yes, {state?.senderName} will recieve a notification with your
                    request of {COUNTRY[state?.sendCountry]?.currencySymbol}{" "}
                    {Number(state?.sendAmount).toLocaleString()}.
                  </p>
                </Row>
                <Row>
                  <Col md={6}>
                    <Button
                      className="modal-btn-2"
                      onClick={() => setState({ confirmationModal: false })}
                    >
                      No
                    </Button>
                  </Col>
                  <Col md={6} className="mt-md-0 mt-3">
                    <Button className="modal-btn-1" onClick={requestMoneyHandler}>
                      Yes
                    </Button>
                  </Col>
                </Row>
              </Modal>
              <Form form={form} onFinish={submitHandler}>
                <Row>
                  <Col md={5}>
                    <Row>
                      <label className="form-label text-white">Enter sender's Email</label>
                      <Form.Item
                        name="senderEmail"
                        rules={[
                          ({ getFieldValue }) => ({
                            validator(rule, value) {
                              let message = "";
                              let obj = validateEmailId(value ? value : "");
                              message = obj.message;
                              if (obj.status === "S") {
                                return Promise.resolve();
                              }
                              return Promise.reject(message);
                            },
                          }),
                        ]}
                      >
                        <Input
                          autoComplete="none"
                          onChange={(e) =>
                            setState({ senderEmail: e.target.value, senderEmailMsg: 0 })
                          }
                          placeholder="Sender Email Address"
                          addonAfter={verifyButton}
                        />
                      </Form.Item>
                      {state.senderEmailMsg === 1 && (
                        <p className="text-info d-flex align-items-center gap-1">
                          <img src={bluetick} />
                          Sender is an XMONIES user!
                        </p>
                      )}
                      {state.senderEmailMsg === 2 && (
                        <p style={{ color: "#FF759B" }} className="d-flex align-items-center gap-1">
                          <img src={redcross} />
                          Sender is not an XMONIES user!
                        </p>
                      )}
                    </Row>
                  </Col>
                  <Col md={2}></Col>
                  <Col md={5}>
                    <Row>
                      <label className="form-label text-white">Sender's Name</label>
                      <Form.Item
                        name="senderName"
                        rules={[
                          {
                            required: true,
                            message: "Please Input Senders Name.",
                          },
                          {
                            min: 2,
                            message: "Senders Name should be between 2 and 30 characters",
                          },
                          {
                            max: 30,
                            message: "Senders Name should be between 2 and 30 characters",
                          },
                        ]}
                      >
                        <Input
                          onChange={(e) => setState({ senderName: e.target.value })}
                          placeholder="Sender Name"
                        />
                      </Form.Item>
                    </Row>
                    <Row>
                      <label className="form-label text-white">Sender's Country</label>
                      <Form.Item
                        name="senderCountry"
                        rules={[
                          {
                            required: true,
                            message: "Please Select Sender Country.",
                          },
                        ]}
                      >
                        <Select
                          placeholder="Sender Country"
                          onChange={(e) => setState({ sendCountry: e })}
                        >
                          {state.senderCountryList.map((i) => (
                            <Select.Option value={i.countryCode}>{i.countryName}</Select.Option>
                          ))}
                        </Select>
                      </Form.Item>
                    </Row>
                    <Row>
                      <label className="form-label text-white">Sender's State</label>
                      <Form.Item
                        name="senderState"
                        rules={[
                          {
                            required: true,
                            message: "Please Select Sender State.",
                          },
                        ]}
                      >
                        <Select
                          placeholder="Sender State"
                          onChange={(e) => setState({ senderState: e })}
                        >
                          {state.countryStateList.map((i) => (
                            <Select.Option value={i.state}>{i.state}</Select.Option>
                          ))}
                        </Select>
                      </Form.Item>
                    </Row>
                    {state.senderEmailMsg === 1 && (
                      <Row>
                        <label className="form-label text-white">Enter Requested Amount</label>
                        <Col md={5}>
                          <Form.Item
                            name="currency"
                            rules={[
                              {
                                required: true,
                                message: "Please Select Currency.",
                              },
                            ]}
                          >
                            <Select
                              placeholder="Select Currency"
                              onChange={(e) => setState({ sendCurrency: e })}
                            >
                              {state.senderCountryList.map((i) => (
                                <Select.Option value={i.currencyCode}>
                                  {i.currencyCode} ({i.countryName})
                                </Select.Option>
                              ))}
                            </Select>
                          </Form.Item>
                        </Col>
                        <Col md={7}>
                          <Form.Item
                            name="amount"
                            rules={[
                              {
                                required: true,
                                message: "Please Input Amount.",
                              },
                              {
                                pattern: new RegExp(/^[0-9]*$/),
                                message: "Please Input a valid Amount",
                              },
                            ]}
                          >
                            <Input
                              onChange={(e) => {
                                setState({ sendAmount: e.target.value });
                              }}
                              className="amount-input"
                              addonBefore={currencyContainer}
                              placeholder="Amount"
                            />
                          </Form.Item>
                        </Col>
                      </Row>
                    )}
                  </Col>
                </Row>
                <Row className="mt-5">
                  <Col md={6} className="mb-md-0 mb-3">
                    <button
                      onClick={backHandler}
                      style={{
                        width: "200px",
                        height: "42px",
                        fontWeight: 700,
                        fontSize: "1rem",
                      }}
                      className="btn-2 mt-4 mt-md-0"
                      type="button"
                    >
                      Back
                    </button>
                  </Col>
                  <Col md={6} className="d-flex justify-content-end mb-md-0 mb-3">
                    <button
                      disabled={state.senderEmailMsg !== 1}
                      style={{
                        width: "200px",
                        height: "42px",
                        fontWeight: 700,
                        fontSize: "1rem",
                      }}
                      className="btn-1"
                      type="submit"
                    >
                      Next
                    </button>
                  </Col>
                </Row>
              </Form>
            </div>
          </div>
        </div>
      </Spinner>
    </div>
  );
}
