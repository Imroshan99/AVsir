import { AutoComplete, Form, Input, Select } from "antd";
import { Row, Col } from "react-bootstrap";
import { inputValidations } from "../../../../services/validations/validations";
import { useSelector } from "react-redux";
import TextArea from "antd/lib/input/TextArea";
const { Option } = Select;
const BankComponent = (props) => {
  const { state, onSelectBank, recvCountryCode } = props;
  const AuthReducer = useSelector((state) => state);
  const _recvCountryCode = recvCountryCode ? recvCountryCode : AuthReducer.recvCountryCode;
  // console.log('_recvCountryCode', _recvCountryCode)
  if (_recvCountryCode === "") {
    return <></>;
  }
  if (_recvCountryCode === "PH" || _recvCountryCode === "ID" || _recvCountryCode === "TH") {
    return (
      <div>
        <Row>
          <Col>
            <Row>
              <div>
                <label className="form-label">Bank Name</label>
                <Form.Item
                  className="form-item"
                  name="bankName"
                  rules={[
                    {
                      required: true,
                      message: "Please select your Bank.",
                    },
                  ]}
                >
                  <AutoComplete size="large" 
                    showSearch
                    labelInValue
                    placeholder="Select Bank or Type Bank Name"
                    onChange={onSelectBank}
                  >
                    {state.bankNames.map((bank, i) => {
                      return (
                        <Option key={i} value={bank.bankName}>
                          <span bankCode={bank.bankCode} isSameBank={bank.isSameBank}>
                            {bank.bankName}
                          </span>
                        </Option>
                      );
                    })}
                  </AutoComplete>
                </Form.Item>
              </div>
            </Row>
            <Row>
              <div>
                <label className="form-label">Bank's BIC Code</label>
                <Form.Item
                  className="form-item"
                  name="bankCode"
                  rules={[
                    {
                      required: true,
                      message: "Please Bank's BIC Code",
                    },
                    ...inputValidations.bankBICCode(_recvCountryCode),
                  ]}
                >
                  <Input size="large"  autoComplete="none" />
                </Form.Item>
              </div>
            </Row>

            <Row>
              <div>
                <label className="form-label">Account Number</label>
                <Form.Item
                  className="form-item"
                  name="accountNo"
                  rules={[
                    {
                      required: true,
                      message: "Please input your Account Number.",
                    },
                    ...inputValidations.accountNumber(_recvCountryCode),
                  ]}
                >
                  <Input.Password  size="large" 
                    autoComplete="new-password"
                    className="input_account_no"
                    placeholder="Enter your Account Number"
                    onPaste={(e) => {
                      e.preventDefault();
                      return false;
                    }}
                    onCopy={(e) => {
                      e.preventDefault();
                      return false;
                    }}
                    visibilityToggle={false}
                  />
                </Form.Item>
              </div>
            </Row>
          </Col>
        </Row>
      </div>
    );
  }

  if (_recvCountryCode === "BD") {
    return (
      <div>
        <Row>
          <Col>
            <Row>
              <div>
                <label className="form-label">Bank Name</label>
                <Form.Item
                  className="form-item"
                  name="bankName"
                  rules={[
                    {
                      required: true,
                      message: "Please select your Bank.",
                    },
                  ]}
                >
                  <AutoComplete size="large" 
                    showSearch
                    labelInValue
                    placeholder="Select Bank or Type Bank Name"
                    onChange={onSelectBank}
                  >
                    {state.bankNames.map((bank, i) => {
                      return (
                        <Option key={i} value={bank.bankName}>
                          <span bankCode={bank.bankCode} isSameBank={bank.isSameBank}>
                            {bank.bankName}
                          </span>
                        </Option>
                      );
                    })}
                  </AutoComplete>
                </Form.Item>
              </div>
            </Row>
            <Row>
              <div>
                <label className="form-label">Bank Branch Number</label>
                <Form.Item
                  className="form-item"
                  name="branchCode"
                  rules={[
                    {
                      required: true,
                      message: "Please enter Bank Branch Number.",
                    },
                    ...inputValidations.bankBranchNo(_recvCountryCode),
                  ]}
                >
                  <Input  size="large"  autoComplete="none" />
                </Form.Item>
              </div>
            </Row>
            <Row>
              <div>
                <label className="form-label">Bank's BIC Code</label>
                <Form.Item
                  className="form-item"
                  name="bankCode"
                  rules={[
                    {
                      required: true,
                      message: "Please Bank's BIC Code",
                    },
                    ...inputValidations.bankBICCode(_recvCountryCode),
                  ]}
                >
                  <Input size="large"  autoComplete="none" />
                </Form.Item>
              </div>
            </Row>

            <Row>
              <div>
                <label className="form-label">Account Number</label>
                <Form.Item
                  className="form-item"
                  name="accountNo"
                  rules={[
                    {
                      required: true,
                      message: "Please input your Account Number.",
                    },
                    ...inputValidations.accountNumber(_recvCountryCode),
                  ]}
                >
                  <Input.Password  size="large" 
                    autoComplete="new-password"
                    className="input_account_no"
                    placeholder="Enter your Account Number"
                    onPaste={(e) => {
                      e.preventDefault();
                      return false;
                    }}
                    onCopy={(e) => {
                      e.preventDefault();
                      return false;
                    }}
                    visibilityToggle={false}
                  />
                </Form.Item>
              </div>
            </Row>
          </Col>
        </Row>
      </div>
    );
  }

  if (_recvCountryCode === "LK") {
    return (
      <div>
        <Row>
          <Col>
            <Row>
              <div>
                <label className="form-label">Bank Name</label>
                <Form.Item
                  className="form-item"
                  name="bankName"
                  rules={[
                    {
                      required: true,
                      message: "Please select your Bank.",
                    },
                  ]}
                >
                 <AutoComplete size="large" 
                    showSearch
                    labelInValue
                    placeholder="Select Bank or Type Bank Name"
                    onChange={onSelectBank}
                  >
                    {state.bankNames.map((bank, i) => {
                      return (
                        <Option key={i} value={bank.bankName}>
                          <span bankCode={bank.bankCode} isSameBank={bank.isSameBank}>
                            {bank.bankName}
                          </span>
                        </Option>
                      );
                    })}
                  </AutoComplete>
                </Form.Item>
              </div>
            </Row>
            <Row>
              <div>
                <label className="form-label">Bank Branch Number</label>
                <Form.Item
                  className="form-item"
                  name="branchCode"
                  rules={[
                    {
                      required: true,
                      message: "Please enter Bank Branch Number.",
                    },
                    ...inputValidations.bankBranchNo(_recvCountryCode),
                  ]}
                >
                  <Input size="large" autoComplete="none" />
                </Form.Item>
              </div>
            </Row>
            <Row>
              <div>
                <label className="form-label">Bank Code</label>
                <Form.Item
                  className="form-item"
                  name="bankCode"
                  rules={[
                    {
                      required: true,
                      message: "Please enter Bank Code",
                    },
                    ...inputValidations.bankCode(_recvCountryCode),
                  ]}
                >
                  <Input size="large" autoComplete="none" />
                </Form.Item>
              </div>
            </Row>
            <Row>
              <div>
                <label className="form-label">Bank's BIC Code</label>
                <Form.Item
                  className="form-item"
                  name="swiftCode"
                  rules={[
                    {
                      required: true,
                      message: "Please Bank's BIC Code",
                    },
                    ...inputValidations.bankBICCode(_recvCountryCode),
                  ]}
                >
                  <Input size="large" autoComplete="none" />
                </Form.Item>
              </div>
            </Row>

            <Row>
              <div>
                <label className="form-label">Account Number</label>
                <Form.Item
                  className="form-item"
                  name="accountNo"
                  rules={[
                    {
                      required: true,
                      message: "Please input your Account Number.",
                    },
                    ...inputValidations.accountNumber(_recvCountryCode),
                  ]}
                >
                  <Input.Password
                    autoComplete="new-password"
                    className="input_account_no"
                    size="large"
                    placeholder="Enter your Account Number"
                    onPaste={(e) => {
                      e.preventDefault();
                      return false;
                    }}
                    onCopy={(e) => {
                      e.preventDefault();
                      return false;
                    }}
                    visibilityToggle={false}
                  />
                </Form.Item>
              </div>
              
            </Row>
          </Col>
        </Row>
        
        
      </div>
    );
  }

  return (
    <div>
      <Row>
        <Col>
          <Row>
            <div>
              <label className="form-label">Bank's Swift Code</label>
              <Form.Item
                className="form-item"
                name="bankCode"
                rules={[
                  {
                    required: true,
                    message: "Please Bank's Swift Code",
                  },
                  ...inputValidations.swiftCode(_recvCountryCode),
                ]}
              >
                <Input size="large"  autoComplete="none" />
              </Form.Item>
            </div>
          </Row>
          <Row>
            <div>
              <label className="form-label">Bank Name</label>
              <Form.Item
                className="form-item"
                name="bankName"
                rules={[
                  {
                    required: true,
                    message: "Please select your Bank.",
                  },
                ]}
              >
                <AutoComplete size="large" 
                  showSearch
                  labelInValue
                  placeholder="Select Bank"
                  onChange={onSelectBank}
                >
                  {state.bankNames.map((bank, i) => {
                    return (
                      <Option key={i} value={bank.bankName}>
                        <span bankCode={bank.bankCode} isSameBank={bank.isSameBank}>
                          {bank.bankName}
                        </span>
                      </Option>
                    );
                  })}
                </AutoComplete>
              </Form.Item>
            </div>
          </Row>
          <Row>
            <div>
              <label className="form-label">Bank Address</label>
              <Form.Item
                className="form-item"
                name="bankAddress"
                rules={[
                  {
                    required: true,
                    message: "Please enter your Bank Address.",
                  },
                  ...inputValidations.bankAddress(_recvCountryCode),
                ]}
              >
                <TextArea  size="large" 
                  autoComplete="none"
                  onKeyDown={(e) => {
                    if (e.key === "Enter") {
                      e.preventDefault();
                      if (!e.shiftKey) {
                        e.preventDefault();
                      }
                    }
                  }}
                  style={{ resize: "none", height: "5rem" }}
                ></TextArea>
              </Form.Item>
            </div>
          </Row>
          <Row>
            <div>
              <label className="form-label">Bank Sort Code</label>
              <Form.Item
                className="form-item"
                name="branchCode"
                rules={[
                  {
                    required: true,
                    message: "Please enter Bank Sort Code.",
                  },
                  ...inputValidations.bankSortCode(_recvCountryCode),

                  // {
                  //   pattern: /^[0-9\b]+$/,
                  //   message: "Only Numbers allowed",
                  // },
                ]}
              >
                <Input  size="large"  autoComplete="none" />
              </Form.Item>
            </div>
          </Row>
          <Row>
            <div>
              <label className="form-label">IBAN Number</label>
              <Form.Item
                className="form-item"
                name="accountNo"
                rules={[
                  {
                    required: true,
                    message: "Please input your IBAN Number.",
                  },
                  ...inputValidations.accountNumber(_recvCountryCode),
                ]}
              >
                <Input.Password  size="large" 
                  autoComplete="new-password"
                  className="input_account_no"
                  placeholder="Enter your IBAN Number"
                  onPaste={(e) => {
                    e.preventDefault();
                    return false;
                  }}
                  onCopy={(e) => {
                    e.preventDefault();
                    return false;
                  }}
                  visibilityToggle={false}
                />
              </Form.Item>
            </div>
          </Row>
        </Col>
        <Col>
          <Row>
            <div>
              <label className="form-label">Intermediary Bank's Swift Code</label>
              <Form.Item
                className="form-item"
                name="interBankCode"
                rules={[...inputValidations.interSwiftCode(_recvCountryCode)]}
              >
                <Input size="large"  autoComplete="none" />
              </Form.Item>
            </div>
          </Row>
          <Row>
            <div>
              <label className="form-label">Intermediary Bank Name</label>
              <Form.Item
                className="form-item"
                name="interBankName"
                rules={[...inputValidations.interBankName(_recvCountryCode)]}
              >
                <Input size="large"  autoComplete="none" />
              </Form.Item>
            </div>
          </Row>
          <Row>
            <div>
              <label className="form-label">Intermediary Bank Address</label>
              <Form.Item
                className="form-item"
                name="interBankAddress"
                rules={[...inputValidations.interBankAddress(_recvCountryCode)]}
              >
                <TextArea  size="large" 
                  onKeyDown={(e) => {
                    if (e.key === "Enter") {
                      e.preventDefault();
                      if (!e.shiftKey) {
                        e.preventDefault();
                      }
                    }
                  }}
                  style={{ resize: "none", height: "5rem" }}
                  autoComplete="none"
                ></TextArea>
              </Form.Item>
            </div>
          </Row>
          <Row>
            <label className="form-label">Intermediary Bank Country</label>
            <div>
              <Form.Item
                className="form-item"
                name="interBankCountry"
                // rules={[
                //   {
                //     required: true,
                //     message: "Please select Intermediary Bank Country.",
                //   },
                // ]}
              >
                <Select  size="large" 
                  // getPopupContainer={(trigger) => trigger.parentNode}
                  // labelInValue
                  placeholder="Select Intermediary Bank Country"
                >
                  {AuthReducer.recvCountryList.map((value, i) => {
                    return (
                      <Option key={i} value={value.recvCountry}>
                        {value.countryName}
                      </Option>
                    );
                  })}
                </Select>
              </Form.Item>
            </div>
          </Row>
        </Col>
      </Row>
    </div>
  );
};
export default BankComponent;
