import React, { useState } from "react";
import SubHeader from "../layout/SubHeader";
import logorefresh from "../../../assets/images/svg/refreshCaptcha.svg";
import { Row, Col } from "react-bootstrap";
import { Form, Input, notification, Select } from "antd";
import { Footer } from "../../../pages/LandingPage/XR";
import useHttp from "../../../hooks/useHttp";
import { GuestAPI } from "../../../apis/GuestAPI";
import Swal from "sweetalert2";
import { useNavigate } from "react-router-dom";
import { useReducer } from "react";
import { useEffect } from "react";
import Spinner from "../../../reusable/Spinner";
import { useSelector } from "react-redux";

const { Option } = Select;
const { TextArea } = Input;

export default function Contact(props) {
  const [form] = Form.useForm();
  const [form1] = Form.useForm();
  const navigate = useNavigate();
  const [captchaImg, setCaptchaImg] = useState();
  const [captchaID, setCaptchaID] = useState();
  const AuthReducer = useSelector((state) => state);
  const [state, setState] = useReducer(
    (state, newState) => ({ ...state, ...newState }),
    {
      phoneCodes: [],
      loader: false,
    }
  );
  const hookContactUsPostLogin = useHttp(GuestAPI.contactUsPostLogin);
  const hookContactUsPreLogin = useHttp(GuestAPI.contactUsPreLogin);
  const hookGetCountryPhoenCodes = useHttp(GuestAPI.getCountryPhoneCodes);
  const hookgetCaptcha = useHttp(GuestAPI.getCaptcha);
  const hookVerifyCaptcha = useHttp(GuestAPI.verifyCaptcha);

  useEffect(() => {
    getCountryPhoneCode();
    getCaptcha();
  }, []);
  const getCaptcha = () => {
    let payload = {
      requestType: "GETCAPTCHA",
    };
    setState({ loader: true });
    hookgetCaptcha.sendRequest(payload, function (data) {
      setState({ loader: false });
      if (data.status == "S") {
        setCaptchaImg(data.captchaImage);
        setCaptchaID(data.id);
      } else {
        notification.error({ message: data.errorMessage });
      }
    });
  };
  const getCountryPhoneCode = () => {
    const countryPayload = {
      requestType: "COUNTRYPHONECODE",
    };
    setState({ loader: true });
    hookGetCountryPhoenCodes.sendRequest(countryPayload, function (data) {
      setState({ loader: false });
      if (data.status === "S") {
        const phoneCodeStatic = [
          { countryPhoneCode: 44, countryName: "United Kingdom" },
          { countryPhoneCode: 91, countryName: "India" },
          { countryPhoneCode: 63, countryName: "Philippines" },
          { countryPhoneCode: 880, countryName: "Bangladesh" },
          { countryPhoneCode: 62, countryName: "Indonesia" },
          { countryPhoneCode: 66, countryName: "Thailand" },
          { countryPhoneCode: 94, countryName: "Sri Lanka" },
        ];
        setState({ phoneCodes: phoneCodeStatic });
      } else {
        notification.error({ message: data.errorMessage });
      }
    });
  };
  const onSubmitHandlerPostLogin = (value) => {
    let payload = {
      requestType: "POSTCONTACTUS",
      category: value.category,
      comments: value.comments.trim().replace("'", ""),
      userId: AuthReducer.userID,
      pageFrom: "POST",
      identifier: "CS",
    };
    setState({ loader: true });
    hookContactUsPostLogin.sendRequest(payload, function (data) {
      setState({ loader: false });
      if (data.status === "S") {
        Swal.fire({
          title: "Success",
          text: "We have recorded your valuable concern/feedback. Our team will try resolving/working on it and our support team will revert you back on your email.",
          icon: "success",
          confirmButtonColor: "#2dbe60",
          allowOutsideClick: false,
        }).then((result) => {
          if (result.isConfirmed) {
            navigate("/new-transaction");
          }
        });
      } else {
        notification.error({ message: data.errorMessage });
        let errors = [];
        data.errorList.forEach((error, i) => {
          let errorData = {
            name: error.field,
            errors: [error.error],
          };
          errors.push(errorData);
        });
        if (errors.length > 0) form.setFields(errors);
      }
    });
  };
  const onSubmitHandlerPreLogin = (value) => {
    let captchaPayload = {
      requestType: "VERIFYCAPTCHA",
      id: captchaID,
      captchaResponse: value.captcha,
      emailId: value.emailId,
    };
    setState({ loader: true });
    hookVerifyCaptcha.sendRequest(captchaPayload, function (data) {
      setState({ loader: false });
      if (data.status == "S") {
        let payload = {
          requestType: "PRECONTACTUS",
          category: value.category,
          fullName: value.fullName.trim(),
          mobilePhoneCode: value.mobilePhoneCode,
          mobileNo: value.mobileNo,
          emailId: value.emailId,
          comments: value.comments.trim().replace("'", ""),
          pageFrom: "PRE",
          identifier: "CS",
        };
        setState({ loader: true });
        hookContactUsPreLogin.sendRequest(payload, function (data) {
          setState({ loader: false });
          if (data.status === "S") {
            Swal.fire({
              title: "Success",
              text: "We have recorded your valuable concern/feedback. Our team will try resolving/working on it and our support team will revert you back on your email.",
              icon: "success",
              confirmButtonColor: "#2dbe60",
              allowOutsideClick: false,
            }).then((result) => {
              if (result.isConfirmed) {
                navigate("/");
              }
            });
          } else {
            notification.error({ message: data.errorMessage });
            let errors = [];
            data.errorList.forEach((error, i) => {
              let errorData = {
                name: error.field,
                errors: [error.error],
              };
              errors.push(errorData);
            });
            if (errors.length > 0) form1.setFields(errors);
          }
        });
      } else {
        form1.setFieldsValue({ captcha: "" });
        form1.setFields([{ name: "captcha", errors: ["Incorrect Captcha"] }]);
        getCaptcha();
      }
    });
  };
  return (
    <React.Fragment>
      <SubHeader title="Contact" contactUs={true}/>
      <Spinner spinning={state.loader}>
        <div className="template2__main py-5">
          <div className="sendmoney__page preloginform">
            <div className="container contactus">
              {AuthReducer.isLoggedIn ? (
                <Form
                  form={form}
                  onFinish={(value) => onSubmitHandlerPostLogin(value)}
                >
                  <div className="row">
                    <div className="col-12 col-md-6">
                      <label className="step-label">Issue category</label>
                      <Form.Item
                        name="category"
                        rules={[
                          {
                            required: true,
                            message: "Select Issue category",
                          },
                        ]}
                      >
                        <Select placeholder="Select" size="large">
                          <Option value="Generic Enquiry">
                            Generic Enquiry
                          </Option>
                          <Option value="Money Transfer">
                            Money Transfer Enquiry
                          </Option>
                          <Option value="Business Enquiry">
                            Business Enquiry
                          </Option>
                          <Option value="Partnership Enquiry">
                            Partnership Enquiry
                          </Option>
                          <Option value="Affiliate Enquiry">
                            Affiliate Enquiry
                          </Option>
                        </Select>
                      </Form.Item>
                    </div>
                    <div className="col-12 col-md-6">
                      <label className="step-label">Describe more</label>
                      <Form.Item
                        name={"comments"}
                        rules={[
                          {
                            required: true,
                            message: "This field is required.",
                          },
                        ]}
                      >
                        <TextArea
                          className="bg-secondary-light"
                          style={{ resize: "none", height: "12.2rem" }}
                          autoComplete="none"
                          onKeyDown={(e) => {
                            if (e.key === "Enter") {
                              e.preventDefault();
                              if (!e.shiftKey) {
                                e.preventDefault();
                              }
                            }
                          }}
                        />
                      </Form.Item>
                    </div>
                  </div>
                  {/* <div className="color-secondary-light contact_footer">
                    Or write to us at <a href="mailto:care@xmonies.com">care@xmonies.com</a>
                  </div> */}
                  <div className="col-12 text-end">
                    <button
                      className="btn btn-sm btn-light text-primary px-5"
                      htmlType="submit"
                    >
                      Submit
                    </button>
                  </div>
                </Form>
              ) : (
                <Form
                  form={form1}
                  onFinish={(value) => onSubmitHandlerPreLogin(value)}
                >
                  <div className="row">
                    <div className="col-12 col-md-6">
                      <Row>
                        <label className="step-label">Your Name</label>
                        <Form.Item
                          name="fullName"
                          className="form-item"
                          rules={[
                            {
                              required: true,
                              message: "Please enter your full name",
                            },
                            {
                              pattern: /^([\w]{1,})+\s+([\w\s]{1,})+$/i,
                              message: "Please enter valid name.",
                            },
                            {
                              pattern: /^([^0-9]*)$/,
                              message: "Number not allow in full name",
                            },
                          ]}
                        >
                          <Input size="large" placeholder="Enter your Name" />
                        </Form.Item>
                      </Row>
                      <Row>
                        <label className="step-label">Email address</label>
                        <Form.Item
                          name="emailId"
                          rules={[
                            {
                              required: true,
                              message: "Please input your E-mail!",
                            },
                            {
                              type: "email",
                              pattern:
                                /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/,
                              message: "Please enter valid E-mail",
                            },
                          ]}
                        >
                          <Input
                            size="large"
                            placeholder="Enter your email address"
                          />
                        </Form.Item>
                      </Row>
                      <Row>
                        <label className="step-label   mb-1">
                          Mobile Number
                        </label>

                        <div className="d-flex group_input">
                          <div className="w-25 ">
                            <Form.Item
                              className="form-item"
                              name="mobilePhoneCode"
                              rules={[
                                {
                                  required: true,
                                  message: "Please select your Country Code.",
                                },
                              ]}
                            >
                              <Select
                                placeholder="Select phone Code"
                                size="large"
                                className="w-100"
                              >
                                {state.phoneCodes.map((phoneCode, i) => {
                                  return (
                                    <Option
                                      key={i}
                                      value={phoneCode.countryPhoneCode}
                                    >{`+${phoneCode.countryPhoneCode} (${phoneCode.countryName})`}</Option>
                                  );
                                })}
                              </Select>
                            </Form.Item>
                          </div>
                          <div className="w-75">
                            <Form.Item
                              name="mobileNo"
                              rules={[
                                {
                                  required: true,
                                  message: "Please enter your mobile number",
                                },
                                {
                                  pattern: /^[0-9\b]+$/,
                                  message: "Only numbers allowed",
                                },
                                {
                                  min: 10,
                                  max: 10,
                                  message: "Mobile Number must be 10 digits",
                                },
                              ]}
                            >
                              <Input
                                placeholder="Enter your mobile number"
                                size="large"
                              />
                            </Form.Item>
                          </div>
                        </div>
                      </Row>
                      <Row>
                        <label className="step-label">Issue category</label>
                        <Form.Item
                          name="category"
                          rules={[
                            {
                              required: true,
                              message: "Select Issue category",
                            },
                          ]}
                        >
                          <Select placeholder="Select a category" size="large">
                            <Option value="Generic Enquiry">
                              Generic Enquiry
                            </Option>
                            <Option value="Money Transfer">
                              Money Transfer Enquiry
                            </Option>
                            <Option value="Business Enquiry">
                              Business Enquiry
                            </Option>
                            <Option value="Partnership Enquiry">
                              Partnership Enquiry
                            </Option>
                            <Option value="Affiliate Enquiry">
                              Affiliate Enquiry
                            </Option>
                          </Select>
                        </Form.Item>
                      </Row>
                    </div>
                    <div className="col-12 col-md-6">
                      <Row>
                        <label className="step-label">Describe more</label>
                        <Form.Item
                          name={"comments"}
                          rules={[
                            {
                              required: true,
                              message: "This field is required.",
                            },
                          ]}
                        >
                          <TextArea
                            onKeyDown={(e) => {
                              if (e.key === "Enter") {
                                e.preventDefault();
                                if (!e.shiftKey) {
                                  e.preventDefault();
                                }
                              }
                            }}
                            className="bg-secondary-light"
                            style={{ resize: "none", height: "10.38rem" }}
                            autoComplete="none"
                          />
                        </Form.Item>
                      </Row>
                      <Row>
                        <label className="step-label">Word Verification</label>
                        <div className="w-100 d-flex mb-3">
                          <div className="me-3">
                            <img
                              src={`data:image/jpeg;base64,${captchaImg}`}
                              alt="captcha"
                            />
                          </div>
                          <div
                            className="d-flex align-items-center text-light my-3"
                            style={{ cursor: "pointer" }}
                            onClick={getCaptcha}
                          >
                            <img
                              src={logorefresh}
                              alt="refresh"
                              className="me-2"
                            />
                            <span className="fs-12">Refresh Code</span>
                          </div>
                        </div>
                        <Form.Item
                          className="form-item"
                          name="captcha"
                          rules={[
                            {
                              required: true,
                              message: "Enter Captcha.",
                            },
                          ]}
                        >
                          <Input
                            size="large"
                            style={{ height: "39.5px" }}
                            placeholder="Enter the text shown in the Image"
                          />
                        </Form.Item>
                      </Row>
                    </div>
                  </div>

                  <div className="col-12 text-end">
                    <button
                      className="btn btn-sm btn-light text-primary px-5"
                      htmlType="submit"
                    >
                      Submit
                    </button>
                  </div>
                </Form>
              )}
            </div>
          </div>
        </div>
        <Footer />
      </Spinner>
    </React.Fragment>
  );
}
