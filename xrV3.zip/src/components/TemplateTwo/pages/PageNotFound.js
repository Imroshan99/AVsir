import React from "react";
import SubHeader from "../layout/SubHeader";
import Image404 from "../../../assets/images/XR/404.svg";


function PageNotFound() {
  return (
    <div>
      <SubHeader title="Error 404. Not found" />
      <div className="template2__main">
        <div className="sendmoney__page text-center">
          <img src={Image404} alt="Error 404, Not found." className="mt-5 pt-5"/>
          <div className="PageText404">Oops! we couldnt find that</div>
        </div>
      </div>
    </div>
  );
}

export default PageNotFound;
