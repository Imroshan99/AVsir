import React from "react";
import SubHeader from "../layout/SubHeader";
import { Row, Col } from "react-bootstrap";
import arrow from "../../../assets/images/svg/arrow-support.svg";
import { Link } from "react-router-dom";
export default function Support(props) {
  return (
    <React.Fragment>
      <SubHeader title="Support" />
      <div className="profile-container template2__main">
        <div className="container _profile_page py-5">
          <div className="support">
            <Row
              className="d-flex justify-content-between"
              style={{
                borderBottom: "1px solid #356078",
              }}
            >
              <Col className="d-flex align-items-center mb-3">
                <h2 style={{ margin: "0" }}>About Us</h2>
              </Col>
              <Col
                className="d-flex justify-content-end align-items-center mb-3 "
                style={{
                  gap: "1.5rem",
                }}
              >
                <Link to={"/about-us"} className="d-flex gap-4">
                  <p style={{ margin: "0", color: "#FFFFFF" }} className="fs-17 op-6 fw-600">
                    Get to know more about{" "}
                  </p>
                  <img src={arrow} alt="arrow" />
                </Link>
              </Col>
            </Row>
            <Row
              className="d-flex justify-content-between mt-3"
              style={{
                borderBottom: "1px solid #356078",
              }}
            >
              <Col className="d-flex align-items-center mb-3">
                <h2 style={{ margin: "0" }}>Contact Us</h2>
              </Col>
              <Col className="d-flex justify-content-end align-items-center mb-3 ">
                <Link to={"/contact"} className="d-flex gap-4">
                  <p style={{ margin: "0", color: "#FFFFFF" }} className="fs-17 op-6 fw-600">
                    Reach us over Call or E-Mail{" "}
                  </p>
                  <img src={arrow} alt="arrow" />
                </Link>
              </Col>
            </Row>
            <Row
              className="d-flex justify-content-between "
              style={{
                borderBottom: "1px solid #356078",
              }}
            >
              <Col className="d-flex align-items-center mb-3 mt-3">
                {" "}
                <h2 style={{ margin: "0" }}>Feedback</h2>
              </Col>
              <Col className="d-flex justify-content-end align-items-center mb-3 mt-3 ">
                <Link to={"/feedback"} className="d-flex gap-4">
                  <p style={{ margin: "0", color: "#FFFFFF" }} className="fs-17 op-6 fw-600">
                    Like our service, Help us make it better{" "}
                  </p>
                  <img src={arrow} alt="arrow" />
                </Link>
              </Col>
            </Row>
            <Row
              className="d-flex justify-content-between mt-3"
              style={{
                borderBottom: "1px solid #356078",
              }}
            >
              <Col className="d-flex align-items-center mb-3">
                <h2 style={{ margin: "0" }}>Raise an Issue</h2>
              </Col>
              <Col className="d-flex justify-content-end align-items-center mb-3">
                <Link to={"/raise-issue"} className="d-flex gap-4">
                  <p style={{ margin: "0", color: "#FFFFFF" }} className="fs-17 op-6 fw-600">
                    Facing any trouble? Let us know
                  </p>
                  <img src={arrow} alt="arrow" />
                </Link>
              </Col>
            </Row>
          </div>
        </div>
      </div>
    </React.Fragment>
  );
}
