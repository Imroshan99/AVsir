/* eslint-disable jsx-a11y/alt-text */
import React from "react";
import SubHeader from "../layout/SubHeader";
// import { Row, Col } from "react-bootstrap";
import { Tabs, Select, Table, notification } from "antd";
import { useSelector } from "react-redux";
import { useReducer, useEffect } from "react";
import useHttp from "../../../hooks/useHttp";
import { GuestAPI } from "../../../apis/GuestAPI";
import Spinner from "../../../reusable/Spinner";
import Copy from "../../../assets/images/copy.png";
import Share from "../../../assets/images/share.png";
import moment from "moment";

const _xrShareUrl = window.location.origin + "/";
export default function ReferAndEarnPage() {
  // const [form] = Form.useForm();
  const AuthReducer = useSelector((state) => state);
  const { TabPane } = Tabs;
  const { Option } = Select;
  useEffect(() => {
    getUserReferralList();
    getReferralBalance();
    getUserRefEarnList();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const [state, setState] = useReducer(
    (state, newState) => ({ ...state, ...newState }),
    {
      clientId: AuthReducer.clientId,
      groupId: AuthReducer.groupId,
      sessionId: AuthReducer.sessionId,
      userID: AuthReducer.userID,
      activeKey: "1",
      referralList: [],
      referEarnList: [],
      spinner: false,
      referralModal: false,
      filterDate: "",
      inviteMailID: "",
      validEmailDID: false,
      clipBoard: "",
      refeemBalance: 0,
      referralFilterList: [],
      referralTypeFilter: "",
      dateFilterValue: "",
      filteredReferEarnList: [],
      filteredReferralList: [],
    }
  );
  useEffect(() => {
    filterDate();
  }, [state.referralTypeFilter, state.dateFilterValue]);
  useEffect(() => {
    if (state.clipBoard) {
      setTimeout(() => {
        setState({ clipBoard: "" });
      }, [3000]);
    }
  }, [state.clipBoard]);
  const hookUserReferralList = useHttp(GuestAPI.userReferralLists);
  const hookUserRefEarnList = useHttp(GuestAPI.userRefEarnList);
  const hookerReferFriend = useHttp(GuestAPI.referFriend);
  const hookReferralBalance = useHttp(GuestAPI.referralBalance);

  const referFriend = (value) => {
    const payload = {
      requestType: "ADDREFERAL",
      requestId: "3453",
      userId: state.userID,
      firstName: "",
      lastName: "",
      emailId: value,
      mobilePhoneCode: "",
      mobileNo: "",
      countryCode: AuthReducer.sendCountryCode,
    };

    setState({ spinner: true });
    hookerReferFriend.sendRequest(payload, function (data) {
      if (data.status === "S") {
        setState({ spinner: false });
        getUserReferralList();
        setState({ referralModal: false });
        notification.success({ message: data.message });
      } else {
        setState({ spinner: false });
        notification.error({ message: data.errorMessage });
      }
    });
  };

  // const afterClose = () => {
  //   form.resetFields();
  // };
  const getReferralBalance = () => {
    const payload = {
      requestType: "REFEARNREDEEM",
      userId: state.userID,
    };
    hookReferralBalance.sendRequest(payload, function (data) {
      if (data.status === "S") {
        setState({ refeemBalance: data.redeemBalence });
      }
    });
  };
  const filterDate = () => {
    if (state.activeKey == "1") {
      if (state.dateFilterValue === "LATEST") {
        let sortedRefEarnList = state.referEarnList.sort(
          (a, b) =>
            moment(b.eventDate).format("YYYYMMDD") -
            moment(a.eventDate).format("YYYYMMDD")
        );
        let reSortedRefEarnList = sortedRefEarnList.filter((i) => {
          return i.referralType.search(state.referralTypeFilter) !== -1;
        });
        setState({ filteredReferEarnList: reSortedRefEarnList });
      } else {
        let sortedRefEarnList = state.referEarnList.sort(
          (a, b) =>
            moment(a.eventDate).format("YYYYMMDD") -
            moment(b.eventDate).format("YYYYMMDD")
        );
        let reSortedRefEarnList = sortedRefEarnList.filter((i) => {
          return i.referralType.search(state.referralTypeFilter) !== -1;
        });
        setState({ filteredReferEarnList: reSortedRefEarnList });
      }
    } else {
      if (state.dateFilterValue === "LATEST") {
        let sortedList = state.referralList.sort(
          (a, b) =>
            moment(b.referralDate).format("YYYYMMDD") -
            moment(a.referralDate).format("YYYYMMDD")
        );
        // let reSortedRefEarnList = sortedRefEarnList.filter((i) => {
        //   return i.referralType.search(state.referralTypeFilter) !== -1;
        // });
        setState({ filteredReferralList: sortedList });
      } else {
        let sortedList = state.referralList.sort(
          (a, b) =>
            moment(a.referralDate).format("YYYYMMDD") -
            moment(b.referralDate).format("YYYYMMDD")
        );
        // let reSortedRefEarnList = sortedRefEarnList.filter((i) => {
        //   return i.referralType.search(state.referralTypeFilter) !== -1;
        // });
        setState({ filteredReferralList: sortedList });
      }
    }
  };
  const getUserRefEarnList = () => {
    const payload = {
      requestType: "USERREFEARNLIST",
      requestId: "1452",
      userId: state.userID,
    };
    setState({ spinner: true });
    hookUserRefEarnList.sendRequest(payload, function (data) {
      setState({ spinner: false });
      if (data.status === "S") {
        let referralFilterList = [];
        setState({
          referEarnList: data.responseData,
          filteredReferEarnList: data.responseData,
        });
        data.responseData.forEach((detail, i) => {
          referralFilterList.push(detail.referralType);
          let newReferralFilterList = [...new Set(referralFilterList)];
          setState({ referralFilterList: newReferralFilterList });
        });
      }
    });
  };
  const getUserReferralList = () => {
    const payload = {
      requestType: "USERREFERRALLIST",
      requestId: "1452",
      userId: state.userID,
      responseDatabase: [],
    };
    setState({ spinner: true });
    hookUserReferralList.sendRequest(payload, function (data) {
      setState({ spinner: false });
      if (data.status === "S") {
        setState({ inviteMailID: "" });
        let responseData = data.responseData;
        responseData.forEach((i) => {
          if (i.status === "P") {
            i.status = "Pending";
          } else if (i.status === "T") {
            i.status = "Transacted";
          } else {
            i.status = "Registered";
          }
        });
        setState({
          referralList: responseData,
          filteredReferralList: responseData,
        });
      }
    });
  };

  const currentTab = (key) => {
    setState({ activeKey: key });
  };

  // const onFinish = (value) => {
  //   referFriend(value);
  // };

  return (
    <React.Fragment>
      <SubHeader title="Refer & Earn" refeemBalance={state.refeemBalance} />
      <Spinner spinning={state.spinner}>
        <div className="template2__main about_us_page py-5">
          <div className="sendmoney__page">
            <div className="container referearn">
              <div className="d-md-flex justify-content-md-between mb-4">
                <div className="mb-md-0 mb-3">
                  <label className="label2">My Referral Code</label>
                  <div className="input d-flex justify-content-center">
                    <input value={AuthReducer.userID}></input>
                    <div
                      className="button"
                      onClick={() => {
                        navigator.clipboard.writeText(AuthReducer.userID);
                        setState({ clipBoard: AuthReducer.userID });
                      }}
                    >
                      <img height={"50%"} src={Copy}></img>
                      {state.clipBoard === AuthReducer.userID
                        ? "Coppied"
                        : "Copy"}
                    </div>
                  </div>
                </div>
                <div className="mb-md-0 mb-3">
                  <label className="label2">Invite using Email</label>
                  <div className="input d-flex justify-content-center">
                    <input
                      type="email"
                      required="required"
                      value={state.inviteMailID}
                      onChange={(e) =>
                        setState({ inviteMailID: e.target.value })
                      }
                    ></input>
                    <button
                      disabled={state.inviteMailID === "" ? true : false}
                      className="button"
                      onClick={() => {
                        const validRegex = new RegExp(
                          /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/
                        );
                        if (validRegex.test(state.inviteMailID)) {
                          referFriend(state.inviteMailID);
                          setState({ validEmailDID: false });
                        } else {
                          setState({ validEmailDID: true });
                        }
                      }}
                    >
                      Invite
                    </button>
                  </div>
                  {state.validEmailDID && (
                    <p className="text-danger">Please enter Valid Email ID</p>
                  )}
                </div>
                <div className="mb-md-0 mb-3 ">
                  <label className="label2">Invite using Referral Link</label>
                  <div className="input d-flex justify-content-center">
                    <input
                      // style={{ width: "250px" }}
                      value={`${_xrShareUrl}signup?uId=${AuthReducer.userID}`}
                    ></input>
                    <div
                      className="button"
                      onClick={() => {
                        setState({
                          clipBoard: `${_xrShareUrl}signup?uId=${AuthReducer.userID}`,
                        });
                        navigator.clipboard.writeText(
                          `${_xrShareUrl}signup?uId=${AuthReducer.userID}`
                        );
                      }}
                    >
                      <img src={Share}></img>
                      {state.clipBoard ===
                      `${_xrShareUrl}signup?uId=${AuthReducer.userID}`
                        ? "Coppied"
                        : "Share"}
                    </div>
                  </div>
                </div>
              </div>
              <div className="hr"></div>
              <h3 className="title mt-3">My Earnings</h3>
              <div className="refer-list-container">
                <div className="d-flex justify-content-between">
                  <div className="referlist-inside-container container-1">
                    <Tabs defaultActiveKey="1" onChange={currentTab}>
                      <TabPane tab="My Rewards" key="1"></TabPane>
                      <TabPane tab="My Invites" key="2"></TabPane>
                    </Tabs>
                  </div>
                  <div className="referlist-inside-container container-2 filter11">
                    <div style={{ height: "3rem" }} className="border-bottom">
                      {state.activeKey === "1" && (
                        <>
                          <button className="filter-button">Filter</button>
                          <Select
                            allowClear
                            showSearch
                            placeholder="Select Referral Type"
                            onChange={(value) =>
                              setState({ referralTypeFilter: value })
                            }
                          >
                            {state.referralFilterList.map((i) => {
                              return <Option value={i}>{i}</Option>;
                            })}
                          </Select>
                        </>
                      )}
                      <button className="filter-button ml-5">Sort By</button>
                      <Select
                        onChange={(value) => {
                          setState({ dateFilterValue: value });
                        }}
                        // allowClear
                        showSearch
                        placeholder="Invite Date"
                      >
                        <Option value="LATEST">Latest</Option>
                        <Option value="OLDEST">Oldest</Option>
                      </Select>
                    </div>
                  </div>
                </div>
                {state.activeKey === "1" && (
                  <div>
                    <Table
                      columns={[
                        {
                          title: "Names",
                          dataIndex: "userName",
                        },
                        {
                          title: "Email-ID",
                          dataIndex: "referralEmailId",
                        },
                        {
                          title: "Referral Type",
                          dataIndex: "referralType",
                        },
                        {
                          title: "Invite Date",
                          dataIndex: "eventDate",
                        },
                        {
                          title: "Rewards Earned",
                          dataIndex: "amount",
                        },
                        {
                          title: "Currency",
                          dataIndex: "currency",
                        },
                      ]}
                      dataSource={[...state.filteredReferEarnList]}
                      pagination={false}
                    />
                  </div>
                )}
                {state.activeKey === "2" && (
                  <div>
                    <Table
                      columns={[
                        {
                          title: "Invite",
                          dataIndex: "referralEmailId",
                        },
                        {
                          title: "Invite Date",
                          dataIndex: "referralDate",
                        },
                        {
                          title: "Referral",
                          dataIndex: "bonusEarned",
                        },
                        {
                          title: "Status",
                          dataIndex: "status",
                          className: "rf_invite_status",
                        },
                      ]}
                      dataSource={[...state.filteredReferralList]}
                      pagination={false}
                    />
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      </Spinner>
    </React.Fragment>
  );
}
