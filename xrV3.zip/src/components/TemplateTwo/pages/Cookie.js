import React from "react";
import SubHeader from "../layout/SubHeader";
import CookiePolicyPage from "../../../pages/CookiePolicy/";
import { Footer } from "../../../pages/LandingPage/XR";
import { Link } from "react-router-dom";

const Cookie = (props) => {
  return (
    <React.Fragment>
      <SubHeader title="Cookie Policy" />
      <div className="template2__main py-5">
        <div className="sendmoney__page">
          <div className="container">
            <CookiePolicyPage />
            <div className="text-end">
              <Link to="/" className="btn btn-sm btn-light text-white mt-3 px-5">
                Go Back
              </Link>
            </div>
          </div>
        </div>
      </div>
      <Footer />
    </React.Fragment>
  );
};

export default Cookie;
