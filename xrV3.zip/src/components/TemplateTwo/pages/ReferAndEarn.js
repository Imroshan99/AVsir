import { Button } from "antd";
import React from "react";
import { Link } from "react-router-dom";
import { Footer } from "../../../pages/LandingPage/XR";
import SubHeader from "../layout/SubHeader";

export default function ReferAndEarn() {
  return (
    <React.Fragment>
      <SubHeader title="Refer &amp; Earn" />
      <div className="profile-container template2__main">
        <div className="container _profile_page py-5 pt-0">
          <div className="refer_earn">
            <h2>How it Works</h2>
            <div style={{marginTop:"28px"}}>
              <p>
                <strong className="reg_title_color">
                  Refer your friends &amp; family and Cash reward
                </strong>
              </p>
              <p>
                Refer your friends &amp; family and get rewarded with Cash when your
                referral make first transaction with us. The rewarded cash that
                you can redeem in your next transaction.
              </p>
              <p>
                <strong className="reg_title_color">How does it work</strong>
              </p>
              <p>Steps to get rewarded:<br/>1. Go to My Account. Select Refer a Friend<br/>
              2. Send your referral link to your friend<br/>
              3. Ask you friend to sign-up with the referral link shared by you.<br/>
              4. You can check status of referral sign-up &amp; transaction<br/>
              5. You get rewarded as your referral make first transaction<br/>
              6. Use these referral rewards earned in you next transaction
              </p>
              <p>
                <strong className="reg_title_color">
                  Get Bonus Referral reward
                </strong>
              </p>
              <p>
                The more you refer, the more you rewarded. For every 5 new
                users, you get bonus reward added to your account.
              </p>
              <p>
                <strong className="reg_title_color">
                  Start Now to get Rewarded
                </strong>
              </p>
            </div>
            <Link to={"/signin"}>
              <Button
                style={{
                  marginTop: "36px",
                  borderRadius: "5px",
                  width: "178px",
                  height: "42px",
                  background: "#FFFFFF",
                  fontWeight: "800",
                  lineHeight: "34px",
                  fontSize: "16px",
                  color: "#003153",
                }}
              >
                Start Referring
              </Button>
            </Link>
          </div>
        </div>
      </div>
      <Footer />
    </React.Fragment>
  );
}
