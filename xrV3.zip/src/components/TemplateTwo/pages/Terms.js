import React from "react";
import SubHeader from "../layout/SubHeader";
import TnC from "../../../pages/T&C/";
import { Footer } from "../../../pages/LandingPage/XR";
import { Link } from "react-router-dom";

const Terms = (props) => {
  return (
    <React.Fragment>
      <SubHeader title="Terms and Conditions" />
      <div className="template2__main py-5">
        <div className="sendmoney__page">
          <div className="container">
            <TnC />
            <div className="text-end">
              <Link to="/" className="btn btn-sm btn-light text-white mt-3 px-5">
                Go Back
              </Link>
            </div>
          </div>
        </div>
      </div>
      <Footer />
    </React.Fragment>
  );
};

export default Terms;
