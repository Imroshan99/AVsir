import React, { useEffect, useState } from "react";
import SubHeader from "../layout/SubHeader";
import { notification, Select } from "antd";
import { Row, Col } from "react-bootstrap";
import { Form, Input } from "antd";
import logorefresh from "../../../assets/images/svg/refreshCaptcha.svg";
import firstUnfillEmoji from "../../../assets/images/emojis/Unfill_Emoji/1.svg";
import secoundUnfillEmoji from "../../../assets/images/emojis/Unfill_Emoji/2.svg";
import thirdUnfillEmoji from "../../../assets/images/emojis/Unfill_Emoji/3.svg";
import fourthUnfillEmoji from "../../../assets/images/emojis/Unfill_Emoji/4.svg";
import fiveUnfillEmoji from "../../../assets/images/emojis/Unfill_Emoji/5.svg";

import firstFill from "../../../assets/images/emojis/Fill_Emoji/1-fill.svg";
import secoundFill from "../../../assets/images/emojis/Fill_Emoji/2-fill.svg";
import thirdFill from "../../../assets/images/emojis/Fill_Emoji/3-fill.svg";
import forthfill from "../../../assets/images/emojis/Fill_Emoji/4-fill.svg";
import fiveFill from "../../../assets/images/emojis/Fill_Emoji/5-fill.svg";

import { GuestAPI } from "../../../apis/GuestAPI";
import useHttp from "../../../hooks/useHttp";
import { useSelector } from "react-redux";
import Swal from "sweetalert2";
import Spinner from "../../../reusable/Spinner";
import { useNavigate } from "react-router-dom";
import { Footer } from "../../../pages/LandingPage/XR";
const { TextArea } = Input;
const { Option } = Select;

export default function Feedback(props) {
  let navigate = useNavigate();
  const AuthReducer = useSelector((state) => state);
  const [form] = Form.useForm();
  const [form1] = Form.useForm();
  const [captchaImg, setCaptchaImg] = useState();
  const [captchaID, setCaptchaID] = useState();
  const [rating, setRating] = useState(0);
  const [validation, setValidation] = useState(false);
  const [loader, setLoader] = useState(false);
  const [state, setState] = useState(0);
  const [phoneCodes, setPhoneCodes] = useState([]);

  const hookFeedbackPostLogin = useHttp(GuestAPI.contactUsPostLogin);
  const hookFeedbackPreLogin = useHttp(GuestAPI.contactUsPreLogin);
  const hookGetCountryPhoenCodes = useHttp(GuestAPI.getCountryPhoneCodes);
  const hookgetCaptcha = useHttp(GuestAPI.getCaptcha);
  const hookVerifyCaptcha = useHttp(GuestAPI.verifyCaptcha);

  useEffect(() => {
    getCountryPhoneCode();
    getCaptcha();
  }, []);
  const getCaptcha = () => {
    let payload = {
      requestType: "GETCAPTCHA",
    };
    setLoader(true);
    hookgetCaptcha.sendRequest(payload, function (data) {
      setLoader(false);
      if (data.status == "S") {
        setCaptchaImg(data.captchaImage);
        setCaptchaID(data.id);
      } else {
        notification.error({ message: data.errorMessage });
      }
    });
  };
  const getCountryPhoneCode = () => {
    const countryPayload = {
      requestType: "COUNTRYPHONECODE",
    };
    setLoader(true);
    hookGetCountryPhoenCodes.sendRequest(countryPayload, function (data) {
      setLoader(false);
      if (data.status === "S") {
        const phoneCodeStatic = [
          { countryPhoneCode: 44, countryName: "United Kingdom" },
          { countryPhoneCode: 91, countryName: "India" },
          { countryPhoneCode: 63, countryName: "Philippines" },
          { countryPhoneCode: 880, countryName: "Bangladesh" },
        ];
        setPhoneCodes(phoneCodeStatic);
        // setState({ phoneCodes: phoneCodeStatic });
      }
    });
  };
  const submitFeedback = (value) => {
    setLoader(true);
    if (rating === 0) {
      setLoader(false);
      setValidation(true);
    } else {
      setValidation(false);
      let payload = {
        requestType: "POSTCONTACTUS",
        category: value.category,
        comments: value.comments.trim().replace("'", ""),
        userId: AuthReducer.userID,
        pageFrom: "POST",
        identifier: "FB",
        rating: rating,
      };
      hookFeedbackPostLogin.sendRequest(payload, function (data) {
        if (data.status === "S") {
          setLoader(false);
          Swal.fire({
            title: "Success",
            text: "We have recorded your valuable concern/feedback. Our team will try resolving/working on it and our support team will revert you back on your email.",
            icon: "success",
            confirmButtonColor: "#2dbe60",
            allowOutsideClick: false,
          }).then((result) => {
            if (result.isConfirmed) {
              navigate("/new-transaction");
            }
          });
        } else {
          setLoader(false);
          notification.error({ message: data.errorMessage });
        }
      });
    }
  };
  const submitFeedbackPreLogin = (value) => {
    if (rating === 0) {
      setValidation(true);
    } else {
      let captchaPayload = {
        requestType: "VERIFYCAPTCHA",
        id: captchaID,
        captchaResponse: value.captcha,
        emailId: value.emailId,
      };
      setLoader(true);
      hookVerifyCaptcha.sendRequest(captchaPayload, function (data) {
        setLoader(false);
        if (data.status == "S") {
          let payload = {
            requestType: "PRECONTACTUS",
            category: value.category,
            fullName: value.fullName.trim(),
            mobilePhoneCode: value.mobilePhoneCode,
            mobileNo: value.mobileNo,
            emailId: value.emailId,
            comments: value.comments.trim().replace("'", ""),
            rating: rating,
            pageFrom: "PRE",
            identifier: "FB",
          };
          setLoader(true);
          hookFeedbackPreLogin.sendRequest(payload, function (data) {
            setLoader(false);
            if (data.status === "S") {
              Swal.fire({
                title: "Success",
                text: "We have recorded your valuable concern/feedback. Our team will try resolving/working on it and our support team will revert you back on your email.",
                icon: "success",
                confirmButtonColor: "#2dbe60",
                allowOutsideClick: false,
              }).then((result) => {
                if (result.isConfirmed) {
                  navigate("/");
                }
              });
            } else {
              notification.error({ message: data.errorMessage });
              let errors = [];
              data.errorList.forEach((error, i) => {
                let errorData = {
                  name: error.field,
                  errors: [error.error],
                };
                errors.push(errorData);
              });
              if (errors.length > 0) form1.setFields(errors);
            }
          });
        } else {
          form1.setFieldsValue({ captcha: "" });
          form1.setFields([{ name: "captcha", errors: ["Incorrect Captcha"] }]);
          getCaptcha();
        }
      });
    }
  };
  return (
    <React.Fragment>
      <SubHeader title="Feedback" />
      <Spinner spinning={loader}>
        <div className="template2__main py-5">
          <div className="sendmoney__page preloginform">
            <div className="container">
              <div>
                {AuthReducer.isLoggedIn ? (
                  <Form form={form} onFinish={submitFeedback}>
                    <div className="row">
                      <div className="col-12 col-md-6">
                        <label className="step-label">Select category</label>
                        <Form.Item
                          name={"category"}
                          rules={[
                            {
                              required: true,
                              message: "Select category",
                            },
                          ]}
                        >
                          <Select placeholder="Select" size="large">
                            <Option value="Money Transfer">Money Transfer</Option>
                            <Option value="Exchange Rate">Exchange Rate</Option>
                            <Option value="Service Fee">Service Fee</Option>
                            <Option value="Payment Gateway">Payment Gateway</Option>
                            <Option value="Portal Experien">Portal Experience</Option>
                            <Option value="Others">Others</Option>
                          </Select>
                        </Form.Item>

                        <label className="step-label">Describe your Feedback </label>
                        <Form.Item
                          name={"comments"}
                          rules={[
                            {
                              required: true,
                              message: "This field is required.",
                            },
                          ]}
                        >
                          <TextArea
                            onKeyDown={(e) => {
                              if (e.key === "Enter") {
                                e.preventDefault();
                                if (!e.shiftKey) {
                                  e.preventDefault();
                                }
                              }
                            }}
                            className="bg-secondary-light"
                            style={{ resize: "none", height: "12.2rem" }}
                            autoComplete="none"
                          />
                        </Form.Item>
                      </div>
                      <div className="col-12 col-md-6">
                        <label className="step-label">How Likely would recommend us to your friend</label>
                        <div className="d-flex gap-3">
                          <img
                            className="emoji-img"
                            onClick={() => {
                              setRating(1);
                              setValidation(false);
                            }}
                            src={rating === 1 ? firstFill : firstUnfillEmoji}
                            alt="Emoji"
                          />
                          <img
                            className="emoji-img"
                            onClick={() => {
                              setRating(2);
                              setValidation(false);
                            }}
                            src={rating === 2 ? secoundFill : secoundUnfillEmoji}
                            alt="Emoji"
                          />
                          <img
                            className="emoji-img"
                            onClick={() => {
                              setRating(3);
                              setValidation(false);
                            }}
                            src={rating === 3 ? thirdFill : thirdUnfillEmoji}
                            alt="Emoji"
                          />
                          <img
                            className="emoji-img"
                            onClick={() => {
                              setRating(4);
                              setValidation(false);
                            }}
                            src={rating === 4 ? forthfill : fourthUnfillEmoji}
                            alt="Emoji"
                          />
                          <img
                            className="emoji-img"
                            onClick={() => {
                              setRating(5);
                              setValidation(false);
                            }}
                            src={rating === 5 ? fiveFill : fiveUnfillEmoji}
                            alt="Emoji"
                          />
                        </div>
                        {validation && (
                          <div>
                            <span style={{ color: "#ff4d4f" }}>Please give us rating</span>
                          </div>
                        )}
                        <div style={{ width: "15.31rem", marginTop: "5px" }} className="d-flex justify-content-between">
                          <span className="rating_below_text">Very Unlikely</span>
                          <span className="rating_below_text">Very Likely</span>
                        </div>
                      </div>
                    </div>

                    <div className="col-12 text-end">
                      <button className="btn btn-sm btn-light text-primary px-3" htmlType="submit">
                        Submit
                      </button>
                    </div>
                  </Form>
                ) : (
                  <Form form={form1} onFinish={submitFeedbackPreLogin}>
                    <div className="row">
                      <div className="col-12 col-md-6">
                        <Row>
                          <label className="step-label">Your Name</label>
                          <Form.Item
                            name="fullName"
                            className="form-item"
                            rules={[
                              {
                                required: true,
                                message: "Please enter your full name",
                              },
                              {
                                pattern: /^([\w]{1,})+\s+([\w\s]{1,})+$/i,
                                message: "Please enter valid name.",
                              },
                              {
                                pattern: /^([^0-9]*)$/,
                                message: "Number not allow in full name",
                              },
                            ]}
                          >
                            <Input size="large" placeholder="Enter your Name" />
                          </Form.Item>
                        </Row>
                        <Row>
                          <label className="step-label">Email address</label>
                          <Form.Item
                            name="emailId"
                            rules={[
                              {
                                required: true,
                                message: "Please input your E-mail!",
                              },
                              {
                                type: "email",
                                pattern: /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/,
                                message: "Please enter valid E-mail",
                              },
                            ]}
                          >
                            <Input size="large" placeholder="Enter your email address" />
                          </Form.Item>
                        </Row>
                        <Row>
                          <label className="step-label   mb-1">Mobile Number</label>
                          <div className="d-flex group_input">
                            <div className="w-25 ">
                              <Form.Item
                                className="form-item"
                                name="mobilePhoneCode"
                                rules={[
                                  {
                                    required: true,
                                    message: "Please select your Country Code.",
                                  },
                                ]}
                              >
                                <Select placeholder="Select phone Code" size="large" className="w-100">
                                  {phoneCodes.map((phoneCode, i) => {
                                    return <Option key={i} value={phoneCode.countryPhoneCode}>{`+${phoneCode.countryPhoneCode} (${phoneCode.countryName})`}</Option>;
                                  })}
                                </Select>
                              </Form.Item>
                            </div>
                            <div className="w-75">
                              <Form.Item
                                name="mobileNo"
                                rules={[
                                  {
                                    required: true,
                                    message: "Please enter your mobile number",
                                  },
                                  {
                                    pattern: /^[0-9\b]+$/,
                                    message: "Only numbers allowed",
                                  },
                                  {
                                    min: 10,
                                    max: 10,
                                    message: "Mobile Number must be 10 digits",
                                  },
                                ]}
                              >
                                <Input placeholder="Enter your mobile number" size="large" />
                              </Form.Item>
                            </div>
                          </div>
                        </Row>
                        <Row>
                          <label className="step-label">Select category</label>
                          <Form.Item
                            name={"category"}
                            rules={[
                              {
                                required: true,
                                message: "Select category",
                              },
                            ]}
                          >
                            <Select placeholder="Select" size="large">
                              <Option value="Money Transfer">Money Transfer</Option>
                              <Option value="Exchange Rate">Exchange Rate</Option>
                              <Option value="Service Fee">Service Fee</Option>
                              <Option value="Payment Gateway">Payment Gateway</Option>
                              <Option value="Portal Experien">Portal Experience</Option>
                              <Option value="Others">Others</Option>
                            </Select>
                          </Form.Item>
                        </Row>
                      </div>
                      <div className="col-12 col-md-6">
                        <Row>
                          <label className="step-label">Describe your Feedback </label>
                          <Form.Item
                            name={"comments"}
                            rules={[
                              {
                                required: true,
                                message: "This field is required.",
                              },
                            ]}
                          >
                            <TextArea
                              onKeyDown={(e) => {
                                if (e.key === "Enter") {
                                  e.preventDefault();
                                  if (!e.shiftKey) {
                                    e.preventDefault();
                                  }
                                }
                              }}
                              className="bg-secondary-light"
                              style={{ resize: "none", height: "8.2rem" }}
                              autoComplete="none"
                            />
                          </Form.Item>
                        </Row>
                        <Row>
                          <label className="step-label">How Likely would recommend us to your friend</label>
                          <div className="d-flex gap-3">
                            <img
                              className="emoji-img"
                              onClick={() => {
                                setRating(1);
                                setValidation(false);
                              }}
                              src={rating === 1 ? firstFill : firstUnfillEmoji}
                              alt="Emoji"
                            />
                            <img
                              className="emoji-img"
                              onClick={() => {
                                setRating(2);
                                setValidation(false);
                              }}
                              src={rating === 2 ? secoundFill : secoundUnfillEmoji}
                              alt="Emoji"
                            />
                            <img
                              className="emoji-img"
                              onClick={() => {
                                setRating(3);
                                setValidation(false);
                              }}
                              src={rating === 3 ? thirdFill : thirdUnfillEmoji}
                              alt="Emoji"
                            />
                            <img
                              className="emoji-img"
                              onClick={() => {
                                setRating(4);
                                setValidation(false);
                              }}
                              src={rating === 4 ? forthfill : fourthUnfillEmoji}
                              alt="Emoji"
                            />
                            <img
                              className="emoji-img"
                              onClick={() => {
                                setRating(5);
                                setValidation(false);
                              }}
                              src={rating === 5 ? fiveFill : fiveUnfillEmoji}
                              alt="Emoji"
                            />
                          </div>
                          {validation && (
                            <div>
                              <span style={{ color: "#ff4d4f" }}>Please give us rating</span>
                            </div>
                          )}
                          <div style={{ width: "15.31rem", marginTop: "5px" }} className="d-flex justify-content-between">
                            <span className="rating_below_text">Very Unlikely</span>
                            <span className="rating_below_text">Very Likely</span>
                          </div>
                        </Row>
                        <Row>
                          <label className="step-label">Word Verification</label>
                          <div className="w-100 d-flex mb-3">
                            <div className="me-3">
                              <img src={`data:image/jpeg;base64,${captchaImg}`} alt="captcha" />
                            </div>
                            <div className="d-flex align-items-center text-light my-3" style={{ cursor: "pointer" }} onClick={getCaptcha}>
                              <img src={logorefresh} alt="refresh" className="me-2" />
                              <span className="fs-12">Refresh Code</span>
                            </div>
                          </div>
                          <Form.Item
                            className="form-item"
                            name="captcha"
                            rules={[
                              {
                                required: true,
                                message: "Enter Captcha.",
                              },
                            ]}
                          >
                            <Input size="large" placeholder="Enter the text shown in the Image" />
                          </Form.Item>
                        </Row>
                      </div>
                    </div>

                    <div className="col-12 text-end">
                      <button className="btn btn-sm btn-light text-primary px-3" htmlType="submit">
                        Submit
                      </button>
                    </div>
                  </Form>
                )}
              </div>
            </div>
          </div>
        </div>
        <Footer />
      </Spinner>
    </React.Fragment>
  );
}
