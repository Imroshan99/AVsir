import { useEffect } from "react";
import { useSearchParams } from "react-router-dom";
import { LogAPI } from "../../../apis/LogAPI";
import SubHeader from "../layout/SubHeader";

export default function SofortSuccess() {
  const [searchParams, setSearchParams] = useSearchParams();
  const transId = searchParams.get("transId");
  console.log("transId", transId);
  useEffect(() => {
    window.localStorage.setItem(transId, "SUCCESS");
    let logPayload = {
      groupId: "XR",
      logText: `SOFORT SUCCESS : ${transId}`,
      callerFileName: "XR_SOFORT.js",
      logFileName: "XR_SOFORT_LOG",
      stackTrace: "",
      msgLevel: "INFO",
    };
    LogAPI.kycLog(logPayload).then((res) => {
      window.close("", "_parent", "");
    });
  }, []);

  const onClickWindowCloseHandler = () => {
    window.close("", "_parent", "");
    // var newWindow = window.open();
    // setTimeout(() => {
    // newWindow.location = "https://www.google.com";
    //   window.open("https://www.google.com")
    // }, 2000);
  };
  return (
    <div>
      <SubHeader title="Transaction Successful. Thank you" />
      <div className="text-center">
        <button className="btn btn-primary text-light mt-5" onClick={onClickWindowCloseHandler}>
          close window
        </button>
      </div>
    </div>
  );
}
