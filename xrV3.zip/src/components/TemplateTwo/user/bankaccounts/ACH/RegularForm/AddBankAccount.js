import React, { useState, useEffect, useReducer } from "react";
import { Row, Col } from "react-bootstrap";
import { Form, Input, Tabs, Select, notification } from "antd";
import { Link, useLocation, useNavigate } from "react-router-dom";
import Spinner from "../../../../../../reusable/Spinner";
import Swal from "sweetalert2";
import { config } from "../../../../../../config";
import { useSelector } from "react-redux";
import { PencilSquare } from "react-bootstrap-icons";

import DefaultLayout from "../../../../layout/DefaultLayout";

import ReviewBankAccountDetails from "./ReviewBankAccountDetails";
import useHttp from "../../../../../../hooks/useHttp";
import { achBankAccountAPI } from "../../../../../../apis/achBankAccountAPI";

const { TabPane } = Tabs;
const { Option } = Select;

export default function AddBankAccount(props) {
  const [form] = Form.useForm();
  const AuthReducer = useSelector((state) => state);
  const [loading, setLoader] = useState(false);
  const [activeStep, setActiveStep] = useState("STEP1");
  
  let navigate = useNavigate();
  let location = useLocation();
  const [bankListData, setBankListData] = useState([]);
  const [routingListData, setRoutingListData] = useState([]);

  const [state, setState] = useReducer(
    (state, newState) => ({ ...state, ...newState }),
    {
      clientId: AuthReducer.clientId,
      groupId: AuthReducer.groupId,
      twofa: AuthReducer.twofa,
      sessionId: AuthReducer.sessionId,
      userID: AuthReducer.userID,
      userFullName: AuthReducer.userFullName,
      bankName: null,
      accountNo: null,
      confirmAccountNo: null,
      accountType: null,
      nickName: null,
      routingNumber: null,
      processType: null,

      redirectPage: "",
      redirectPageState: [],
    }
  );

  useEffect(async () => {
    window.scrollTo({ top: 0, behavior: "smooth" });
    getBankListHandler();
    setState({
      redirectPage: location.state.fromPage,
      redirectPageState: location.state.fromPageState,
    });
  }, []);

  const hookGetBankNames = useHttp(achBankAccountAPI.getBankNames);
  const hookGetBankRoutingNumber = useHttp(
    achBankAccountAPI.getBankRoutingNumber
  );

  const getBankListHandler = () => {
    let bankListPayload = {
      requestType: "GETBANKNAME",
      userId: AuthReducer.userID,
      countryCode: AuthReducer.sendCountryCode,
      bankName: "",
    };

    hookGetBankNames.sendRequest(bankListPayload, function (data) {
      if (data.status == "S") {
        console.log(data.responseData);
        setBankListData(data.responseData);
        // setState({ transactionLists: data.responseData });
      }
    });
  };

  const handleChangeBankName = (data) => {
    let routingPayload = {
      requestType: "GETBANKNAME",
      userId: AuthReducer.userID,
      countryCode: AuthReducer.sendCountryCode,
      bankName: data,
    };

    hookGetBankRoutingNumber.sendRequest(routingPayload, function (data) {
      if (data.status == "S") {
        setRoutingListData(data.responseData);
      }
    });
  };

  const hookCheckDuplicateBankAccount = useHttp(
    achBankAccountAPI.checkDuplicateBankAccount
  );
  const hookCheckAchAccountNickName = useHttp(
    achBankAccountAPI.checkAchAccountNickName
  );

  const handleAccountNoBlur = (e) => {
    if (e.target.value.length >= 1) {
      const payloadDuplicateBankAccount = {
        requestType: "CHECKDUPLICATE",
        userId: AuthReducer.userID,
        bankName: props.state.bankName,
        accountNo: e.target.value,
        routingNumber: props.state.routingNumber,
        processType: "YODLEE",
      };

      hookCheckDuplicateBankAccount.sendRequest(
        payloadDuplicateBankAccount,
        function (data) {
          if (DataView.status == "S") {
            // notification.success({ message: DataView.message });
          } else {
            // notification.error({ message: res.data.errorMessage });
            form.setFields([
              { name: "accountNo", errors: [data.errorMessage] },
            ]);
          }
        }
      );
    }
  };

  const handleNickNameBlur = (e) => {
    if (e.target.value.length >= 1) {
      const payloadCheckNickName = {
        requestId: config.requestId,
        requestType: "CHECKACCNICKNAME",
        channelId: config.channelId,
        clientId: AuthReducer.clientId,
        groupId: AuthReducer.groupId,
        sessionId: AuthReducer.sessionId,
        ipAddress: "127.0.0.1",
        userId: AuthReducer.userID,
        nickName: e.target.value,
      };

      hookCheckAchAccountNickName.sendRequest(
        payloadCheckNickName,
        function (data) {
          if (data.status == "S") {
            // notification.success({ message: data.message });
          } else {
            // notification.error({ message: data.errorMessage });
            form.setFields([{ name: "nickName", errors: [data.message] }]);
          }
        }
      );
    }
  };

  const handleSetSteps = (stepValue) => {
    setActiveStep(stepValue);
  };

  const onFinish = async (value) => {
    form.setFields([
      { name: "accountNo", errors: [] },
      { name: "nickName", errors: [] },
    ]);
    
    setState({
      bankName: value.bankName,
      routingNumber: value.routingNumber,
      accountType: value.accountType,
      processType: "YODLEE",
      accountNo: value.accountNo,
      confirmAccountNo: value.accountNo,
      nickName: value.nickName,
    });
    setActiveStep("REVIEW");
  };

  return (
    <div>
      <div className="p-2 inner_title_wrapper">
        <div className="container">
          <h2 className="mb-0 inner_title">
            {!state.showConfirmBankAccountDetails
              ? "Add Bank Account"
              : "My Bank Account Review"}
          </h2>
        </div>
      </div>
      <DefaultLayout
        accessToken={props.appState.accessToken}
        isLoggedIn={props.appState.isLoggedIn}
        publicKey={props.appState.publicKey}
      >
        <Spinner spinning={loading} delay={500}>
          {!state.showConfirmBankAccountDetails && (
            <Row className="justify-content-center ">
              <Col lg={8} md={10}>
                <div className="card p-3 mb-4">
                 
                  
                
                  {activeStep === "STEP1" && (
                     <Form
                     form={form}
                     onFinish={onFinish}
                     initialValues={{
                       accountHolderName: state.userFullName,
                       bankName: state.bankName,
                       routingNumber: state.routingNumber,
                       accountType: state.accountType,
                       accountNo: state.accountNo,
                       accConNum: state.confirmAccountNo,
                       nickName: state.nickName,
                     }}
                   >
                     <Row className="justify-content-center">
                       <Col md={12}>
                         <div className="">
                           <label className="form-label">
                             Account Holder Name
                           </label>
                           <Form.Item
                             className="form-item"
                             name="accountHolderName"
                             rules={[
                               {
                                 required: true,
                                 message: "Enter Account Holder Name.",
                               },
                             ]}
                           >
                             <Input
                               size="large"
                               placeholder="Account Holder Name"
                             />
                           </Form.Item>
                         </div>
                       </Col>
 
                       <Col md={12}>
                         <div className="">
                           <label className="form-label">Bank Name</label>
 
                           <Form.Item
                             className="form-item"
                             name="bankName"
                             rules={[
                               {
                                 required: true,
                                 message: "Please select Bank Name.",
                               },
                             ]}
                           >
                             <Select
                             size="large"
                               // defaultValue={{ value: props.state.bankName }}
                               className="w-100"
                               onChange={handleChangeBankName}
                               placeholder="Select Bank Name"
                             >
                               {bankListData.map((acc, i) => {
                                 return (
                                   <Option
                                     key={i}
                                     value={acc.bankName}
                                   >{`${acc.bankName}`}</Option>
                                 );
                               })}
                             </Select>
                           </Form.Item>
                         </div>
                       </Col>
 
                       <Col md={12}>
                         <div className="">
                           <label className="form-label">
                             ABA Routing Number
                           </label>
                           <Form.Item
                             className="form-item"
                             name="routingNumber"
                             rules={[
                               {
                                 required: true,
                                 message: "Please select ABA Routing Number.",
                               },
                               {
                                 min: 9,
                                 max: 9,
                                 message: "Routing number must be 9 digits.",
                               },
                             ]}
                           >
                             <Select
                               size="large"
                               className="w-100"
                               placeholder="Select Routing Number"
                             >
                               {routingListData.map((acc, i) => {
                                 return (
                                   <Option
                                     key={i}
                                     value={acc.routingNumber}
                                   >{`${acc.routingNumber}`}</Option>
                                 );
                               })}
                             </Select>
                           </Form.Item>
                         </div>
                       </Col>
 
                       <Col md={12}>
                         <div className="">
                           <label className="form-label">Account Type</label>
                           <Form.Item
                             className="form-item"
                             name="accountType"
                             rules={[
                               {
                                 required: true,
                                 message: "Please select Account Type",
                               },
                             ]}
                           >
                             <Select
                               size="large"
                               className="w-100"
                               placeholder="Select Account Type"
                             >
                               <Option key="ac1" value="S">
                                 Saving
                               </Option>
                               <Option key="ac2" value="C">
                                 Current / Checking
                               </Option>
                             </Select>
                           </Form.Item>
                         </div>
                       </Col>
 
                       <Col md={12}>
                         <div className="">
                           <label className="form-label">Account Number</label>
                           <Form.Item
                             className="form-item"
                             name="accountNo"
                             rules={[
                               {
                                 required: true,
                                 message: "Please input your Account Number.",
                               },
                               {
                                 min: 8,
                                 message:
                                   "Account Number should be between 8 and 25 digits",
                               },
                               {
                                 max: 25,
                                 message:
                                   "Account Number should be between 8 and 25 digits",
                               },
                               {
                                 pattern: /^[0-9\b]+$/,
                                 message: "Only Numbers allowed",
                               },
                               // {
                               //   min: 12,
                               //   max: 12,
                               //   message: "Account number must be 12 digit.",
                               // },
                             ]}
                           >
                             <Input.Password
                               size="large"
                               placeholder="Enter your Account Number"
                               onBlur={handleAccountNoBlur}
                               onPaste={(e) => {
                                 e.preventDefault();
                                 return false;
                               }}
                               onCopy={(e) => {
                                 e.preventDefault();
                                 return false;
                               }}
                               maxLength={25}
                               visibilityToggle={false}
                             />
                           </Form.Item>
                         </div>
                       </Col>
                       <Col md={12}>
                         <div className="">
                           <label className="form-label">
                             Confirm Account Number
                           </label>
                           <Form.Item
                             className="form-item"
                             name="accConNum"
                             rules={[
                               {
                                 required: true,
                                 message:
                                   "Please input your Confirm Account Number.",
                               },
                               {
                                 min: 8,
                                 message:
                                   "Account Number should be between 8 and 25 digits",
                               },
                               {
                                 max: 25,
                                 message:
                                   "Account Number should be between 8 and 25 digits",
                               },
                               {
                                 pattern: /^[0-9\b]+$/,
                                 message: "Only Numbers allowed",
                               },
                               ({ getFieldValue }) => ({
                                 validator(rule, value) {
                                   if (
                                     !value ||
                                     getFieldValue("accountNo") === value
                                   ) {
                                     return Promise.resolve();
                                   }
                                   return Promise.reject(
                                     "The two account number that you entered do not match!"
                                   );
                                 },
                               }),
                             ]}
                           >
                             <Input
                               size="large"
                               placeholder="Enter your Confirm Account Number"
                               maxLength={25}
                               onPaste={(e) => {
                                 e.preventDefault();
                                 return false;
                               }}
                               onCopy={(e) => {
                                 e.preventDefault();
                                 return false;
                               }}
                             />
                           </Form.Item>
                         </div>
                       </Col>
 
                       <Col md={12}>
                         <div className="">
                           <label className="form-label">Nick Name</label>
                           <Form.Item
                             className="form-item"
                             name="nickName"
                             rules={[
                               {
                                 required: true,
                                 message: "Nick Name.",
                               },
                               {
                                 min: 3,
                                 message:
                                   "Nick Name should be between 3 and 40 characters",
                               },
                               {
                                 max: 40,
                                 message:
                                   "Nick Name should be between 3 and 40 characters",
                               },
                               {
                                 pattern: /^[a-zA-Z0-9]+$/,
                                 message: "No Special Chars",
                               },
                             ]}
                           >
                             <Input
                               size="large"
                               onBlur={handleNickNameBlur}
                               placeholder="Nick Name"
                             />
                           </Form.Item>
                         </div>
                       </Col>
 
                       <Col md={12}>
                         <div className="d-flex justify-content-end">
                           <Link
                             to={"/my-bank-accounts"}
                             className="btn btn-secondary btn-sm me-3 my-3"
                           >
                             Back
                           </Link>
                           <button
                             className="btn btn-primary text-white btn-sm my-3"
                             type="submit"
                             //   onClick={() => setIsICICI(true)}
                           >
                             Review
                           </button>
                         </div>
                       </Col>
                     </Row>
                   </Form>
                  )}

                  {activeStep === "REVIEW" && (
                    <ReviewBankAccountDetails
                      accessToken={props.appState.accessToken}
                      isLoggedIn={props.appState.isLoggedIn}
                      publicKey={props.appState.publicKey}
                      setStep={handleSetSteps}
                      setState={setState}
                      state={state}
                    />
                  )}
                </div>
              </Col>
            </Row>
          )}
        </Spinner>
      </DefaultLayout>
    </div>
  );
}
