import React, { useState, useEffect, useReducer } from "react";
import { Row, Col } from "react-bootstrap";
import { Form, Input, Tabs, Select, notification, Spin } from "antd";
import { Link } from "react-router-dom";
import { achBankAccountAPI } from "../../../../../../apis/achBankAccountAPI";
import { config } from "../../../../../../config";
import { useSelector } from "react-redux";
import {
  encrypt,
  decrypt,
  publickey,
} from "../../../../../../helpers/makeHash";
import { Option } from "antd/lib/mentions";
import useHttp from "../../../../../../hooks/useHttp";

export default function AddBankAccountStep1(props) {
  const AuthReducer = useSelector((state) => state);
  const [form] = Form.useForm();
  const [bankListData, setBankListData] = useState([]);
  const [routingListData, setRoutingListData] = useState([]);

  const hookGetBankNames = useHttp(achBankAccountAPI.getBankNames);
  const hookGetBankRoutingNumber = useHttp(
    achBankAccountAPI.getBankRoutingNumber
  );

  useEffect(() => {
    getBankListHandler();
  }, []);

  const getBankListHandler = () => {
    let bankListPayload = {
      requestType: "GETBANKNAME",
      userId: AuthReducer.userID,
      countryCode: AuthReducer.sendCountryCode,
      bankName: "",
    };

    hookGetBankNames.sendRequest(bankListPayload, function (data) {
      if (data.status == "S") {
        console.log(data.responseData);
        setBankListData(data.responseData);
        // setState({ transactionLists: data.responseData });
      }
    });
  };

  const handleChangeBankName = (data) => {
    let routingPayload = {
      requestType: "GETBANKNAME",
      userId: AuthReducer.userID,
      countryCode: AuthReducer.sendCountryCode,
      bankName: data,
    };

    hookGetBankRoutingNumber.sendRequest(routingPayload, function (data) {
      if (data.status == "S") {
        setRoutingListData(data.responseData);
      }
    });
  };

  const onFinish = async (value) => {
    props.setStep("STEP2");
    props.setState({
      bankName: value.bankName,
      routingNumber: value.routingNumber,
      accountType: value.accountType,
      processType: "YODLEE",
    });
  };

  return (
    <Form
      form={form}
      onFinish={onFinish}
      initialValues={{
        accountHolderName: props.state.userFullName,
        bankName: props.state.bankName,
        routingNumber: props.state.routingNumber,
        accountType: props.state.accountType,
      }}
    >
      <Row className="justify-content-center">
        <Col md={12}>
          <div className="">
            <label className="form-label">Account Holder Name</label>
            <Form.Item
              className="form-item"
              name="accountHolderName"
              rules={[
                {
                  required: true,
                  message: "Enter Account Holder Name.",
                },
              ]}
            >
              <Input size="large" placeholder="Account Holder Name" />
            </Form.Item>
          </div>
        </Col>

        <Col md={12}>
          <div className="">
            <label className="form-label">Bank Name</label>

            <Form.Item
              className="form-item"
              name="bankName"
              rules={[{ required: true, message: "Please select Bank Name." }]}
            >
              <Select
                // defaultValue={{ value: props.state.bankName }}
                className="w-100"
                onChange={handleChangeBankName}
                placeholder="Select Bank Name"
              >
                {bankListData.map((acc, i) => {
                  return (
                    <Option
                      key={i}
                      value={acc.bankName}
                    >{`${acc.bankName}`}</Option>
                  );
                })}
              </Select>
            </Form.Item>
          </div>
        </Col>

        <Col md={12}>
          <div className="">
            <label className="form-label">ABA Routing Number</label>
            <Form.Item
              className="form-item"
              name="routingNumber"
              rules={[
                {
                  required: true,
                  message: "Please select ABA Routing Number.",
                },
                {
                  min: 9,
                  max: 9,
                  message: "Routing number must be 9 digits.",
                },
              ]}
            >
              <Select
                showSearch
                className="w-100"
                placeholder="Select Routing Number"
              >
                {routingListData.map((acc, i) => {
                  return (
                    <Option
                      key={i}
                      value={acc.routingNumber}
                    >{`${acc.routingNumber}`}</Option>
                  );
                })}
              </Select>
            </Form.Item>
          </div>
        </Col>

        <Col md={12}>
          <div className="">
            <label className="form-label">Account Type</label>
            <Form.Item
              className="form-item"
              name="accountType"
              rules={[
                {
                  required: true,
                  message: "Please select Account Type",
                },
              ]}
            >
              <Select
                showSearch
                className="w-100"
                placeholder="Select Account Type"
              >
                <Option key="ac1" value="S">
                  Saving
                </Option>
                <Option key="ac2" value="C">
                  Current / Checking
                </Option>
              </Select>
            </Form.Item>
          </div>
        </Col>

        <Col md={12}>
          <div className="d-flex justify-content-end">
            <Link
              to={"/my-bank-accounts"}
              className="btn btn-secondary btn-sm me-3 my-3"
            >
              Back
            </Link>
            <button
              className="btn btn-primary text-white btn-sm my-3"
              type="submit"
              //   onClick={() => setIsICICI(true)}
            >
              Account Details
            </button>
          </div>
        </Col>
      </Row>
    </Form>
  );
}
