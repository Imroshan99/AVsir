import React, { useEffect, useReducer, Fragment, useState } from "react";
import { config } from "../../../../config";
import { useSelector } from "react-redux";
import DefaultLayout from "../../layout/DefaultLayout";
import { encrypt, decrypt, publickey } from "../../../../helpers/makeHash";
import { Form, Input, DatePicker, Modal, Spin } from "antd";
import { Row, Col } from "react-bootstrap";
import { RateAlertAPI } from "../../../../apis/RateAlertAPI";
import moment from "moment";
import { Link } from "react-router-dom";
import useHttp from "../../../../hooks/useHttp";

function RateAlert(props) {
  const AuthReducer = useSelector((state) => state);
  const [form] = Form.useForm();
  const [expiryDate, setExpiryDate] = useState("");

  const [state, setState] = useReducer(
    (state, newState) => ({ ...state, ...newState }),
    {
      clientId: AuthReducer.clientId,
      groupId: AuthReducer.groupId,
      sessionId: AuthReducer.sessionId,
      userID: AuthReducer.userID,
      _isShowModel: false,
      successMsg: "",
    }
  );

  const hookAddRateAlert = useHttp(RateAlertAPI.addRateAlert);

  useEffect(async () => {
    form.setFieldsValue({
      currentExchangeRate: 101.61,
    });
  }, []);

  const onFinish = (value) => {
    let payload = {
      requestType: "ADDRATEALERT",     
      sendCountryCode: "GB",
      sendCurrencyCode: "GBP",
      recvCountryCode: "IN",
      recvCurrencyCode: "INR",
      currentExchangeRate: value.currentExchangeRate,
      exchangeRate: value.exchangeRate,
      expiryDate: moment(expiryDate).format("YYYY-MM-DD"),
      sendModeCode: "CIP",
      programCode: "FER",
      userId: state.userID,
    };

    hookAddRateAlert.sendRequest(payload, function (data) {
      if (data.status == "S") {
        setState({
          _isShowModel: true,
          successMsg: data.message,
        });
      } else {
        let errors = [];
        data.errorList.forEach((error, i) => {
          let errorData = {
            name: error.field,
            errors: [error.error],
          };
          errors.push(errorData);
        });

        if (errors.length > 0) form.setFields(errors);
      }
    });
  };

  return (
    <Fragment>
      <div className="p-2 bg-secondary">
        <h2 className="mb-0 text-white">Rate Alert</h2>
      </div>
      <DefaultLayout
        accessToken={props.appState.accessToken}
        isLoggedIn={props.appState.isLoggedIn}
        publicKey={props.appState.publicKey}
      >
        <div className="bg-white shadow-sm rounded p-4 mb-4">
          <h5>Set a New Rate Alert</h5>
          <Form form={form} onFinish={onFinish}>
            <div className="d-flex justify-content-center align-items-center">
              <Row className="justify-content-center">
                <Col md={12}>
                  <p className="my-4">Today's Exchange Rate</p>
                  <Form.Item
                    className="form-item"
                    name="currentExchangeRate"
                    rules={[
                      {
                        required: true,
                        message: "Please input your Today's Exchange Rate.",
                      },
                    ]}
                  >
                    <Input placeholder="Today Exchange Rate" />
                  </Form.Item>
                </Col>

                <Col md={12}>
                  <p>Desired Exchange Rate</p>
                  <Form.Item
                    className="form-item"
                    name="exchangeRate"
                    rules={[
                      {
                        required: true,
                        message: "Please input your Desired Exchange Rate.",
                      },
                    ]}
                  >
                    <Input placeholder="Desired Exchange Rate" />
                  </Form.Item>
                </Col>

                <Col md={12}>
                  <p>End Date</p>
                  <Form.Item
                    className="form-item"
                    name="expiryDate"
                    rules={[
                      {
                        required: true,
                        message: "Please input your End Date.",
                      },
                    ]}
                  >
                    <DatePicker
                      className="w-100"
                      disabledDate={(current) => {
                        return current && current <= moment(state.start_date);
                      }}
                      onChange={(value, dateString) =>
                        setExpiryDate(value, dateString)
                      }
                    />
                  </Form.Item>
                </Col>

                <div className="d-grid gap-2 d-flex mt-4">
                  <button className="btn btn-sm px-4" type="button">
                    Cancel
                  </button>

                  <button className="btn btn-primary btn-sm text-white px-4 btn-sm">
                    Set a Rate Alert
                  </button>
                </div>
              </Row>
            </div>
          </Form>
        </div>
        <Modal
          centered
          title="Rate Alert"
          visible={state._isShowModel}
          onCancel={() => setState({ _isShowModel: false })}
          onOk={() => setState({ _isShowModel: false })}
          footer={null}
        >
          <p>{state.successMsg}</p>
          <Link
            to={"/new-transaction"}
            className="btn btn-primary text-white btn-sm btn-block"
          >
            Ok
          </Link>
        </Modal>
      </DefaultLayout>
    </Fragment>
  );
}

export default RateAlert;
