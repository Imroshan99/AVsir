import React, { useEffect, useReducer, Fragment } from "react";
import { useSelector } from "react-redux";
import DefaultLayout from "../../layout/DefaultLayout";
import { encrypt, decrypt, publickey } from "../../../../helpers/makeHash";
import { config } from "../../../../config";
import { ProfileAPI } from "../../../../apis/ProfileAPI";
import { GuestAPI } from "../../../../apis/GuestAPI";
import AboutMe from "../../../../containers/AboutMe";
import CurrentAddress from "../../../../containers/CurrentAddress";
import ReviewProfile from "../../../../containers/ReviewProfile";
import { notification } from "antd";
import { useNavigate } from "react-router-dom";
import useHttp from "../../../../hooks/useHttp";

function ProfileSetup(props) {
  const AuthReducer = useSelector((state) => state);
  let navigate = useNavigate();

  const [state, setState] = useReducer(
    (state, newState) => ({ ...state, ...newState }),
    {
      clientId: AuthReducer.clientId,
      groupId: AuthReducer.groupId,
      sessionId: AuthReducer.sessionId,
      userID: AuthReducer.userID,
      isProfileLoad: true,
      isStep: 0,
      citizenshipLists: [],
      occupationLists: [],
      professionLists: [],
      incomeLists: [],
      age: "",
      dob: "",
      gender: "",
      mainAddress: "",
      citizenship: "",
      citizenshipDesc: "",
      income_id: "",
      incomeDesc: "",
      profession_id: "",
      professionDesc: "",
      nationality_id: "",
      nationalityDesc: "",
      occupation_id: "",
      occupationDesc: "",
      address1: "",
      // address2: "",
      address3: "",
      city: "",
      state: "",
      country: "United Kingdom",
      zip: "",
      verificationToken: "",
      verifiedToken: "",
    }
  );

  const hookGetProfile = useHttp(ProfileAPI.getProfile);
  const hookGetIncomeLists = useHttp(ProfileAPI.incomeLists);
  const hookEditProfile = useHttp(ProfileAPI.editProfile);

  const hookGetCitizenshipLists = useHttp(GuestAPI.citizenshipLists);
  const hookGetOccupationLists = useHttp(GuestAPI.occupationLists);
  const hookGetProfessionLists = useHttp(GuestAPI.professionLists);

  useEffect(async () => {
    getProfile();
    incomeLists();
    citizenshipLists();
    occupationLists();
    professionLists();
  }, []);

  const getProfile = () => {
    let payload = {
      requestType: "LEAD",      
      userId: state.userID,
    };

    hookGetProfile.sendRequest(payload, function (data) {
      if (data.status == "S") {
        setState({
          isStep: 1,
          firstName: data.firstName,
          middleName: data.middleName,
          lastName: data.lastName,
          emailId: data.emailId,
          age: data.age,
          dob: data.dob,
          mobileNo: data.mobileNo,
          gender: data.gender,
          mobilePhoneCode: data.mobilePhoneCode,
          citizenship: data.citizenship,
          citizenshipDesc: data.citizenshipDesc,
          nationality_id: data.nationality,
          nationalityDesc: data.nationalityDesc,
          occupation_id: data.occupation,
          occupationDesc: data.occupationDesc,
          profession_id: data.profession,
          professionDesc: data.professionDesc,
          address1: data.address1,
          // address2: data.address2,
          address3: data.address3,
          city: data.city,
          state: data.state,
          zip: data.zip,
          income_id: data.income,
          incomeDesc: data.incomeDesc,
          isProfileLoad: true,
        });
      }
    });
  };

  const incomeLists = () => {
    let payload = {
      requestType: "LEAD",     
      userId: state.userID,
    };

    hookGetIncomeLists.sendRequest(payload, function (data) {
      if (data.status == "S") {
        setState({ incomeLists: data.responseData });
      }
    });
  };

  const citizenshipLists = () => {
    let payload = {
      requestType: "LEAD",     
    };

    hookGetCitizenshipLists.sendRequest(payload, function (data) {
      if (data.status == "S") {
        setState({ citizenshipLists: data.responseData });
      }
    });
  };

  const occupationLists = () => {
    let payload = {
      requestType: "LEAD",     
    };

    hookGetOccupationLists.sendRequest(payload, function (data) {
      if (data.status == "S") {
        setState({ occupationLists: data.responseData });
      }
    });
  };

  const professionLists = () => {
    let payload = {
      requestType: "LEAD",     
    };

    hookGetProfessionLists.sendRequest(payload, function (data) {
      if (data.status == "S") {
        setState({ professionLists: data.responseData });
      }
    });
  };

  const editProfile = (verifiedToken) => {
    const editProfileData = {
      requestType: "EDITPROFILE",      
      SIN: undefined,
      // address1: state.address1,
      address1: window.btoa(state.address1),
      // address2: state.address2,
      // address3: state.address3,
      address3: window.btoa(state.address3),
      citizenship: state.citizenship,
      city: window.btoa(state.city),
      commAddress1: "",
      commAddress2: "",
      commCity: "",
      commCountry: "",
      commPostalCode: "",
      commStateProvince: "",
      companyName: "",
      dob: state.dob,
      gender: state.gender,
      homePhoneNo: "",
      income: state.income_id,
      industry: "",
      motherMaidenName: "",
      nationality: state.nationality_id,
      occupation: state.occupation_id,
      pageName: "EDITPROFILE",
      pep: "",
      periodicUpdate: "Y",
      primaryBusinessFunction: "",
      profession: state.profession_id,
      salutation: "",
      sendCountry: "GB",
      state: window.btoa(state.state),
      tnc: "",
      zipCode: state.zip,
      userId: state.userID,
    };

    hookEditProfile.sendRequest(editProfileData, function (data) {
      if (data.status == "S") {
        setState({
          _isShowAddressEditModel: false,
          _isShowContactEditModel: false,
          _isShowMarketingEditModel: false,
          _isShowAddressOTPBOX: false,
          _isShowContactOTPBOX: false,
          _isShowMarketingOTPBOX: false,
          isModalVisible: false,
        });
        notification.success({ message: data.message });
        navigate("/profile");
      } else {
        setState({
          isModalVisible: false,
        });
        notification.error({ message: data.errorMessage });
      }
      getProfile();
    });
  };
  
  return (
    <Fragment>
      <div className="p-2 bg-secondary">
        <h2 className="mb-0 text-white">Personal Detail</h2>
      </div>
      <div className="mt-4" style={{ backgroundColor: "#f1f5f6" }}>
        <DefaultLayout
          accessToken={props.appState.accessToken}
          isLoggedIn={props.appState.isLoggedIn}
          publicKey={props.appState.publicKey}
        >
          {state.isProfileLoad && (
            <>
              {state.isStep == 1 && (
                <AboutMe state={state} setState={setState} />
              )}
              {state.isStep == 2 && (
                <CurrentAddress state={state} setState={setState} />
              )}
              {state.isStep == 3 && (
                <ReviewProfile
                  state={state}
                  setState={setState}
                  editProfile={editProfile}
                />
              )}
            </>
          )}
        </DefaultLayout>
      </div>
    </Fragment>
  );
}

export default ProfileSetup;
