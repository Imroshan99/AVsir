import React, { useState, useEffect, useReducer } from "react";
import { Row, Col } from "react-bootstrap";
import { Form, Input, Radio, Select, notification, AutoComplete, Tabs, DatePicker } from "antd";
import { useLocation } from "react-router-dom";
import { ReceiverAPI } from "../../../../apis/ReceiverAPI";
import { GuestAPI } from "../../../../apis/GuestAPI";
import { useSelector } from "react-redux";
import useHttp from "../../../../hooks/useHttp";
import { inputValidations } from "../../../../services/validations/validations";
import Spinner from "../../../../reusable/Spinner";
import moment from "moment";
import BankComponent from "./BankComponent";

const { Option } = Select;
const { TabPane } = Tabs;
const { TextArea } = Input;

export default function EditRecipient(props) {
  const [form] = Form.useForm();
  const [form1] = Form.useForm();
  const AuthReducer = useSelector((state) => state);
  const ConfigReducer = useSelector((state) => state);
  const AddRecipientFormConfig = ConfigReducer.groupIdSettings.recipientModule.AddRecipientForm;
  const [loading, setLoader] = useState(false);
  const [activeStep, setActiveStep] = useState(true);
  const [currentTab, setCurrentTab] = useState(1);
  const [form1Data, setForm1Data] = useState({});
  const editRecipientData = props.editRecipientData;

  const location = useLocation();

  const [state, setState] = useReducer((state, newState) => ({ ...state, ...newState }), {
    clientId: AuthReducer.clientId,
    groupId: AuthReducer.groupId,
    twofa: AddRecipientFormConfig?.twoFA ? AddRecipientFormConfig.twoFA : AuthReducer.twofa,
    // twofa:   AuthReducer.twofa,
    sessionId: AuthReducer.sessionId,
    userID: AuthReducer.userID,
    nationalities: [],
    stateCities: [],
    _showOTPBOX: false,
    showConfirmAddRecipient: false,
    isConfirmAddRecipient: false,
    formData: {},
    editData: {},
    verificationToken: "",
    isOTPVerfied: false,
    isModalVisible: false,
    otpType: "RA",
    branchCode: "",
    bankBranch: "",
    bankAddress: "",
    bankState: "",
    bankCity: "",
    bankName: "",
    isSameBank: "N",
    bankCode: "",
    bankId: "",
    bankCountry: "",
    bankLists: [],
    cityLists: [],
    branchLists: [],
    phoneCodes: [],
    occupationLists: [],
    relationshipLists: [],
    deliveryOptionsList: [],
    deliveryOption: "",
    stateLists: [],
    dob: "",
    redirectPage: "",
    redirectPageState: [],
    receiverCountryLists: [],
    recvCountryCode: "",
    recvCurrencyCode: "",

    accountNumber: "",
  });

  const hookGetNationality = useHttp(GuestAPI.getNationality);
  const hookGetCountryPhoneCodes = useHttp(GuestAPI.getCountryPhoneCodes);
  const hookGetRelationshipLists = useHttp(GuestAPI.relationshipLists);
  const hookGetDeliveryOptions = useHttp(GuestAPI.deliveryOptions);
  const hookGetCountryStates = useHttp(GuestAPI.countryStates);
  const hookGetBankBranchData = useHttp(GuestAPI.bankBranchData);
  const hookGetStateCities = useHttp(GuestAPI.stateCities);
  const hookGetReceiverCountryLists = useHttp(GuestAPI.receiverCountryList);
  const hookGetBankLists = useHttp(ReceiverAPI.bankLists);
  const hookGetBankStateCities = useHttp(ReceiverAPI.bankStateCities);
  const hookGebankBranches = useHttp(ReceiverAPI.bankBranches);
  const hookCheckDuplicateReceiver = useHttp(ReceiverAPI.checkDuplicateReceiver);
  const hookEditReceiver = useHttp(ReceiverAPI.editReceiver);

  useEffect(() => {
    if (editRecipientData) {
      setActiveStep(true);
      setState({
        deliveryOption: editRecipientData.recvMode,
      });
      setState({
        bankName: editRecipientData.bankName,
        bankBranch: editRecipientData.bankBranch,
        bankState: editRecipientData.bankState,
        bankCity: editRecipientData.bankCity,
        branchCode: editRecipientData.branchCode,
        recvCountryCode: editRecipientData.recvCountry,
        recvCurrencyCode: editRecipientData.recvCurrency,
        dob : editRecipientData.dob
      });
      form.setFieldsValue({
        mobileCountryCode: editRecipientData.mobileCountryCode,
        firstName: editRecipientData.firstName,
        middleName: editRecipientData.middleName,
        lastName: editRecipientData.lastName,
        nickName: editRecipientData.nickName,
        mobileNo: editRecipientData.mobileNo,
        phoneNo: editRecipientData.offPhone,
        relationship: editRecipientData.relationship,
        address1: editRecipientData.address1,
        address2: editRecipientData.address2,
        zipCode: editRecipientData.zipcode,
        nationality: editRecipientData.recvCountryName,
        city: editRecipientData.city,
        state: editRecipientData.state,
        country: editRecipientData.recvCountryName,
        emailId: editRecipientData.emailId,
        dob: editRecipientData.dob !== "" ? moment(editRecipientData.dob) : "",
      });
      form1.setFieldsValue({
        deliveryOptions: editRecipientData.recvMode,
        accountNo: editRecipientData.accountNo,
        accConNum: editRecipientData.accountNo,
        bankName: editRecipientData.bankName,
        bankCity: editRecipientData.bankCity,
        branch: editRecipientData.bankBranch,
        accountType: editRecipientData.accountType,
        IFSCCode: editRecipientData.branchCode,
        bankState: editRecipientData.bankState,
        branchCode: editRecipientData.branchCode,
      });
      if (editRecipientData.recvCountry !== "IN") {
        form1.setFieldsValue({
          interBankCode: editRecipientData.interBankCode,
          interBankName: editRecipientData.interBank,
          interBankCountry: editRecipientData.interBankCountry,
          interBankAddress: editRecipientData.interBankAddress,
        });

        if (editRecipientData.recvCountry === "BD" || editRecipientData.recvCountry === "PH" || editRecipientData.recvCountry === "ID" || editRecipientData.recvCountry === "TH") {
          form1.setFieldsValue({
            bankCode: editRecipientData.swiftCode,
          });
        }

        if (editRecipientData.recvCountry === "LK") {
          form1.setFieldsValue({
            swiftCode: editRecipientData.swiftCode,
            bankCode: editRecipientData.recvUniqueIdValue
          });
        }
      }
    }
  }, [editRecipientData]);

  useEffect(() => {
    getDeliveryOptions();
    getNationality();
    getCoutryCodes();
    getBankList();
    getReceiverCountryLists();
    // getOccupationLists();
    getRelationshipLists();
    getStateLists();
    form1.setFieldsValue({
      country: editRecipientData.recvCountryName,
    });
    setState({
      redirectPage: location.state?.fromPage,
      redirectPageState: location.state?.fromPageState,
    });
  }, [editRecipientData]);

  const getNationality = async () => {
    const payload = {
      requestType: "NATIONALITYLIST",
      keyword: "",
    };

    setLoader(true);
    hookGetNationality.sendRequest(payload, function (data) {
      if (data.status == "S") {
        setState({ nationalities: data.responseData });
      } else {
        notification.error({ message: data.data.errorMessage });
      }
      setLoader(false);
    });
  };

  const onChangeAccountNumberHandler = (value) => {
    setState({
      accountNumber: value.target.value,
    });
  };

  const getReceiverCountryLists = () => {
    const payload = {
      requestType: "RECVCOUNTRYLIST",
      sendCountry: "GB",
      sendCurrency: "GBP",
    };

    hookGetReceiverCountryLists.sendRequest(payload, function (data) {
      if (data.status == "S") {
        setState({
          receiverCountryLists: data.responseData,
        });
        props.newForm1.setFieldsValue({
          country: data.responseData[0].countryName,
        });
      }
    });
  };

  const getCoutryCodes = async () => {
    if (AuthReducer.groupId === "XR") {
      setState({
        phoneCodes: [
          { countryPhoneCode: 44, countryName: "United Kingdom" },
          { countryPhoneCode: 91, countryName: "India" },
          { countryPhoneCode: 63, countryName: "Philippines" },
          { countryPhoneCode: 880, countryName: "Bangladesh" },
          { countryPhoneCode: 62, countryName: "Indonesia" },
          { countryPhoneCode: 66, countryName: "Thailand" },
          { countryPhoneCode: 94, countryName: "Sri Lanka" },
        ],
        selectPhoneCodes: true,
      });
    } else {
      const payload = {
        requestType: "COUNTRYPHONECODE",
      };
      props.AddRecipientFormsetLoader(true);
      hookGetCountryPhoneCodes.sendRequest(payload, function (data) {
        if (data.status == "S") {
          let _recvCountryCode = data.responseData.filter(
            (item) => item.countryCode === editRecipientData.recvCountry,
          );

          setState({
            phoneCodes: data.responseData,
            selectPhoneCodes: false,
            // mobileCountryCode: _recvCountryCode[0].countryPhoneCode,
          });
          props.newForm1.setFieldsValue({
            mobileCountryCode: _recvCountryCode[0].countryPhoneCode,
          });
          props.setLoader(false);
        }
      });
    }
  };

  const getRelationshipLists = async () => {
    let payload = {
      requestType: "RELAIONSHIPLISTS",
      countryCode : AuthReducer.sendCountryCode,
      countryCurrency : AuthReducer.sendCurrencyCode,
      recvCountryCode : state.recvCountryCode,
      recvCountryCurrency : state.recvCurrencyCodes
    };

    setLoader(true);
    hookGetRelationshipLists.sendRequest(payload, function (data) {
      if (data.status == "S") {
        setState({ relationshipLists: data.responseData });
      }
      setLoader(false);
    });
  };

  const getDeliveryOptions = async () => {
    let payload = {
      requestType: "RECVMODE",
      countryCode: editRecipientData.recvCountry,
    };
    setLoader(true);
    hookGetDeliveryOptions.sendRequest(payload, function (data) {
      if (data.status === "S") {
        setState({ deliveryOptionsList: data.responseData });
        setLoader(false);
      }
    });
  };
  const getStateCityList = async (stateCode) => {
    const payload = {
      requestType: "CITILIST",
      keyword: "",
      stateCode: stateCode,
      countryCode: editRecipientData.recvCountry,
    };

    setLoader(true);
    hookGetStateCities.sendRequest(payload, function (data) {
      if (data.status == "S") {
        setState({ stateCities: data.responseData });
      } else {
        notification.error({ message: data.errorMessage });
        setState({ stateCities: [] });
      }
      setLoader(false);
    });
  };
  const onSelectState = (value) => {
    getStateCityList(value);
  };

  const getStateLists = async () => {
    let payload = {
      requestType: "STATELIST",
      countryCode: editRecipientData.recvCountry,
      keyword: "",
    };
    setLoader(true);
    hookGetCountryStates.sendRequest(payload, function (data) {
      if (data.status === "S") {
        setState({ stateLists: data.responseData });
        setLoader(false);
      }
    });
  };

  const onChangeIFSCCode = async (e) => {
    if (e.target.value.length == 11) {
      const payload = {
        requestType: "BANKBRANCHDATA",
        branchCode: e.target.value,
      };
      setLoader(true);
      hookGetBankBranchData.sendRequest(payload, function (data) {
        if (data.status == "S") {
          notification.success({ message: data.message });
          setState({
            branchCode: data.branchCode,
            bankBranch: data.branchName,
            bankAddress: data.bankAddress,
            bankState: data.bankState,
            bankCity: data.bankCity,
            bankName: data.bankName,
            bankId: data.bankId,
            bankCountry: data.bankCountry,
          });
          form1.setFieldsValue({
            bankName: data.bankName,
            bankState: data.bankState,
            bankCity: data.bankCity,
            branch: data.branchName,
          });
          setLoader(false);
        } else {
          // notification.error({ message: res.data.errorMessage });
          form1.setFields([{ name: "IFSCCode", errors: [data.data.errorMessage] }]);
          setState({
            branchCode: "",
            bankBranch: "",
            bankAddress: "",
            bankState: "",
            bankCity: "",
            bankName: "",
            bankId: "",
            bankCountry: "",
          });
        }
        setLoader(false);
      });
    } else {
      setState({
        branchCode: "",
        bankBranch: "",
        bankAddress: "",
        bankState: "",
        bankCity: "",
        bankName: "",
        bankId: "",
        bankCountry: "",
      });
    }
  };

  const getBankList = async (e) => {
    const payload = {
      requestType: "BANKLIST",
      countryCode: editRecipientData.recvCountry,
      userId: state.userID,
    };

    setLoader(true);
    hookGetBankLists.sendRequest(payload, function (data) {
      if (data.status === "S") {
        setState({
          bankLists: data.responseData,
        });
        setLoader(false);
      }
    });
  };

  const onSelectBank = async (row) => {
    if (editRecipientData.recvCountry === "IN") {
      const bankName = row.value;
      let bankCode = row.label.props.bankCode;
      let isSameBank = row.label.props.isSameBank;
      setState({
        bankName: bankName,
        bankCode: bankCode,
        isSameBank: isSameBank,
      });
      form1.setFieldsValue({
        bankName: bankName,
        cityName: undefined,
        branch: undefined,
        bankCity: undefined,
        branchCode: undefined,
      });
      const payload = {
        requestType: "BankStateCities",
        countryCode: editRecipientData.recvCountry,
        state: "",
        bankName: bankName,
        search: "",
      };
      setLoader(true);
      hookGetBankStateCities.sendRequest(payload, function (data) {
        setLoader(false);
        if (data.status === "S") {
          setState({
            cityLists: data.responseData,
          });
        }
      });
    } else {
      setState({ bankName: row.value });
    }
  };

  const onSetectCity = async (cityName) => {
    setState({ bankCity: cityName });
    const payload = {
      requestType: "BANKBRANCHES",
      countryCode: editRecipientData.recvCountry,
      bankCode: state.bankCode,
      bankName: state.bankName,
      cityCode: "",
      stateCode: "",
      city: cityName,
      keyword: "",
    };

    setLoader(true);
    hookGebankBranches.sendRequest(payload, function (data) {
      if (data.status === "S") {
        setState({
          branchLists: data.responseData,
        });
        setLoader(false);
      }
    });
  };

  const onSetectBranch = async (value) => {
    let branch = JSON.parse(value);
    setState({
      branchCode: branch.branchCode,
      bankBranch: branch.branchName,
      bankAddress: branch.bankAddress,
      bankState: branch.bankState,
      bankCity: branch.bankCity,
      bankName: branch.bankName,
      bankId: branch.bankId,
      bankCountry: branch.bankCountry,

      // bankCode: bankCode,
      // branchName: branchName
    });

    form1.setFieldsValue({
      IFSCCode: branch.branchCode,
      branch: branch.branchName,
      bankState: branch.bankState,
    });
  };

  const editReceiver = async (value) => {
    let editPostData = value.editData;
    hookEditReceiver.sendRequest(editPostData, function (data) {
      if (data.status == "S") {
        setLoader(false);
        props.getReceiverLists();
        notification.success({ message: data.message });
        props.setEditRecipientModal(false);
      } else {
        notification.error({ message: data.errorMessage });

        let errors = [];
        data.errorList.forEach((error, i) => {
          const _fields = ["branchCode", "bankCode", "bankName", "bankAddress", "swfitCode"];
          if (_fields.includes(error.field)) {
            setActiveStep(true);
          }
          let errorData = {
            name: error.field,
            errors: [error.error],
          };
          errors.push(errorData);
        });
        if (errors.length > 0) form1.setFields(errors);
        if (errors.length > 0) form.setFields(errors);
        setLoader(false);
      }
    });
  };

  const activeTab = (key) => {
    if (currentTab !== key) {
      setCurrentTab(key);
    }
  };
  const onFinish1 = async (value) => {
    setForm1Data(value);
    setActiveStep(!activeStep);
  };

  const onFinish2 = async (val) => {
    let value = { ...val, ...form1Data };
    let bankPayload = {};

    if (state.recvCountryCode === "IN") {
      bankPayload.accountType = value.accountType;
      bankPayload.bankName = value.bankName;
      bankPayload.branchCode = value.branchCode ? value.branchCode : value.IFSCCode;
      bankPayload.bankBranch = value.branchName ? value.branchName : value.branch.trim();
      bankPayload.bankAddress = value.bankAddress;
      bankPayload.bankState = value.bankState;
      bankPayload.bankCity = value.bankCity ? value.bankCity : value.cityName.trim();
    } else {
      if (state.recvCountryCode === "BD" || state.recvCountryCode === "PH" || state.recvCountryCode === "ID" || state.recvCountryCode === "TH") {
        bankPayload.swiftCode = value.bankCode;
      }
      bankPayload.accountType = "S";
      bankPayload.bankName = state.bankName;
      bankPayload.bankCode = value.bankCode;
      bankPayload.branchCode = (state.recvCountryCode === "PH" || state.recvCountryCode === "ID" || state.recvCountryCode === "TH") ? "000000" : value.branchCode;
      bankPayload.bankBranch = state.bankName;
      bankPayload.bankAddress = value.bankAddress;
      bankPayload.bankState = state.recvCountryCode;
      bankPayload.bankCity = state.recvCountryCode;

      if (state.recvCountryCode === "LK") {
        bankPayload.swiftCode = value.swiftCode;
        bankPayload.recvUniqueIdValue = value.bankCode;
      }
    }
    let formData = {
      requestType: "RECEIVERADD",
      receiverType: "INDIVIDUAL",
      firstName: value.firstName.trim(),
      middleName: value.middleName ? value.middleName : "",
      lastName: value.lastName.trim(),
      nickName: value.nickName.trim(),
      accountNo: value.accountNo,
      relationship: value.relationship,
      gender: "",
      dob: state.dob ? state.dob : "",
      // dob: value.dob,

      address1: value.address1.trim(),
      address2: value.address2,
      zipcode: value.zipCode,
      state: value.state.trim(),
      stateOther: "",
      city: value.city.trim(),
      nationality: value.nationality,
      cityOther: "",
      emailId: value.emailId ? value.emailId : "",

      mobileCountryCode: value.mobileCountryCode ? value.mobileCountryCode : "",
      mobileNo: value.mobileNo ? value.mobileNo : "",
      phoneNo: value.phoneNo ? value.phoneNo : "",

      altPhone: "",
      fax: "",

      recvMode: form1Data.deliveryOptions,
      accountHolderName: `${value.firstName.trim()} ${value.lastName.trim()}`,

      accountType: value.accountType,
      bankCode: value.bankCode,
      bankName: value.bankName ? value.bankName : state.bankName,
      branchCode: value.IFSCCode ? value.IFSCCode : state.branchCode,
      bankBranch: value.branch ? value.branch : state.bankBranch,
      bankAddress: null,
      bankState: value.bankState ? value.bankState : state.bankState,
      bankCity: value.bankCity ? value.bankCity : state.bankCity,
      isSameBank: "N",

      nearestBranchCode: "",
      nearestBranch: "",
      recvUniqueIdType: "",
      recvUniqueIdValue: "",

      interBankCode: value.interBankCode ? value.interBankCode : "",
      interBank: value.interBankName ? value.interBankName : "",
      interAccountNo: "",
      interAccountType: "",
      interBranchCode: "",
      interBankBranch: "",
      interBankAddress: value.interBankAddress ? value.interBankAddress : "",
      interBankCountry: value.interBankCountry ? value.interBankCountry : "",

      recvCountry: state.recvCountryCode,
      recvCurrency: state.recvCurrencyCode,
      purpose: "",
      purposeCode: "",
      remark: "",
      twofa: state.twofa,
      userId: state.userID,
      recordToken: editRecipientData.recordToken,
      ...bankPayload,
    };

    setLoader(true);
    await hookCheckDuplicateReceiver.sendRequest(formData, function (data) {
      if (data.status == "S") {
        editReceiver({ editData: formData });
      } else {
        notification.error({ message: data.errorMessage });
        setLoader(false);
      }
    });
  };

  const onChangeDeliveryOptionHandler = (value) => {
    setState({
      deliveryOption: value,
    });
  };

  return (
    <div className="EditReceiver">
      <Spinner spinning={loading}>
        <div className="d-flex justify-content-between mb-32">
          <h2
            className="mb-4"
            style={{
              borderBottom: "1px solid #658C99",
            }}
          >
            Edit Receiver
          </h2>
          {activeStep ? <h2>Step 1</h2> : <h2>Step 2</h2>}
        </div>
        {activeStep && (
          <Form onFinish={onFinish1} form={form1}>
            <Row>
              <Col className="Modal-Delivery-Options-Container">
                <label className="form-label">Delivery Options</label>
                <Form.Item
                  className="form-item"
                  name="deliveryOptions"
                  rules={[
                    {
                      required: true,
                      message: "Please select Delivery Options.",
                    },
                  ]}
                >
                  <Select
                    className="w-100"
                    placeholder="Select Delivery Options"
                    onChange={onChangeDeliveryOptionHandler}
                  >
                    {state.deliveryOptionsList.map((value, i) => {
                      return (
                        <Option key={i} value={value.recvModeCode}>
                          {value.recvMode}
                        </Option>
                      );
                    })}
                  </Select>
                </Form.Item>
              </Col>
            </Row>
            {state.recvCountryCode === "IN" && (
              <div>
                <label>Do you know the IFSC of beneficiary bank?</label>
                <Tabs defaultActiveKey={currentTab} onChange={activeTab}>
                  <TabPane tab="Yes" key="1">
                    <Row>
                      <Col md={6} style={{ marginBottom: "24px" }}>
                        <label>Receivers IFSC Code</label>
                        <Form.Item
                          className="mb-0"
                          name="IFSCCode"
                          rules={[
                            {
                              required: true,
                              message: "Please input your IFSC Code.",
                            },
                            {
                              min: 11,
                              max: 11,
                              message: "Please input valid IFSC Code.",
                            },
                          ]}
                          onChange={onChangeIFSCCode}
                        >
                          <Input autoComplete="none" />
                        </Form.Item>
                        {/* {showIfscAddress && ifscCode.length == 11 && (
                              <span className="text-info mt-2">
                                {ifscAddress}
                              </span>
                            )} */}
                      </Col>
                    </Row>
                    <Row>
                      <Col sm={12} md={6}>
                        <div>
                          <label>Bank Name</label>
                          <Form.Item name="bankName">
                            <AutoComplete
                              disabled
                              showSearch
                              labelInValue
                              placeholder="Bank Name"
                            ></AutoComplete>
                          </Form.Item>
                        </div>
                      </Col>
                      <Col sm={12} md={6}>
                        <div>
                          <label>Bank Branch State</label>
                          <Form.Item name="bankState">
                            <AutoComplete
                              disabled
                              showSearch
                              placeholder="Bank Branch State"
                            ></AutoComplete>
                          </Form.Item>
                        </div>
                      </Col>
                    </Row>
                    <Row>
                      <Col sm={12} md={6}>
                        <div>
                          <label>City</label>
                          <Form.Item name="bankCity">
                            <AutoComplete
                              disabled
                              showSearch
                              onSelect={onSetectCity}
                              placeholder="City"
                            ></AutoComplete>
                          </Form.Item>
                        </div>
                      </Col>
                      <Col sm={12} md={6}>
                        <div>
                          <label>Branch</label>
                          <Form.Item name="branch">
                            <AutoComplete
                              disabled
                              autoComplete="off"
                              showSearch
                              onSelect={onSetectBranch}
                              placeholder="Branch"
                            ></AutoComplete>
                          </Form.Item>
                        </div>
                      </Col>
                    </Row>
                    <div className="row">
                      <div className="col-12 col-md-6">
                        <div>
                          <label>Account Number</label>
                          <Form.Item
                            name="accountNo"
                            rules={[
                              {
                                required: true,
                                message: "Please input your Account Number.",
                              },
                              ...inputValidations.accountNumber(editRecipientData.recvCountry),
                            ]}
                          >
                            <Input.Password
                              autoComplete="off"
                              className="input_account_no"
                              placeholder="Enter your Account Number"
                              onPaste={(e) => {
                                e.preventDefault();
                                return false;
                              }}
                              onCopy={(e) => {
                                e.preventDefault();
                                return false;
                              }}
                              visibilityToggle={false}
                            />
                          </Form.Item>
                        </div>
                      </div>
                      <div className="col-12 col-md-6">
                        <div>
                          <label>Confirm Account Number</label>
                          <Form.Item
                            name="accConNum"
                            rules={[
                              {
                                required: true,
                                message: "Please input your Confirm Account Number.",
                              },
                              ...inputValidations.accountNumber(editRecipientData.recvCountry),
                              ({ getFieldValue }) => ({
                                validator(rule, value) {
                                  if (!value || getFieldValue("accountNo") === value) {
                                    return Promise.resolve();
                                  }
                                  return Promise.reject(
                                    "The two account number that you entered do not match!",
                                  );
                                },
                              }),
                            ]}
                          >
                            <Input
                              className="input_account_no"
                              placeholder="Enter your Confirm Account Number"
                              onPaste={(e) => {
                                e.preventDefault();
                                return false;
                              }}
                              onCopy={(e) => {
                                e.preventDefault();
                                return false;
                              }}
                            />
                          </Form.Item>
                        </div>
                      </div>
                    </div>

                    <Row>
                      <Col>
                        <label>Account Type</label>
                        <Form.Item
                          rules={[
                            {
                              required: true,
                              message: "Please select your account type.",
                            },
                          ]}
                          name="accountType"
                        >
                          <Radio.Group className="d-flex" style={{ gap: "1rem" }}>
                            <Radio value={"S"}>Savings Account</Radio>
                            <Radio value={"NE"}>NRE</Radio>
                            <Radio value={"NO"}>NRO</Radio>
                          </Radio.Group>
                        </Form.Item>
                      </Col>
                      <Col className="d-flex justify-content-end align-items-center">
                        <button
                          style={{ width: "10rem", fontWeight: 700 }}
                          className="btn btn-sm btn-light text-primary"
                          type="submit"
                        >
                          Next
                        </button>
                      </Col>
                    </Row>
                  </TabPane>
                  <TabPane tab="No" key="2">
                    <Row>
                      <Col>
                        <label className="form-label">Bank Name</label>
                        <Form.Item
                          className="form-item"
                          name="bankName"
                          rules={[
                            {
                              required: true,
                              message: "Please select your Bank.",
                            },
                          ]}
                        >
                          <Select
                            showSearch
                            className="w-100"
                            labelInValue
                            placeholder="Select Bank"
                            onChange={onSelectBank}
                          >
                            {state.bankLists.map((bank, i) => {
                              return (
                                <Option key={i} value={bank.bankName}>
                                  <span bankCode={bank.bankCode} isSameBank={bank.isSameBank}>
                                    {bank.bankName}
                                  </span>
                                </Option>
                              );
                            })}
                          </Select>
                        </Form.Item>
                      </Col>
                      <Col>
                        <label>Bank Branch State</label>
                        <Form.Item
                          name="bankState"
                          rules={[
                            {
                              required: true,
                              message: "Please select your State.",
                            },
                          ]}
                        >
                          <Select showSearch placeholder="Select State">
                            {state.stateLists.map((state, i) => {
                              return (
                                <Option key={i} value={state.stateCode}>
                                  {state.state}
                                </Option>
                              );
                            })}
                          </Select>
                        </Form.Item>
                      </Col>
                    </Row>
                    <Row>
                      <Col>
                        <label className="form-label">City</label>
                        <Form.Item
                          className="form-item"
                          name="bankCity"
                          rules={[
                            {
                              required: true,
                              message: "Please select your City.",
                            },
                          ]}
                        >
                          <Select
                            className="w-100"
                            placeholder="Select City"
                            showSearch
                            onChange={onSetectCity}
                          >
                            {state.cityLists.map((city, i) => {
                              return (
                                <Option key={i} value={city.city}>
                                  {city.city}
                                </Option>
                              );
                            })}
                          </Select>
                        </Form.Item>
                      </Col>
                      <Col>
                        <label className="form-label">Branch</label>
                        <Form.Item
                          className="form-item"
                          name="branch"
                          rules={[
                            {
                              required: true,
                              message: "Please select your Branch.",
                            },
                          ]}
                        >
                          <Select
                            className="w-100"
                            placeholder="Select Branch"
                            showSearch
                            onChange={onSetectBranch}
                          >
                            {state.branchLists.map((branch, i) => {
                              return (
                                <Option key={i} value={JSON.stringify(branch)}>
                                  {branch.branchName}
                                </Option>
                              );
                            })}
                          </Select>
                        </Form.Item>
                      </Col>
                    </Row>
                    <Row>
                      <Col>
                        <label className="form-label">Account Number</label>
                        <Form.Item
                          className="form-item"
                          name="accountNo"
                          rules={[
                            {
                              required: true,
                              message: "Please input your Account Number.",
                            },
                            ...inputValidations.accountNumber(editRecipientData.recvCountry),
                          ]}
                        >
                          <Input.Password
                            placeholder="Enter your Account Number"
                            maxLength={12}
                            onPaste={(e) => {
                              e.preventDefault();
                              return false;
                            }}
                            onCopy={(e) => {
                              e.preventDefault();
                              return false;
                            }}
                            visibilityToggle={false}
                          />
                        </Form.Item>
                      </Col>
                      <Col>
                        <label>Account Type</label>
                        <Form.Item
                          rules={[
                            {
                              required: true,
                              message: "Please select your account type.",
                            },
                          ]}
                          name="accountType"
                        >
                          <Radio.Group
                            // onChange={onChangeAccountTypeHandler}
                            className="d-flex"
                            style={{ gap: "1rem" }}
                          >
                            <Radio value={"S"}>Savings Account</Radio>
                            <Radio value={"NE"}>NRE</Radio>
                            <Radio value={"NO"}>NRO</Radio>
                          </Radio.Group>
                        </Form.Item>
                      </Col>
                    </Row>
                    <Row>
                      <Col>
                        <label className="form-label">Confirm Account Number</label>
                        <Form.Item
                          className="form-item"
                          name="accConNum"
                          rules={[
                            {
                              required: true,
                              message: "Please input your Confirm Account Number.",
                            },
                            ...inputValidations.accountNumber(editRecipientData.recvCountry),
                            ({ getFieldValue }) => ({
                              validator(rule, value) {
                                if (!value || getFieldValue("accountNo") === value) {
                                  return Promise.resolve();
                                }
                                return Promise.reject(
                                  "The two account number that you entered do not match!",
                                );
                              },
                            }),
                          ]}
                        >
                          <Input
                            placeholder="Enter your Confirm Account Number"
                            maxLength={12}
                            onPaste={(e) => {
                              e.preventDefault();
                              return false;
                            }}
                            onCopy={(e) => {
                              e.preventDefault();
                              return false;
                            }}
                          />
                        </Form.Item>
                      </Col>
                      <Col className="d-flex justify-content-end align-items-center">
                        <button
                          style={{ width: "10rem", fontWeight: 700 }}
                          className="btn btn-sm btn-light text-primary"
                          type="submit"
                        >
                          Next
                        </button>
                      </Col>
                    </Row>
                  </TabPane>
                </Tabs>
                <Row></Row>
              </div>
            )}

            {state.recvCountryCode !== "IN" && (
              <BankComponent
                state={state}
                recvCountryCode={state.recvCountryCode}
                onSelectBank={onSelectBank}
                onChangeAccountNumberHandler={onChangeAccountNumberHandler}
              />
            )}
          </Form>
        )}
        {!activeStep && (
          <Form form={form} onFinish={onFinish2}>
            <Row>
              <Col>
                <Row>
                  <div className="Container">
                    <label>First Name</label>
                    <Form.Item
                      name="firstName"
                      rules={[
                        {
                          required: true,
                          message: "Please input your First Name.",
                        },
                        {
                          min: 2,
                          message: "First Name should be between 2 and 30 characters",
                        },
                        {
                          max: 30,
                          message: "First Name should be between 2 and 30 characters",
                        },
                      ]}
                    >
                      <Input placeholder="Enter your First Name" autoComplete="none" />
                    </Form.Item>
                  </div>
                </Row>
                <Row>
                  <div className="Container">
                    <label>Middle Name</label>
                    <Form.Item
                      name="middleName"
                      rules={[
                        {
                          min: 0,
                          message: "Middle Name should be between 0 and 30 characters",
                        },
                        {
                          max: 30,
                          message: "Middle Name should be between 0 and 30 characters",
                        },
                      ]}
                    >
                      <Input placeholder="Enter your Middle Name" autoComplete="none" />
                    </Form.Item>
                  </div>
                </Row>
                <Row>
                  <div className="Container">
                    <label>Last Name</label>
                    <Form.Item
                      name="lastName"
                      rules={[
                        {
                          required: true,
                          message: "Please input your Last Name.",
                        },
                        {
                          min: 2,
                          message: "Last Name should be between 2 and 30 characters",
                        },
                        {
                          max: 30,
                          message: "Last Name should be between 2 and 30 characters",
                        },
                      ]}
                    >
                      <Input placeholder="Enter your Last Name" autoComplete="none" />
                    </Form.Item>
                  </div>
                </Row>
                <Row>
                  <div className="Container">
                    <label>Nick Name</label>
                    <Form.Item
                      name="nickName"
                      rules={[
                        {
                          required: true,
                          message: "Please input your Nick Name.",
                        },
                        {
                          min: 2,
                          message: "Nick Name should be between 2 and 30 characters",
                        },
                        {
                          max: 30,
                          message: "Nick Name should be between 2 and 30 characters",
                        },
                        {
                          pattern: /^[a-zA-Z0-9]+$/,
                          message: "No Special Chars",
                        },
                      ]}
                    >
                      <Input placeholder="Enter your Nick Name" autoComplete="none" />
                    </Form.Item>
                  </div>
                </Row>
                <Row>
                  <div className="Container">
                    <label>Country</label>
                    <Form.Item
                      className="form-item"
                      name="country"
                      rules={[
                        {
                          required: true,
                          message: "Please select Country.",
                        },
                      ]}
                    >
                      <Select
                        disabled={true}
                        className="w-100"
                        placeholder="Select Country"
                      // onChange={handleReceivingCountry}
                      >
                        {state.receiverCountryLists.map((clist, i) => {
                          return (
                            <Option
                              key={i}
                              value={clist.countryName}
                            >{`${clist.countryName}`}</Option>
                          );
                        })}
                      </Select>
                    </Form.Item>
                  </div>
                </Row>
              </Col>
              <Col>
                <Row>
                  <div className="Container">
                    <label>Address</label>
                    <Form.Item
                      rules={[
                        {
                          required: true,
                          message: "Please Enter your Address",
                        },
                        {
                          min: 10,
                          message: "Address should be between 10 and 300 characters",
                        },
                        {
                          max: 300,
                          message: "Address should be between 10 and 300 characters",
                        },
                      ]}
                      name="address1"
                    >
                      <TextArea
                        onKeyDown={(e) => {
                          if (e.key === "Enter") {
                            e.preventDefault();
                            if (!e.shiftKey) {
                              e.preventDefault();
                            }
                          }
                        }}
                        style={{ resize: "none", height: "7.2rem" }}
                        autoComplete="none"
                      />
                    </Form.Item>
                  </div>
                </Row>
                <Row>
                  <div className="Container">
                    <label>
                      {state.recvCountryCode === "BD" || AuthReducer.recvCountryCode === "PH"
                        ? "Region"
                        : "State"}
                    </label>
                    <Form.Item
                      className="form-item"
                      name="state"
                      rules={[
                        {
                          required: true,
                          message: "Please select your State.",
                        },
                      ]}
                    >
                      {state.recvCountryCode === "IN" ? (
                        <Select
                          className="w-100"
                          placeholder="Select State"
                          onSelect={onSelectState}
                          showSearch
                          autoComplete="none"
                        >
                          {state.stateLists.map((state, i) => {
                            return (
                              <Option key={i} value={state.stateCode}>
                                {state.state}
                              </Option>
                            );
                          })}
                        </Select>
                      ) : (
                        <AutoComplete
                          showSearch
                          onSelect={onSelectState}
                          placeholder="Select State or Type State"
                          filterOption={(inputValue, option) =>
                            option.value.toUpperCase().indexOf(inputValue.toUpperCase()) !== -1
                          }
                        >
                          {state.stateLists.map((state, i) => {
                            return (
                              <Option key={i} value={state.stateCode}>
                                {state.state}
                              </Option>
                            );
                          })}
                        </AutoComplete>
                      )}
                    </Form.Item>
                  </div>
                </Row>
                <Row>
                  <div className="Container">
                    <label>City</label>
                    <Form.Item
                      className="form-item"
                      name="city"
                      rules={[
                        {
                          required: true,
                          message: "Please select your City.",
                        },
                      ]}
                    >
                      <AutoComplete
                        autoComplete="none"
                        className="w-100"
                        placeholder="Select City"
                        filterOption={(inputValue, option) =>
                          option.value.toUpperCase().indexOf(inputValue.toUpperCase()) !== -1
                        }
                      >
                        {state.stateCities.map((city, i) => {
                          return (
                            <Option key={i} value={city.city}>
                              {city.city}
                            </Option>
                          );
                        })}
                      </AutoComplete>
                    </Form.Item>
                  </div>
                </Row>
                <Row>
                  <div className="Container">
                    <label>Pincode</label>
                    <Form.Item
                      name="zipCode"
                      rules={[
                        {
                          required: true,
                          message: "Please input your Zipcode.",
                        },
                        // ...inputValidations.zipCode(editRecipientData.recvCountry),
                      ]}
                    >
                      <Input placeholder="Enter Zipcode" autoComplete="none" />
                    </Form.Item>
                  </div>
                </Row>
              </Col>
              <Col>
                <Row>
                  <div className="Container">
                    <label>Relationship</label>
                    <Form.Item
                      name="relationship"
                      rules={[
                        {
                          required: true,
                          message: "Please select Relationship.",
                        },
                      ]}
                    >
                      <Select
                        placeholder="Select Relationship"
                        showSearch
                        onChange={(value) => {
                          setState({
                            relationshipValue: value.relationshipValue,
                            relationshipDesc: value.relationshipDesc,
                          });
                        }}
                      >
                        {state.relationshipLists.map((list, i) => {
                          return (
                            <Option key={i} value={list.relationshipValue}>
                              {list.relationshipDesc}
                            </Option>
                          );
                        })}
                      </Select>
                    </Form.Item>
                  </div>
                </Row>

                <Row>
                  <div className="Container">
                    <label>Date of Birth</label>
                    <Form.Item
                      className="form-item"
                      name="dob"
                      rules={[
                        {
                          required: true,
                          message: "Please input valid DOB.",
                        },
                      ]}
                    >
                      <DatePicker
                        className="w-100"
                        defaultPickerValue={moment().subtract(18, "years")}
                        disabledDate={(d) =>
                          !d ||
                          d.isAfter(moment().subtract(18, "years")) ||
                          d.isSameOrBefore("1900-01-01")
                        }
                        onChange={(value, dateString) => {
                          value !== null ? setState({ dob: dateString }) : setState({ dob: "" });
                        }}
                      />
                    </Form.Item>
                  </div>
                </Row>

                <Row>
                  <div className="Container">
                    <label>Email ID</label>
                    <Form.Item
                      className="form-item"
                      name="emailId"
                      rules={[
                        {
                          type: "email",
                          message: "Please input valid Email ID.",
                        },
                      ]}
                    >
                      <Input autoComplete="none" />
                    </Form.Item>
                  </div>
                </Row>
                <Row>
                  <div className="Container">
                    <label>Mobile Number</label>
                    <div className="d-flex justify-content-between">
                      <Form.Item
                        name="mobileCountryCode"
                        rules={[
                          {
                            required: true,
                            message: "Please select your Country Code.",
                          },
                        ]}
                      >
                        <Select
                          autoComplete="none"
                          style={{ width: "5.5rem" }}
                          showSearch
                          placeholder="Select Phone Code"
                          dropdownMatchSelectWidth={200}
                          filterOption={(input, option) =>
                            (option?.children ?? "")
                              .toLowerCase()
                              .includes(input.toLowerCase())
                          }
                        >
                          {state.phoneCodes.map((phoneCode, i) => {
                            return (
                              <Option
                                key={i}
                                value={phoneCode.countryPhoneCode}
                              >{`(${phoneCode.countryPhoneCode}) ${phoneCode.countryName}`}</Option>
                            );
                          })}
                        </Select>
                      </Form.Item>
                      <Form.Item
                        name="mobileNo"
                        rules={[
                          {
                            required: true,
                            message: "Please input your Mobile Number.",
                          },
                          {
                            min: 10,
                            max: 10,
                            message: "Mobile number must be 10 digit.",
                          },
                          {
                            pattern: /^[0-9\b]+$/,
                            message: "Only Numbers allowed",
                          },
                          // { pattern: new RegExp("^[6]{1}[0-9]*$"), message: "Mobile number must start with 6" }
                        ]}
                      >
                        <Input
                          style={{ width: "11.5rem" }}
                          placeholder="123456789"
                          maxLength={10}
                          autoComplete="none"
                        />
                      </Form.Item>
                    </div>
                  </div>
                </Row>
                <Row>
                  <div className="Container">
                    <label>Phone Number</label>
                    <Form.Item
                      name="phoneNo"
                      rules={[
                        {
                          min: 0,
                          max: 14,
                          message: "Phone number must be 10 digit.",
                        },
                        {
                          pattern: /^[0-9\b]+$/,
                          message: "Only Numbers allowed",
                        },
                      ]}
                    >
                      <Input placeholder="123456789" maxLength={10} autoComplete="none" />
                    </Form.Item>
                  </div>
                </Row>
              </Col>
            </Row>
            <div className="d-flex justify-content-between">
              <button
                style={{ width: "10rem", fontWeight: 600, color: "white" }}
                className="Back-Button"
                onClick={() => setActiveStep(!activeStep)}
              >
                Back
              </button>
              <button
                style={{ fontWeight: 700 }}
                className="btn btn-sm btn-light text-primary"
                type="submit"
              >
                Confirm Recipient
              </button>
            </div>
          </Form>
        )}
      </Spinner>
    </div>
  );
}
