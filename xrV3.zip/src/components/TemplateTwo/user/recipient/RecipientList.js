import React, { useState, useEffect, useReducer, Fragment } from "react";
import { Table, Modal, Input, Select } from "antd";
import { Row, Col } from "react-bootstrap";
import SvgIcon from "@mui/material/SvgIcon";
import { ReactComponent as MoreSvg } from "../../../../assets/images/XR/more.svg";
import { ReactComponent as EditSvg } from "../../../../assets/images/XR/edit.svg";
import { ReactComponent as DeleteSvg } from "../../../../assets/images/XR/delete.svg";
// import { DeleteFilled, EditFilled, InfoCircleFilled } from "@ant-design/icons";
import { ReceiverAPI } from "../../../../apis/ReceiverAPI";
import Swal from "sweetalert2";
import { useSelector } from "react-redux";
import RecipientInfo from "./RecipientInfo";
import useHttp from "../../../../hooks/useHttp";
import AddRecipient from "./AddRecipient";
import EditRecipient from "./EditRecipient";
import SubHeader from "../../layout/SubHeader";
import Spinner from "../../../../reusable/Spinner";
import { COUNTRY } from "../../../../services/Country";

const { Option } = Select;

function RecipientList(props) {
  const AuthReducer = useSelector((state) => state);
  const ConfigReducer = useSelector((state) => state);
  const recipientListConfig = ConfigReducer.groupIdSettings.recipientModule.recipientList;
  const [loading, setLoader] = useState(false);
  const [spinner, setSpinner] = useState(false);
  const [editRecipientModal, setEditRecipientModal] = useState(false);
  const [addRecipentModal, setAddRecipentModal] = useState(false);
  const [editRecipientData, setEditRecipientData] = useState();
  const [recipientListTable, setRecipientListTable] = useState(false);
  const [contentRender, setContentRender] = useState(false);
  const [state, setState] = useReducer((state, newState) => ({ ...state, ...newState }), {
    receiverLists: [],
    filteredRecieverList: [],
    clientId: AuthReducer.clientId,
    groupId: AuthReducer.groupId,
    sessionId: AuthReducer.sessionId,
    userID: AuthReducer.userID,
    isModalVisible: false,
    modalRecipientsDetails: {},
    searchButtonStatus: true,
    searchInputValue: "",
    accountTypeFilter: "",
    stateFilter: "",
    filteredStateList: [],
    countryFilter: "",
    filteredCountryList: [],
  });

  const hookGetReceiverLists = useHttp(ReceiverAPI.receiverLists);
  const hookViewRecipientsDetails = useHttp(ReceiverAPI.viewRecipientsDetails);
  const hookDeleteReceiver = useHttp(ReceiverAPI.deleteReceiver);

  useEffect(() => {
    if (props.appState.isLoggedIn) {
      getReceiverLists();
    }
  }, []);
  useEffect(() => {
    receiverListFilter();
  }, [state.accountTypeFilter, state.stateFilter, state.countryFilter]);

  const accountType = (value) => {
    if (value == "S") {
      return "Savings Account";
    } else if (value == "NE") {
      return "NRE Account";
    } else {
      return "NRO Account";
    }
  };
  const afterClose = () => {
    setState({ modalRecipientsDetails: {} });
  };
  const getReceiverLists = () => {
    const payload = {
      requestType: "GETRECVLIST",
      userId: state.userID,
      favouriteFlag: "",
      startIndex: "0",
      recordsPerRequest: "",
      search: "",
      statusFlag: "",
    };

    setLoader(true);
    hookGetReceiverLists.sendRequest(payload, function (data) {
      if (data.status == "S") {
        let verifiedStatus = "";
        setRecipientListTable(true);
        let resData = [];
        let stateList = [];
        let countryList = [];
        if (data.responseData[0].status == "V") {
          verifiedStatus = "Verified";
        } else {
          verifiedStatus = data.status;
        }
        data.responseData.forEach((detail, i) => {
          let data = {
            key: i,
            name: `${detail.firstName} ${detail.lastName}`,
            bankName: `${detail.bankName}`,
            accountNo: `${detail.accountNo}`,
            status: `${verifiedStatus}`,
            recordToken: `${detail.recordToken}`,
            nickName: `${detail.nickName}`,
            bankBranch: `${detail.bankBranch}`,
            city: `${detail.city}`,
            country: COUNTRY[detail.countryCode].countryName,
            // country:`${detail.countryCode}`,
            state: `${detail.state}`,
            accountType: accountType(detail.accountType),
          };

          resData.push(data);
          stateList.push(detail.state);
          countryList.push(detail.country);
        });
        let newFilteredStateList = [...new Set(stateList)];
        let newFilteredCountryList = [...new Set(countryList)];
        setState({
          filteredStateList: newFilteredStateList,
          filteredCountryList: newFilteredCountryList,
          receiverLists: resData,
          filteredRecieverList: resData,
        });
        setContentRender(true);
      } else {
        setRecipientListTable(false);
        setContentRender(true);
      }
      setLoader(false);
    });
  };
  const onKeyPressEnterSearch = (e) => {
    if (e.code == "Enter") {
      receiverListFilter();
    }
  };

  const receiverListFilter = () => {
    let filteredRecieverList = state.receiverLists.filter((i) => {
      return i.name.toLowerCase().search(state.searchInputValue.toLowerCase()) !== -1;
    });
    let reFilteredRecieverList = filteredRecieverList.filter((i) => {
      return i.accountType.search(state.accountTypeFilter) !== -1;
    });
    let reReFilteredRecieverList = reFilteredRecieverList.filter((i) => {
      return i.state.search(state.stateFilter) !== -1;
    });

    let _reReFilteredRecieverList = reReFilteredRecieverList.filter((i) => {
      return i.country.search(state.countryFilter) !== -1;
    });
    setState({ filteredRecieverList: _reReFilteredRecieverList });
  };

  const viewDetailsHandlerClick = (row) => {
    setState({ isModalVisible: true });
    const payload = {
      requestType: "RECEIVERINFO",
      userId: state.userID,
      nickName: row.nickName,
      recordToken: row.recordToken,
    };

    setSpinner(true);
    hookViewRecipientsDetails.sendRequest(payload, function (data) {
      if (data.status === "S") {
        setSpinner(false);
        setState({
          modalRecipientsDetails: data,
        });
      }
    });
  };

  const deleteReceiverHandler = async (row) => {
    Swal.fire({
      text: "Are you sure you want to delete this receiver?",
      showCancelButton: true,
      confirmButtonText: "Confirm",
      denyButtonText: `Cancel`,
      confirmButtonColor: "#FFFFFF",
      color: "#FFFFFF",
      background: "#003153",
      customClass: {
        confirmButton: "btn btn-primary text-white ",
        cancelButton: "btn btn-secondary",
      },
    }).then((result) => {
      /* Read more about isConfirmed, isDenied below */
      if (result.isConfirmed) {
        const payload = {
          requestType: "GETRECVLIST",
          userId: state.userID,
          nickName: row.nickName,
          recordToken: row.recordToken,
        };

        setLoader(true);
        hookDeleteReceiver.sendRequest(payload, function (data) {
          setLoader(false);
          if (data.status == "S") {
            getReceiverLists();
          }
        });
      } else if (result.isDenied) {
        Swal.fire("Changes are not saved", "", "info");
      }
    });
  };

  const editReceiverHandler = (row) => {
    const payload = {
      requestType: "RECEIVERINFO",
      userId: state.userID,
      nickName: row.nickName,
      recordToken: row.recordToken,
    };

    setLoader(true);
    hookViewRecipientsDetails.sendRequest(payload, function (data) {
      if (data.status === "S") {
        setEditRecipientData(data);
        setEditRecipientModal(true);
        setLoader(false);
      }
    });
  };

  return (
    <Fragment>
      <Modal
        className="primary"
        centered
        visible={addRecipentModal}
        onCancel={() => setAddRecipentModal(false)}
        width={1000}
        footer={null}
      >
        <AddRecipient
          getReceiverLists={getReceiverLists}
          setAddRecipentModal={setAddRecipentModal}
        />
      </Modal>
      <Modal
        className="primary"
        centered
        visible={editRecipientModal}
        onCancel={() => setEditRecipientModal(false)}
        width={1000}
        footer={null}
      >
        <EditRecipient
          appState={props.appState}
          getReceiverLists={getReceiverLists}
          editRecipientData={editRecipientData}
          setEditRecipientModal={setEditRecipientModal}
        />
      </Modal>

      <SubHeader title="My Receivers" />
      <Spinner spinning={loading}>
        <div className="template2__main">
          <div className="container py-5">
            <div className="RecipientListContainer">
              {contentRender && recipientListTable && (
                <>
                  <Row className="d-flex">
                    <Col md={6}>
                      <Input
                        placeholder="Search with Receiver Name"
                        onKeyDown={onKeyPressEnterSearch}
                        onChange={(e) => {
                          setState({ searchInputValue: e.target.value });
                          // e.target.value == ""
                          //   ? setState({ searchButtonStatus: true })
                          //   : setState({ searchButtonStatus: false });
                        }}
                        style={{
                          marginBottom: "1rem",
                          height: "2.5rem",
                          backgroundColor: "#F0FFF0",
                        }}
                      ></Input>
                    </Col>
                    <Col md={6} className="d-flex">
                      <button
                        // disabled={state.searchButtonStatus}
                        style={{
                          height: "2.5rem",
                          marginBottom: "1rem",
                          width: "10rem",
                        }}
                        className="btn btn-sm btn-info m-w-100"
                        onClick={() => {
                          receiverListFilter();
                        }}
                      >
                        Search
                      </button>
                    </Col>
                  </Row>
                  <Row className="mb-3">
                    <Col
                      style={{ gap: "0.5rem", flexWrap: "wrap" }}
                      className="d-flex align-items-center"
                    >
                      <span className="text-info fs-15 fw-800 m-w-100">Filter</span>
                      <Select
                        className="m-w-100"
                        allowClear
                        showSearch
                        onChange={(value) => setState({ accountTypeFilter: value })}
                        placeholder="Select Account Type"
                      >
                        <Option value="Savings Account">Savings Account</Option>
                        <Option value="NRE Account">NRE Account</Option>
                        <Option value="NRO Account">NRO Account</Option>
                      </Select>
                      <Select
                        className="m-w-100"
                        allowClear
                        showSearch
                        onChange={(value) => setState({ stateFilter: value })}
                        placeholder="Select State"
                      >
                        {state.filteredStateList.map((state, i) => {
                          return (
                            <Option key={i} value={state}>
                              {state}
                            </Option>
                          );
                        })}
                      </Select>

                      <Select
                        className="m-w-100"
                        allowClear
                        showSearch
                        onChange={(value) => setState({ countryFilter: value })}
                        placeholder="Select Country"
                      >
                        {state.filteredCountryList.map((item, i) => {
                          return (
                            <Option key={i} value={item}>
                              {item}
                            </Option>
                          );
                        })}
                      </Select>
                    </Col>
                  </Row>
                </>
              )}
              {contentRender && recipientListTable && (
                <div className="RecpListTableContainer">
                  <Row>
                    <div className="RecpListHeaderContainer">
                      <div className="RecpListHeaderInnerContainer">
                        <h5>All Receivers</h5>
                      </div>
                    </div>
                  </Row>
                  <Table
                    columns={[
                      {
                        title: "Name",
                        dataIndex: "name",
                        className: "w-auto",
                      },
                      {
                        title: "Account No",
                        dataIndex: "accountNo",
                      },
                      {
                        title: "Account Type",
                        dataIndex: "accountType",
                      },
                      {
                        title: "State",
                        dataIndex: "state",
                      },
                      {
                        title: "Country",
                        dataIndex: "country",
                      },
                      {
                        title: "",
                        dataIndex: "",
                        key: "y",
                        className: "border-bottom-0 tw-30 text-end",
                        render: (text, record, index) => {
                          return (
                            <div className="d-flex justify-content-end align-items-center">
                              <span
                                style={{ cursor: "pointer" }}
                                className="px-2 text-info-dark d-flex align-items-center"
                                i={index}
                                onClick={() => viewDetailsHandlerClick(text)}
                              >
                                <SvgIcon>
                                  <MoreSvg className="me-1" />
                                </SvgIcon>
                                <p
                                  style={{
                                    color: "#0A7E8C",
                                    fontSize: "12px",
                                    fontWeight: "800",
                                  }}
                                  className="m-0"
                                >
                                  More
                                </p>
                              </span>
                              <span className="vl"></span>
                              <span
                                style={{ cursor: "pointer" }}
                                className="px-2 text-info-dark d-flex align-items-center"
                                i={index}
                                onClick={() => editReceiverHandler(text)}
                              >
                                <SvgIcon>
                                  <EditSvg className="me-1" />
                                </SvgIcon>
                                <p
                                  style={{
                                    color: "#0A7E8C",
                                    fontSize: "12px",
                                    fontWeight: "800",
                                  }}
                                  className="m-0"
                                >
                                  Edit
                                </p>
                              </span>
                              <span className="vl"></span>
                              <span
                                style={{ cursor: "pointer" }}
                                className="px-2 text-info-dark d-flex align-items-center"
                                i={index}
                                onClick={() => deleteReceiverHandler(text)}
                              >
                                <SvgIcon>
                                  <DeleteSvg className="me-1" />
                                </SvgIcon>
                                <p
                                  style={{
                                    color: "#0A7E8C",
                                    fontSize: "12px",
                                    fontWeight: "800",
                                  }}
                                  className="m-0"
                                >
                                  Delete
                                </p>
                              </span>
                            </div>
                          );
                        },
                      },
                    ]}
                    dataSource={state.filteredRecieverList}
                    pagination={false}
                  />
                </div>
              )}
              {contentRender && !recipientListTable && (
                <div className="d-flex justify-content-center mt-5">
                  <h3 className="text-white">No Recipients available</h3>
                </div>
              )}
              <div className="d-flex justify-content-end">
                <button
                  style={{
                    backgroundColor: "white",
                    fontWeight: 700,
                    width: "9rem",
                    height: "2.5rem",
                  }}
                  className="btn btn-secondary btn-sm mt-5"
                  onClick={() => setAddRecipentModal(true)}
                >
                  Add Receiver
                </button>
              </div>
            </div>
          </div>
        </div>
        <RecipientInfo
          afterClose={afterClose}
          state={state}
          spinner={spinner}
          setState={setState}
        />
      </Spinner>
    </Fragment>
  );
}

export default RecipientList;
