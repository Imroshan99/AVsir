/* eslint-disable jsx-a11y/alt-text */
import { Button, Checkbox, Form, Input, notification, Radio, Select, Space } from "antd";
import { Col, Row } from "react-bootstrap";
import { useDispatch, useSelector } from "react-redux";
import { COUNTRY } from "../../../../services/Country";
import SubHeader from "../../layout/SubHeader";
import questionMark from "../../../../assets/images/svg/questionMark.svg";
import { Link } from "react-router-dom";
import Spinner from "../../../../reusable/Spinner";
import { useEffect, useReducer, useState } from "react";
import useHttp from "../../../../hooks/useHttp";
import { GuestAPI } from "../../../../apis/GuestAPI";
import { TransactionAPI } from "../../../../apis/TransactionAPI";
import { ProfileAPI } from "../../../../apis/ProfileAPI";
import TransactionSuccess from "../sendmoney/Stepper/TransactionSuccess";

export default function RequestTransactionConfirm(props) {
  const [loader, setLoader] = useState(0);
  const [bookingPage, setBookingPage] = useState(false);
  const dispatch = useDispatch();
  const { Option } = Select;
  const [form] = Form.useForm();
  const reqRecpDetails = props?.state?.reqRecpDetails;
  const AuthReducer = useSelector((state) => state);
  const [state, setState] = useReducer((state, newState) => ({ ...state, ...newState }), {
    paymentOptionsList: [],
    bankAccountLists: [],
    deliveryOptionsList: [],
    purposeLists: [],
    refDiscInp: "",
    voucherInp: "",
    promoCode: "",
    referralBalance: "",
    exchangeRateData: {},
    purposeOfSending: "",
    purposeId: "",
    senderAccId: "",
    deliveryOption: "",
    promoType: "",
    sendModeCode: AuthReducer.groupIdSettings.default.sendModeCode,
    programCode: AuthReducer.groupIdSettings.default.programCode,
    promoValueWithDesc: "",

    toggleCongoText: false,
    applyCouponType: '',
  });

  const hookGetPaymentOption = useHttp(GuestAPI.paymentOption);
  const hookGetBankAccountLists = useHttp(TransactionAPI.getBankAccountLists);
  const hookGetDeliveryOptions = useHttp(GuestAPI.deliveryOptions);
  const hookGetPurposeLists = useHttp(TransactionAPI.purposeLists);
  const hookGetComputeExchangeRates = useHttp(TransactionAPI.computeExchangeRates);
  const hookReferralBalance = useHttp(GuestAPI.referralBalance);
  const hookBookTransaction = useHttp(TransactionAPI.bookTransaction);
  const hookNotificationList = useHttp(ProfileAPI.notificationLists);
  const hookTransactionReceiptDetails = useHttp(TransactionAPI.transactionReceiptDetails);
  const hookUserRedeemCheck = useHttp(TransactionAPI.redeemCheck);
  const hookApplyPromoLists = useHttp(TransactionAPI.promoLists);

  useEffect(() => {
    getSendingTransferOptionsList();
    getBankAccountLists();
    getDeliveryOptions();
    getPurposeLists();
    getReferralBalance();
  }, []);
  useEffect(() => {
    getComputeExchangeRate("SENDMONEY");
  }, [state.promoCode]);

  const handleTermsCondition = () => {
    getComputeExchangeRate("TXNREVIEW");
  };
  const getNotificationList = () => {
    let payload = {
      requestType: "NOTIFICATIONLISTS",
      userId: AuthReducer.userID,
    };
    setLoader((prevState) => prevState + 1);
    hookNotificationList.sendRequest(payload, (data) => {
      setLoader((prevState) => prevState - 1);
      if (data.status === "S") {
        dispatch({
          type: "SET_NOTIFICATION_COUNT",
          payload: data.newNotification,
        });
      }
    });
  };

  const transactionReceiptDetails = (txnRefno) => {
    const payload = {
      requestType: "TXNDETAILS",
      rgtn: "",
      txnRefNo: txnRefno,
      userId: AuthReducer.userID,
    };
    setLoader((prevState) => prevState + 1);
    hookTransactionReceiptDetails.sendRequest(payload, function (data) {
      setLoader((prevState) => prevState - 1);
      if (data.status === "S") {
        setState({
          txnRefNumber: data.txnRefNumber,
          txnAccountName: data.receiverName,
          txnAccountNumber: data.recvAccNumber,
          txnAccountAddress: data.recvAddress,
          txnSendAmount: data.sendAmount,
        });
        setBookingPage(true);
      } else {
        notification.error({ message: data.errorMessage });
      }
    });
  };

  const bookTransaction = () => {
    const payload = {
      requestType: "BOOKTRANSACTION",
      amount: reqRecpDetails.amount,
      // amount: state.recvAmount,
      corrBankId: "ICIC",
      endDate: "",
      enteredAmtCurrency: AuthReducer.sendCurrencyCode,
      exRateToken: state.exchangeRateData.exRateToken,
      exchangeRate: "",
      frequency: "",
      methodType: "NOT",
      noOfTransactions: "0",
      outwardFlag: "N",
      paymentMode1: "",
      paymentMode2: "",
      personalMessage: "",
      personalMsg: "",
      premiumCharge: "0.0",
      programCode: state.programCode,
      promoCode: state.promoCode,
      rateBlockFlag: "N",
      recvCountryCode: reqRecpDetails.countryCode,
      recvCountryCurrency: COUNTRY[reqRecpDetails?.countryCode]?.countryCurrency,
      recvCurrencyCode: COUNTRY[reqRecpDetails?.countryCode]?.countryCurrency,
      recvModeCode: state.deliveryOption ? state.deliveryOption : "DC",
      recvNickName: reqRecpDetails.nickName,
      // achAccId: state.achAccId,
      sendCountryCurrency: AuthReducer.sendCurrencyCode,
      sendCountryCode: AuthReducer.sendCountryCode,
      sendCurrencyCode: AuthReducer.sendCurrencyCode,
      // sendModeCode: "ACH",
      sendModeCode: state.sendModeCode,
      sendAccId: state.senderAccId,
      // sendAccId: state.sendAccId,
      sourceOfFunds: "",
      startDate: "",
      transferType: "O",
      twofa: "N",
      txnPurposeDesc: state.purposeOfSending,
      txnPurposeId: state.purposeId,
      txnSubPurposeDesc: "",
      txnSubPurposeId: "",
      txnSubSurposeId: "",
      txnType: "REQUESTMONEY",
      userId: AuthReducer.userID,
    };

    setLoader((prevState) => prevState + 1);
    hookBookTransaction.sendRequest(payload, function (data) {
      setLoader((prevState) => prevState - 1);
      if (data.status === "S") {
        transactionReceiptDetails(data.txnRefno);
        getNotificationList();
        // Branch code start
        var custom_data = {
          Custom_Event_Property_Key1: "Custom_Event_Property_val1",
          Custom_Event_Property_Key2: "Custom_Event_Property_val2",
        };
        // eslint-disable-next-line no-undef
        branch.logEvent("transaction_booked", custom_data, function (err) {
          console.log("LogEventError", err);
        });
        // Brand code end
      } else {
        notification.error({ message: data.errorMessage });
      }
    });
  };

  const getReferralBalance = () => {
    const payload = {
      requestType: "REFEARNREDEEM",
      userId: AuthReducer.userID,
    };
    setLoader((prevState) => prevState + 1);
    hookReferralBalance.sendRequest(payload, function (data) {
      setLoader((prevState) => prevState - 1);
      if (data.status === "S") {
        setState({ referralBalance: data });
      }
    });
  };

  const getComputeExchangeRate = (pageName) => {
    const payload = {
      requestType: "EXCHANGERATE",
      userId: AuthReducer.userID,
      sendCountryCode: AuthReducer.sendCountryCode,
      sendCurrencyCode: AuthReducer.sendCurrencyCode,
      recvCountryCode: reqRecpDetails.countryCode,
      recvCurrencyCode: COUNTRY[reqRecpDetails?.countryCode]?.countryCurrency,
      recvModeCode: state.deliveryOption ? state.deliveryOption : "DC",
      recvNickName: reqRecpDetails.nickName,
      promoCode: state.promoCode,
      amount: reqRecpDetails.sendAmount, //dynamic amount
      sendModeCode: state.sendModeCode,
      programCode: state.programCode,
      enteredAmtCurrency: AuthReducer.sendCurrencyCode,
      paymentMode1: "",
      paymentMode2: "",
      pageName: pageName,
      txnType: "REQUESTMONEY",
    };
    setLoader((prevState) => prevState + 1);
    hookGetComputeExchangeRates.sendRequest(payload, function (data) {
      setLoader((prevState) => prevState - 1);
      if (data.status === "S") {
        setState({ exchangeRateData: data, promoValueWithDesc: data.promoValueWithDesc });
      } else {
        notification.error({ message: data.errorMessage });
      }
    });
  };

  const getPurposeLists = () => {
    const payload = {
      requestType: "PurposeList",
      keyword: "",
      nickName: reqRecpDetails?.nickName,
      recvCountryCode: reqRecpDetails?.countryCode,
      userId: AuthReducer.userID,
    };

    setLoader((prevState) => prevState + 1);
    hookGetPurposeLists.sendRequest(payload, function (data) {
      setLoader((prevState) => prevState - 1);
      if (data.status === "S") {
        setState({ purposeLists: data.responseData });
      }
    });
  };

  const getDeliveryOptions = () => {
    const payload = {
      requestType: "RECVMODE",
      countryCode: reqRecpDetails.countryCode,
    };
    setLoader((prevState) => prevState + 1);
    hookGetDeliveryOptions.sendRequest(payload, function (data) {
      setLoader((prevState) => prevState - 1);
      if (data.status == "S") {
        setState({ deliveryOptionsList: data.responseData });
      }
    });
  };

  const getSendingTransferOptionsList = () => {
    const payload = {
      requestType: "PAYMENTOPTION",
      amount: "1000",
      sendCountryCode: AuthReducer.sendCountryCode,
      sendCountryCurrency: AuthReducer.sendCurrencyCode,
      recvCountryCode: AuthReducer.recvCountryCode,
      recvCountryCurrency: AuthReducer.recvCurrencyCode,
    };

    setLoader((prevState) => prevState + 1);
    hookGetPaymentOption.sendRequest(payload, function (data) {
      setLoader((prevState) => prevState - 1);
      if (data.status === "S") {
        setState({ paymentOptionsList: data.responseData });
      }
    });
  };

  const getBankAccountLists = () => {
    const payload = {
      requestType: "SENDERACCOUNTLIST",
      countryCode: AuthReducer.sendCountryCode,
      countryId: undefined,
      favouriteFlag: "1",
      recordsPerRequest: "15",
      startIndex: "0",
      userId: AuthReducer.userID,
    };
    setLoader((prevState) => prevState + 1);
    hookGetBankAccountLists.sendRequest(payload, function (data) {
      setLoader((prevState) => prevState - 1);
      if (data.status === "S") {
        setState({ bankAccountLists: data.responseData });
      }
    });
  };

  const userRedeemCheck = () => {
    setState({
      promoCode: "",
      promoType: "",
    });
    let payload = {
      requestType: "USERREDEEMCHECK",
      recvModeCode: state.deliveryOption ? state.deliveryOption : "DC",
      sendCountryCode: AuthReducer.sendCountryCode,
      sendCurrencyCode: AuthReducer.sendCurrencyCode,
      txnAmount: reqRecpDetails.sendAmount,
      redeemValue: state.refDiscInp,
      userId: AuthReducer.userID,
      recvCountryCode: reqRecpDetails.countryCode,
      recvCurrencyCode: COUNTRY[reqRecpDetails?.countryCode]?.countryCurrency,
      // recvCountryCode: reqRecpDetails.countryCode,
      // recvCurrencyCode: COUNTRY[reqRecpDetails.countryCode].countryCurrency,
    };
    setLoader((prevState) => prevState + 1);
    hookUserRedeemCheck.sendRequest(payload, (res) => {
      setLoader((prevState) => prevState - 1);
      if (res.status === "S") {
        const payloadPromoList = {
          requestType: "PROMOLISTS",
          programCode: state.programCode,
          promoAmount: reqRecpDetails.sendAmount,
          promoCode: `RAF-${AuthReducer.sendCountryCode}-${AuthReducer.sendCurrencyCode}-${
            reqRecpDetails.countryCode
          }-${COUNTRY[reqRecpDetails?.countryCode]?.countryCurrency}-${state.refDiscInp}`,
          recvCountryCode: reqRecpDetails.countryCode,
          recvCurrencyCode: COUNTRY[reqRecpDetails?.countryCode]?.countryCurrency,
          // promoCode: promoCode,
          recvModeCode: state.deliveryOption ? state.deliveryOption : "DC",
          sendCountryCode: AuthReducer.sendCountryCode,
          sendCurrencyCode: AuthReducer.sendCurrencyCode,
          sendModeCode: state.sendModeCode,
          userId: AuthReducer.userID,
          // promoCode: `RAF-${AuthReducer.sendCountryCode}-${AuthReducer.sendCurrencyCode}-${
          //   reqRecpDetails.countryCode
          // }-${COUNTRY[reqRecpDetails.countryCode].countryCurrency}-${state.refDiscInp}`,
          // recvCountryCode: reqRecpDetails.countryCode,
          // recvCurrencyCode: COUNTRY[reqRecpDetails.countryCode].countryCurrency,
        };
        setLoader((prevState) => prevState + 1);
        hookApplyPromoLists.sendRequest(payloadPromoList, function (data) {
          setLoader((prevState) => prevState - 1);
          form.setFieldsValue({ readTermsConditions: false });
          if (data.status === "S") {
            const { promoType } = data.responseData[0];
            setState({
              promoCode: data.responseData[0].promoCode,
              promoType: promoType,
              applyCouponType : 'RAF_CODE'
            });
          } else {
            notification.error({ message: data.errorMessage });
          }
        });
      } else {
        notification.error({ message: res.errorMessage });

        let errors = [];
        res.data.errorList.forEach((error, i) => {
          let errorData = {
            name: error.field,
            errors: [error.error],
          };
          errors.push(errorData);
        });

        if (errors.length > 0) form.setFields(errors);
      }
    });
  };

  const applyPromoCode = () => {
    
    setState({
      promoCode: "",
      promoType: "",
      
    });
    const payload = {
      requestType: "PROMOLISTS",
      programCode: state.programCode,
      promoAmount: reqRecpDetails.sendAmount,
      promoCode: state.voucherInp,
      recvCountryCode: reqRecpDetails.countryCode,
      recvCurrencyCode: COUNTRY[reqRecpDetails?.countryCode]?.countryCurrency,
      recvModeCode: state.deliveryOption ? state.deliveryOption : "DC",
      sendCountryCode: AuthReducer.sendCountryCode,
      sendCurrencyCode: AuthReducer.sendCurrencyCode,
      sendModeCode: state.sendModeCode,
      userId: AuthReducer.userID,
      // recvCountryCode: reqRecpDetails.countryCode,
      // recvCurrencyCode: COUNTRY[reqRecpDetails.countryCode].countryCurrency,
    };
    setLoader((prevState) => prevState + 1);
    hookApplyPromoLists.sendRequest(payload, function (data) {
      setLoader((prevState) => prevState - 1);
      form.setFieldsValue({ readTermsConditions: false });
      if (data.status === "S") {
        const { promoType } = data.responseData[0];
        setState({
          promoCode: state.voucherInp,
          promoType: promoType,
          applyCouponType : 'PROMO_CODE'
        });
      } else {
        notification.error({ message: data.errorMessage });
      }
    });
  };

  const handlePurposeOfSending = (data) => {
    let purpose = JSON.parse(data);
    setState({
      purposeOfSending: purpose.displayName,
      purposeId: purpose.purposeId,
    });
  };
  const handleSenderAccount = (data) => {
    setState({
      senderAccId: data,
    });
  };
  const handleDeliveryOptions = (data) => {
    setState({
      deliveryOption: data,
    });
  };
  const handleChangeRadio = (data) => {
    setState({
      programCode: data.target.value,
      // paymentOption: data.target.value,
      // selectedPaymentMethod: data.target.programName,
    });
  };

  return (
    <>
      <SubHeader
        multiTitle={!bookingPage}
        isTransactionBook={bookingPage}
        txnRefNumber={state.txnRefNumber}
        title2={`Sending Money to ${reqRecpDetails?.fullName}`}
        title1="Transaction Confirmation"
      />

      {!bookingPage && (
        <Form form={form} onFinish={bookTransaction}>
          <Spinner spinning={loader !== 0}>
            <div className="template2__main">
              <div className="Request-Money-Band">
                <div className="container sendmoney__page">
                  <Row>
                    <Col className="d-flex gap-2">
                      <h4 className="text-white fw-500">Request Amount:</h4>
                      <h4 className="text-info fw-500">
                        {COUNTRY[AuthReducer.sendCountryCode]?.currencySymbol}{" "}
                        {Number(reqRecpDetails?.amount).toLocaleString()}
                      </h4>
                    </Col>
                  </Row>
                  <Row>
                    <Col className="d-flex gap-2">
                      <h4 className="text-white fw-500">Bank Name:</h4>
                      <h4 className="text-white fw-500">{reqRecpDetails?.bankName}</h4>
                    </Col>
                  </Row>
                </div>
              </div>
              <div className="container py-5 RequestMoneyContainer">
                <Row>
                  <Col md={5}>
                    <Row>
                      <label className="inp-label">Payment Amount</label>
                      <Col md={4} className="mb-3 mb-md-0">
                        <Select
                          placeholder="Select Currency"
                          value={AuthReducer.sendCurrencyCode}
                          disabled
                        >
                          <Select.Option value={AuthReducer.sendCurrencyCode}>
                            {AuthReducer.sendCurrencyCode}(
                            {COUNTRY[AuthReducer.sendCountryCode].countryName})
                          </Select.Option>
                        </Select>
                      </Col>
                      <Col md={8}>
                        <Input
                          className="inp"
                          disabled
                          value={`${COUNTRY[AuthReducer.sendCountryCode].currencySymbol} ${Number(
                            reqRecpDetails?.sendAmount,
                          ).toLocaleString()}`}
                        />
                      </Col>
                    </Row>
                    <Row>
                      <label className="inp-label mt-3">Referral Discount</label>
                      <Col md={9} className="mb-3 mb-md-0">
                        <Form.Item
                          className="apply_coupon_box mb-1"
                          style={{ display: "flex" }}
                          name="redeemValue"
                          rules={[
                            {
                              required: false,
                              message: "Please input your referral discount",
                            },
                            {
                              pattern: /^[0-9\b]+$/,
                              message: "Only Numbers allowed",
                            },
                          ]}
                        >
                          <Input
                            className="inp"
                            placeholder="Enter Referral Code"
                            onChange={(e) => setState({ refDiscInp: e.target.value })}
                          />
                        </Form.Item>
                      </Col>
                      <Col md={3}>
                        <Button
                          className="btn-3"
                          onClick={userRedeemCheck}
                          disabled={state.refDiscInp.length === 0}
                        >
                          Apply
                        </Button>
                      </Col>
                    </Row>
                    <div>
                      {state.applyCouponType === 'RAF_CODE' && state.promoValueWithDesc !== "" && (
                        <p className="text-info">{state.promoValueWithDesc}</p>
                      )}
                    </div>
                    <div className="d-flex justify-content-between mt-3">
                      <div className="text-white fs-14">Usable Amount</div>
                      <div className="d-flex gap-1 text-info fs-14">
                        {AuthReducer.sendCurrencyCode} {state.referralBalance.totalCreditApplicable}
                        <img src={questionMark} />
                      </div>
                    </div>
                    <div className="d-flex justify-content-between mb-3">
                      <div className="text-white fs-14">Total Amount Available</div>
                      <div className="d-flex gap-1 text-info fs-14">
                        {AuthReducer.sendCurrencyCode} {state.referralBalance.redeemBalence}
                        <img src={questionMark} style={{ visibility: "hidden" }} />
                      </div>
                    </div>
                    <Row>
                      <label className="inp-label">Coupon Code / Gift Voucher</label>
                      <Col md={9}>
                        <Form.Item
                          className="apply_coupon_box"
                          style={{ display: "flex" }}
                          name="couponCode"
                          rules={[
                            {
                              required: false,
                              message: "Please input your coupon code.",
                            },
                            {
                              max: 30,
                              message: "coupon code must be maximum 30 characters.",
                            },
                          ]}
                        >
                          <Input
                            onChange={(e) => setState({ voucherInp: e.target.value })}
                            className="inp"
                            placeholder="Enter Code"
                          />
                        </Form.Item>
                      </Col>
                      <Col md={3}>
                        <Button
                          className="btn-3"
                          onClick={applyPromoCode}
                          disabled={state.voucherInp.length === 0}
                        >
                          Apply
                        </Button>
                      </Col>
                    </Row>
                    <Row>
                      <Col md={12}>
                        
                        
                        {state.applyCouponType === 'PROMO_CODE'  && state.promoValueWithDesc !== "" && (
                          <p className="text-info">{state.promoValueWithDesc}</p>
                        )}
                      </Col>
                    </Row>
                  </Col>
                  <Col md={1}></Col>
                  <Col md={6}>
                    <Row>
                      <Col md={6}>
                        <label className="inp-label">Transfer Options</label>
                        <Form.Item
                          className="form-item"
                          name="transferOption"
                          rules={[
                            {
                              required: true,
                              message: "Please select your transfer options.",
                            },
                          ]}
                        >
                          <Radio.Group onChange={handleChangeRadio}>
                            {state.paymentOptionsList.map((clist, i) => {
                              return (
                                <Radio
                                  key={`po_${i}`}
                                  programName={clist.programName}
                                  value={clist.programCode}
                                >
                                  {clist.programName}
                                </Radio>
                              );
                            })}
                          </Radio.Group>
                        </Form.Item>
                      </Col>
                      <Col md={6}>
                        <label className="inp-label">Sender Source Account</label>
                        <Form.Item
                          className="form-item"
                          name="senderAccount"
                          rules={[
                            {
                              required: true,
                              message: "Please select sender account.",
                            },
                          ]}
                        >
                          <Select
                            placeholder="Select Sender Account"
                            onChange={handleSenderAccount}
                          >
                            {state.bankAccountLists.map((clist, i) => {
                              return (
                                <Option key={i} value={clist.sendAccId}>
                                  <span>
                                    {clist.accountHolderName}&nbsp;&nbsp;&nbsp;{clist.accountNo}
                                  </span>
                                </Option>
                              );
                            })}
                          </Select>
                        </Form.Item>
                      </Col>
                    </Row>
                    <Row>
                      <Col md={6}>
                        <label className="inp-label">Delivery Options</label>
                        <Form.Item
                          className="form-item"
                          name="deliveryOption"
                          rules={[
                            {
                              required: true,
                              message: "Please select delivery options.",
                            },
                          ]}
                        >
                          <Select
                            placeholder="Select Delivery Options"
                            onChange={handleDeliveryOptions}
                          >
                            {state.deliveryOptionsList.map((clist, i) => {
                              return (
                                <Option
                                  key={i}
                                  value={clist.recvModeCode}
                                >{`${clist.recvMode}`}</Option>
                              );
                            })}
                          </Select>
                        </Form.Item>
                      </Col>
                      <Col md={6}>
                        <label className="inp-label">Purpose of Sending</label>
                        <Form.Item
                          className="form-item"
                          name="purposeOfSending"
                          rules={[
                            {
                              required: true,
                              message: "Please select purpose of sending.",
                            },
                          ]}
                        >
                          <Select
                            onChange={handlePurposeOfSending}
                            placeholder="Select Purpose of Sending"
                          >
                            {state.purposeLists.map((clist, i) => {
                              return (
                                <Option
                                  key={i}
                                  value={JSON.stringify(clist)}
                                >{`${clist.displayName}`}</Option>
                              );
                            })}
                          </Select>
                        </Form.Item>
                      </Col>
                    </Row>
                    <Row>
                      <Col>
                        <div className="hr"></div>
                      </Col>
                    </Row>
                    <div className="d-flex justify-content-between mb-1">
                      <div className="text-white fs-16 fw-600">Transfer Fee:</div>
                      <div className="d-flex gap-1 text-white fs-16">
                        {COUNTRY[AuthReducer.sendCountryCode].currencySymbol}{" "}
                        {state.exchangeRateData.fee}
                      </div>
                    </div>

                    <div className="d-flex justify-content-between mb-1">
                      <div className="text-white fs-16 fw-600">Coupon Discount:</div>
                      <div className="d-flex gap-1 text-white fs-16">
                        {COUNTRY[AuthReducer.sendCountryCode].currencySymbol}{" "}
                        {state.exchangeRateData.sendAmtbenefit
                          ? state.exchangeRateData.sendAmtbenefit
                          : "0.00"}
                      </div>
                    </div>
                    {/* <div className="d-flex justify-content-between mb-1">
                      <div className="text-white fs-16 fw-600">Referral Bonus:</div>
                      <div className="d-flex gap-1 text-white fs-16">
                        {COUNTRY[AuthReducer.sendCountryCode].currencySymbol}{" "}
                        {state.exchangeRateData.sendAmtbenefit
                          ? state.exchangeRateData.sendAmtbenefit
                          : "0.00"}
                      </div>
                    </div> */}
                    {/* <div className="d-flex justify-content-between mb-1">
                      <div className="text-white fs-5 fw-700"></div>
                      <div
                        style={{ textDecoration: "underline" }}
                        className="d-flex gap-1 text-info fs-12"
                      >
                        Know More
                      </div>
                    </div> */}
                    <Row>
                      <Col>
                        <div className="hr"></div>
                      </Col>
                    </Row>
                    <div className="d-flex justify-content-between mb-1">
                      <div className="text-white fs-5 fw-700">Amount Payable:</div>
                      <div className="d-flex gap-1 text-info fw-700 fs-5">
                        {COUNTRY[AuthReducer.sendCountryCode].currencySymbol}{" "}
                        {Number(state.exchangeRateData.amountPayable).toLocaleString()}
                      </div>
                    </div>
                    <Row>
                      <Col>
                        <div className="hr"></div>
                      </Col>
                    </Row>
                  </Col>
                </Row>
                <Row>
                  <Form.Item
                    className="form-item"
                    name="readTermsConditions"
                    valuePropName="checked"
                    onChange={handleTermsCondition}
                    rules={[
                      {
                        validator: (_, value) =>
                          value
                            ? Promise.resolve()
                            : Promise.reject(new Error("Please confirm terms and conditions.")),
                      },
                    ]}
                  >
                    <Checkbox style={{ color: "#fff" }}>
                      I accept and agree to the{" "}
                      <Link to="/terms-and-conditions" target="_blank">
                        <u className="text-info">Terms and Conditions</u>
                      </Link>
                    </Checkbox>
                  </Form.Item>
                  <Form.Item
                    className="form-item"
                    name="paymentService"
                    valuePropName="checked"
                    // onChange={handleTermsCondition}
                    rules={[
                      {
                        validator: (_, value) =>
                          value
                            ? Promise.resolve()
                            : Promise.reject(new Error("Please confirm terms and conditions.")),
                      },
                    ]}
                  >
                    <Checkbox style={{ color: "#fff" }}>
                      I agree & understand that the Payment Services provided through the website
                      URL www.xmonies.com in United Kingdom will be processed by our compliance
                      partner Rational Foreign Exchange Ltd. Rational Foreign Exchange Ltd is
                      authorised by the Financial Conduct Authority (FRN: 507958) under the Payment
                      Services Regulations 2009, for the provision of payment services. Issued by HM
                      Revenue & Customs (HMRC) Rational Foreign Exchange Ltd trading as RationalFX
                      is a registered Money Service Business (MSB) - Money Laundering Regulation
                      number: 12206957.
                    </Checkbox>
                  </Form.Item>
                </Row>
                <Row>
                  <Col md={6}>
                    <Button
                      onClick={() => props.setState({ isStep: props.state.prevStep })}
                      style={{ width: "268px" }}
                      className="btn-4"
                    >
                      Back
                    </Button>
                  </Col>
                  <Col md={6} className="d-flex flex-row-reverse mt-3 mt-md-0">
                    <Button htmlType="submit" style={{ width: "268px" }} className="btn-2">
                      Confirm and Pay
                    </Button>
                  </Col>
                </Row>
              </div>
            </div>
          </Spinner>
        </Form>
      )}
      {bookingPage && (
        <div className="template2__main">
          <div className="sendmoney__page container ">
            <TransactionSuccess state={state} setState={setState} />
          </div>
        </div>
      )}
    </>
  );
}
