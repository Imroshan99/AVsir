/* eslint-disable jsx-a11y/alt-text */
import { Table } from "antd";
import Spinner from "../../../../reusable/Spinner";
import { COUNTRY } from "../../../../services/Country";
import deleteIcon from "../../../../assets/images/svg/delete.svg";
import { useNavigate } from "react-router-dom";
import { useSelector } from "react-redux";
import { useState } from "react";
import SubHeader from "../../layout/SubHeader";

export default function RecipientRequestTable(props) {
  const navigate = useNavigate();
  const AuthReducer = useSelector((state) => state);
  const [selectedRowKeys, setSelectedRowKeys] = useState([null]);

  return (
    <>
      <SubHeader title="Requests" />
      <div className="template2__main">
        <div className="container py-5">
          <div className="RecipientListContainer">
            <div className="RecpListTableContainer">
              <Spinner spinning={props.loading}>
                <Table
                  onRow={(record, rowIndex) => {
                    return {
                      onClick: () => {
                        setSelectedRowKeys([record.key]);
                        props.setState({
                          reqRecpDetails: record,
                          selectedRecvNickName: record.nickName,
                          isStep: 1,
                        });
                      },
                    };
                  }}
                  rowSelection={{
                    type: "radio",
                    selectedRowKeys,
                    selections: [
                      Table.SELECTION_ALL,
                      Table.SELECTION_INVERT,
                      Table.SELECTION_NONE,
                      {
                        key: "odd",
                        text: "Select Odd Row",
                        onSelect: (changableRowKeys) => {
                          let newSelectedRowKeys = [];
                          newSelectedRowKeys = changableRowKeys.filter((_, index) => {
                            if (index % 2 !== 0) {
                              return false;
                            }
                            return true;
                          });
                          setSelectedRowKeys(newSelectedRowKeys);
                        },
                      },
                      {
                        key: "even",
                        text: "Select Even Row",
                        onSelect: (changableRowKeys) => {
                          let newSelectedRowKeys = [];
                          newSelectedRowKeys = changableRowKeys.filter((_, index) => {
                            if (index % 2 !== 0) {
                              return true;
                            }
                            return false;
                          });
                          setSelectedRowKeys(newSelectedRowKeys);
                        },
                      },
                    ],
                  }}
                  columns={[
                    //   {
                    //     title: "Name",
                    //     dataIndex: "name",
                    //     className: "w-auto",
                    //   },
                    {
                      title: "Name",
                      dataIndex: "fullName",
                    },
                    {
                      title: "Country",
                      dataIndex: "country",
                    },
                    {
                      title: "Nick Name",
                      dataIndex: "nickName",
                    },
                    {
                      title: "Amount",
                      dataIndex: "amount",
                      render: (text, record, index) => {
                        return (
                          <>
                            <p
                              style={{ height: "43px" }}
                              className="m-0 d-flex align-items-center text-primary"
                            >
                              <p className="m-0 d-flex align-items-center text-primary fw-900">
                                {COUNTRY[AuthReducer.sendCountryCode].currencySymbol}
                              </p>{" "}
                              {Number(record.sendAmount).toLocaleString()}
                            </p>
                          </>
                        );
                      },
                    },
                    {
                      title: "Date",
                      dataIndex: "requestDate",
                    },
                    {
                      title: "Action / Status",
                      dataIndex: "",
                      key: "y",
                      render: (text, record, index) => {
                        return (
                          <div className="d-flex justify-content-center">
                            {record.status === "P" && (
                              <div className="d-flex align-items-center gap-1">
                                <button
                                  className="btn-1"
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    props.recipientRequestApproveHandler(record, "N");
                                  }}
                                >
                                  Decline
                                </button>
                                <button
                                  className="btn-2"
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    props.recipientRequestApproveHandler(record, "Y");
                                    // navigate("/new-transaction", {
                                    //   state: {
                                    //     fromPage: "RECIPIENT_REQUEST_LIST",
                                    //     record: record,
                                    //     repeatTransaction: false,
                                    //     flag: "Y",
                                    //   },
                                    // });
                                  }}
                                >
                                  Accept
                                </button>
                              </div>
                            )}
                            {record.status === "N" && (
                              <div className="d-flex align-items-center gap-1">
                                <p
                                  style={{
                                    color: "#FF6892",
                                    height: "43px",
                                    fontSize: "15px",
                                    width: "143px",
                                  }}
                                  className="m-0 fw-800 d-flex align-items-center"
                                >
                                  Request Declined
                                </p>
                              </div>
                            )}
                            {record.status === "Y" && (
                              <div className="d-flex align-items-center gap-1">
                                <button
                                  style={{ width: "140px !important" }}
                                  className="btn-3"
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    props.setState({
                                      prevStep: 0,
                                      isStep: 2,
                                      reqRecpDetails: record,
                                      selectedRecvNickName: record.nickName,
                                    });
                                    // navigate("/new-transaction", {
                                    //   state: {
                                    //     fromPage: "RECIPIENT_REQUEST_LIST",
                                    //     repeatTransaction: true,
                                    //     record: record,
                                    //     // flag: "Y",
                                    //   },
                                    // });
                                  }}
                                >
                                  Send Money
                                </button>
                              </div>
                            )}
                            {/* {record.reSendFlag === "Y" && (
                              <span className="px-2" style={{ cursor: "pointer" }}>
                                <button
                                  className="btn btn-sm btn-primary text-white"
                                  i={index}
                                  onClick={() => {
                                    navigate("/new-transaction", {
                                      state: {
                                        fromPage: "RECIPIENT_REQUEST_LIST",
                                        repeatTransaction: true,
                                        record: record,
                                        // flag: "Y",
                                      },
                                    });
                                  }}
                                >
                                  Resend
                                </button>
                              </span>
                            )}
                            {record.reSendFlag === "P" && (
                              <span className="px-2" style={{ cursor: "pointer" }}>
                                <button
                                  className="btn btn-sm btn-primary text-white"
                                  i={index}
                                  onClick={() => {
                                    navigate("/new-transaction", {
                                      state: {
                                        fromPage: "RECIPIENT_REQUEST_LIST",
                                        repeatTransaction: true,
                                        record: record,
                                        // flag: "Y",
                                      },
                                    });
                                  }}
                                >
                                  Send
                                </button>
                              </span>
                            )} */}
                          </div>
                        );
                      },
                    },
                    // {
                    //   title: "",
                    //   dataIndex: "",
                    //   key: "y",
                    //   render: (text, record, index) => {
                    //     return (
                    //       <div className="d-flex gap-1 align-items-center">
                    //         <img src={deleteIcon} />
                    //         <p style={{ fontSize: "12px" }} className="text-primary m-0 fw-800">
                    //           Delete
                    //         </p>
                    //       </div>
                    //     );
                    //   },
                    // },
                  ]}
                  dataSource={props.state.recipientRequestLists}
                  pagination={props.state.recipientRequestLists.length > 10}
                />
              </Spinner>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
