import { Col, Row } from "react-bootstrap";
import { useSelector } from "react-redux";
import { useNavigate } from "react-router-dom";
import Spinner from "../../../../reusable/Spinner";
import { COUNTRY } from "../../../../services/Country";
import SubHeader from "../../layout/SubHeader";

export default function RequestDetails(props) {
  const reqRecpDetails = props?.state?.reqRecpDetails;
  const AuthReducer = useSelector((state) => state);
  const navigate = useNavigate();

  return (
    <>
      <SubHeader title="Request Details" />
      <Spinner spinning={props.loading}>
        <div className="template2__main">
          <div className="container py-5">
            <div className="RecipientListContainer">
              <div className="RequestDetails">
                <h2 className="text-white mb-4 mb-md-0">Request from {reqRecpDetails?.fullName}</h2>
                <div className="Details-Container mt-md-5">
                  <Row className="mt-3">
                    <Col md={5}>
                      <Row>
                        <Col md={6} className="text-white">
                          Bank Name:
                        </Col>
                        <Col md={6} className="text-info">
                          {reqRecpDetails?.bankName}
                        </Col>
                      </Row>
                    </Col>
                    <Col md={5}>
                      <Row>
                        <Col md={6} className="text-white mt-md-0 mt-3">
                          Account Number:
                        </Col>
                        <Col md={6} className="text-info">
                          {reqRecpDetails?.accountNo}
                        </Col>
                      </Row>
                    </Col>
                  </Row>
                  <Row className="mt-3">
                    <Col md={5}>
                      <Row>
                        <Col md={6} className="text-white">
                          NickName:
                        </Col>
                        <Col md={6} className="text-info">
                          {reqRecpDetails?.nickName}
                        </Col>
                      </Row>
                    </Col>
                    <Col md={5}>
                      <Row>
                        <Col md={6} className="text-white mt-md-0 mt-3">
                          Date:
                        </Col>
                        <Col md={6} className="text-info">
                          {reqRecpDetails?.requestDate}
                        </Col>
                      </Row>
                    </Col>
                  </Row>
                  <Row className="mt-3">
                    <Col md={5}>
                      <Row>
                        <Col md={6} className="text-white">
                          State:
                        </Col>
                        <Col md={6} className="text-info">
                          {reqRecpDetails?.state}
                        </Col>
                      </Row>
                    </Col>
                    <Col md={5}>
                      <Row>
                        <Col md={6} className="text-white mt-md-0 mt-3">
                          Country:
                        </Col>
                        <Col md={6} className="text-info mb-3 mb-md-0">
                          {reqRecpDetails?.country}
                        </Col>
                      </Row>
                    </Col>
                  </Row>
                  <Row className="mt-md-5">
                    <Col md={5} className="d-flex gap-2 align-items-center mt-3 mt-md-0">
                      <h4 className="text-white m-0 fw-700 fs-25">Request Amount:</h4>
                      <h4 className="text-info m-0 fw-700 fs-25">
                        {COUNTRY[AuthReducer.sendCountryCode]?.currencySymbol}{" "}
                        {Number(reqRecpDetails?.amount).toLocaleString()}
                      </h4>
                    </Col>
                    {reqRecpDetails.status === "P" && (
                      <Col md={5} className="mt-3 mt-md-0">
                        <Row>
                          <Col md={6}>
                            <button
                              className="btn-4 w-100 mt-4 mt-md-0"
                              onClick={() => {
                                props.recipientRequestApproveHandler(reqRecpDetails, "N");
                              }}
                            >
                              Decline
                            </button>
                          </Col>
                          <Col md={6}>
                            <button
                              className="btn-2 w-100 mt-2 mt-md-0"
                              onClick={() => {
                                props.recipientRequestApproveHandler(reqRecpDetails, "Y");
                                // navigate("/new-transaction", {
                                //   state: {
                                //     fromPage: "RECIPIENT_REQUEST_LIST",
                                //     record: reqRecpDetails,
                                //     repeatTransaction: false,
                                //     flag: "Y",
                                //   },
                                // });
                              }}
                            >
                              Accept
                            </button>
                          </Col>
                        </Row>
                      </Col>
                    )}
                    {reqRecpDetails.status === "Y" && (
                      <Col md={5} className="d-flex flex-md-row flex-column gap-2 mt-3 mt-md-0">
                        <button
                          style={{ width: "140px" }}
                          className="btn-3 w-100"
                          onClick={() => {
                            props.setState({ prevStep: 1, isStep: 2 });

                            // navigate("/new-transaction", {
                            //   state: {
                            //     fromPage: "RECIPIENT_REQUEST_LIST",
                            //     repeatTransaction: true,
                            //     record: reqRecpDetails,
                            //     // flag: "Y",
                            //   },
                            // });
                          }}
                        >
                          Send Money
                        </button>
                      </Col>
                    )}
                    {reqRecpDetails.status === "N" && (
                      <Col md={5} className="d-flex flex-md-row flex-column gap-2 mt-3 mt-md-0">
                        <h4
                          className="m-0 fw-700 fs-25 mb-3 mb-md-0"
                          style={{ color: "#FF6892", opacity: "0.7" }}
                        >
                          Request Declined
                        </h4>
                      </Col>
                    )}
                  </Row>
                  <Row className="mt-0 mt-md-5">
                    <Col className="mt-0 mt-md-5">
                      <button
                        onClick={() => props.setState({ isStep: 0 })}
                        className="btn-4 mt-2 mt-md-5"
                        style={{ width: "267px" }}
                      >
                        Back
                      </button>
                    </Col>
                  </Row>
                </div>
              </div>
            </div>
          </div>
        </div>
      </Spinner>
    </>
  );
}
