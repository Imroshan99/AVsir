import { AutoComplete, Form, Input, Select } from "antd";
import { Row, Col } from "react-bootstrap";
import { inputValidations } from "../../../../services/validations/validations";
import { useSelector } from "react-redux";
import TextArea from "antd/lib/input/TextArea";
const { Option } = Select;
const BankComponent = (props) => {
  const { state, onSelectBank, onChangeAccountNumberHandler, recvCountryCode } = props;
  const AuthReducer = useSelector((state) => state);
  const _recvCountryCode = recvCountryCode ? recvCountryCode : AuthReducer.recvCountryCode;
  // console.log('_recvCountryCode', _recvCountryCode)
  if (_recvCountryCode === "PH" || _recvCountryCode === "ID" || _recvCountryCode === "TH") {
    return (
      <div>
        <Row>
          <Col>
            <Row>
              <div>
                <label>Bank Name</label>
                <Form.Item
                  name="bankName"
                  rules={[
                    {
                      required: true,
                      message: "Please select your Bank.",
                    },
                  ]}
                >
                  <AutoComplete
                    showSearch
                    labelInValue
                    placeholder="Select Bank or Type Bank Name"
                    onChange={onSelectBank}
                    filterOption={(inputValue, option) =>
                      option.value.toUpperCase().indexOf(inputValue.toUpperCase()) !== -1
                    }
                  >
                    {state.bankLists.map((bank, i) => {
                      return (
                        <Option key={i} value={bank.bankName}>
                          <span bankCode={bank.bankCode} isSameBank={bank.isSameBank}>
                            {bank.bankName}
                          </span>
                        </Option>
                      );
                    })}
                  </AutoComplete>
                </Form.Item>
              </div>
            </Row>
            <Row>
              <div>
                <label>Bank's BIC Code</label>
                <Form.Item
                  name="bankCode"
                  rules={[
                    {
                      required: true,
                      message: "Please Bank's BIC Code",
                    },
                    ...inputValidations.bankBICCode(_recvCountryCode),
                  ]}
                >
                  <Input autoComplete="none" />
                </Form.Item>
              </div>
            </Row>

            <Row>
              <div>
                <label>Account Number</label>
                <Form.Item
                  name="accountNo"
                  rules={[
                    {
                      required: true,
                      message: "Please input your Account Number.",
                    },
                    ...inputValidations.accountNumber(_recvCountryCode),
                  ]}
                >
                  <Input.Password
                    autoComplete="new-password"
                    className="input_account_no"
                    onChange={onChangeAccountNumberHandler}
                    placeholder="Enter your Account Number"
                    onPaste={(e) => {
                      e.preventDefault();
                      return false;
                    }}
                    onCopy={(e) => {
                      e.preventDefault();
                      return false;
                    }}
                    visibilityToggle={false}
                  />
                </Form.Item>
              </div>
              <div>
                <div>
                  <label>Confirm Account Number</label>
                  <Form.Item
                    name="accConNum"
                    rules={[
                      {
                        required: true,
                        message: "Please input your Confirm Account Number.",
                      },
                      ...inputValidations.accountNumber(_recvCountryCode),
                      ({ getFieldValue }) => ({
                        validator(rule, value) {
                          if (!value || getFieldValue("accountNo") === value) {
                            return Promise.resolve();
                          }
                          return Promise.reject(
                            "The two account number that you entered do not match!",
                          );
                        },
                      }),
                    ]}
                  >
                    <Input
                      className="input_account_no"
                      placeholder="Enter your Confirm Account Number"
                      onPaste={(e) => {
                        e.preventDefault();
                        return false;
                      }}
                      onCopy={(e) => {
                        e.preventDefault();
                        return false;
                      }}
                    />
                  </Form.Item>
                </div>
              </div>
            </Row>
          </Col>
        </Row>
        <div className="d-flex justify-content-end mt-5">
          <button
            style={{ width: "10rem", fontWeight: 700 }}
            className="btn btn-sm btn-light text-primary m-w-100"
            type="submit"
          >
            Next
          </button>
        </div>
      </div>
    );
  }

  if (_recvCountryCode === "BD") {
    return (
      <div>
        <Row>
          <Col>
            <Row>
              <div>
                <label>Bank Name</label>
                <Form.Item
                  name="bankName"
                  rules={[
                    {
                      required: true,
                      message: "Please select your Bank.",
                    },
                  ]}
                >
                  <AutoComplete
                    showSearch
                    labelInValue
                    placeholder="Select Bank or Type Bank Name"
                    onChange={onSelectBank}
                    filterOption={(inputValue, option) =>
                      option.value.toUpperCase().indexOf(inputValue.toUpperCase()) !== -1
                    }
                  >
                    {state.bankLists.map((bank, i) => {
                      return (
                        <Option key={i} value={bank.bankName}>
                          <span bankCode={bank.bankCode} isSameBank={bank.isSameBank}>
                            {bank.bankName}
                          </span>
                        </Option>
                      );
                    })}
                  </AutoComplete>
                </Form.Item>
              </div>
            </Row>
            <Row>
              <div>
                <label>Bank Branch Number</label>
                <Form.Item
                  name="branchCode"
                  rules={[
                    {
                      required: true,
                      message: "Please enter Bank Branch Number.",
                    },
                    ...inputValidations.bankBranchNo(_recvCountryCode),
                  ]}
                >
                  <Input autoComplete="none" />
                </Form.Item>
              </div>
            </Row>
            <Row>
              <div>
                <label>Bank's BIC Code</label>
                <Form.Item
                  name="bankCode"
                  rules={[
                    {
                      required: true,
                      message: "Please Bank's BIC Code",
                    },
                    ...inputValidations.bankBICCode(_recvCountryCode),
                  ]}
                >
                  <Input autoComplete="none" />
                </Form.Item>
              </div>
            </Row>

            <Row>
              <div>
                <label>Account Number</label>
                <Form.Item
                  name="accountNo"
                  rules={[
                    {
                      required: true,
                      message: "Please input your Account Number.",
                    },
                    ...inputValidations.accountNumber(_recvCountryCode),
                  ]}
                >
                  <Input.Password
                    autoComplete="new-password"
                    className="input_account_no"
                    onChange={onChangeAccountNumberHandler}
                    placeholder="Enter your Account Number"
                    onPaste={(e) => {
                      e.preventDefault();
                      return false;
                    }}
                    onCopy={(e) => {
                      e.preventDefault();
                      return false;
                    }}
                    visibilityToggle={false}
                  />
                </Form.Item>
              </div>
              <div>
                <div>
                  <label>Confirm Account Number</label>
                  <Form.Item
                    name="accConNum"
                    rules={[
                      {
                        required: true,
                        message: "Please input your Confirm Account Number.",
                      },
                      ...inputValidations.accountNumber(_recvCountryCode),
                      ({ getFieldValue }) => ({
                        validator(rule, value) {
                          if (!value || getFieldValue("accountNo") === value) {
                            return Promise.resolve();
                          }
                          return Promise.reject(
                            "The two account number that you entered do not match!",
                          );
                        },
                      }),
                    ]}
                  >
                    <Input
                      className="input_account_no"
                      placeholder="Enter your Confirm Account Number"
                      onPaste={(e) => {
                        e.preventDefault();
                        return false;
                      }}
                      onCopy={(e) => {
                        e.preventDefault();
                        return false;
                      }}
                    />
                  </Form.Item>
                </div>
              </div>
            </Row>
          </Col>
        </Row>
        <div className="d-flex justify-content-end mt-5">
          <button
            style={{ width: "10rem", fontWeight: 700 }}
            className="btn btn-sm btn-light text-primary m-w-100"
            type="submit"
          >
            Next
          </button>
        </div>
      </div>
    );
  }

  if (_recvCountryCode === "LK") {
    return (
      <div>
        <Row>
          <Col>
            <Row>
              <div>
                <label>Bank Name</label>
                <Form.Item
                  name="bankName"
                  rules={[
                    {
                      required: true,
                      message: "Please select your Bank.",
                    },
                  ]}
                >
                  <AutoComplete
                    showSearch
                    labelInValue
                    placeholder="Select Bank or Type Bank Name"
                    onChange={onSelectBank}
                    filterOption={(inputValue, option) =>
                      option.value.toUpperCase().indexOf(inputValue.toUpperCase()) !== -1
                    }
                  >
                    {state.bankLists.map((bank, i) => {
                      return (
                        <Option key={i} value={bank.bankName}>
                          <span bankCode={bank.bankCode} isSameBank={bank.isSameBank}>
                            {bank.bankName}
                          </span>
                        </Option>
                      );
                    })}
                  </AutoComplete>
                </Form.Item>
              </div>
            </Row>
            <Row>
              <div>
                <label>Bank Branch Number</label>
                <Form.Item
                  name="branchCode"
                  rules={[
                    {
                      required: true,
                      message: "Please enter Bank Branch Number.",
                    },
                    ...inputValidations.bankBranchNo(_recvCountryCode),
                  ]}
                >
                  <Input autoComplete="none" />
                </Form.Item>
              </div>
            </Row>
            <Row>
              <div>
                <label>Bank Code</label>
                <Form.Item
                  name="bankCode"
                  rules={[
                    {
                      required: true,
                      message: "Please enter Bank Code",
                    },
                    ...inputValidations.bankCode(_recvCountryCode),
                  ]}
                >
                  <Input autoComplete="none" />
                </Form.Item>
              </div>
            </Row>
            <Row>
              <div>
                <label>Bank's BIC Code</label>
                <Form.Item
                  name="swiftCode"
                  rules={[
                    {
                      required: true,
                      message: "Please Bank's BIC Code",
                    },
                    ...inputValidations.bankBICCode(_recvCountryCode),
                  ]}
                >
                  <Input autoComplete="none" />
                </Form.Item>
              </div>
            </Row>

            <Row>
              <div>
                <label>Account Number</label>
                <Form.Item
                  name="accountNo"
                  rules={[
                    {
                      required: true,
                      message: "Please input your Account Number.",
                    },
                    ...inputValidations.accountNumber(_recvCountryCode),
                  ]}
                >
                  <Input.Password
                    autoComplete="new-password"
                    className="input_account_no"
                    onChange={onChangeAccountNumberHandler}
                    placeholder="Enter your Account Number"
                    onPaste={(e) => {
                      e.preventDefault();
                      return false;
                    }}
                    onCopy={(e) => {
                      e.preventDefault();
                      return false;
                    }}
                    visibilityToggle={false}
                  />
                </Form.Item>
              </div>
              <div>
                <div>
                  <label>Confirm Account Number</label>
                  <Form.Item
                    name="accConNum"
                    rules={[
                      {
                        required: true,
                        message: "Please input your Confirm Account Number.",
                      },
                      ...inputValidations.accountNumber(_recvCountryCode),
                      ({ getFieldValue }) => ({
                        validator(rule, value) {
                          if (!value || getFieldValue("accountNo") === value) {
                            return Promise.resolve();
                          }
                          return Promise.reject(
                            "The two account number that you entered do not match!",
                          );
                        },
                      }),
                    ]}
                  >
                    <Input
                      className="input_account_no"
                      placeholder="Enter your Confirm Account Number"
                      onPaste={(e) => {
                        e.preventDefault();
                        return false;
                      }}
                      onCopy={(e) => {
                        e.preventDefault();
                        return false;
                      }}
                    />
                  </Form.Item>
                </div>
              </div>
            </Row>
          </Col>
        </Row>
        <div className="d-flex justify-content-end mt-5">
          <button
            style={{ width: "10rem", fontWeight: 700 }}
            className="btn btn-sm btn-light text-primary m-w-100"
            type="submit"
          >
            Next
          </button>
        </div>
      </div>
    );
  }
  return (
    <div>
      <Row>
        <Col>
          <Row>
            <div>
              <label>Bank's Swift Code</label>
              <Form.Item
                name="bankCode"
                rules={[
                  {
                    required: true,
                    message: "Please Bank's Swift Code",
                  },
                  ...inputValidations.swiftCode(_recvCountryCode),
                ]}
              >
                <Input autoComplete="none" />
              </Form.Item>
            </div>
          </Row>
          <Row>
            <div>
              <label>Bank Name</label>
              <Form.Item
                name="bankName"
                rules={[
                  {
                    required: true,
                    message: "Please select your Bank.",
                  },
                ]}
              >
                <AutoComplete
                  showSearch
                  labelInValue
                  placeholder="Select Bank"
                  onChange={onSelectBank}
                  filterOption={(inputValue, option) =>
                    option.value.toUpperCase().indexOf(inputValue.toUpperCase()) !== -1
                  }
                >
                  {state.bankLists.map((bank, i) => {
                    return (
                      <Option key={i} value={bank.bankName}>
                        <span bankCode={bank.bankCode} isSameBank={bank.isSameBank}>
                          {bank.bankName}
                        </span>
                      </Option>
                    );
                  })}
                </AutoComplete>
              </Form.Item>
            </div>
          </Row>
          <Row>
            <div>
              <label>Bank Address</label>
              <Form.Item
                name="bankAddress"
                rules={[
                  {
                    required: true,
                    message: "Please enter your Bank Address.",
                  },
                  ...inputValidations.bankAddress(_recvCountryCode),
                ]}
              >
                <TextArea
                  autoComplete="none"
                  onKeyDown={(e) => {
                    if (e.key === "Enter") {
                      e.preventDefault();
                      if (!e.shiftKey) {
                        e.preventDefault();
                      }
                    }
                  }}
                  style={{ resize: "none", height: "5rem" }}
                ></TextArea>
              </Form.Item>
            </div>
          </Row>
          <Row>
            <div>
              <label>Bank Sort Code</label>
              <Form.Item
                name="branchCode"
                rules={[
                  {
                    required: true,
                    message: "Please enter Bank Sort Code.",
                  },
                  ...inputValidations.bankSortCode(_recvCountryCode),

                  // {
                  //   pattern: /^[0-9\b]+$/,
                  //   message: "Only Numbers allowed",
                  // },
                ]}
              >
                <Input autoComplete="none" />
              </Form.Item>
            </div>
          </Row>
          <Row>
            <div>
              <label>IBAN Number</label>
              <Form.Item
                name="accountNo"
                rules={[
                  {
                    required: true,
                    message: "Please input your IBAN Number.",
                  },
                  ...inputValidations.accountNumber(_recvCountryCode),
                ]}
              >
                <Input.Password
                  autoComplete="new-password"
                  className="input_account_no"
                  onChange={onChangeAccountNumberHandler}
                  placeholder="Enter your IBAN Number"
                  onPaste={(e) => {
                    e.preventDefault();
                    return false;
                  }}
                  onCopy={(e) => {
                    e.preventDefault();
                    return false;
                  }}
                  visibilityToggle={false}
                />
              </Form.Item>
            </div>
          </Row>
        </Col>
        <Col>
          <Row>
            <div>
              <label>Intermediary Bank's Swift Code</label>
              <Form.Item
                name="interBankCode"
                rules={[...inputValidations.interSwiftCode(_recvCountryCode)]}
              >
                <Input autoComplete="none" />
              </Form.Item>
            </div>
          </Row>
          <Row>
            <div>
              <label>Intermediary Bank Name</label>
              <Form.Item
                name="interBankName"
                rules={[...inputValidations.interBankName(_recvCountryCode)]}
              >
                <Input autoComplete="none" />
              </Form.Item>
            </div>
          </Row>
          <Row>
            <div>
              <label>Intermediary Bank Address</label>
              <Form.Item
                name="interBankAddress"
                rules={[...inputValidations.interBankAddress(_recvCountryCode)]}
              >
                <TextArea
                  onKeyDown={(e) => {
                    if (e.key === "Enter") {
                      e.preventDefault();
                      if (!e.shiftKey) {
                        e.preventDefault();
                      }
                    }
                  }}
                  style={{ resize: "none", height: "5rem" }}
                  autoComplete="none"
                ></TextArea>
              </Form.Item>
            </div>
          </Row>
          <Row>
            <label>Intermediary Bank Country</label>
            <div>
              <Form.Item
                className="mb-0"
                name="interBankCountry"
                // rules={[
                //   {
                //     required: true,
                //     message: "Please select Intermediary Bank Country.",
                //   },
                // ]}
              >
                <Select
                  // getPopupContainer={(trigger) => trigger.parentNode}
                  // labelInValue
                  placeholder="Select Intermediary Bank Country"
                >
                  {AuthReducer.recvCountryList.map((value, i) => {
                    return (
                      <Option key={i} value={value.recvCountry}>
                        {value.countryName}
                      </Option>
                    );
                  })}
                </Select>
              </Form.Item>
            </div>
          </Row>
        </Col>
      </Row>
      <div className="d-flex justify-content-end mt-5">
        <button
          style={{ width: "10rem", fontWeight: 700 }}
          className="btn btn-sm btn-light text-primary m-w-100"
          type="submit"
        >
          Next
        </button>
      </div>
    </div>
  );
};
export default BankComponent;
