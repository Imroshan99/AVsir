/* eslint-disable jsx-a11y/alt-text */
import React, { useState, useEffect, useReducer } from "react";
import { ReceiverAPI } from "../../../../apis/ReceiverAPI";
import { useSelector } from "react-redux";
import useHttp from "../../../../hooks/useHttp";
import moment from "moment";
import { COUNTRY } from "../../../../services/Country";
import RecipientRequestTable from "./RecipientRequestTable";
import RequestDetails from "./RequestDetails";
import { notification } from "antd";
import RequestTransactionConfirm from "./RequestTransactionConfirm";

function RecipientRequestList(props) {
  const AuthReducer = useSelector((state) => state);
  const [loading, setLoader] = useState(false);
  const [state, setState] = useReducer((state, newState) => ({ ...state, ...newState }), {
    receiverLists: [],
    filteredRecieverList: [],
    recipientRequestLists: [],
    isStep: 0,
    prevStep: 0,
    reqRecpDetails: {},
    selectedRecvNickName: "",
  });

  const hookRecipientRequestLists = useHttp(ReceiverAPI.recipientRequestLists);
  const hookRecipientRequestApprove = useHttp(ReceiverAPI.recipientRequestApprove);

  useEffect(() => {
    if (props.appState.isLoggedIn) {
      recipientRequestListsHandler();
    }
  }, []);

  const recipientRequestApproveHandler = (record, flag) => {
    const payload = {
      requestType: "RECREQAPPROVE",
      userId: AuthReducer.userID,
      rmId: record.rmId,
      aprroveFlag: flag,
      recordToken: record.recordToken,
      nickName: record.nickName,
    };
    setLoader(true);
    hookRecipientRequestApprove.sendRequest(payload, (res) => {
      setLoader(false);
      if (res.status === "S") {
        recipientRequestListsHandler();
        notification.success({ message: res.message });
      }
    });
  };

  const recipientRequestListsHandler = () => {
    const payload = {
      requestType: "RECREQLIST",
      userId: AuthReducer.userID,
      startIndex: "0",
      recordsPerRequest: "",
      search: "",
      statusFlag: "",
      favouriteFlag: "",
    };
    setLoader(true);
    hookRecipientRequestLists.sendRequest(payload, (res) => {
      setLoader(false);
      if (res.status === "S") {
        let newResData = [];
        res.responseData.forEach((i) => {
          let newDate = moment(i.registrationDate).format("DD/MM/YYYY");
          newResData.push({
            ...i,
            fullName: `${i.recvFirstName} ${i.recvLastName}`,
            amount: `${i.sendAmount}`,
            requestDate: `${newDate}`,
            country: COUNTRY[i.countryCode].countryName,
          });
        });
        if (state.selectedRecvNickName) {
          let updatedRecvDetails = newResData.filter((i) => {
            return i.nickName === state.selectedRecvNickName;
          });
          setState({ reqRecpDetails: updatedRecvDetails[0] });
        }
        setState({
          recipientRequestLists: newResData,
        });
      }
    });
  };

  return (
    <div className="RequestMoneyContainer">
      {state.isStep === 0 && (
        <RecipientRequestTable
          state={state}
          setState={setState}
          loading={loading}
          recipientRequestApproveHandler={recipientRequestApproveHandler}
        />
      )}
      {state.isStep === 1 && (
        <RequestDetails
          state={state}
          setState={setState}
          loading={loading}
          recipientRequestApproveHandler={recipientRequestApproveHandler}
        />
      )}
      {state.isStep === 2 && (
        <RequestTransactionConfirm
          state={state}
          setState={setState}
          loading={loading}
          recipientRequestApproveHandler={recipientRequestApproveHandler}
        />
      )}
    </div>
  );
}

export default RecipientRequestList;
