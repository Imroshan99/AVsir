import React, { useEffect, useReducer, useState } from "react";
import { Form, Input, Radio, Tabs, Select, notification, Button, Spin, AutoComplete } from "antd";
import { Row, Col, Container } from "react-bootstrap";
import { useLocation } from "react-router-dom";
import { ReceiverAPI } from "../../../../apis/ReceiverAPI";
import { GuestAPI } from "../../../../apis/GuestAPI";
import { useDispatch, useSelector } from "react-redux";
import { ProfileAPI } from "../../../../apis/ProfileAPI";
import { encrypt, decrypt, publickey } from "../../../../helpers/makeHash";
import useHttp from "../../../../hooks/useHttp";
import { inputValidations } from "../../../../services/validations/validations";
import { COUNTRY } from "../../../../services/Country";
import { validateBankBranch } from "../../../../services/validations/bankbranch";
import BankComponent from "./BankComponent";

const { TabPane } = Tabs;
const { Option } = Select;
const { TextArea } = Input;
export default function AddRecipientStep1(props) {
  const dispatch = useDispatch();
  // const [ifscAddress, setIfscAddress] = useState("");
  const [ifscCode, setIfscCode] = useState("");

  // const [showIfscAddress, setShowIfscAddress] = useState(false);
  const AuthReducer = useSelector((state) => state);
  const ConfigReducer = useSelector((state) => state);
  const AddRecipientFormConfig = ConfigReducer.groupIdSettings.recipientModule.AddRecipientForm;
  const location = useLocation();
  const [state, setState] = useReducer((state, newState) => ({ ...state, ...newState }), {
    clientId: AuthReducer.clientId,
    groupId: AuthReducer.groupId,
    twofa: AddRecipientFormConfig?.twoFA ? AddRecipientFormConfig.twoFA : AuthReducer.twofa,
    // twofa:   AuthReducer.twofa,
    sessionId: AuthReducer.sessionId,
    userID: AuthReducer.userID,
    nationalities: [],
    stateCities: [],
    branch: "",
    _showOTPBOX: false,
    showConfirmAddRecipient: false,
    isConfirmAddRecipient: false,
    formData: {},
    verificationToken: "",
    isOTPVerfied: false,
    isModalVisible: false,
    otpType: "RA",
    branchCode: "",
    bankBranch: "",
    bankAddress: "",
    bankState: "",
    bankCity: "",
    bankName: "",
    isSameBank: "N",
    bankCode: "",
    bankId: "",
    bankCountry: "",
    isSelectedIFSC: false,
    bankLists: [],
    cityLists: [],
    branchLists: [],
    phoneCodes: [],
    occupationLists: [],
    relationshipLists: [],
    deliveryOptionsList: [],
    deliveryOption: "",
    accountNumber: "",
    accountType: "",
    stateLists: [],
    dob: "",
    redirectPage: "",
    redirectPageState: [],
    selectedBranch: {},
  });
  // const hookGetNationality = useHttp(GuestAPI.getNationality);
  const hookGetCountryPhoneCodes = useHttp(GuestAPI.getCountryPhoneCodes);
  const hookGetDeliveryOptions = useHttp(GuestAPI.deliveryOptions);
  const hookGetCountryStates = useHttp(GuestAPI.countryStates);
  const hookGetBankBranchData = useHttp(GuestAPI.bankBranchData);
  const hookGetBankLists = useHttp(ReceiverAPI.bankLists);
  const hookGetBankStateCities = useHttp(ReceiverAPI.bankStateCities);
  const hookGebankBranches = useHttp(ReceiverAPI.bankBranches);
  const hookGetBankBranchState = useHttp(GuestAPI.getBankBranchState);

  useEffect(() => {
    window.scrollTo({ top: 0, behavior: "smooth" });
    if (props.state.recvCountryCode) {
      getDeliveryOptions();
      getCoutryCodes();
      getBankList();
      getStateLists();
    }

    setState({
      redirectPage: location.state?.fromPage,
      redirectPageState: location.state?.fromPageState,
    });
  }, [props.state.recvCountryCode]);
  useEffect(() => {
    props.newForm.setFieldsValue({ recvCountry: AuthReducer.recvCountryCode });
    props.setState({
      recvCountryCode: AuthReducer.recvCountryCode,
      recvCurrencyCode: AuthReducer.recvCurrencyCode,
    });
  }, [AuthReducer.recvCountryCode]);

  const getCoutryCodes = async () => {
    const payload = {
      requestType: "COUNTRYPHONECODE",
    };
    props.setLoader(true);
    hookGetCountryPhoneCodes.sendRequest(payload, function (data) {
      if (data.status == "S") {
        setState({ phoneCodes: data.responseData });
        props.setLoader(false);
      }
    });
  };

  const getDeliveryOptions = async () => {
    setState({ deliveryOptionsList: [] });
    let payload = {
      requestType: "RECVMODE",
      countryCode: props.state.recvCountryCode,
    };
    props.setLoader(true);
    hookGetDeliveryOptions.sendRequest(payload, function (data) {
      if (data.status === "S") {
        setState({ deliveryOptionsList: data.responseData });
        props.newForm.setFieldsValue({
          deliveryOption: data.responseData[0].recvModeCode
        });
        props.setLoader(false);
      }
    });
  };
  const getStateLists = async () => {
    let payload = {
      requestType: "STATELIST",
      countryCode: props.state.recvCountryCode,
      keyword: "",
    };
    props.setLoader(true);
    hookGetBankBranchState.sendRequest(payload, function (data) {
      if (data.status === "S") {
        setState({ stateLists: data.responseData });
        props.setLoader(false);
      }
    });
  };

  const onChangeIFSCCode = async (e) => {
    setIfscCode(e.target.value);
    setState({ ifscFormRadio: false });
    if (
      e.target.value.length == 11 &&
      /^(?=.*[a-zA-Z])(?=.*[0-9])[A-Za-z0-9]+$/.test(e.target.value)
    ) {
      // props.setLoader(true);state
      const payload = {
        requestType: "BANKBRANCHDATA",
        branchCode: e.target.value,
        userId: state.userID,
      };
      props.setLoader(true);
      hookGetBankBranchData.sendRequest(payload, function (data) {
        props.setIfscCodeValidator(data);
        props.setLoader(false);
        if (data.status == "S") {
          props.newForm.setFieldsValue({
            bankName: data.bankName,
            cityName: data.bankCity,
            bankState: data.bankState,
            branch: data.branchName,
          });
          props.setState({ ifscRadioInput: false });

          // props.setLoader(false);
          notification.success({ message: data.message });
          // setShowIfscAddress(true);
          props.setIfscBranchName(data);
          // setIfscAddress(data.bankAddress);
          setState({
            branch: data,
            branchCode: data.branchCode,
            bankBranch: data.bankBranch,
            bankAddress: data.bankAddress,
            bankState: data.bankState,
            bankCity: data.bankCity,
            bankName: data.bankName,
            bankId: data.bankId,
            bankCountry: data.bankCountry,
          });
        } else {
          setState({ ifscFormRadio: true });
          props.newForm.setFieldsValue({
            bankName: "",
            cityName: "",
            bankState: "",
            branch: "",
          });
          // notification.error({ message: res.data.errorMessage });
          // setShowIfscAddress(false);
          // props.newForm.setFields([{ name: "IFSCCode", errors: [data.errorMessage] }]);
          // props.newForm.setFields([{ name: "IFSCCode", errors: ["The IFSC provided by you is not in our list. Kindly make sure that the IFSC is correct. Any return of funds due to invalid IFSC, will impose charges by disbursing bank and will be applicable to you. Confirm If you wish to continue with this IFSC"] }]);
          setState({
            branch: "",
            branchCode: "",
            bankBranch: "",
            bankAddress: "",
            bankState: "",
            bankCity: "",
            bankName: "",
            bankId: "",
            bankCountry: "",
          });
        }
      });
    } else {
      setState({
        branch: "",
        branchCode: "",
        bankBranch: "",
        bankAddress: "",
        bankState: "",
        bankCity: "",
        bankName: "",
        bankId: "",
        bankCountry: "",
      });
    }
  };

  const getBankList = async (e) => {
    setState({ bankLists: [] });
    const payload = {
      requestType: "BANKLIST",
      countryCode: props.state.recvCountryCode,
      userId: state.userID,
    };
    props.setLoader(true);
    hookGetBankLists.sendRequest(payload, function (data) {
      if (data.status === "S") {
        setState({
          bankLists: data.responseData,
        });
        props.setLoader(false);
      }
    });
  };
  const onSelectBank = async (row) => {
    if (props.state.recvCountryCode === "IN") {
      const bankName = row.value;
      let bankCode = row.label.props.bankCode;
      let isSameBank = row.label.props.isSameBank;
      setState({
        bankName: bankName,
        bankCode: bankCode,
        isSameBank: isSameBank,
      });
      // form1.setFieldsValue({ cityName: undefined, branch: undefined });
      const payload = {
        requestType: "BankStateCities",
        countryCode: props.state.recvCountryCode,
        state: "",
        bankName: bankName,
        search: "",
      };
      props.setLoader(true);
      hookGetBankStateCities.sendRequest(payload, function (data) {
        if (data.status === "S") {
          setState({
            cityLists: data.responseData,
          });
          props.setLoader(false);
        }
      });
    } else {
      props.setState({ bankName: row.value });
    }
  };
  const onSetectCity = async (cityName) => {
    setState({ bankCity: cityName });
    const payload = {
      requestType: "BANKBRANCHES",
      countryCode: props.state.recvCountryCode,
      bankCode: state.bankCode,
      bankName: state.bankName,
      cityCode: "",
      stateCode: "",
      city: cityName,
      keyword: "",
    };
    props.setLoader(true);
    hookGebankBranches.sendRequest(payload, function (data) {
      if (data.status === "S") {
        setState({
          branchLists: data.responseData,
        });
        props.setLoader(false);
      }
    });
  };
  const onSetectBranch = async (value) => {
    let branch = state.branchLists.find((i) => {
      if (i.branchName == value) {
        return i;
      }
    });
    props.setState({ selectedBranch: branch });
    props.newForm.setFieldsValue({ bankState: branch.bankState });
    setState({
      branchCode: branch.branchCode,
      bankBranch: branch.branchName,
      bankAddress: branch.bankAddress,
      bankState: branch.bankState,
      bankCity: branch.bankCity,
      bankName: branch.bankName,
      bankId: branch.bankId,
      bankCountry: branch.bankCountry,
    });
  };
  const onChangeDeliveryOptionHandler = (value) => {
    let bankName = value;
    setState({
      deliveryOption: value,
      bankName: bankName,
    });
  };
  const onChangeAccountNumberHandler = (value) => {
    setState({
      accountNumber: value.target.value,
    });
  };
  const onChangeAccountTypeHandler = (value) => {
    setState({
      accountType: value.target.value,
    });
  };
  let onFinish = (value) => {
    if (props.state.recvCountryCode === "IN") {
      if (props.activeTab == 1) {
        if (props.ifscCodeValidator.status == "S") {
          let finalValue = {
            ...value,
            ...props.ifscBranchName,
          };
          props.saveFormDataHandler(finalValue);
          props.setAddRecipentModalSetp2(false);
        } else {
          props.newForm.setFields([
            {
              name: "IFSCCode",
              errors: [props.ifscCodeValidator.errorMessage],
            },
          ]);
        }
      } else {
        let finalValue = { ...value, ...props.state.selectedBranch };
        props.saveFormDataHandler(finalValue);
        props.setAddRecipentModalSetp2(false);
      }
    } else {
      props.saveFormDataHandler(value);
      props.setAddRecipentModalSetp2(false);
    }
  };

  const onSelectRecvCountry = (val) => {
    dispatch({ type: "SET_RECV_COUNTRY_CODE", payload: val });
    dispatch({
      type: "SET_RECV_CURRENCY_CODE",
      payload: COUNTRY[val].countryCurrency,
    });
    props.setState({ recvCountryCode: val, recvCurrencyCode: COUNTRY[val].countryCurrency });
    setState({ ifscFormRadio: false }); //to disable incorrect ifsc message
    props.newForm.setFieldsValue({
      branch: "",
      cityName: "",
      bankState: "",
      bankName: "",
      IFSCCode: "",
      deliveryOption: "",
    });
  };

  let activeTabHandler = (key) => {
    if (key !== props.activeTab) {
      props.setState({ ifscRadioInput: false });
      // setIfscAddress("");
      // props.newForm.resetFields();
      setState({ ifscFormRadio: false }); //to disable incorrect ifsc message
      props.newForm.setFieldsValue({
        branch: "",
        cityName: "",
        bankState: "",
        bankName: "",
        IFSCCode: "",
        // deliveryOption: "",
      });
    }
    props.setActiveTab(key);
  };
  return (
    <div className="AddReceipentStep1">
      <Form form={props.newForm} onFinish={onFinish}>
        <div className="row mb-3">
          <div className="col-12 col-md-3">
            <label>Receiving Country</label>
          </div>
          <div className="col-12 col-md-6">
            <Form.Item
              className="mb-0"
              name="recvCountry"
              rules={[
                {
                  required: true,
                  message: "Please select Receiving Country.",
                },
              ]}
            >
              <Select
                // labelInValue
                placeholder="Select Receiving Country"
                onChange={onSelectRecvCountry}
              >
                {AuthReducer.recvCountryList.map((value, i) => {
                  return (
                    <Option key={i} value={value.recvCountry}>
                      {value.countryName}
                    </Option>
                  );
                })}
              </Select>
            </Form.Item>
          </div>
        </div>
        {props.state.recvCountryCode !== "" && (
          <div className="row mb-3">
            <div className="col-12 col-md-3">
              <label>Delivery Options</label>
            </div>
            <div className="col-12 col-md-6">
              <Form.Item
                className="mb-0"
                name="deliveryOption"
                rules={[
                  {
                    required: true,
                    message: "Please select Delivery Options.",
                  },
                ]}
              >
                <Select
                  // labelInValue
                  placeholder="Select Delivery Options"
                  onChange={onChangeDeliveryOptionHandler}
                >
                  {state.deliveryOptionsList.map((value, i) => {
                    return (
                      <Option key={i} value={value.recvModeCode}>
                        {value.recvMode}
                      </Option>
                    );
                  })}
                </Select>
              </Form.Item>
            </div>
          </div>
        )}
        <>
          {props.state.recvCountryCode === "IN" && (
            <div>
              <label>Do you know the IFSC of beneficiary bank?</label>
              <Tabs defaultActiveKey={props.activeTab} onChange={activeTabHandler}>
                <TabPane tab="Yes" key="1">
                  {props.activeTab == 1 && (
                    <>
                      <Row>
                        <Col md={6}>
                          <label>Receivers IFSC Code</label>
                          <Form.Item
                            className="mb-0"
                            name="IFSCCode"
                            rules={[
                              {
                                required: true,
                                message: "Please input your IFSC Code.",
                              },
                              {
                                len: 11,
                                message: "IFSC Code must be exactly 11 characters.",
                              },
                              {
                                pattern: /^(?=.*[a-zA-Z])(?=.*[0-9])[A-Za-z0-9]+$/,
                                message: "IFSC code should be alphanumeric.",
                              },
                            ]}
                            onChange={onChangeIFSCCode}
                          >
                            <Input autoComplete="none" maxLength={"11"} />
                          </Form.Item>
                        </Col>
                        {state.ifscFormRadio && ifscCode.length == 11 && (
                          <>
                            <span className="text-justify text-info mt-2">
                              The IFSC provided by you is not in our list. Kindly make sure that the
                              IFSC is correct. Any return of funds due to invalid IFSC, will impose
                              charges by disbursing bank and will be applicable to you. Confirm If
                              you wish to continue with this IFSC
                            </span>
                            <span className="text-justify text-info">
                              Alternatively, you can "Raise an Issue" request to verify and add this
                              IFSC in our database from Support menu
                            </span>
                            <Form.Item className="mb-0">
                              <Radio.Group
                                onChange={(e) => {
                                  props.setState({ ifscRadioInput: e.target.value });
                                  props.newForm.setFieldsValue({
                                    bankName: "",
                                    cityName: "",
                                    bankState: "",
                                    branch: "",
                                  });
                                }}
                              >
                                <Radio value={true}>Yes</Radio>
                                <Radio value={false}>No</Radio>
                              </Radio.Group>
                            </Form.Item>
                          </>
                        )}
                      </Row>
                      <Row className="mt-4">
                        <Col sm={12} md={6}>
                          <div>
                            <label>Bank Name</label>
                            <Form.Item
                              name="bankName"
                              rules={[
                                {
                                  required: true,
                                  message: "Please select bank name",
                                },
                              ]}
                            >
                              <Select
                                disabled={!props.state.ifscRadioInput}
                                showSearch
                                placeholder="Bank Name"
                              >
                                {state.bankLists.map((bank, i) => {
                                  return (
                                    <Option key={i} value={bank.bankName}>
                                      {/* <span bankCode={bank.bankCode} isSameBank={bank.isSameBank}> */}
                                      {bank.bankName}
                                      {/* </span> */}
                                    </Option>
                                  );
                                })}
                              </Select>
                            </Form.Item>
                          </div>
                        </Col>
                        <Col sm={12} md={6}>
                          <div>
                            <label>Bank Branch State</label>
                            <Form.Item
                              name="bankState"
                              rules={[
                                {
                                  required: true,
                                  message: "Please select bank state",
                                },
                              ]}
                            >
                              <Select
                                disabled={!props.state.ifscRadioInput}
                                showSearch
                                placeholder="Bank Branch State"
                              >
                                {state.stateLists.map((state, i) => {
                                  return (
                                    <Option key={i} value={state.stateCode}>
                                      {state.state}
                                    </Option>
                                  );
                                })}
                              </Select>
                            </Form.Item>
                          </div>
                        </Col>
                      </Row>
                      <Row>
                        <Col sm={12} md={6}>
                          <div>
                            <label>City</label>
                            <Form.Item
                              name="cityName"
                              rules={[
                                {
                                  required: true,
                                  message: "Please enter city",
                                },
                                {
                                  min: 3,
                                  max: 100,
                                  message: "City must be between 3 and 100 characters",
                                },
                                {
                                  pattern: /^[a-zA-Z ]*$/, //alphanumeric with space
                                  message: "Please enter valid city name",
                                },
                              ]}
                            >
                              <AutoComplete
                                disabled={!props.state.ifscRadioInput}
                                showSearch
                                onSelect={onSetectCity}
                                placeholder="City"
                              ></AutoComplete>
                            </Form.Item>
                          </div>
                        </Col>
                        <Col sm={12} md={6}>
                          <div>
                            <label>Branch</label>
                            <Form.Item
                              name="branch"
                              rules={[
                                {
                                  required: true,
                                  message: "Please enter branch",
                                },
                                {
                                  min: 3,
                                  max: 300,
                                  message: "Branch must be between 3 and 300 characters",
                                },
                                ({ getFieldValue }) => ({
                                  validator(rule, value) {
                                    let message = "";
                                    let obj = validateBankBranch(value ? value : "");
                                    message = obj.message;
                                    if (obj.status === "S") {
                                      return Promise.resolve();
                                    }
                                    return Promise.reject(message);
                                  },
                                }),
                              ]}
                            >
                              <AutoComplete
                                disabled={!props.state.ifscRadioInput}
                                autoComplete="none"
                                showSearch
                                onSelect={onSetectBranch}
                                placeholder="Branch"
                              ></AutoComplete>
                            </Form.Item>
                          </div>
                        </Col>
                      </Row>
                      <div className="row">
                        <div className="col-12 col-md-6">
                          <div>
                            <label>Account Number</label>
                            <Form.Item
                              name="accountNo"
                              rules={[
                                {
                                  required: true,
                                  message: "Please input your Account Number.",
                                },
                                ...inputValidations.accountNumber(props.state.recvCountryCode),
                              ]}
                            >
                              <Input.Password
                                autoComplete="new-password"
                                className="input_account_no"
                                onChange={onChangeAccountNumberHandler}
                                placeholder="Enter your Account Number"
                                onPaste={(e) => {
                                  e.preventDefault();
                                  return false;
                                }}
                                onCopy={(e) => {
                                  e.preventDefault();
                                  return false;
                                }}
                                visibilityToggle={false}
                              />
                            </Form.Item>
                          </div>
                        </div>
                        <div className="col-12 col-md-6">
                          <div>
                            <label>Confirm Account Number</label>
                            <Form.Item
                              name="accConNum"
                              rules={[
                                {
                                  required: true,
                                  message: "Please input your Confirm Account Number.",
                                },
                                ...inputValidations.accountNumber(props.state.recvCountryCode),
                                ({ getFieldValue }) => ({
                                  validator(rule, value) {
                                    if (!value || getFieldValue("accountNo") === value) {
                                      return Promise.resolve();
                                    }
                                    return Promise.reject(
                                      "The two account number that you entered do not match!",
                                    );
                                  },
                                }),
                              ]}
                            >
                              <Input
                                className="input_account_no"
                                placeholder="Enter your Confirm Account Number"
                                onPaste={(e) => {
                                  e.preventDefault();
                                  return false;
                                }}
                                onCopy={(e) => {
                                  e.preventDefault();
                                  return false;
                                }}
                              />
                            </Form.Item>
                          </div>
                        </div>
                      </div>
                      <Row>
                        <Col>
                          <label>Account Type</label>
                          <Form.Item
                            rules={[
                              {
                                required: true,
                                message: "Please select your account type.",
                              },
                            ]}
                            name="accountType"
                          >
                            <Radio.Group
                              className="d-flex"
                              style={{ gap: "1rem" }}
                              onChange={onChangeAccountTypeHandler}
                            >
                              <Radio value={"S"}>Savings Account</Radio>
                              <Radio value={"NE"}>NRE</Radio>
                              <Radio value={"NO"}>NRO</Radio>
                            </Radio.Group>
                          </Form.Item>
                        </Col>
                        <Col className="d-flex justify-content-end align-items-center">
                          <button
                            style={{ width: "10rem", fontWeight: 700 }}
                            className="btn btn-sm btn-light text-primary m-w-100"
                            type="submit"
                          >
                            Next
                          </button>
                        </Col>
                      </Row>
                    </>
                  )}
                </TabPane>
                <TabPane tab="No" key="2">
                  {props.activeTab == 2 && (
                    <div className="Modal-Bottom-Content-Container-2">
                      <Row>
                        <Col sm={12} md={6}>
                          <div>
                            <label>Bank Name</label>
                            <Form.Item
                              name="bankName"
                              rules={[
                                {
                                  required: true,
                                  message: "Please select your Bank.",
                                },
                              ]}
                            >
                              <Select
                                getPopupContainer={(trigger) => trigger.parentNode}
                                showSearch
                                labelInValue
                                placeholder="Select Bank"
                                onChange={onSelectBank}
                              >
                                {state.bankLists.map((bank, i) => {
                                  return (
                                    <Option key={i} value={bank.bankName}>
                                      <span bankCode={bank.bankCode} isSameBank={bank.isSameBank}>
                                        {bank.bankName}
                                      </span>
                                    </Option>
                                  );
                                })}
                              </Select>
                            </Form.Item>
                          </div>
                        </Col>
                        <Col sm={12} md={6}>
                          <div>
                            <label>Bank Branch State</label>
                            <Form.Item
                              name="bankState"
                              rules={[
                                {
                                  required: true,
                                  message: "Please select your State.",
                                },
                              ]}
                            >
                              <Select
                                getPopupContainer={(trigger) => trigger.parentNode}
                                showSearch
                                placeholder="Select State"
                              >
                                {state.stateLists.map((state, i) => {
                                  return (
                                    <Option key={i} value={state.stateCode}>
                                      {state.state}
                                    </Option>
                                  );
                                })}
                              </Select>
                            </Form.Item>
                          </div>
                        </Col>
                      </Row>
                      <Row>
                        <Col sm={12} md={6}>
                          <div>
                            <label>City</label>
                            <Form.Item
                              name="cityName"
                              rules={[
                                {
                                  required: true,
                                  message: "Please select your City.",
                                },
                              ]}
                            >
                              <Select
                                getPopupContainer={(trigger) => trigger.parentNode}
                                showSearch
                                onSelect={onSetectCity}
                                placeholder="Select City"
                              >
                                {state.cityLists.map((city, i) => {
                                  return (
                                    <Option key={i} value={city.city}>
                                      {city.city}
                                    </Option>
                                  );
                                })}
                              </Select>
                            </Form.Item>
                          </div>
                        </Col>
                        <Col sm={12} md={6}>
                          <div>
                            <label>Branch</label>
                            <Form.Item
                              name="branch"
                              rules={[
                                {
                                  required: true,
                                  message: "Please select your Branch.",
                                },
                              ]}
                            >
                              <Select
                                getPopupContainer={(trigger) => trigger.parentNode}
                                autoComplete="none"
                                showSearch
                                onSelect={onSetectBranch}
                                placeholder="Select Branch"
                              >
                                {state.branchLists.map((branch, i) => {
                                  return (
                                    <Option key={i} value={branch.branchName}>
                                      {branch.branchName}
                                    </Option>
                                  );
                                })}
                              </Select>
                            </Form.Item>
                          </div>
                        </Col>
                      </Row>
                      <Row>
                        <Col sm={12} md={6}>
                          <div>
                            <label>Account Number</label>
                            <Form.Item
                              name="accountNo"
                              rules={[
                                {
                                  required: true,
                                  message: "Please input your Account Number.",
                                },
                                ...inputValidations.accountNumber(props.state.recvCountryCode),
                              ]}
                            >
                              <Input.Password
                                autoComplete="none"
                                className="input_account_no"
                                onChange={onChangeAccountNumberHandler}
                                placeholder="Enter your Account Number"
                                onPaste={(e) => {
                                  e.preventDefault();
                                  return false;
                                }}
                                onCopy={(e) => {
                                  e.preventDefault();
                                  return false;
                                }}
                                visibilityToggle={false}
                              />
                            </Form.Item>
                          </div>
                        </Col>
                        <Col sm={12} md={6}>
                          <div>
                            <label>Confirm Account Number</label>
                            <Form.Item
                              name="accConNum"
                              rules={[
                                {
                                  required: true,
                                  message: "Please input your Confirm Account Number.",
                                },
                                ...inputValidations.accountNumber(props.state.recvCountryCode),
                                ({ getFieldValue }) => ({
                                  validator(rule, value) {
                                    if (!value || getFieldValue("accountNo") === value) {
                                      return Promise.resolve();
                                    }
                                    return Promise.reject(
                                      "The two account number that you entered do not match!",
                                    );
                                  },
                                }),
                              ]}
                            >
                              <Input
                                className="input_account_no"
                                placeholder="Enter your Confirm Account Number"
                                onPaste={(e) => {
                                  e.preventDefault();
                                  return false;
                                }}
                                onCopy={(e) => {
                                  e.preventDefault();
                                  return false;
                                }}
                              />
                            </Form.Item>
                          </div>
                        </Col>
                      </Row>
                      <Row>
                        <Col>
                          <div className="Account-Type-Container">
                            <label>Account Type</label>
                            <Form.Item
                              rules={[
                                {
                                  required: true,
                                  message: "Please select your account type.",
                                },
                              ]}
                              name="accountType"
                            >
                              <Radio.Group
                                onChange={onChangeAccountTypeHandler}
                                className="d-flex"
                                style={{ gap: "1rem" }}
                              >
                                <Radio value={"S"}>Savings Account</Radio>
                                <Radio value={"NE"}>NRE</Radio>
                                <Radio value={"NO"}>NRO</Radio>
                              </Radio.Group>
                            </Form.Item>
                          </div>
                        </Col>
                        <Col className=" d-flex justify-content-end align-items-center">
                          <button
                            style={{ width: "10rem", fontWeight: 700 }}
                            className="btn btn-sm btn-light text-primary m-w-100"
                            type="submit"
                          >
                            Next
                          </button>
                        </Col>
                      </Row>
                    </div>
                  )}
                </TabPane>
              </Tabs>
            </div>
          )}
          {props.state.recvCountryCode !== "IN" && (
            <BankComponent
              state={state}
              onSelectBank={onSelectBank}
              onChangeAccountNumberHandler={onChangeAccountNumberHandler}
            />
          )}
        </>

        
      </Form>
    </div>
  );
}
