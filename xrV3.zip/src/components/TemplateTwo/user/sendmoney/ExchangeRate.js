import React, { useEffect, useReducer, useState } from "react";
import { useSelector } from "react-redux";
import { GuestAPI } from "../../../../apis/GuestAPI";
import { Form, Input, Select, notification, Spin, Space, Radio } from "antd";
import useHttp from "../../../../hooks/useHttp";

const { Option } = Select;

const ExchangeRate = (props) => {
  const ConfigReducer = useSelector((state) => state);
  const AuthReducer = useSelector((state) => state);
  const [rateLoader, setRateLoader] = React.useState(false);
  const [form] = Form.useForm();

  const defaultSettings = ConfigReducer.groupIdSettings.default;
  const [timeoutId, setTimeoutId] = React.useState("");
  const [amount, setAmount] = useState({
    sendAmount: 1000,
    recvAmount: 0,
  });

  const [state, setState] = useReducer((state, newState) => ({ ...state, ...newState }), {
    sendModeCode: defaultSettings.sendModeCode,
    programCode: defaultSettings.programCode,
    totalFee: 0,
    serviceCharge: 0,
    exRate: 0,
    amountPayable: 0,
    expectedDeliveryDate: "",
    transferFee: "",

    tax: "",

    sendCountryList: [],
    receiverCountryList: [],

    sendCountryCode: "GB",
    sendCurrencyCode: "GBP",
    recvCountryCode: "",
    recvCurrencyCode: "",

    paymentOptionsList: [],
  });

  const hookPostExchangeRate = useHttp(GuestAPI.postExchangeRate);
  const hookGetUserCountryList = useHttp(GuestAPI.countryList);
  const hookReceiverCountryList = useHttp(GuestAPI.receiverCountryList);
  const hookPaymentOptions = useHttp(GuestAPI.paymentOption);

  useEffect(() => {
    form.setFieldsValue({
      exchangePromgramCode: "FER",
      senderCountry: "GB",
    });
    getSendCountryList();
    if (state.recvCountryCode !== "") {
      loadExhangeRateHandler(1000, AuthReducer.sendCurrencyCode, "FER");
    }
  }, []);

  useEffect(() => {
    getReceiverCountryList();
  }, [state.sendCountryCode]);

  useEffect(() => {
    if (state.recvCountryCode !== "") {
      getPaymentOption();
      loadExhangeRateHandler(1000, state.sendCurrencyCode, "FER");
    }
  }, [state.recvCountryCode]);

  // useEffect(() => {
  //   loadExhangeRateHandler(1000, AuthReducer.sendCurrencyCode, "FER");
  // }, [state.programCode]);
  const getSendCountryList = () => {
    const dataCountry = {
      requestType: "SENDCOUNTRYLIST",
    };
    setState({ loading: true });
    hookGetUserCountryList.sendRequest(dataCountry, function (data) {
      setState({ loading: false });
      if (data.status === "S") {
        setState({ sendCountryList: data.responseData });
      }
    });
  };

  const getReceiverCountryList = (countryCode, currencyCode) => {
    const payload = {
      requestType: "RECVCOUNTRYLIST",
      sendCountry: countryCode ? countryCode : state.sendCountryCode,
      sendCurrency: currencyCode ? currencyCode : state.sendCurrencyCode,
    };
    hookReceiverCountryList.sendRequest(payload, function (data) {
      if (data.status === "S") {
        const recvCountryListData = data.responseData;
        setState({
          receiverCountryList: recvCountryListData,
          recvCountryCode: recvCountryListData[0].recvCountry,
          recvCurrencyCode: recvCountryListData[0].recvCurrency,
        });

        form.setFieldsValue({
          receiverCountry: recvCountryListData[0].recvCountry,
        });
      }
    });
  };

  const getPaymentOption = () => {
    const payload = {
      requestType: "PAYMENTOPTION",
      amount: "1000",
      sendCountryCode: state.sendCountryCode,
      sendCountryCurrency: state.sendCurrencyCode,
      recvCountryCode: state.recvCountryCode,
      recvCountryCurrency: state.recvCurrencyCode,
    };

    // setState({ loading: true });
    hookPaymentOptions.sendRequest(payload, function (data) {
      if (data.status === "S") {
        setState({ paymentOptionsList: data.responseData });
        setState({
          programCode: defaultSettings.programCode,
        });
        // setValue(defaultSettings.programCode);
        // setState({ loading: false });
      }
    });
  };

  const loadExhangeRateHandler = (valueSendAmount, __currency, prgmCode) => {
    let payload = {
      requestType: "EXCHANGERATE",
      pageName: "PRELOGIN",
      amount: valueSendAmount,
      recvNickName: "NEWRECV_SB",
      recvModeCode: "DC",
      // sendModeCode: "ACH",
      sendModeCode: state.sendModeCode,
      programCode: prgmCode,
      paymentMode1: "",
      paymentMode2: "",
      promoCode: "",
      loyaltyPoints: "",
      recvCountryCode: state.recvCountryCode,
      recvCurrencyCode: state.recvCurrencyCode,
      sendCountryCode: state.sendCountryCode,
      sendCurrencyCode: state.sendCurrencyCode,
      // enteredAmtCurrency: "GBP",
      enteredAmtCurrency: __currency,
    };
    setRateLoader(true);
    hookPostExchangeRate.sendRequest(payload, function (data) {
      setRateLoader(false);
      if (data.status == "S") {
        let expectedDeliveryDateStr = data.expectedDeliveryDate;
        let expectedDeliveryDate = expectedDeliveryDateStr.substring(
          0,
          expectedDeliveryDateStr.lastIndexOf(" ") + 1,
        );

        setAmount({
          ...amount,
          sendAmount: __currency === "GBP" ? data.enteredAmount : data.amountPayable,
          recvAmount: __currency === "INR" ? data.enteredAmount : data.recvAmount,
        });
        form.setFieldsValue({
          sendAmount: __currency === "GBP" ? data.enteredAmount : data.amountPayable,
          recvAmount: __currency === "INR" ? data.enteredAmount : data.recvAmount,
        });
        setState({
          // sendAmount: data.sendAmount,
          // recvAmount: data.recvAmount,
          amountPayable: data.sendAmount,
          totalFee: data.totalFee,
          serviceCharge: data.serviceCharge,
          exRate: data.exRate,
          expectedDeliveryDate: expectedDeliveryDate,

          transferFee: data.totalFee,

          tax: data.serviceTax,
        });
      } else {
        if (data.errorList) {
          notification.error({ message: data.errorList[0].error });
        } else {
          notification.error({ message: data.errorMessage });
        }
        setAmount({
          ...amount,
          recvAmount: 0,
        });
        setState({
          totalFee: 0,
          exRate: 0,
        });
      }
    });
  };

  const sendAmountHandler = (e, __currency) => {
    // setState({ sendAmount: e.target.value })
    clearTimeout(timeoutId);
    if (e.target.value) {
      setAmount({
        ...amount,
        sendAmount: e.target.value,
        // recvAmount: e.target.value,
      });

      const valueSendAmount = e.target.value;
      let valueTimeOutId = setTimeout(
        () => loadExhangeRateHandler(valueSendAmount, __currency, state.programCode),
        500,
      );
      setTimeoutId(valueTimeOutId);
    } else {
      setAmount({
        ...amount,
        sendAmount: "",
        recvAmount: "",
      });
    }
  };

  const recvAmountHandler = (e) => {
    clearTimeout(timeoutId);
    if (e.target.value) {
      setAmount({
        ...amount,
        // sendAmount: e.target.value,
        recvAmount: e.target.value,
      });

      const valueSendAmount = e.target.value;
      let valueTimeOutId = setTimeout(
        () => loadExhangeRateHandler(valueSendAmount, "INR", state.programCode),
        500,
      );
      setTimeoutId(valueTimeOutId);
    } else {
      setAmount({
        ...amount,
        recvAmount: "",
        sendAmount: "",
      });
    }
  };

  const handleChangeRadio = (e) => {
    const prgmCode = e.target.value;
    loadExhangeRateHandler(amount.sendAmount, AuthReducer.sendCurrencyCode, prgmCode);
    setState({ programCode: prgmCode });
  };

  const handleSenderCountry = (data, e) => {
    console.log("data", data);
    console.log("data", e["data-currency"]);

    getReceiverCountryList(data, e["data-currency"]);
  };

  const handleReceivingCountry = (data, e) => {
    setState({
      recvCountryCode: data,
      recvCurrencyCode: e["data-currency"],
    });
  };

  return (
    <div className="main">
      <Form form={form}>
        <div className="container sendmoney__page exchange_rate__page py-3">
          <div className="row my-5 ">
            <div className="col-12 col-md-6">
              <Form.Item
                className="form-item"
                name="exchangePromgramCode"
                rules={[
                  {
                    required: true,
                    message: "Please select your transfer options.",
                  },
                ]}
              >
                <Radio.Group
                  size="large"
                  // value=""
                  onChange={handleChangeRadio}
                >
                  <Space direction="horizontal">
                    {state.paymentOptionsList.map((clist, i) => {
                      return (
                        <Radio key={i} value={clist.programCode} style={{ color: "#fff" }}>
                          {clist.programName}
                        </Radio>
                      );
                    })}
                  </Space>
                </Radio.Group>
              </Form.Item>
            </div>
            <div className="col-12 col-md-6">
              <p className="text-info text-end fs-18 fw-600">
                Exchange Rate : {state.exRate} {state.recvCurrencyCode}
              </p>
            </div>
            <div
              style={{
                borderBottom: "1px solid white",
                marginBottom: "30px",
              }}
            ></div>

            {/* left */}
            <div className="col">
              <div className="row">
                <div className="col-12 col-md-7">
                  <Form.Item
                    className="form-item"
                    name="senderCountry"
                    rules={[
                      {
                        required: true,
                        message: "Please select sender country.",
                      },
                    ]}
                  >
                    <Select
                      size="large"
                      className="w-100"
                      placeholder="Select Sender Country"
                      onChange={handleSenderCountry}
                    >
                      {state.sendCountryList.map((clist, i) => {
                        return (
                          <Option
                            key={i}
                            data-currency={clist.sendCurrency}
                            value={clist.sendCountry}
                          >
                            <div className="d-flex align-items-center">
                              <img
                                alt="Sending Country"
                                src={`images/flags/${clist.sendCountry}.png`}
                                height={"24px"}
                                className="me-2"
                              />
                              <span>{clist.countryName}</span>
                            </div>
                          </Option>
                        );
                      })}
                    </Select>
                  </Form.Item>
                </div>
                <div className="col-12 col-md-5 d-flex justify-content-start">
                  <Form.Item
                    name="sendAmount"
                    className="w-100"
                    rules={[
                      {
                        required: true,
                        message: "Please input your amount.",
                      },
                    ]}
                  >
                    <Input
                      size="large"
                      className="exchange_amount_input"
                      addonBefore={state.sendCurrencyCode}
                      type="text"
                      defaultValue={amount.sendAmount}
                      value={amount.sendAmount}
                      onChange={(e) => sendAmountHandler(e, AuthReducer.sendCurrencyCode)}
                    />
                  </Form.Item>
                </div>
              </div>
            </div>

            {/* RIGHT  */}
            <div className="col-auto text-light text-center mb-3 mb-md-0 to_text">to</div>
            <div className="col">
              <div className="row">
                <div className="col-12 col-md-7">
                  <Form.Item
                    className="form-item"
                    name="receiverCountry"
                    rules={[
                      {
                        required: true,
                        message: "Please select receiver country.",
                      },
                    ]}
                  >
                    <Select
                      size="large"
                      className="w-100"
                      placeholder="Select Receiver Country"
                      onChange={handleReceivingCountry}
                    >
                      {state.receiverCountryList.map((clist, i) => {
                        return (
                          <Option
                            key={i}
                            data-currency={clist.recvCurrency}
                            value={clist.recvCountry}
                          >
                            <div className="d-flex align-items-center">
                              <img
                                alt="Receiver Country"
                                src={`images/flags/${clist.recvCountry}.png`}
                                height={"24px"}
                                className="me-2"
                              />
                              <span>{clist.countryName}</span>
                            </div>
                          </Option>
                        );
                      })}
                    </Select>
                  </Form.Item>
                </div>
                <div className="col-12 col-md-5 d-flex justify-content-start">
                  <Form.Item
                    name="recvAmount"
                    className="w-100"
                    rules={[
                      {
                        required: true,
                        message: "Please input your amount.",
                      },
                    ]}
                  >
                    <Input
                      size="large"
                      className="exchange_amount_input"
                      addonBefore={state.recvCurrencyCode}
                      type="text"
                      defaultValue={amount.recvAmount}
                      value={amount.recvAmount}
                      onChange={(e) => recvAmountHandler(e)}
                    />
                  </Form.Item>
                </div>
              </div>
            </div>
            {/* bottom */}
            {/* <div className="col-12 col-md-6 text-light mt-3">
              <div className="row">
                <div className="col-7 py-2 px-3">Transfer Fee :</div>
                <div className="col-5 py-2 px-3">
                  {AuthReducer.sendCurrencyCode} {state.transferFee}
                </div>
              </div>
              <div className="row">
                <div className="col-7 py-2 px-3">Service Charge :</div>
                <div className="col-5 py-2 px-3">
                  {AuthReducer.recvCurrencyCode} {state.serviceCharge}
                </div>
              </div>
              <div className="row">
                <div className="col-7 py-2 px-3">Tax :</div>
                <div className="col-5 py-2 px-3">
                  {AuthReducer.recvCurrencyCode} {state.tax}
                </div>
              </div>
            </div> */}
          </div>
        </div>
      </Form>
    </div>
  );
};

export default ExchangeRate;
