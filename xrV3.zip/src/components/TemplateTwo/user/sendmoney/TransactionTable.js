import React, {
  useState,
  useEffect,
  useReducer,
  Fragment,
  useRef,
} from "react";
import {
  Form,
  Table,
  Select,
  DatePicker,
  Input,
  Button,
  notification,
} from "antd";
import { SearchOutlined } from "@ant-design/icons";
import IconButton from "@mui/material/IconButton";
import CancelIcon from "@mui/icons-material/Cancel";
import { Link } from "react-router-dom";
import Swal from "sweetalert2";
import { config } from "../../../../config";
import { useSelector } from "react-redux";
import DefaultLayout from "../../layout/DefaultLayout";
import { encrypt, decrypt, publickey } from "../../../../helpers/makeHash";
import { TransactionAPI } from "../../../../apis/TransactionAPI";
import moment from "moment";
import { jsPDF } from "jspdf";
import * as autoTable from "jspdf-autotable";
import Grid from "@mui/material/Grid";
import { Tooltip } from "@mui/material";
import useHttp from "../../../../hooks/useHttp";
// import SearchIcon from "@mui/icons-material/Search";
// import SystemUpdateAltIcon from "@mui/icons-material/SystemUpdateAlt";
import PaymentIcon from "@mui/icons-material/Payment";
// import PrintIcon from "@mui/icons-material/Print";
import DraftsOutlinedIcon from "@mui/icons-material/DraftsOutlined";
import SubHeader from "../../layout/SubHeader";
import html2canvas from "html2canvas";
import { useReactToPrint } from "react-to-print";
import SofortTrnStatusLink from "./SofortTrnStatusLink";
import { ProfileAPI } from "../../../../apis/ProfileAPI";
import Spinner from "../../../../reusable/Spinner";
import SvgIcon from "@mui/material/SvgIcon";
import { ReactComponent as SearchIcon } from "../../../../assets/images/XR/search.svg";
import { ReactComponent as DownloadIcon } from "../../../../assets/images/XR/download.svg";
import { ReactComponent as PrintIcon } from "../../../../assets/images/XR/print.svg";

const XrPdf = React.lazy(() => import("./Invoice/XR"));
const KcbPdf = React.lazy(() => import("./Invoice/KCB"));

const { Option } = Select;
const { RangePicker } = DatePicker;

const transactionStatusList = [
  { code: 152, name: "Ready for Processing" },
  { code: 203, name: "Amount delivered" },
  { code: 301, name: "Transaction Closed" },
];

export default function TransactionTable(props) {
  const pdfRef = useRef(null);
  const AuthReducer = useSelector((state) => state);
  const [loading, setLoader] = useState(false);
  const [listType, setListType] = useState(null);
  const [fdateRange, setFdateRange] = useState([]);
  const [loginId, setLoginId] = useState("");

  const [state, setState] = useReducer(
    (state, newState) => ({ ...state, ...newState }),
    {
      transactionLists: [],
      clientId: AuthReducer.clientId,
      groupId: AuthReducer.groupId,
      sessionId: AuthReducer.sessionId,
      userID: AuthReducer.userID,
      trasactionStatus: [{ name: "Status 1" }, { name: "Status 2" }],
      XrtnNumber: "",
      rgtn: "",
      transactionReceiverName: [],
      pdfDetails: "",
      txnStatus: "",
      txnReceiverName: "",
      coreBankDetailsList: [],
    }
  );

  const hookGetTransactionLists = useHttp(TransactionAPI.transactionLists);
  const hookGetTxnStatement = useHttp(TransactionAPI.txnStatement);
  const hookGetTransactionReceiptDetails = useHttp(
    TransactionAPI.transactionReceiptDetails
  );
  const hookCancelTransaction = useHttp(TransactionAPI.cancelTransaction);
  const hookGetReceiverLists = useHttp(TransactionAPI.receiverLists);
  const hookGetCoreBankDetails = useHttp(TransactionAPI.getCoreBankDetails);
  const hookProfileApi = useHttp(ProfileAPI.getProfile);
  useEffect(async () => {
    getTransactionList(null);
  }, [state.txnStatus, state.txnReceiverName]);

  useEffect(async () => {
    getReceiverNameLists();
    getCoreBankDetails();
    getProfileHandler();
  }, []);

  const getProfileHandler = () => {
    let payload = {
      requestType: "GETPROFILE",
      userId: state.userID,
    };
    hookProfileApi.sendRequest(payload, (data) => {
      if (data.status == "S") {
        setLoginId(data.loginId);
      } else {
        notification.error({ message: data.errorMessage });
      }
    });
  };

  const getCoreBankDetails = () => {
    const payload = {
      requestType: "CORRBANKDTLS",
      userId: state.userID,
      sendCountryCode: "GB",
      sendCurrencyCode: "GBP",
      sendModeCode: "CIP",
    };

    setLoader(true);
    hookGetCoreBankDetails.sendRequest(payload, function (data) {
      if (data.status == "S") {
        setState({ coreBankDetailsList: data.responseData });
        setLoader(false);
      }
    });
  };

  const getTransactionList = (isFav) => {
    let transactiondata = {
      requestType: "TRANSACTIONLIST",
      bookingDateFrom: fdateRange.length == 2 ? fdateRange[0] : "",
      bookingDateTo: fdateRange.length == 2 ? fdateRange[1] : "",
      favouriteFlag: isFav,
      recordsPerRequest: "",
      recvNickName: state.txnReceiverName,
      startIndex: "-1",
      status: state.txnStatus,
      txnRefNo: "",
      userId: state.userID,
    };
    setLoader(true);
    hookGetTransactionLists.sendRequest(transactiondata, function (data) {
      setLoader(false);
      let resData = [];
      if (data.errorMessage == null) {
        data.responseData.forEach((detail, i) => {
          let data = {
            key: i,
            date_sent: `${moment(detail.bookingDate).format(
              "DD-MMM-YYYY"
            )} \n ${moment(detail.bookingDate).format("hh:mm A")}`,
            description: ``,
            sent_to: `${detail.receiverName} \n${
              detail.recvCountryCode === "IN" ? "India" : detail.recvCountryCode
            }`,
            amount: `${detail.amount}`,
            amount_deliverd: `${detail.recvAmount}`,

            c_promocode_rate: `${detail.category_promoCodeRate}`,
            rate: `${detail.exchangeRate}`,

            track_id_ref_no: `${detail.txnRefNo}`,
            rgtn: `${detail.rgtn}`,
            txn_status: `${detail.txnRefNo} \n${detail.txnStatus}`,
            date_delivered: `${
              detail.txnCompletedDate != ""
                ? moment(detail.txnCompletedDate).format("DD-MMM-YYYY")
                : ""
            }`,
            bookingDate: detail.bookingDate,
            bookingDateTZ: detail.bookingDateTZ,
            txnStatusCode: detail.txnStatusCode,
          };

          resData.push(data);
        });
        setState({ transactionLists: resData });
      } else {
        setState({ transactionLists: [] });
      }
    });
  };

  const getReceiverNameLists = () => {
    const payload = {
      requestType: "GETRECVLIST",
      userId: state.userID,
      favouriteFlag: "",
      startIndex: "0",
      recordsPerRequest: "",
      search: "",
      statusFlag: "VALID",
    };

    hookGetReceiverLists.sendRequest(payload, function (data) {
      if (data.status == "S") {
        setState({ transactionReceiverName: data.responseData });
      }
    });
  };

  const handleTransactionStatus = (data) => {
    setState({ txnStatus: data });
  };

  const handleTransactionReceiver = (data) => {
    setState({ txnReceiverName: data });
  };

  const txnStatement = () => {
    let payload = {
      requestType: "TXNSTATEMENT",
      txnRefNo: "",
      recvNickName: "",
      status: "",
      bookingDateFrom: fdateRange.length == 2 ? fdateRange[0] : "",
      bookingDateTo: fdateRange.length == 2 ? fdateRange[1] : "",
      favouriteFlag: "",
      userId: state.userID,
    };

    hookGetTxnStatement.sendRequest(payload, function (data) {
      if (data.status == "S") {
        notification.success({ message: data.message });
      } else {
        notification.success({ message: data.errorMessage });
      }
    });
  };

  const handleSearch = (selectedKeys, confirm) => {
    confirm();
  };

  const handleReset = (clearFilters) => {
    clearFilters();
  };

  const onCancelTranscationHandler = (rgtn) => {
    // alert(rgtn);
    const payloadCancelTrn = {
      requestType: "CANCELTRANSACTIONS",
      rgtn: rgtn,
      userId: state.userID,
      // txnRefNo: txnRefno,
    };

    hookCancelTransaction.sendRequest(payloadCancelTrn, function (data) {
      if (data.status == "S") {
        Swal.fire({
          title: "Success",
          text: data.message,
          icon: "success",
          confirmButtonColor: "#2dbe60",
        }).then((result) => {
          if (result.isConfirmed) {
            getTransactionList(null);
          }
        });
      }
    });
  };

  const onClickTrack = () => {};

  const onClickViewAndDownload = (txnRefno) => {
    const payload = {
      requestType: "TXNDETAILS",
      rgtn: "",
      txnRefNo: txnRefno,
      userId: state.userID,
    };

    hookGetTransactionReceiptDetails.sendRequest(payload, function (data) {
      if (data.status == "S") {
        setState({ pdfDetails: data });
        downloadPdf(txnRefno);
      }
    });
  };

  const downloadPdf = (txnRefno) => {
    var txnRefNumber = txnRefno;
    html2canvas(pdfRef.current, {
      windowWidth: "1200px",
      scale: 1,
    }).then((canvas) => {
      const imgData = canvas.toDataURL("image/png");
      const pdf = new jsPDF();
      pdf.addImage(imgData, "JPEG", 0, 0);
      // pdf.output('dataurlnewwindow');
      pdf.save(`${txnRefNumber}.pdf`);
    });
  };

  const printPdf = (txnRefno) => {
    const payload = {
      requestType: "TXNDETAILS",
      rgtn: "",
      txnRefNo: txnRefno,
      userId: state.userID,
    };

    hookGetTransactionReceiptDetails.sendRequest(payload, function (data) {
      if (data.status == "S") {
        setState({ pdfDetails: data });
        handlePrint();
      }
    });
  };

  const handlePrint = useReactToPrint({
    content: () => pdfRef.current,
  });

  const columns = [
    { title: "Date", dataIndex: "date_sent" },
    {
      title: "Username",
      dataIndex: "sent_to",
    },
    { title: "Description", dataIndex: "description" },
    { title: "Amount", dataIndex: "amount" },
    {
      title: "Status",
      dataIndex: "",
      render: (text, record, index) => {
        return (
          <>
            {record.txn_status} <br />
            {record.txnStatusCode !== "301" && (
              <SofortTrnStatusLink loginId={loginId} rgtn={record.rgtn} />
            )}
          </>
        );
      },
    },
    {
      title: "More Options",
      dataIndex: "",
      width: "20%",
      align: "right",
      render: (text, record, index) => {
        // console.log("record", record);

        let diffTime = moment(new Date()).diff(new Date(record.bookingDate));

        let duration = moment.duration(diffTime);
        let asMinutes = duration.asMinutes();
        // console.log(duration.asMinutes());
        return (
          <>
            {asMinutes <= 30 && (
              <>
                {/* txnStatusCode 301 for Close and cancel transcation */}
                {record.txnStatusCode !== "301" && (
                  <Tooltip title="Cancel Transcation">
                    <IconButton
                      color="error"
                      component="span"
                      onClick={() => {
                        onCancelTranscationHandler(record.rgtn);
                      }}
                    >
                      <CancelIcon />
                    </IconButton>
                  </Tooltip>
                )}
              </>
            )}

            <Link
              className="text-info-dark"
              to={{
                pathname: "/track-money-transfer",
              }}
              state={{ rgtn: record.rgtn }}
            >
              <SvgIcon
                component={SearchIcon}
                fontSize="medium"
                viewBox="0 0 24 24"
              />
            </Link>
            <button
              style={{
                background: "transparent",
                border: "0",
              }}
              className="text-info-dark"
              onClick={() => onClickViewAndDownload(record.track_id_ref_no)}
            >
              <SvgIcon
                component={DownloadIcon}
                fontSize="medium"
                viewBox="0 0 18 24"
              />
            </button>
            <button
              style={{
                background: "transparent",
                border: "0",
              }}
              className="text-info-dark"
              onClick={() => printPdf(record.track_id_ref_no)}
            >
              <SvgIcon
                component={PrintIcon}
                fontSize="medium"
                viewBox="0 0 24 24"
              />
            </button>
            {/* <DraftsOutlinedIcon /> */}
          </>
        );
      },
    },
    {
      title: "",
      dataIndex: "",
      width: "10%",
      align: "right",
      className: "border-bottom-0 tw-20 text-end",
      render: (text, record, index) => {
        let diffTime = moment(new Date()).diff(new Date(record.bookingDate));
        let duration = moment.duration(diffTime);
        let asMinutes = duration.asMinutes();
        return (
          <>
            <Link
              className="mx-2 my-2"
              to={{
                pathname: "/new-transaction",
              }}
              state={{ rgtn: record.rgtn, txnRefNo: record.track_id_ref_no }}
            >
              <button className="btn btn-primary text-white btn-sm fs-10 fw-600">
                Repeat Remittance
              </button>
            </Link>
          </>
        );
      },
    },
  ];

  const onSubmitSearch = () => {
    let transactiondata = {
      requestType: "TRANSACTIONLIST",
      bookingDateFrom: fdateRange.length == 2 ? fdateRange[0] : "",
      bookingDateTo: fdateRange.length == 2 ? fdateRange[1] : "",
      favouriteFlag: null,
      recordsPerRequest: "",
      recvNickName: "",
      startIndex: "-1",
      status: "",
      txnRefNo: state.XrtnNumber,
      userId: state.userID,
    };

    hookGetTransactionLists.sendRequest(transactiondata, function (data) {
      let resData = [];
      if (data.errorMessage == null) {
        data.responseData.forEach((detail, i) => {
          let data = {
            key: i,
            date_sent: `${moment(detail.bookingDate).format(
              "DD-MMM-YYYY"
            )} \n ${moment(detail.bookingDate).format("hh:mm A")}`,
            description: ``,
            sent_to: `${detail.receiverName} \n${
              detail.recvCountryCode === "IN" ? "India" : detail.recvCountryCode
            }`,
            amount: `${detail.amount}`,
            amount_deliverd: `${detail.recvAmount}`,

            c_promocode_rate: `${detail.category_promoCodeRate}`,
            rate: `${detail.exchangeRate}`,

            track_id_ref_no: `${detail.txnRefNo}`,
            rgtn: `${detail.rgtn}`,
            txn_status: `${detail.txnRefNo} \n${detail.txnStatus}`,
            date_delivered: `${
              detail.txnCompletedDate != ""
                ? moment(detail.txnCompletedDate).format("DD-MMM-YYYY")
                : ""
            }`,
            bookingDate: detail.bookingDate,
            bookingDateTZ: detail.bookingDateTZ,
          };

          resData.push(data);
        });
        setState({ transactionLists: resData });
      } else {
        setState({ transactionLists: [] });
      }
    });
  };

  const onSubmitDate = () => {
    let transactiondata = {
      requestType: "TRANSACTIONLIST",
      bookingDateFrom: fdateRange.length == 2 ? fdateRange[0] : "",
      bookingDateTo: fdateRange.length == 2 ? fdateRange[1] : "",
      favouriteFlag: null,
      recordsPerRequest: "",
      recvNickName: "",
      startIndex: "-1",
      status: "",
      txnRefNo: "",
      userId: state.userID,
    };

    hookGetTransactionLists.sendRequest(transactiondata, function (data) {
      let resData = [];
      if (data.errorMessage == null) {
        data.responseData.forEach((detail, i) => {
          let data = {
            key: i,
            date_sent: `${moment(detail.bookingDate).format(
              "DD-MMM-YYYY"
            )} \n ${moment(detail.bookingDate).format("hh:mm A")}`,
            description: ``,
            sent_to: `${detail.receiverName} \n${
              detail.recvCountryCode === "IN" ? "India" : detail.recvCountryCode
            }`,
            amount: `${detail.amount}`,
            amount_deliverd: `${detail.recvAmount}`,

            c_promocode_rate: `${detail.category_promoCodeRate}`,
            rate: `${detail.exchangeRate}`,

            track_id_ref_no: `${detail.txnRefNo}`,
            rgtn: `${detail.rgtn}`,
            txn_status: `${detail.txnRefNo} \n${detail.txnStatus}`,
            date_delivered: `${
              detail.txnCompletedDate != ""
                ? moment(detail.txnCompletedDate).format("DD-MMM-YYYY")
                : ""
            }`,
            bookingDate: detail.bookingDate,
            bookingDateTZ: detail.bookingDateTZ,
          };

          resData.push(data);
        });
        setState({ transactionLists: resData });
      } else {
        setState({ transactionLists: [] });
      }
    });
  };

  const PdfPage = () => {
    const pdfAuthGroupId = useSelector((state) => state);
    switch (pdfAuthGroupId.groupId) {
      case "KCB":
        return (
          <KcbPdf
            ref={pdfRef}
            pdfDetails={state.pdfDetails}
            bankDetails={state.coreBankDetailsList}
          />
        );
        break;
      case "XR":
        return (
          <XrPdf
            ref={pdfRef}
            pdfDetails={state.pdfDetails}
            bankDetails={state.coreBankDetailsList}
          />
        );
        break;
      default:
        break;
    }
  };

  return (
    <Fragment>
      <div style={{ position: "absolute", marginTop: "-2000px" }}>
        <PdfPage />
      </div>
      <Spinner spinning={loading} delay={100}>
        <div className="py-4 mb-4">
          <div className="row g-2">
            <div className="col-8 col-md-4">
              <Form.Item
                className="form-item"
                name="XrtnNumber"
                rules={[
                  {
                    required: true,
                    message: "Please select XRTN Number.",
                  },
                ]}
              >
                <Input
                  size="large"
                  className="bg-secondary-light"
                  onChange={(e) => setState({ XrtnNumber: e.target.value })}
                  placeholder="XRTN Number"
                />
              </Form.Item>
            </div>
            <div className="col-4 col-md-3">
              <button
                className="btn btn-info btn-sm XrtnNumberBtn"
                onClick={onSubmitSearch}
              >
                Search
              </button>
            </div>
          </div>
          <Grid container justify="center" alignItems="center" spacing={3}>
            {listType == "statement" && (
              <Grid item lg={12} md={12} sm={12}>
                <h3>Receive an e-statement on your registered Email ID </h3>
                <p>
                  Choose a date range you wish to receive an e-statement for. A
                  request will be placed and you will receive the e-statement
                  within 24 hours.
                </p>
              </Grid>
            )}
          </Grid>
        </div>

        {listType != "statement" && (
          <div className="py-4 mb-4">
            <div className="row">
              <div className="col-12 col-md-6">
                <RangePicker
                  className="input-picker-info"
                  allowClear
                  format="DD-MM-YYYY"
                  onChange={(value, dateString) => {
                    value !== null
                      ? setFdateRange(dateString)
                      : setFdateRange([]);
                  }}
                />
                <button
                  className="btn btn-info btn-sm ms-2 fw-800 daterangebtn"
                  onClick={onSubmitDate}
                >
                  Submit
                </button>
              </div>

              <div className="col-12 col-md-6 mt-3 mt-md-0">
                <div className="row justify-content-md-end">
                  <div className="col-6 col-md-4">
                    <Form.Item
                      className="form-item input-select-info"
                      name="transactionStatus"
                      rules={[
                        {
                          required: true,
                          message: "Please select Status.",
                        },
                      ]}
                    >
                      <Select
                      className="txnlist_status_dropdown"
                        placeholder="Select Status"
                        onChange={handleTransactionStatus}
                      >
                        {transactionStatusList.map((clist, i) => {
                          return (
                            <Option key={i} value={clist.code}>
                              {clist.name}
                            </Option>
                          );
                        })}
                      </Select>
                    </Form.Item>
                  </div>
                  <div className="col-6 col-md-4">
                    <Form.Item
                      className="form-item input-select-info"
                      name="receiverName"
                      rules={[
                        {
                          required: true,
                          message: "Please select receiver.",
                        },
                      ]}
                    >
                      <Select className="txnlist_receiver_dropdown"
                        placeholder="Select Receiver"
                        onChange={handleTransactionReceiver}
                      >
                        {state.transactionReceiverName.map((clist, i) => {
                          return (
                            <Option key={i} value={clist.nickName}>
                              {clist.firstName} {clist.lastName}
                            </Option>
                          );
                        })}
                      </Select>
                    </Form.Item>
                  </div>
                </div>
              </div>
            </div>

            {/* <Link
                    to={"/new-transaction"}
                    className="btn btn-primary text-white btn-sm mb-3"
                  >
                    New Transaction
                  </Link> */}

            {
              <Table
                style={{ whiteSpace: "pre" }}
                columns={columns}
                dataSource={state.transactionLists}
                pagination={state.transactionLists.length > 10}
              />
            }
            <div className="text-end mt-3">
              <Link to={"/"}>
                <button className="btn btn-sm btn-light text-primary px-3">
                  Go to dashboard
                </button>
              </Link>
            </div>
          </div>
        )}
      </Spinner>
    </Fragment>
  );
}
