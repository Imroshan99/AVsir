import React, { useEffect, useReducer, useState } from "react";
import Typography from "@mui/material/Typography";
import List from "@mui/material/List";
import ListItem from "@mui/material/ListItem";
import ListItemText from "@mui/material/ListItemText";
import Grid from "@mui/material/Grid";
import { Form, Checkbox, Input, Space, Radio, Modal, notification, AutoComplete } from "antd";
import { Link } from "react-router-dom";
import { useSelector } from "react-redux";
import useHttp from "../../../../../hooks/useHttp";
import { TransactionAPI } from "../../../../../apis/TransactionAPI";
import ViewTransactionDetails from "./ViewTransactionDetails";
import Swal from "sweetalert2";
import KYCModal from "../../../auth/KYCModal";
import { DeleteFilled } from "@ant-design/icons";
import axios from "axios";
import moment from "moment";
import { GuestAPI } from "../../../../../apis/GuestAPI";

export default function Confirm(props) {
  const [form] = Form.useForm();

  const AuthReducer = useSelector((state) => state);
  const [viewDetails, setViewDetails] = useState(false);
  const [promoCode, setPromoCode] = useState("");
  const [referalCode, setReferalCode] = useState("");
  const [promoLists, setPromoLists] = useState([]);
  const [isModalVisible, setIsModalVisible] = useState(false);
  const currentURL = window.location.origin;
  const [state, setState] = useReducer((state, newState) => ({ ...state, ...newState }), {
    referalDiscountDisable: false,
    couponCodeDisable: false,
    redeemValueState: 0,
    toggleCongoText: false,
    toggleCongoTextCoupon: false,
    offerModal: false,
    showOffer: false,
    offers: [],
  });

  useEffect(() => {
    // promoListHandler();
    // getOffers();
    getBannerList();
    setReferalCode("");
    setPromoCode("");
    setState({
      referalDiscountDisable: false,
      couponCodeDisable: false,
    });

    // remove referral code
    props.setState({ couponCode: false });
    props.setState({
      promoCode: "",
      promoType: "",
    });
    // const _promoCode = props.state.promoCode;

    // if (_promoCode.startsWith("RAF-")) {
    // setReferalCode(_promoCode.replace("RAF-GB-GBP-IN-INR-", ""));
    // setState({
    //   referalDiscountDisable: true, couponCodeDisable: true
    // });

    // } else {
    //   setPromoCode(props.state.promoCode);
    //   if (props.state.promoCode !== "") {
    //     setState({ referalDiscountDisable: true, couponCodeDisable: true });
    //   }
    // }
  }, []);

  useEffect(() => {
    if (parseInt(props.state.totalDeliveredAmount) <= 0) {
      notification.error({ message: "Sending Amount should be higher than 0" });
    }
  }, [props.state.totalDeliveredAmount]);
  console.log("promoType", props.state.promoType);
  const column1 = [
    {
      name: "Sending Mode:",
      price: props.state.selectedPaymentMethod,
    },
    {
      name: "Sending Amount",
      price: props.state.sendingAmount + " " + props.state.sendingCurrencyCode,
    },
    ...(props.state.promoType === "AD"
      ? [
          {
            name: "Coupon Discount",
            price:
              (props.state.sendAmtbenefit ? props.state.sendAmtbenefit : 0) +
              " " +
              props.state.sendingCurrencyCode,
          },
          {
            name: "Amount Payable",
            price: props.state.totalDeliveredAmount + " " + props.state.sendingCurrencyCode,
            txtColorCls: "text-info",
          },
        ]
      : []),
    {
      name: "Transfer Fee",
      price: props.state.transferFee + " " + props.state.sendingCurrencyCode,
    },
    {
      name: "Total Delivered",
      price: props.state.sendAmount + " " + props.state.sendingCurrencyCode,
    },
  ];

  const column2 = [
    {
      name: "Fixed Exchange Rate:",
      price: `1 ${props.state.sendCurrencyCode} = ${props.state.displayExRate} ${props.state.recvCurrencyCode}`,
    },
    {
      name: "Exchange Rate As On:",
      price: props.state.initiateDate,
    },
    {
      name: "Receiving Amount:",
      price: props.state.recvAmount + " " + props.state.recvCurrencyCode,
    },
  ];

  const hookApplyPromoLists = useHttp(TransactionAPI.promoLists);
  const hookUserRedeemCheck = useHttp(TransactionAPI.redeemCheck);
  const hookBannerList = useHttp(GuestAPI.getBannerList);
  const handleTermsCondition = () => {
    props.getComputeExchangeRate(props.state.sendingAmount, "FORWARD", "TXNREVIEW");
  };

  const onFinishAccount = (value) => {
    if (AuthReducer.userKYC === "DOB") {
      Swal.fire({
        title: "WARNING",
        text: "Complete your KYC details to book and process this transaction.",
        icon: "warning",
        confirmButtonColor: "#2dbe60",
        allowOutsideClick: false,
        confirmButtonText: `Complete your KYC`,
      }).then((result) => {
        if (result.isConfirmed) {
          setIsModalVisible(true);
        }
      });
    } else {
      props.handleSubmit();
    }
  };

  const handleCouponCodeRadio = (code) => {
    props.setState({ couponCode: false });
    props.setState({ promoCode: "" });
  };

  const handleCouponCodeText = (e) => {
    const inputValue = e.target.value;
    inputValue === ""
      ? setState({ referalDiscountDisable: false, couponCodeDisable: false })
      : setState({ referalDiscountDisable: true, couponCodeDisable: false });
    setPromoCode(inputValue);
    setReferalCode("");
    // if (value === "") {
    //   props.setState({
    //     promoCode: "",
    //     promoType: "",
    //   });
    // }
  };
  const getBannerList = () => {
    let payload = {
      requestType: "BANNERLIST",
      countryCode: AuthReducer.sendCountryCode,
      position: "HOMEPAGE_TOP",
    };
    props.setState({ loading: true });
    hookBannerList.sendRequest(payload, function (data) {
      props.setState({ loading: false });
      if (data.status === "S") {
        const obj = data.responseData;
        setState({
          offers: [
            {
              title: obj[0].header,
              subText1: obj[0].subHeader,
              subText2: obj[0].bannerDesc,
              img: obj[0].filePath,
            },
          ],
        });
      }
    });
  };

  const handleReferalCodeChange = (e) => {
    const inputValue = e.target.value;
    inputValue === ""
      ? setState({
          // redeemValueState: e.target.value,
          referalDiscountDisable: false,
          couponCodeDisable: false,
        })
      : setState({
          // redeemValueState: e.target.value,
          referalDiscountDisable: false,
          couponCodeDisable: true,
        });
    setReferalCode(inputValue);
  };

  const clearCouponCodeHandler = (e) => {
    props.setState({
      promoCode: "",
      promoType: "",
    });
    setPromoCode("");
    setReferalCode("");
    setState({
      referalDiscountDisable: false,
      couponCodeDisable: false,
    });
  };
  // const getOffers = () => {
  //   axios.get(`${currentURL}/offers.json`).then((res) => {
  //     setState({ offers: res.data });
  //     let expiry = res.data[0].expiry;
  //     if (moment(expiry).fromNow().includes("ago")) {
  //       setState({ showOffer: false });
  //     } else {
  //       setState({ showOffer: true });
  //     }
  //   });
  // };

  const applyPromoCode = (e) => {
    setState({ toggleCongoText: false });
    e.preventDefault();
    props.setState({ couponCode: false, loading: true });

    if (promoCode) {
      setState({ toggleCongoTextCoupon: true });
      const payload = {
        requestType: "PROMOLISTS",
        programCode: "FERINST",
        promoAmount: props.state.sendingAmount,
        promoCode: promoCode,
        recvCountryCode: AuthReducer.recvCountryCode,
        recvCurrencyCode: AuthReducer.recvCurrencyCode,
        recvModeCode: "DC",
        sendCountryCode: AuthReducer.sendCountryCode,
        sendCurrencyCode: AuthReducer.sendCurrencyCode,
        sendModeCode: "CIP",
        userId: props.state.userID,
      };

      hookApplyPromoLists.sendRequest(payload, function (data) {
        props.setState({ loading: false });
        form.setFieldsValue({ readTermsConditions: false });
        if (data.status === "S") {
          const { promoType } = data.responseData[0];
          props.setState({
            promoCode: promoCode,
            promoType: promoType,
          });
          setState({
            couponCodeDisable: true,
          });
        } else {
          notification.error({ message: data.errorMessage });
        }
      });
    } else {
      props.setState({ loading: false });
      alert("please enter promo code!");
    }
  };

  const promoListHandler = () => {
    const payload = {
      requestType: "PROMOLISTS",
      programCode: "FERINST",
      promoAmount: props.state.sendingAmount,
      promoCode: "",
      recvCountryCode: "IN",
      recvCurrencyCode: "INR",
      recvModeCode: "DC",
      sendCountryCode: AuthReducer.sendCountryCode,
      sendCurrencyCode: AuthReducer.sendCurrencyCode,
      sendModeCode: "CIP",
      userId: props.state.userID,
    };

    hookApplyPromoLists.sendRequest(payload, function (data) {
      props.setState({ loading: false });
      form.setFieldsValue({ readTermsConditions: false });
      if (data.status === "S") {
        const _promoList = data.responseData;
        if (_promoList && _promoList.length) {
          const pList = data.responseData.map((item) => ({
            value: item.promoCode,
          }));
          setPromoLists(pList);
        }
      } else {
        notification.error({ message: data.errorMessage });
      }
    });
  };
  const userRedeemCheck = (e) => {
    e.preventDefault();
    setState({ toggleCongoTextCoupon: false });

    // regex for amount is number or not
    const checkNumber = /^[0-9\b]+$/.test(referalCode);

    if (referalCode === "" || !checkNumber) {
      alert("please enter valid referral amount!");
    } else {
      props.setState({ loading: true });
      setState({ toggleCongoText: true });
      let payload = {
        requestType: "USERREDEEMCHECK",
        recvCountryCode: AuthReducer.recvCountryCode,
        recvCurrencyCode: AuthReducer.recvCurrencyCode,
        recvModeCode: "DC",
        sendCountryCode: AuthReducer.sendCountryCode,
        sendCurrencyCode: AuthReducer.sendCurrencyCode,
        txnAmount: props.state.sendingAmount,
        redeemValue: referalCode,
        userId: props.state.userID,
      };
      hookUserRedeemCheck.sendRequest(payload, (res) => {
        if (res.status === "S") {
          const payloadPromoList = {
            requestType: "PROMOLISTS",
            programCode: "FERINST",
            promoAmount: props.state.sendingAmount,
            // promoCode: promoCode,
            promoCode: `RAF-${AuthReducer.sendCountryCode}-${AuthReducer.sendCurrencyCode}-${AuthReducer.recvCountryCode}-${AuthReducer.recvCurrencyCode}-${referalCode}`,
            recvCountryCode: AuthReducer.recvCountryCode,
            recvCurrencyCode: AuthReducer.recvCurrencyCode,
            recvModeCode: "DC",
            sendCountryCode: AuthReducer.sendCountryCode,
            sendCurrencyCode: AuthReducer.sendCurrencyCode,
            sendModeCode: "CIP",
            userId: props.state.userID,
          };

          hookApplyPromoLists.sendRequest(payloadPromoList, function (data) {
            props.setState({ loading: false });
            form.setFieldsValue({ readTermsConditions: false });
            if (data.status === "S") {
              const { promoType } = data.responseData[0];
              props.setState({
                promoCode: data.responseData[0].promoCode,
                promoType: promoType,
              });
              setState({
                referalDiscountDisable: true,
              });
            } else {
              notification.error({ message: data.errorMessage });
            }
          });
        } else {
          props.setState({ loading: false });
          notification.error({ message: res.errorMessage });

          let errors = [];
          res.data.errorList.forEach((error, i) => {
            let errorData = {
              name: error.field,
              errors: [error.error],
            };
            errors.push(errorData);
          });

          if (errors.length > 0) form.setFields(errors);
        }
      });
    }
  };

  return (
    <React.Fragment>
      <KYCModal isModalVisible={isModalVisible} setIsModalVisible={setIsModalVisible} />
      <Modal
        className="XR__home_promo_modal"
        width={"auto"}
        centered
        visible={state.offerModal}
        onCancel={() => setState({ offerModal: false })}
        footer={null}
      >
        <img src={state?.offers[0]?.img}></img>
      </Modal>
      <Modal
        className="primary"
        centered
        visible={viewDetails}
        onCancel={() => setViewDetails(false)}
        width={1000}
        footer={null}
      >
        <ViewTransactionDetails state={props.state} />
      </Modal>

      <Form form={form} onFinish={onFinishAccount} className="sendmoney_step3_form">
        <h4 style={{ color: "#fff" }}>Transaction summary</h4>
        <br />
        <Grid container spacing={{ xs: 2, md: 10 }}>
          <Grid item xs={12} sm={6}>
            <List disablePadding>
              {column1.map((product) => (
                <ListItem key={product.name} sx={{ py: 1, px: 0 }}>
                  <ListItemText primary={product.name} />
                  <Typography variant="body2">
                    <span className={product?.txtColorCls ? product?.txtColorCls : ""}>
                      {product.price}
                    </span>
                    {product.name === "Coupon Discount" && (
                      <DeleteFilled onClick={clearCouponCodeHandler} className="coupon_dlt_icon" />
                    )}
                  </Typography>
                </ListItem>
              ))}
            </List>
          </Grid>
          <Grid item xs={12} sm={6}>
            <List disablePadding>
              {column2.map((product) => (
                <ListItem key={product.name} sx={{ py: 1, px: 0 }}>
                  <ListItemText primary={product.name} />
                  <Typography variant="body2">{product.price}</Typography>
                </ListItem>
              ))}
            </List>
            <br />
            <br />
            <div className="text-end">
              <span
                className="text-info"
                style={{ cursor: "pointer", position : 'relative' }}
                onClick={() => setViewDetails(true)}
              >
                <u>Know more</u>
              </span>
            </div>
          </Grid>
        </Grid>
        <br />
        <Grid container spacing={{ xs: 2, md: 10 }}>
          <Grid item xs={12} sm={6}>
            <div className="mb-3">
              <div className="">
                <span class="text-light me-3 fs-12">Total Amount Available</span>{" "}
                <label className="step-label text-info  fs-12">
                  {AuthReducer.sendCurrencyCode} {props.state.redeemBalance}
                </label>
              </div>

              <label className="step-label input-label">Referral Discount</label>
              <Form.Item
                className="apply_coupon_box mb-1"
                style={{ display: "flex" }}
                name="redeemValue"
                rules={[
                  {
                    required: false,
                    message: "Please input your referral discount",
                  },
                  {
                    pattern: /^[0-9\b]+$/,
                    message: "Only Numbers allowed",
                  },
                ]}
              >
                <Input
                  className="bg-secondary-light"
                  style={{ width: "30%" }}
                  placeholder="Enter Amount"
                  value={referalCode}
                  onChange={handleReferalCodeChange}
                  disabled={state.referalDiscountDisable}
                />
                <button
                  className="btn btn-sm apply_btn  btn-sm-inline btn-light text-white ms-1 px-4"
                  onClick={userRedeemCheck}
                  disabled={state.referalDiscountDisable}
                >
                  Apply
                </button>
              </Form.Item>
              {state.toggleCongoText && props.state.promoValueWithDesc !== "" && (
                <p className="text-info">{props.state.promoValueWithDesc}</p>
              )}
            </div>

            <label className="step-label input-label">Coupon Code / Gift Voucher</label>
            <Form.Item
              className="apply_coupon_box"
              style={{ display: "flex" }}
              name="couponCode"
              rules={[
                {
                  required: false,
                  message: "Please input your coupon code.",
                },
                {
                  max: 30,
                  message: "coupon code must be maximum 30 characters.",
                },
              ]}
            >
              {/* <Radio.Group value={props.state.value} onChange={handleCouponCodeRadio}>
                <Space direction="vertical">
                  {props.state.categoryPromoLists.map((clist, i) => {
                    return (
                      <Radio key={i} value={clist.promoCode}>
                        {clist.promoDesc}
                      </Radio>
                    );
                  })}
                </Space>
              </Radio.Group> */}

              {/* <Input
                className="bg-secondary-light"
                type="text"
                onChange={handleCouponCodeText}
                style={{ width: "70%" }}
                value={promoCode}
              /> */}

              <Input
                className="bg-secondary-light"
                style={{ width: "50%" }}
                onChange={handleCouponCodeText}
                value={promoCode}
                disabled={state.couponCodeDisable}
              />
              {/* <AutoComplete
                style={{ width: "70%" }}
                className="bg-secondary-light"
                onChange={handleCouponCodeText}
                options={promoLists}
                value={promoCode}
                disabled={state.couponCodeDisable}
              ></AutoComplete> */}
              <button
                className="btn btn-sm apply_btn btn-sm-inline btn-light text-white ms-1 px-4  w-25"
                onClick={applyPromoCode}
                disabled={state.couponCodeDisable}
              >
                Apply
              </button>
              {state.offers.length !== 0 && (
                <button
                  type="button"
                  onClick={() => setState({ offerModal: true })}
                  className="btn btn-sm apply_btn btn-sm-inline ms-0 ms-md-3 px-4 offer-button w-25"
                >
                  Get Offers
                </button>
              )}
            </Form.Item>
            {state.toggleCongoTextCoupon && props.state.promoValueWithDesc !== "" && (
              <p className="text-info">{props.state.promoValueWithDesc}</p>
            )}
          </Grid>
          <Grid item xs={12} sm={6}>
            <Form.Item
              className="form-item"
              name="readTermsConditions"
              valuePropName="checked"
              onChange={handleTermsCondition}
              rules={[
                {
                  validator: (_, value) =>
                    value
                      ? Promise.resolve()
                      : Promise.reject(new Error("Please confirm terms and conditions.")),
                },
              ]}
            >
              <Checkbox style={{ color: "#fff" }}>
                I accept and agree to the{" "}
                <Link to="/terms-and-conditions" target="_blank">
                  <u>Terms and Conditions</u>
                </Link>
              </Checkbox>
            </Form.Item>

            <Form.Item
              className="form-item"
              name="paymentService"
              valuePropName="checked"
              // onChange={handleTermsCondition}
              rules={[
                {
                  validator: (_, value) =>
                    value
                      ? Promise.resolve()
                      : Promise.reject(new Error("Please confirm terms and conditions.")),
                },
              ]}
            >
              <Checkbox style={{ color: "#fff" }}>
                I agree &amp; understand that the Payment Services provided through the website URL
                www.xmonies.com in United Kingdom will be processed by our compliance partner
                Rational Foreign Exchange Ltd. Rational Foreign Exchange Ltd is authorised by the
                Financial Conduct Authority (FRN: 507958) under the Payment Services Regulations
                2009, for the provision of payment services. Issued by HM Revenue &amp; Customs
                (HMRC) Rational Foreign Exchange Ltd trading as RationalFX is a registered Money
                Service Business (MSB) - Money Laundering Regulation number: 12206957.
              </Checkbox>
            </Form.Item>
          </Grid>
        </Grid>

        <div className="row">
          <div className="col-6">
            <button
              className="btn btn-sm btn-outline-light me-2"
              onClick={() => props.setState({ activeStep: 1 })}
            >
              Back
            </button>
          </div>
          <div className="col-6 text-end">
            {parseInt(props.state.totalDeliveredAmount) >= 1 && (
              <button htmlType="submit" className="btn btn-sm btn-light text-white">
                Confirm
              </button>
            )}
          </div>
        </div>
      </Form>
    </React.Fragment>
  );
}
