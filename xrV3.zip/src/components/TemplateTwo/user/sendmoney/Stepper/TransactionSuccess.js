import React, { useState, useEffect, useReducer, useRef } from "react";
import { useNavigate } from "react-router-dom";
import Grid from "@mui/material/Grid";
import { Form, Input, Row, Col, Button, Tabs, notification, Modal } from "antd";
import { CopyOutlined } from "@ant-design/icons";
import useHttp from "../../../../../hooks/useHttp";
import { TransactionAPI } from "../../../../../apis/TransactionAPI";
import { ProfileAPI } from "../../../../../apis/ProfileAPI";
import Swal from "sweetalert2";
import { Link } from "react-router-dom";
import { useSelector } from "react-redux";
import { useReactToPrint } from "react-to-print";
import Spinner from "../../../../../reusable/Spinner";

const XrPdf = React.lazy(() => import("../../sendmoney/Invoice/XR"));
const KcbPdf = React.lazy(() => import("../../sendmoney/Invoice/KCB"));

const { TabPane } = Tabs;

export default function TranctionSuccess(props) {
  const pdfRef = useRef(null);
  const navigate = useNavigate();
  const [transcationIntervalId, setTranscationIntervalId] = useState();
  const [sofortBtnLoader, setSofortBtnLoader] = useState(false);
  const [loginId, setLoginId] = useState("");
  const [copyLabel, setCopyLabel] = useState("Copy");
  const [transactionXrn, setTransactionXrn] = useState();
  const [activeKey, setActiveKey] = useState(props.state.programCode === "FERINST" ? "1" : "2");

  const AuthReducer = useSelector((state) => state);
  const inProcessArr = ["PENDING", "NEW", "REFER"];

  const hookProfileApi = useHttp(ProfileAPI.getProfile);
  const hookGetTransactionReceiptDetails = useHttp(TransactionAPI.transactionReceiptDetails);
  const hookGetCoreBankDetails = useHttp(TransactionAPI.getCoreBankDetails);
  const hookTxnTraceUpdate = useHttp(TransactionAPI.txnTraceUpdate);

  const [state, setState] = useReducer((state, newState) => ({ ...state, ...newState }), {
    userID: AuthReducer.userID,
    pdfDetails: "",
    coreBankDetailsList: [],
    kycPendingInfoModal: inProcessArr.includes(AuthReducer.userKYCStatus) ? true : false,
  });

  // useEffect(() => {
  //   Swal.fire({
  //     // title: "Transaction Failed",
  //     html: `<p>Dear Xmonies Family,</p>
  //     <p>Take note that our UK Pool Account details has changed. Please locate the new bank account information on the Transaction Confirmation page. If you have added our old details as a beneficiary in NetBanking, please change it with the new bank account information.</p>
  //     <p>We always promise you the best service.</p>
  //     <p>Thank you,<br/>Team Xmonies</p>`,
  //     confirmButtonText: "Close",
  //     confirmButtonColor: "#2dbe60",
      
  //     customClass: {
  //       popup: "home_swal_popup",
  //     },
  //   }).then((result) => {
  //     if (result.isConfirmed) {
  //     }
  //   });
  //   // getCoreBankDetails();
  // }, []);

  // const getCoreBankDetails = () => {
  //   const payload = {
  //     requestType: "CORRBANKDTLS",
  //     userId: state.userID,
  //     sendCountryCode: "GB",
  //     sendCurrencyCode: "GBP",
  //     sendModeCode: "CIP",
  //   };

  //   setSofortBtnLoader(true);
  //   hookGetCoreBankDetails.sendRequest(payload, function (data) {
  //     if (data.status == "S") {
  //       setState({ coreBankDetailsList: data.responseData });
  //       setSofortBtnLoader(false);
  //     }
  //   });
  // };

  const getProfileHandler = () => {
    let payload = {
      requestType: "GETPROFILE",
      userId: AuthReducer.userID,
    };
    hookProfileApi.sendRequest(payload, (data) => {
      if (data.status == "S") {
        setLoginId(data.loginId);
      } else {
        notification.error({ message: data.errorMessage });
      }
    });
  };

  const getSofortTranscationDetails = async () => {
    try {
      const payload = {
        groupId: "XR",
        userId: props.state.userID,
        loginId: loginId,
        rgtn: props.state.txnId,
      };
      setSofortBtnLoader(true);
      const response = await TransactionAPI.sofortTransaction(payload, "");
      const data = response.data;
      if (data.status == "S") {
        return {
          tranId: data.tranId,
          redirectUrl: data.redirectUrl,
        };
      }
    } catch (error) {
      setSofortBtnLoader(false);
    }
  };

  const callback = (key) => {
    console.log(key);
  };

  useEffect(() => {
    props.setState({
      isTransactionBook: true,
    });
    getProfileHandler();
  }, []);

  useEffect(() => {
    return () => {
      clearInterval(transcationIntervalId);
    };
  }, [transcationIntervalId]);

  const onSofortClickHandler = async () => {
    clearInterval(transcationIntervalId);
    const sofortResponse = await getSofortTranscationDetails();

    //Open SOFORT external URL
    window.open(sofortResponse.redirectUrl);
    let transcationInterval = setInterval(() => {
      const SOFORT_TRANS_STATUS = window.localStorage.getItem(sofortResponse.tranId);
      if (SOFORT_TRANS_STATUS) {
        clearInterval(transcationInterval);
        if (SOFORT_TRANS_STATUS === "SUCCESS") {
          Swal.fire({
            title: "Payment Successful",
            text: "Transaction Successfull",
            // icon: "success",
            html: `<img src="${require("../../../../../assets/images/XR/payment-successful.gif")}" style="width:200px;" />`,
            confirmButtonText: "Track Payment",
            allowOutsideClick: false,
          }).then((result) => {
            if (result.isConfirmed) {
              navigate("/my-transaction");
            }
          });
          // Branch code start
          var custom_data = {
            Custom_Event_Property_Key1: "Custom_Event_Property_val1",
            Custom_Event_Property_Key2: "Custom_Event_Property_val2",
          };
          // eslint-disable-next-line no-undef
          branch.logEvent("payment_success_sofort", custom_data, function (err) {
            console.log("LogEventError", err);
          });
          // Brand code end
        }
        if (SOFORT_TRANS_STATUS === "FAILED") {
          // Swal.fire({
          //   title: "Payment Failed",
          //   text: "Payment through Sofort has failed. Click here to try again with Sofort.",
          //   // icon: "error",
          //   html: `<img src="${require("../../../../../assets/images/XR/payment-failed.gif")}" style="width:130px;" />`,
          //   showCancelButton: true,
          //   confirmButtonText: "Try Again",
          //   allowOutsideClick: false,
          // }).then((result) => {
          //   if (result.isConfirmed) {
          //     onSofortClickHandler();
          //   }
          // });
          Swal.fire({
            title: "Transaction Failed",
            html: `<p>Your payment thru Payment Gateway could not be processed due to below reason. <br/> 
            <span class="text-info">Reason : Transaction Failed</span> </p>
            <p>If you wish to retry with Payment Gateway, Click on <strong>"Retry with Payment Gateway"</strong></p>
            <p>OR</p>
            <p>You can transfer the funds from your Bank's Netbanking page. Details and process to transfer from your bank is given on <strong>"Pay from your Bank Account"</strong> tab</p>`,
            icon: "error",
            confirmButtonText: "Retry with Payment Gateway",
            confirmButtonColor: "#2dbe60",
            allowOutsideClick: false,

            showDenyButton: true,
            denyButtonText: "Pay from your Bank Netbanking",
            denyButtonColor: "#2dbe60",

            customClass: {
              popup: "timeout_swal_popup",
            },
          }).then((result) => {
            if (result.isConfirmed) {
              setSofortBtnLoader(false);
              onSofortClickHandler();
            }
            if (result.isDenied) {
              setActiveKey("2");
            }
          });
        }
        if (SOFORT_TRANS_STATUS === "TIMEOUT") {
          // Swal.fire({
          //   title: "Timeout",
          //   text: "Transaction timeout",
          //   icon: "error",
          //   confirmButtonColor: "#2dbe60",
          //   allowOutsideClick: false,
          // }).then((result) => {
          //   if (result.isConfirmed) {
          //     setSofortBtnLoader(false);
          //   }
          // });
          Swal.fire({
            title: "Transaction Failed",
            html: `<p>Your payment thru Payment Gateway could not be processed due to below reason. <br/> 
            <span class="text-info">Reason : Transaction Failed</span> </p>
            <p>If you wish to retry with Payment Gateway, Click on <strong>"Retry with Payment Gateway"</strong></p>
            <p>OR</p>
            <p>You can transfer the funds from your Bank's Netbanking page. Details and process to transfer from your bank is given on <strong>"Pay from your Bank Account"</strong> tab</p>`,
            icon: "error",
            confirmButtonText: "Retry with Payment Gateway",
            confirmButtonColor: "#2dbe60",
            allowOutsideClick: false,

            showDenyButton: true,
            denyButtonText: "Pay from your Bank Netbanking",
            denyButtonColor: "#2dbe60",

            customClass: {
              popup: "timeout_swal_popup",
            },
          }).then((result) => {
            if (result.isConfirmed) {
              setSofortBtnLoader(false);
              onSofortClickHandler();
            }
            if (result.isDenied) {
              setActiveKey("2");
            }
          });
        }
      }
    }, 2000);

    setTranscationIntervalId(transcationInterval);
  };

  const handleTransactionXrn = (e) => {
    setTransactionXrn(e.target.value);
  };

  const handleTxnTraceUpdateClickHandler = () => {
    const payload = {
      requestType: "TXNTRACENOUPDATE",
      userId: state.userID,
      rgtn: props.state.txnId,
      traceNo: transactionXrn,
    };

    hookTxnTraceUpdate.sendRequest(payload, function (data) {
      if (data.status == "S") {
        notification.success({
          message: data.message,
        });
      } else {
        notification.error({
          message: data.errorMessage,
        });
      }
    });
  };

  // const printPdf = (txnRefno) => {
  //   const payload = {
  //     requestType: "TXNDETAILS",
  //     rgtn: "",
  //     txnRefNo: txnRefno,
  //     userId: props.state.userID,
  //   };

  //   hookGetTransactionReceiptDetails.sendRequest(payload, function (data) {
  //     if (data.status == "S") {
  //       setState({ pdfDetails: data });
  //       handlePrint();
  //     }
  //   });
  // };

  // const handlePrint = useReactToPrint({
  //   content: () => pdfRef.current,
  // });

  const handlerCopyText = (text) => {
    if (navigator.clipboard) {
      navigator.clipboard.writeText(text).then(
        function () {
          setCopyLabel("Copied");
        },
        function (err) {
          console.error("Async: Could not copy text: ", err);
        },
      );
    }
  };

  console.log("all state =>", props.state);

  const PdfPage = () => {
    const pdfAuthGroupId = useSelector((state) => state);
    switch (pdfAuthGroupId.groupId) {
      case "KCB":
        return (
          <KcbPdf
            ref={pdfRef}
            pdfDetails={state.pdfDetails}
            bankDetails={state.coreBankDetailsList}
          />
        );
        break;
      case "XR":
        return (
          <XrPdf
            ref={pdfRef}
            pdfDetails={state.pdfDetails}
            bankDetails={state.coreBankDetailsList}
          />
        );
        break;
      default:
        break;
    }
  };

  const checkPaymentModeExists = (inputprogramCode) => {
    const pOptions = props.state.paymentOptionsList;
    return pOptions.some((obj) => obj.programCode === inputprogramCode);
  };

  return (
    <React.Fragment>
      <div style={{ display: "none" }}>
        <PdfPage />
      </div>
      <Modal
        className="primary"
        centered
        visible={state.kycPendingInfoModal}
        onCancel={() => setState({ kycPendingInfoModal: false })}
        footer={null}
        closable={false}
        maskClosable={false}
      >
        <div className="">
          <h3 className="text-light mb-3">Information</h3>
          <p className="mt-3 mb-3 fs-18 text-light">
            Your KYC is in process. Your Transaction will be processed once your KYC verification is
            completed.
          </p>
          <div className="d-flex flex-row-reverse mt-3 w-100">
            <button
              onClick={() => setState({ kycPendingInfoModal: false })}
              className="btn btn-light btn-sm text-primary"
            >
              Close
            </button>
          </div>
        </div>
      </Modal>
      <div className="py-5">
        <Grid container spacing={3}>
          <Grid item xs={12} sm={12}>
            <Tabs
              activeKey={activeKey}
              defaultActiveKey={props.state.programCode === "FERINST" ? "1" : "2"}
              onChange={callback}
            >
              {checkPaymentModeExists("FERINST") && (
                <TabPane tab="Pay online via Payment Gateway" key="1">
                  <div className="row mb-5">
                    <div className="col-12 col-md-7">
                      <p className="fs-18">
                        'SOFORT Banking' is XR's new direct payment option in partnership with UK's
                        leading Payment Gateway. You no longer have to take the effort to visit your
                        internet banking website, add our account details or approve us as a
                        beneficiary. Sofort Banking has been authorized by all banks in the United
                        Kingdom to accept payments.
                      </p>
                    </div>

                    <div className="col-md-1 text-center d-none d-md-block">
                      <span className="_v_line_secondary mt-4" style={{ height: "150px" }}></span>
                    </div>
                    <div className="col-12 col-md-4">
                      <div className="row text-light mb-2">
                        <div className="col-8  fs-15">Total Amount</div>
                        <div className="col-4">
                          {props.state.sendCurrencyCode}{" "}
                          <span className="text-info ms-1">{props.state.sendAmount}</span>
                        </div>
                      </div>
                      <div className="row text-light mb-2">
                        <div className="col-8  fs-15">Payment Gateway Charges</div>
                        <div className="col-4">
                          {props.state.sendCurrencyCode}{" "}
                          <span className="text-info ms-1">{props.state.transferFee}</span>
                        </div>
                      </div>
                      <div className="row text-light mb-2">
                        <div className="col-8  fs-15">Total Amount to Transfer</div>
                        <div className="col-4">
                          {props.state.sendCurrencyCode}{" "}
                          <span className="text-info ms-1">{props.state.totalDeliveredAmount}</span>
                        </div>
                      </div>

                      <div className="row mt-3">
                        <div className="col-12">
                          <p className="text-info fs-12">
                            NOTE : In case you want to send money later by adding XR bank account
                            details yourself, please select the existing Internet Banking option.
                          </p>
                        </div>
                        <div className="col-12">
                          <Spinner spinning={sofortBtnLoader}>
                            <button
                              className="btn btn-sm btn-light text-primary w-100"
                              onClick={onSofortClickHandler}
                            >
                              Proceed Securely to SOFORT
                            </button>
                          </Spinner>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="row">
                    <div className="col-12">
                      <p style={{ fontSize: "14.7003px", fontWeight: "600" }}>
                        Simply select your bank name on the secure and pay safely &amp; directly
                        using your internet banking details. SOFORT Banking's 128-bit SSL
                        encryption, through well-known security providers like Norton and Trusteer,
                        ensures that your banking information is secure and your funds are
                        transferred directly to our accounts in a safe and secure manner. Remember,
                        all banks in the United Kingdom have authorized Sofort Banking to collect
                        payments from customers.
                      </p>
                    </div>
                  </div>
                </TabPane>
              )}

              <TabPane tab="Pay from your Bank Account" key="2" style={{ color: "#fff" }}>
                <div className="d-flex align-items-center mt-4 ">
                  <p className="text-info mb-0 fs-18 fw-600">Next Steps&nbsp;</p>
                  <p className="fs-16 text-light mb-0">
                    (How to transfer money from your Bank Account)
                  </p>
                </div>
                <p className="fs-23 fw-600">
                  Follow the Steps below to Transfer money from your Bank Account
                </p>
                <br />
                <p className="text-info mb-0 fs-18 fw-600">Step 1</p>
                <p className="fs-23 fw-600">
                  Note Down your Transaction Number : {props.state.txnRefNumber}
                </p>
                <br />
                <p className="text-info mb-0 fs-18 fw-600">Step 2</p>
                <p className="fs-23 fw-600">
                  Login to Internet banking of your local bank account.
                </p>
                <br />
                <p className="text-info mb-0 fs-18 fw-600">Step 3</p>
                <p className="fs-23 fw-600">
                  Go to funds transfer section and make us as a beneficiary / recipient.
                </p>
                <br />
                <p className="text-info mb-0 fs-18 fw-600">Step 4</p>
                <p className="fs-23 fw-600">
                  Enter the beneficiary / recipient information as below
                </p>
                <div className="row trans_details">
                  <div className="col-md-5">
                    <p>Bank Account Name: Rational Foreign Exchange Ltd</p>
                    <p>Bank Bank: JP Morgan</p>
                    <p>Bank Address: 25 Bank Street, Canary Wharf, London, E14 5JP</p>
                    <p>Account Number: 16226741</p>
                    <p>Sort Code: 60-92-42</p>
                  </div>
                  <div className="col-md-1 text-center d-none d-md-block">
                    <span className="_v_line_secondary mt-3" style={{ height: "80px" }}></span>
                  </div>
                  <div className="col-md-6">
                    <p>IBAN: GB03CHAS60924216226741</p>
                    <p>SWIFT/BIC code: CHASGB2L</p>
                    <p>
                      XMONIES Transaction Number: {props.state.txnRefNumber}
                      <button
                        className="btn btn-link btn-sm btn-copy px-2 text-info"
                        onClick={() => handlerCopyText(props.state.txnRefNumber)}
                      >
                        {copyLabel} <CopyOutlined className="ms-1" />
                      </button>
                    </p>
                  </div>
                </div>

                <p className="text-info notepara">
                  NOTE : <br />
                  Please mention your XR Transaction No. {props.state.txnRefNumber} in "reference
                  description details" in your Internet banking website when you do the transfer.
                  This will help us to trace your money.
                </p>
                <br />

                <p className="text-info mb-0 fs-18 fw-600">Step 5</p>
                <p className="fs-23 fw-600">
                  Enter the amount to be transferred as being{" "}
                  <span className="text-info">{props.state.txnSendAmount} GBP</span>. (Also make
                  sure you transfer {props.state.txnSendAmount} GBP i.e. the exact same amount that
                  you have done a booking for.)
                </p>
                <br />
                <p className="text-info mb-0 fs-18 fw-600">Step 6</p>
                <p className="fs-23 fw-600">
                  Confirm the transaction and update the trace number below, if any.
                </p>
                <br />
                <div className="bg-secondary-light text-primary p-3 rounded-3 mb-5">
                  <h3 className="fs-30 fw-700">Track your Transaction</h3>
                  <p className="text-primary">
                    Once you have sent the money from your Bank A/c via internet banking/Sofort
                    Banking transfer, your bank may give you a Trace Transaction Reference Number,
                    please enter it in here. This will help us in tracking your transaction better.
                  </p>

                  <div className="row g-2">
                    <div className="col-6 col-md-4">
                      <Form.Item
                        style={{ display: "flex" }}
                        name="txn_number"
                        rules={[
                          {
                            required: true,
                            message: "Please enter your transcation number.",
                          },
                        ]}
                      >
                        <Input
                          placeholder="Enter transaction number"
                          onChange={handleTransactionXrn}
                        />
                      </Form.Item>
                    </div>
                    <div className="col-4 col-md-2">
                      <button
                        className="btn btn-primary text-light btn-sm btn-sm-inline txt_track_btn"
                        onClick={handleTxnTraceUpdateClickHandler}
                      >
                        Track
                      </button>
                    </div>
                  </div>
                  <p className="text-primary fs-12 op-8">
                    This step is optional but important to track your transaction.
                  </p>
                </div>
                <p className="text-info mb-0 fs-18 fw-600">Step 7</p>
                <p className="fs-23 fw-600">
                  You can check the status of your transaction on{" "}
                  <Link to="/my-transaction">Transaction Summary</Link> page.
                </p>
                <br />
              </TabPane>
            </Tabs>
          </Grid>
        </Grid>
      </div>
    </React.Fragment>
  );
}
