import React, { createRef, forwardRef, useState } from "react";
import { useSelector } from "react-redux";

function XRInvoice(props, ref) {
  const AuthReducer = useSelector((state) => state);
  const txnDetails = props.pdfDetails;
  const invRef = createRef();
  const [isFav, setFav] = useState(false);

  const bankDetails = props.bankDetails;
  return (
    <div ref={ref} className="pdf_invoice">
      <div>
        <div
          style={{
            width: "800px",
          }}
        >
          <section className="bg-light p-3 mt-3" ref={invRef}>
            <div>
              <img
                src={require("../../../../../assets/images/logos/" +
                  AuthReducer.groupId +
                  "_logo.png")}
                height="48px"
              />
            </div>
            <p className="mt-3">
              <span
                style={{
                  backgroundColor: "#31c331",
                  color: "#FFF",
                  padding: "4px",
                  marginRight: "10px",
                }}
              >
                DONE
              </span>
              Step 1 : Money Transfer Request to XMONIES
              <br />
              Status: Transaction successfully booked. Funds awaited.
              <br />
              Your XMONIES Transaction No. (XRTN) :
              <b>{txnDetails.txnRefNumber}</b>
            </p>

            <p className="mt-3">
              <span
                style={{
                  backgroundColor: "#FF0000",
                  color: "#FFF",
                  padding: "4px",
                  marginRight: "10px",
                }}
              >
                PENDING
              </span>
              Step 2 : Transfer Money to XMONIES Bank Account
              <br />
              The unique reference number for this transaction request is
              {txnDetails.txnRefNumber}. <br />
              Please follow the steps mentioned below to enable us to process
              your request:
              <br />
              Kindly print the Wire Transfer form and present it to your local
              bank.
              <br />
              <ol>
                <li>
                  Approach your local bank in United Kingdom for initiating a
                  wire transfer transaction
                </li>
                <li>
                  Instruct your local bank to route the transaction though our
                  bank details mentioned below mentioning{" "}
                  {txnDetails.txnRefNumber} in the additional information
                  usually field 70 or 72 of the SWIFT message
                </li>
              </ol>
              We shall process your transaction post receiving the money in our
              account.
              <br />
              {/* <>
                {bankDetails && (
                  <>
                    <table
                      border="0"
                      width="100%"
                      cellspacing="0"
                      cellpadding="0"
                    >
                      <tbody>
                        {bankDetails.map((bank) => {
                          return (
                            <tr>
                              <td width="30%">
                                <strong>{bank.corr_caption}:</strong>
                              </td>
                              <td>{bank.corr_value}</td>
                            </tr>
                          );
                        })}
                      </tbody>
                    </table>
                  </>
                )}
              </> */}
              <table border="0" width="100%" cellspacing="0" cellpadding="0">
                <tbody>
                  <tr>
                    <td width="30%">
                      <strong>Bank Account Name:</strong>
                    </td>
                    <td>Rational Foreign Exchange Ltd</td>
                  </tr>
                  <tr></tr>
                  <tr>
                    <td width="30%">
                      <strong>Bank Name:</strong>
                    </td>
                    <td>JP Morgan</td>
                  </tr>
                  <tr></tr>
                  <tr>
                    <td width="30%">
                      <strong>Bank Address:</strong>
                    </td>
                    <td>25 Bank Street, Canary Wharf, London, E14 5JP</td>
                  </tr>
                  <tr></tr>
                  <tr>
                    <td width="30%">
                      <strong>Account Number:</strong>
                    </td>
                    <td>16226741</td>
                  </tr>
                  <tr></tr>
                 
                  <tr>
                    <td width="30%">
                      <strong>Swift Code:</strong>
                    </td>
                    <td>CHASGB2L</td>
                  </tr>
                  <tr></tr>
                  <tr>
                    <td width="30%">
                      <strong>Sort Code:</strong>
                    </td>
                    <td>60-92-42</td>
                  </tr>
                  <tr></tr>
                  <tr>
                    <td width="30%">
                      <strong>IBAN:</strong>
                    </td>
                    <td>GB03CHAS60924216226741</td>
                  </tr>
                  <tr></tr>

                  <tr>
                    <td width="30%">
                      <strong>XMONIES Transaction Number </strong>
                    </td>
                    <td>{txnDetails.txnRefNumber}</td>
                  </tr>
                </tbody>
              </table>
              <span>
                (Please ensure that you enter the XMONIES Transaction Number in
                the Wire Transfer instruction)
              </span>
            </p>

            <p>
              All charges to be paid by me
              <br />
              <b>Important Information:</b>
              <ol>
                <li>
                  Please ensure that the account from which the money is sent
                  belongs to you. In case of any discrepancy, the transaction
                  may be rejected or the processing may get delayed.
                </li>

                <li>XMONIES Payment Policy &amp; Error Resolution.</li>
              </ol>
            </p>
          </section>
        </div>
      </div>
    </div>
  );
}

export default forwardRef(XRInvoice);
