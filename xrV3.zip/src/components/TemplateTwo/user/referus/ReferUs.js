import React, {
  useState,
  useEffect,
  useReducer,
  Fragment,
  useRef,
} from "react";
import {
  Form,
  Table,
  Spin,
  Select,
  DatePicker,
  Input,
  Button,
  notification,
  Tabs,
  Modal,
} from "antd";
import DefaultLayout from "../../layout/DefaultLayout";
import Grid from "@mui/material/Grid";
import SubHeader from "../../layout/SubHeader";
import ReferUsModal from "./ReferUsModal";

const { TabPane } = Tabs;

export default function ReferUs(props) {
  const [referUsModal, setReferUsModal] = useState(false);

  const [state, setState] = useReducer(
    (state, newState) => ({ ...state, ...newState }),
    {
      isTransactionBook: false,
    }
  );

  return (
    <React.Fragment>
      <SubHeader isTransactionBook={state.isTransactionBook} />

      <Modal
        centered
        visible={referUsModal}
        onCancel={() => setReferUsModal(false)}
        width={1000}
        footer={null}
      >
        <ReferUsModal />
      </Modal>
      <div className="main">
        <section className="xr_header" style={{ height: "100vh" }}>
          <div className="py-5">
            <div style={{ marginLeft: "100px" }}>
              <button onClick={() => setReferUsModal(true)}>
                Open Refer Us Modal
              </button>
            </div>
          </div>
        </section>
      </div>
    </React.Fragment>
  );
}
