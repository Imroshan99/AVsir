import React, { useEffect, useLayoutEffect, useState } from "react";
import Home from "../../pages/LandingPage/index";
import Dashboard from "./Dashboard";
import SignUp from "./auth/SignUp";
import SignIn from "./auth/SignIn";
import Header from "./layout/Header";

import ForgotUserID from "./auth/ForgotUserID";
import ForgotPassword from "./auth/ForgotPassword";
import UnlockUserid from "./auth/UnlockUserid";
import { Helmet } from "react-helmet";
import { PublicRoute } from "./../../Routes/PublicRoute";
import SingleSignUpForm from "./auth/SingleSignUpForm";
import { Route, Routes, useLocation, useParams } from "react-router-dom";
import { useSelector } from "react-redux";
import UnlockAccount from "./auth/UnlockAccount";
import XRMeta from "../../assets/meta/XR.json";
import ReactGA from "react-ga";
import TagManager from "react-gtm-module";
import { notification } from "antd";

// const RequestMoney = React.lazy(() => import("./pages/request-money"));
// ReactGA.initialize("G-PDPZME3HHH");
// ReactGA.pageview(window.location.pathname + window.location.search);
export default function TemplateTwo({ state, manageRefreshToken, manageAuth }) {
  const AuthReducer = useSelector((state) => state);
  const _title = useSelector((state) => state.groupIdSettings.title);
  // const [title, setTitle] = useState("");
  // const [desc, setDesc] = useState("");
  const location = useLocation();

  const pathName = location.pathname;
  const metaFilter = XRMeta.filter((item) => item.path === pathName);
  const title = metaFilter.length ? metaFilter[0].title : _title;
  const desc = metaFilter.length ? metaFilter[0].desc : _title;
  // useEffect(() => {
  //   const pathName = location.pathname;
  //   const metaFilter = XRMeta.filter((item) => item.path === pathName);

  //   if (metaFilter.length) {
  //     setTitle(metaFilter[0].title);
  //     setDesc(metaFilter[0].desc);
  //   } else {
  //     setTitle(_title);
  //     setDesc(_title);
  //   }
  // }, [location, _title]);

  // for GA and GTM tags
  useEffect(() => {
    // ReactGA.pageview(window.location.pathname + window.location.search);
    TagManager.initialize({
      gtmId: "GTM-NDB9S3P",
    });

    // TagManager.initialize({
    //   gtmId: "GTM-NDB9S3P",
    //   events: {
    //     send_to: "AW-10884287102/X86JCLvUidkDEP6UhMYo",
    //   },
    // });
  }, []);

  useEffect(() => {
    if (location.pathname === "/") {
      notification.destroy();
    }
    //   TagManager.initialize({
    //     gtmId: "GTM-NDB9S3P",
    //     events: {
    //       send_to: "AW-10884287102/X86JCLvUidkDEP6UhMYo",
    //     },
    //   });
  }, [location]);

  useEffect(() => {
    localStorage.removeItem("uId");
    localStorage.removeItem("refId");
    const queryParams = new URLSearchParams(location.search);
    const uId = queryParams.get("uId");
    const refId = queryParams.get("refId");
    const utmSource = queryParams.get("utm_source");
    const utmMedium = queryParams.get("utm_medium");
    const utmCampaign = queryParams.get("utm_campaign");
    const utmTerm = queryParams.get("utm_term");
    const utmContent = queryParams.get("utm_content");
    const utmAdgroup = queryParams.get("utm_group");
    if (utmSource) {
      localStorage.setItem("utmSource", utmSource);
    }
    if (utmMedium) {
      localStorage.setItem("utmMedium", utmMedium);
    }
    if (utmCampaign) {
      localStorage.setItem("utmCampaign", utmCampaign);
    }
    if (utmTerm) {
      localStorage.setItem("utmTerm", utmTerm);
    }
    if (utmContent) {
      localStorage.setItem("utmContent", utmContent);
    }
    if (utmAdgroup) {
      localStorage.setItem("utmAdgroup", utmAdgroup);
    }
    if (uId) {
      localStorage.setItem("uId", uId);
    }
    if (refId) {
      localStorage.setItem("refId", refId);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return (
    <>
      <Helmet>
        <title>{title}</title>
        <meta name="description" content={desc} />
        <link rel="manifest" href="/XR_manifest.json" />
        <link
          rel="icon"
          type="image/png"
          sizes="16x16"
          href={require(`./../../assets/images/fav_icons/${AuthReducer.groupId + "_logo.ico"}`)}
        />
        {/* <noscript>{`<link rel="stylesheet" type="text/css" href="foo.css" />`}</noscript> */}
      </Helmet>
      <Routes>
        <Route
          path="/"
          element={
            <PublicRoute auth={{ isLoggedIn: state.isLoggedIn }}>
              <Home appState={state} manageAuth={manageAuth} />
            </PublicRoute>
          }
        />
        <Route
          path="/signin"
          element={
            <PublicRoute auth={{ isLoggedIn: state.isLoggedIn }}>
              <SignIn appState={state} manageAuth={manageAuth} />
            </PublicRoute>
          }
        />
        <Route
          path="/signup"
          element={
            <PublicRoute auth={{ isLoggedIn: state.isLoggedIn }}>
              {AuthReducer.groupIdSettings.signUpForm.formType === "REGULAR" ? (
                <SignUp appState={state} manageAuth={manageAuth} />
              ) : (
                <SingleSignUpForm appState={state} manageAuth={manageAuth} />
              )}
            </PublicRoute>
          }
        />
        <Route path="/*" element={<Dashboard appState={state} manageAuth={manageAuth} />} />

        {/* <Route path="/request-money" element={<RequestMoney />} /> */}

        <Route
          path="/forgot-userid"
          element={<ForgotUserID appState={state} manageAuth={manageAuth} />}
        />
        <Route
          path="/forgot-password"
          element={<ForgotPassword appState={state} manageAuth={manageAuth} />}
        />
        <Route
          path="/unlock-userid"
          element={<UnlockUserid appState={state} manageAuth={manageAuth} />}
        />
        <Route
          path="/unlock-account"
          element={<UnlockAccount appState={state} manageAuth={manageAuth} />}
        />

        {/* <Route
          exact
          path="/"
          element={
            <PublicRoute auth={{ isLoggedIn: state.isLoggedIn }}>
              <Home appState={state} />
            </PublicRoute>
          }
        /> */}
      </Routes>
    </>
  );
}
