import React, { useState, useEffect, useReducer } from "react";
import { Link, Outlet, useLocation, useNavigate } from "react-router-dom";
import Box from "@mui/material/Box";
import Badge from "@mui/material/Badge";
import SvgIcon from "@mui/material/SvgIcon";

import { ReactComponent as ProfileSvg } from "../../../assets/images/XR/profile.svg";
import { ReactComponent as NotificationSvg } from "../../../assets/images/XR/notification.svg";
import { ReactComponent as MenuMobileOpen } from "../../../assets/images/XR/menu.svg";
import { ReactComponent as MenuMobileClose } from "../../../assets/images/XR/menu-close.svg";
import DownArrowSvg from "../../../assets/images/XR/downarrow.svg";

import IconButton from "@mui/material/IconButton";
import Avatar from "@mui/material/Avatar";
import Button from "@mui/material/Button";
import { ProfileAPI } from "../../../apis/ProfileAPI";
import { Modal, notification } from "antd";
import { useSelector, useDispatch } from "react-redux";
import { NavLink } from "react-router-dom";
import useHttp from "../../../hooks/useHttp";
import NotificationMenu from "../user/NotificationMenu";
import UserMenu from "../user/UserMenu";
import UploadAdditonalDoc from "../user/profile/UploadAdditonalDoc";

const pages = [
  // {
  //   label: "Request Money",
  //   link: "/request-money",
  //   isLoginRequired: true,
  // },
  {
    label: "Send Money",
    // link: "/new-transaction",
    link: "/",
    isLoginRequired: true,
  },
  {
    label: "Support",
    link: "/support",
    isLoginRequired: false,
  },
  {
    label: "FAQs",
    link: "/faq",
    isLoginRequired: false,
  },
];

function stringToColor(string) {
  let hash = 0;
  let i;

  /* eslint-disable no-bitwise */
  for (i = 0; i < string.length; i += 1) {
    hash = string.charCodeAt(i) + ((hash << 5) - hash);
  }

  let color = "#";

  for (i = 0; i < 3; i += 1) {
    const value = (hash >> (i * 8)) & 0xff;
    color += `00${value.toString(16)}`.slice(-2);
  }
  /* eslint-enable no-bitwise */

  return color;
}
function stringAvatar(name) {
  let nameAr = name.split(" ");
  let nm = "";
  if (nameAr.length > 1) {
    nm = `${name.split(" ")[0][0]}${name.split(" ")[1][0]}`;
  } else {
    nm = `${name.split(" ")[0][0]}`;
  }
  return {
    sx: {
      bgcolor: stringToColor(name),
    },
    children: nm,
  };
}
export default function Header(props) {
  let navigate = useNavigate();
  let location = useLocation();
  let dispatch = useDispatch();

  const AuthReducer = useSelector((state) => state);
  const [anchorElNav, setAnchorElNav] = useState(null);
  const [anchorElUser, setAnchorElUser] = useState(null);
  const [anchorElNoti, setAnchorElNoti] = useState(null);
  const [notificationMenu, setNotificationMenu] = useState(false);
  const [notificationLoader, setNotificationLoader] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [mobileSubMenuOpen, setMobileSubMenuOpen] = useState(false);
  const [isModalVisible, setIsModalVisible] = useState(false);
  const [state, setState] = useReducer((state, newState) => ({ ...state, ...newState }), {
    firstName: "",
    lastName: "",
    clientId: AuthReducer.clientId,
    groupId: AuthReducer.groupId,
    sessionId: AuthReducer.sessionId,
    userID: AuthReducer.userID,
    notificationList: [],
    alertList: [],
    newNotificationCount: "0",
  });
  const hookProfileApi = useHttp(ProfileAPI.getProfile);
  const hookNotificationList = useHttp(ProfileAPI.notificationLists);
  const hookUpdateNotification = useHttp(ProfileAPI.updateNotification);

  useEffect(async () => {
    if (props.appState.isLoggedIn) {
      getProfileHandler();
      getNotificationList();
    }
  }, [props.appState.isLoggedIn]);

  const getProfileHandler = () => {
    let payload = {
      requestType: "GETPROFILE",
      userId: AuthReducer.userID,
    };
    hookProfileApi.sendRequest(payload, (data) => {
      if (data.status == "S") {
        setState({
          firstName: data.firstName,
          lastName: data.lastName,
        });
      } else {
        notification.error({ message: data.errorMessage });
      }
    });
  };
  const getNotificationList = async () => {
    let payload = {
      requestType: "NOTIFICATIONLISTS",
      userId: AuthReducer.userID,
    };
    setNotificationLoader(true);
    await hookNotificationList.sendRequest(payload, (data) => {
      if (data.status == "S") {
        const responseData = data.responseData.slice(0, 5);
        let notificationLists = [];
        let alertLists = [];
        responseData.filter((i) => {
          if (i.notificationName.search("ALERT_") !== -1) {
            alertLists.push(i);
          } else {
            notificationLists.push(i);
          }
        });
        setState({
          notificationList: notificationLists,
          alertList: alertLists,
        });
        dispatch({
          type: "SET_NOTIFICATION_COUNT",
          payload: data.newNotification,
        });
        setNotificationLoader(false);
      } else {
        // notification.error({ message: data.errorMessage });
        setNotificationLoader(false);
      }
    });
  };
  const updateNotificationHandler = async () => {
    let payload = {
      requestType: "UPDATENOTIFICATIONS",
      userId: AuthReducer.userID,
    };
    await hookUpdateNotification.sendRequest(payload, (data) => {
      if (data.status == "S") {
        dispatch({ type: "SET_NOTIFICATION_COUNT", payload: "0" });
        // setState({ newNotificationCount: "0" });
      }
    });
  };

  const handleOpenNavMenu = (event) => {
    setAnchorElNav(event.currentTarget);
  };
  const handleOpenUserMenu = (event) => {
    setAnchorElUser(event.currentTarget);
  };
  const handleCloseNavMenu = () => {
    setAnchorElNav(null);
  };
  const handleOpenNotiMenu = (event) => {
    setAnchorElNoti(event.currentTarget);
    setNotificationMenu(true);
    async function fetch() {
      await getNotificationList();
      await updateNotificationHandler();
    }
    fetch();
  };
  const handleCloseNotiMenu = () => {
    setAnchorElNoti(null);
    setNotificationMenu(false);
  };
  const handleCloseUserMenu = (e) => {
    setAnchorElUser(null);
    if (e === "Logout") {
      window.location.href = "/";
    }
  };

  function handleclosemenuandmodel() {
    setMobileMenuOpen(!mobileMenuOpen);
    setIsModalVisible(true);
  }

  return (
    <>
      <header className="header">
        <div className="container py-2 pt-md-4">
          <div class="row">
            <div className="col-auto d-flex align-items-center">
              <h2 className="logo-text mb-0">
                <Link to={AuthReducer.isLoggedIn ? "/new-transaction" : "/"}>
                  <img
                    src={require("../../../assets/images/logos/" +
                      AuthReducer.groupId +
                      "_dark_logo.svg")}
                    height="40px"
                  />
                </Link>
              </h2>
            </div>
            <div className="col d-flex justify-content-end text-end">
              {AuthReducer.isLoggedIn == true && (
                <>
                  <Box
                    sx={{ flexGrow: 1, display: { xs: "none", md: "flex" } }}
                    style={{
                      justifyContent: "end",
                    }}
                  >
                    {pages.map((page) => (
                      <Button
                        key={page.link}
                        onClick={handleCloseNavMenu}
                        sx={{ color: "white", display: "block" }}
                      >
                        <NavLink className="template2_nav" to={page.link}>
                          {page.label}
                        </NavLink>
                      </Button>
                    ))}
                  </Box>

                  <Box sx={{ flexGrow: 0 }} justifyContent={"end"}>
                    {/* Notification Button disabled till product team reverts */}
                    <IconButton className="me-2" onClick={handleOpenNotiMenu} sx={{ p: 0 }}>
                      <Badge
                        overlap="circular"
                        badgeContent={AuthReducer.notificationCount}
                        color="error"
                        invisible={
                          AuthReducer.notificationCount === "" ||
                          AuthReducer.notificationCount === "0"
                            ? true
                            : false
                        }
                      >
                        <Avatar>
                          <SvgIcon>
                            <NotificationSvg />
                          </SvgIcon>
                        </Avatar>
                      </Badge>
                    </IconButton>
                    {notificationMenu && (
                      <NotificationMenu
                        setIsModalVisible={setIsModalVisible}
                        state={state}
                        anchorElNoti={anchorElNoti}
                        setAnchorElNoti={setAnchorElNoti}
                        handleCloseNotiMenu={handleCloseNotiMenu}
                        notificationLoader={notificationLoader}
                      />
                    )}

                    <IconButton
                      className="profile_icon_menu_header"
                      onClick={handleOpenUserMenu}
                      sx={{ p: 0 }}
                    >
                      <Avatar
                        alt={AuthReducer.userFullName}
                        // {...stringAvatar(AuthReducer.userFullName)}
                      >
                        {/* <PermIdentityOutlinedIcon /> */}
                        <SvgIcon>
                          <ProfileSvg />
                        </SvgIcon>
                      </Avatar>
                    </IconButton>
                    <UserMenu
                      anchorElUser={anchorElUser}
                      handleCloseUserMenu={handleCloseUserMenu}
                      setIsModalVisible={setIsModalVisible}
                    />

                    <IconButton
                      className="mobile_icon_menu_header"
                      onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
                      sx={{ p: 0 }}
                    >
                      <Avatar
                        alt={AuthReducer.userFullName}
                        // {...stringAvatar(AuthReducer.userFullName)}
                      >
                        {/* <PermIdentityOutlinedIcon /> */}
                        <SvgIcon>
                          {!mobileMenuOpen ? <MenuMobileOpen /> : <MenuMobileClose />}
                        </SvgIcon>
                      </Avatar>
                    </IconButton>
                  </Box>
                </>
              )}
            </div>
            <div
              className={
                !mobileMenuOpen
                  ? "xr_mobile_menu mobile-nav-menu"
                  : "xr_mobile_menu mobile-nav-menu-active"
              }
            >
              <ul className="linkcolor" style={{ listStyle: "none", padding: "0" }}>
                <li
                  className={!mobileSubMenuOpen ? "d-flex" : "d-flex menuactive"}
                  onClick={() => setMobileSubMenuOpen(!mobileSubMenuOpen)}
                >
                  <div className="flex-fill  ">
                    <span className="fs-20"> Account </span>

                    <div
                      className={
                        !mobileSubMenuOpen
                          ? "xr_mobile_submenu mobile-nav-menu"
                          : "xr_mobile_submenu mobile-nav-menu-active"
                      }
                    >
                      <ul
                        className="xr_profile_menu"
                        style={{ listStyle: "none", padding: "0", fontSize: "20px" }}
                      >
                        <li onClick={() => setMobileMenuOpen(!mobileMenuOpen)}>
                          <Link to="/my-bank-accounts">Account Summary</Link>
                        </li>
                        <li onClick={() => setMobileMenuOpen(!mobileMenuOpen)}>
                          <Link to="/profile">My Profile</Link>
                        </li>
                        <li onClick={() => setMobileMenuOpen(!mobileMenuOpen)}>
                          <Link to="/change-password">Change Password</Link>
                        </li>
                        <li onClick={() => setMobileMenuOpen(!mobileMenuOpen)}>
                          <Link to="/my-recipient">My Receivers</Link>
                        </li>
                        <li onClick={() => setMobileMenuOpen(!mobileMenuOpen)}>
                          <Link
                            to={{
                              pathname: "/my-transaction",
                            }}
                            state={{ activeStep: 1 }}
                          >
                            {" "}
                            Transaction Summary
                          </Link>
                        </li>
                        <li onClick={() => setMobileMenuOpen(!mobileMenuOpen)}>
                          <Link
                            to={{
                              pathname: "/my-transaction",
                            }}
                            state={{ activeStep: 2 }}
                          >
                            {" "}
                            Schedule Reminder
                          </Link>
                        </li>
                        <li onClick={() => setMobileMenuOpen(!mobileMenuOpen)}>
                          <Link
                            to={{
                              pathname: "/my-transaction",
                            }}
                            state={{ activeStep: 3 }}
                          >
                            Exchange Rate
                          </Link>
                        </li>
                        <li onClick={() => setMobileMenuOpen(!mobileMenuOpen)}>
                          <Link to="/recipient-request-list">Recipient Request List</Link>
                        </li>
                        <li onClick={() => handleclosemenuandmodel()}>
                          Upload Additonal Documents
                        </li>
                        <li onClick={() => setMobileMenuOpen(!mobileMenuOpen)}>
                          <Link to="/refer-and-earn">Refer and Earn</Link>
                        </li>
                        <li onClick={() => handleCloseUserMenu("Logout")}>Logout</li>
                      </ul>
                    </div>
                  </div>
                  <div>
                    <img
                      className={!mobileSubMenuOpen ? "menu_close_arrow" : "menu_open_arrow"}
                      src={DownArrowSvg}
                      alt="Down Arrow"
                    />
                  </div>
                </li>
                <li className="lifont" onClick={() => setMobileMenuOpen(!mobileMenuOpen)}>
                  <Link to="/new-transaction">Send Money</Link>
                </li>
                <li onClick={() => setMobileMenuOpen(!mobileMenuOpen)}>
                  <Link to="/support">Support</Link>
                </li>
                <li onClick={() => setMobileMenuOpen(!mobileMenuOpen)}>
                  <Link to="/faq">Help</Link>
                </li>
              </ul>
            </div>
          </div>
          {/* {props.appState.isLoggedIn == true && (
            <SubHeader appState={props.appState} />
          )} */}
        </div>
        {isModalVisible && (
          <UploadAdditonalDoc
            isModalVisible={isModalVisible}
            setIsModalVisible={setIsModalVisible}
          />
        )}
      </header>
      <Outlet />
    </>
  );
}
