import KycPage from "../auth/KYC";
import { useSelector } from "react-redux";
import React, { useState, useRef, useReducer, useEffect } from "react";
import { Modal, Button } from "antd";
import XRInvoice from "../user/sendmoney/Invoice/XR";
import { jsPDF } from "jspdf";
import html2canvas from "html2canvas";
import { TransactionAPI } from "../../../apis/TransactionAPI";
import useHttp from "../../../hooks/useHttp";
import KYCModal from "../auth/KYCModal";
import Contact from "../../../assets/images/svg/contact.svg";

export default function SubHeader(props) {
  const AuthReducer = useSelector((state) => state);
  const [isModalVisible, setIsModalVisible] = useState(false);
  const pdfRef = useRef(null);
  const inProcessArr = ["PENDING", "NEW", "REFER"];
  const failedArr = ["INACTIVE", "REJECTED", "SUSPENDED", "FAILED"];
  const verifiedArr = ["ACTIVE", "VERIFIED", "PASS"];

  const [state, setState] = useReducer((state, newState) => ({ ...state, ...newState }), {
    transactionLists: [],
    clientId: AuthReducer.clientId,
    groupId: AuthReducer.groupId,
    sessionId: AuthReducer.sessionId,
    userID: AuthReducer.userID,

    _invoiceTxnRefNumber: "",
    _invoiceData: [],
    pdfDetails: "",
    coreBankDetailsList: [],
  });

  const hookGetTransactionReceiptDetails = useHttp(TransactionAPI.transactionReceiptDetails);
  const hookGetCoreBankDetails = useHttp(TransactionAPI.getCoreBankDetails);

  useEffect(() => {
    // getCoreBankDetails();
  }, []);

  const getCoreBankDetails = () => {
    const payload = {
      requestType: "CORRBANKDTLS",
      userId: state.userID,
      sendCountryCode: "GB",
      sendCurrencyCode: "GBP",
      sendModeCode: "CIP",
    };

    hookGetCoreBankDetails.sendRequest(payload, function (data) {
      if (data.status == "S") {
        setState({ coreBankDetailsList: data.responseData });
      }
    });
  };

  const onClickViewAndDownload = (txnRefno) => {
    const payload = {
      requestType: "TXNDETAILS",
      rgtn: "",
      txnRefNo: props.txnRefNumber,
      userId: state.userID,
    };

    hookGetTransactionReceiptDetails.sendRequest(payload, function (data) {
      if (data.status == "S") {
        setState({ pdfDetails: data });
        downloadPdf();
      }
    });
  };

  const downloadPdf = () => {
    html2canvas(pdfRef.current, {
      windowWidth: "1200px",
      scale: 1,
    }).then((canvas) => {
      const imgData = canvas.toDataURL("image/png");
      const pdf = new jsPDF();
      pdf.addImage(imgData, "JPEG", 0, 0);
      // pdf.output('dataurlnewwindow');
      pdf.save(`${props.txnRefNumber}.pdf`);
    });
  };

  const transcationBookedHeader = (
    <React.Fragment>
      <p className="mb-0 booking_id_subheader">Booking ID: {props.txnRefNumber} </p>
      <p className="welcome_username">Transaction Booking Successful</p>
    </React.Fragment>
  );
  const multiTitleHeader = (
    <React.Fragment>
      <p className="mb-0 booking_id_subheader">{props.title2}</p>
      <p className="welcome_username">{props.title1}</p>
    </React.Fragment>
  );

  const contactUsContainer = (
    <div className="d-flex justify-content-end">
      <div className="d-flex flex-column justify-content-center align-items-end">
        <a
          rel="noreferrer"
          className="subheader_referal_balance text-center"
          href="tel:442035829516"
          target="_blank"
        >
          <span className="contact-us-text">
            <img src={Contact} />
            +44 2035 829 516
          </span>
        </a>
        <div className="m-0 mt-3 contact-us-text text-end">
          8:30AM - 5:00PM UK
          <br />
          (Mon - Fri excluding UK Bank Holidays)
        </div>
      </div>
    </div>
  );

  return (
    <>
      <div style={{ position: "absolute", marginTop: "-2000px" }}>
        <XRInvoice
          ref={pdfRef}
          pdfDetails={state.pdfDetails}
          bankDetails={state.coreBankDetailsList}
        />
      </div>
      <div className="subheader pt-5 pb-4">
        <div className="container">
          {AuthReducer.isLoggedIn == true && (
            <div className="d-flex justify-content-between align-items-end">
              <div className="welcome__box">
                {!props.title && (
                  <React.Fragment>
                    {props.isTransactionBook && transcationBookedHeader}
                    {!props.isTransactionBook && (
                      <>
                        {!props.multiTitle ? (
                          <>
                            <p className="mb-0 welcome_default">Welcome to XMONIES,</p>
                            <p className="welcome_username">{AuthReducer.userFullName}</p>
                          </>
                        ) : (
                          multiTitleHeader
                        )}
                      </>
                    )}
                  </React.Fragment>
                )}
                {props.title && (
                  <React.Fragment>
                    <p className="welcome_username">{props.title}</p>
                  </React.Fragment>
                )}
              </div>
              <div className="d-flex align-items-center">
                {props.isTransactionBook ? (
                  <button onClick={onClickViewAndDownload} className="btn btn-primary text-white ">
                    Download Receipt
                  </button>
                ) : AuthReducer.userKYC == "DOB" ? (
                  <div className="d-flex flex-column text-center">
                    <button
                      className="btn btn-primary text-white fw-800"
                      onClick={() => setIsModalVisible(true)}
                    >
                      Complete KYC
                    </button>
                    <div className="text-primary fw-800 mb-3 fs-6 mt-3">
                      {AuthReducer.userKYCStatus === "NOTINIT" ? (
                        <span className="text-danger">KYC not Initiated</span>
                      ) : (
                        ""
                      )}
                    </div>
                  </div>
                ) : (
                  <div className="text-primary fw-800 mb-3 fs-6">
                    {/* ------ */}
                    {AuthReducer.userKYC === "PROFILE_REVIEW" &&
                      AuthReducer.userKYCStatus === "NOTINIT" ? (
                      <span className="text-danger">KYC In-Process</span>
                    ) : (
                      <></>
                    )}
                    {/* ------ */}
                    {inProcessArr.includes(AuthReducer.userKYCStatus) ? (
                      <span className="text-danger">KYC In-Process</span>
                    ) : verifiedArr.includes(AuthReducer.userKYCStatus) ? (
                      "KYC Verified"
                    ) : failedArr.includes(AuthReducer.userKYCStatus) ? (
                      <span className="text-danger">KYC Failed</span>
                    ) : (
                      ""
                    )}
                  </div>
                )}
                {props.refeemBalance && (
                  <>
                    <div className="text-end subheader_referal_balance">
                      <span className="text-primary mb-2 subheader_referal_balance__title">
                        Referral Balance
                      </span>
                      <br />
                      <span className="text-primary">
                        <span className="subheader_referal_balance__country_code">GBP</span>
                        <span className="subheader_referal_balance__amount">
                          {props.refeemBalance}
                        </span>
                      </span>
                    </div>
                    {/* <div className="subheader_referal_balance__bg"></div> */}
                  </>
                )}
                {props.contactUs && contactUsContainer}
              </div>
              <KYCModal isModalVisible={isModalVisible} setIsModalVisible={setIsModalVisible} />
            </div>
          )}
          {AuthReducer.isLoggedIn == false && (
            <>
              <div className="d-flex justify-content-between align-items-end">
                <div className="welcome__box">
                  <p className="welcome_username">{props.title}</p>
                </div>
                {props.contactUs && contactUsContainer}
              </div>
            </>
          )}
        </div>
      </div>
    </>
  );
}
