import React, { useState, useEffect } from "react";
import { Form, Input, Select, Modal, notification } from "antd";
import { Row, Col } from "react-bootstrap";
import Spinner from "../../../reusable/Spinner";
import InputOTPBox from "../../../containers/InputOTPBox";
const { Option } = Select;

export default function EditContactBox(props) {
  const [form] = Form.useForm();

  useEffect(() => {
    form.setFieldsValue({
      mobilePhoneCode: props.state.mobilePhoneCode,
      mobileNo: props.state.mobileNo,
      communicationEmailID: props.state.emailId,
    });
    props.setState({
      editablemobilePhoneCode: props.state.mobilePhoneCode,
      editableMobileNo: props.state.mobileNo,
    });
  }, []);

  useEffect(() => {
    if (props.state.senderContactDetailsErrors) {
      let errors = [];
      props.state.senderContactDetailsErrors.forEach((error, i) => {
        let errorData = {
          name: error.field,
          errors: [error.error],
        };
        errors.push(errorData);
      });
      form.setFields(errors);
    } else {
      form.setFields([{ name: "mobileNo", errors: [] }]);
    }
  }, [props.state.senderContactDetailsErrors]);

  const onFinish = (value) => {
    if (props.state.editContactTab === "3") {
      // props.setState({twofa:"Y"})

      if (!props.state.OTPVerifed) {
        // props.editSenderContactdtls(props.state.otpVerfiedToken);
        // props.setState({ otpVerfiedToken: "" });
        if (props.state.emailId1==="") {
          notification.error({ message: "Your Email is same as before" });
         }else{          
           props.sendOTP("CU", "Edit_Contact");
           props.setState({ twofaAuth: "Y" });
         }
      }
    } else {
      props.setState({ twofaAuth: "N" });
    }
    if (props.state.twofa === "Y") {
      props.sendOTP("CU", "Edit_Contact");
    }
  };

  return (
    <>
      <Modal
        centered
        className="primary"
        width={500}
        visible={props.state._isShowContactEditModel}
        onCancel={() => props.setState({ _isShowContactEditModel: false })}
        footer={null}
      >
        <Form className="contact_details_form"
          form={form}
          onFinish={onFinish}
          initialValues={{
            mobileNo: props.state.mobileNo,
            phoneNo: props.state.phoneNo,
          }}
        >
          <Spinner spinning={props.loader}>
            <div className="d-flex justify-content-center align-items-center">
              <Row className="justify-content-center">
                <Row>
                  <div className="p-0 mb-4">
                    <h2 className="text-white">Contact details</h2>
                  </div>
                </Row>

                {props.state.editContactTab == 1 && (
                  <>
                    <Col md={5}>
                      <label className="form-label">Country Code</label>
                      <Form.Item
                        className="form-item"
                        name="mobilePhoneCode"
                        rules={[
                          {
                            required: true,
                            message: "Please select your Country Code.",
                          },
                        ]}
                      >
                        <Select
                          size="large"
                          className="w-100"
                          placeholder="Select Country Code"
                          showSearch
                          optionFilterProp="children"
                          onSelect={(v) =>
                            props.setState({ editablemobilePhoneCode: v })
                          }
                        >
                          {props.state.phoneCodes.map((list, i) => {
                            return (
                              <Option key={i} value={list.countryPhoneCode}>
                                +{list.countryPhoneCode} ( {list.countryName})
                              </Option>
                            );
                          })}
                        </Select>
                      </Form.Item>
                    </Col>
                    <Col md={7}>
                      <label className="form-label">Mobile</label>
                      <Form.Item
                        className="form-item"
                        name="mobileNo"
                        rules={[
                          {
                            required: true,
                            message: "Please input your Mobile Number.",
                          },
                          {
                            min: 10,
                            max: 10,
                            message: "Mobile number must be 10 digit.",
                          },
                          {
                            pattern: /^[0-9\b]+$/,
                            message: "Only Numbers allowed",
                          },
                        ]}
                      >
                        <Input
                          onChange={(e) =>
                            props.setState({ editableMobileNo: e.target.value })
                          }
                          size="large"
                          placeholder="Enter your Mobile"
                        />
                      </Form.Item>
                    </Col>
                  </>
                )}
                {/* {props.state.editContactTab == 2 && (
                  <Col md={12}>
                    <label className="form-label">Phone Number</label>
                    <Form.Item
                      className="form-item"
                      name="phoneNo"
                      rules={[
                        {
                          min: 10,
                          max: 10,
                          message: "Mobile number must be 10 digit.",
                        },
                        {
                          pattern: /^[0-9\b]+$/,
                          message: "Only Numbers allowed",
                        },
                      ]}
                    >
                      <Input
                        onChange={(e) =>
                          props.setState({ phoneNo: e.target.value })
                        }
                        size="large"
                        placeholder="Enter your Phone Number"
                      />
                    </Form.Item>
                  </Col>
                )} */}
                {props.state.editContactTab == 3 && (
                  <Col md={12}>
                    <label className="form-label">Communication Email ID</label>
                    <Form.Item
                      className="form-item"
                      name="communicationEmailID"
                      rules={[
                        {
                          required: true,
                          message: "Please input your Communication Email ID.",
                        },
                        {
                          type: "email",
                          message: "Please input your valid email.",
                        },
                      ]}
                    >
                      <Input
                        onChange={(e) =>
                          props.setState({ emailId1: e.target.value })
                        }
                        disabled={props.state.disabled}
                        size="large"
                        placeholder="Enter your Communication Email ID"
                      />
                    </Form.Item>
                    {props.state.otpBoxEmail && (
                      <>
                        <InputOTPBox
                          state={props.state}
                          setState={props.setState}
                          otpType="UL"
                          useFor="signup"
                          appState={props.appState}
                          setCurrent={props.setCurrent}
                          setLoader={props.setLoader}
                          editSenderContactdtls={props.editSenderContactdtls}
                        />
                      </>
                    )}
                  </Col>
                )}
                {!props.state.otpBoxEmail && (
                  <div className="d-grid gap-2 d-flex justify-content-between mt-4">
                    <button
                      className="btn btn-danger btn-block btn-sm px-4"
                      onClick={() =>
                        props.setState({ _isShowContactEditModel: false })
                      }
                      type="button"
                    >
                      Cancel
                    </button>
                    <button
                      disabled={
                        props.state.OTPVerifed ? false : props.state.disabled
                      }
                      className="btn btn-secondary btn-sm px-4"
                    >
                      {props.state.editContactTab == 3 ? "Update" : "Submit"}
                    </button>
                  </div>
                )}
              </Row>
            </div>
          </Spinner>
        </Form>
      </Modal>
    </>
  );
}
