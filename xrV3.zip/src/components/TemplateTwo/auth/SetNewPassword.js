import React, { useState, useReducer, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { Form, Input, notification } from "antd";
import { AuthAPI } from "../../../apis/AuthAPI";
import { useSelector } from "react-redux";
import useHttp from "../../../hooks/useHttp";
import Spinner from "../../../reusable/Spinner";

function SetNewPassword(props) {
  let navigate = useNavigate();
  const [form] = Form.useForm();
  const [loading, setLoader] = useState(false);

  const hookResetPassword = useHttp(AuthAPI.resetPassword);

  useEffect(() => {
    window.scrollTo({ top: 0, behavior: "smooth" });
  }, []);

  const saveSignUpData = (value) => {
    form.setFields([{ name: "passwordNew", errors: [] }]);
    const resetPasswordPayload = {
      requestType: "RESETPASSWORD",
      password: value.passwordNew,
      verifyType: "O",
      verifiedToken: props.state.verifiedToken,
    };

    setLoader(true);
    hookResetPassword.sendRequest(resetPasswordPayload, function (data) {
      if (data.status == "S") {
        notification.success({ message: data.message });
        navigate("/signin");
      } else {
        setLoader(false);
        notification.error({ message: data.errorMessage });
        let errors = [];
        data.errorList.forEach((error, i) => {
          if (error.field == "password") {
            form.setFields([{name:"passwordNew", errors:[error.error]}]);
            notification.error({ message: error.error });
          }
          let errorData = {
            name: error.field,
            errors: [error.error],
          };
          errors.push(errorData);
        });

        if (errors.length > 0) form.setFields(errors);
      }
    });
  };

  return (
    <Form form={form} onFinish={saveSignUpData}>
      <div>
        <label htmlFor="exampleFormControlInput1" className="step-label  mb-1">
          Enter New Password
        </label>
        <Form.Item
          className="form-item"
          name="passwordNew"
          rules={[
            { required: true, message: "Please input your Password." },
            {
              min: 10,
              max: 20,
              message: "Password should be between 10 and 20 characters long.",
            },
          ]}
        >
          <Input.Password size="large" placeholder="Enter your Password" />
        </Form.Item>
      </div>
      <div className="mb-3">
        <label htmlFor="exampleFormControlInput1" className="step-label  mb-1">
          Confirm New Password
        </label>
        <Form.Item
          className="form-item"
          name="confirmPassword"
          rules={[
            {
              required: true,
              message: "Please input your Confirm Password.",
            },
            ({ getFieldValue }) => ({
              validator(rule, value) {
                if (!value || getFieldValue("passwordNew") === value) {
                  return Promise.resolve();
                }
                return Promise.reject(
                  "The two password that you entered do not match!"
                );
              },
            }),
          ]}
        >
          <Input.Password
            size="large"
            placeholder="Enter your Confirm Password"
          />
        </Form.Item>
      </div>
      <div className="my-4"></div>
      <Spinner spinning={loading} delay={500}>
        <div className="d-grid g-2">
          <button className="btn btn-primary text-white my-1" type="submit">
            Next
          </button>
        </div>
      </Spinner>
    </Form>
  );
}

export default SetNewPassword;
