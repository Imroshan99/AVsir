import { Modal } from "antd";
import { useEffect } from "react";
import { useSelector, useDispatch } from "react-redux";
import KycPage from "./KYC";

export default function KYCModal(props) {
  const dispatch = useDispatch();
  const AuthReducer = useSelector((state) => state);
  useEffect(() => {
    if (AuthReducer.userKYCBoolean) {
      props.setIsModalVisible(true);
    }
  }, [props.isModalVisible, AuthReducer.userKYCBoolean]);
  return (
    <>
      <Modal
        className="light kyc"
        centered
        visible={props.isModalVisible}
        onCancel={() => {
          props.setIsModalVisible(false);
          dispatch({ type: "SET_USER_KYC_BOOLEAN", payload: false });
        }}
        footer={null}
        width={1000}
        maskClosable={false}
      >
        <KycPage getProfile={props.getProfile} setIsModalVisible={props.setIsModalVisible} />
      </Modal>
    </>
  );
}
