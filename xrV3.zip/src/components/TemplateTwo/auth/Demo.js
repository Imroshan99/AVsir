export default function Demo(){
    return(
        <div>
            Hello sanajy suthar
        </div>
    )
}