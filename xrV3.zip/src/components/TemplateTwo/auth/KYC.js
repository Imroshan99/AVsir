import React, { useState, useEffect, useReducer } from "react";
import { Row, Col } from "react-bootstrap";
import {
  Form,
  Input,
  Select,
  notification,
  Upload,
  Button,
  DatePicker,
  message,
  AutoComplete,
  Tabs,
} from "antd";
import {
  CameraOutlined,
  DeleteOutlined,
  FilePdfOutlined,
  LoadingOutlined,
} from "@ant-design/icons";
import moment from "moment";
import { useLocation } from "react-router-dom";
import { useDispatch, useSelector } from "react-redux";
import { ProfileAPI } from "../../../apis/ProfileAPI";
import { GuestAPI } from "../../../apis/GuestAPI";
import { LogAPI } from "../../../apis/LogAPI";
import { TransactionAPI } from "../../../apis/TransactionAPI";
import Lottie from "react-lottie";
import * as kycLottie from "../../../assets/images/XR/KYC-under-review.json";
import useHttp from "../../../hooks/useHttp";
import { inputValidations } from "../../../services/validations/validations";
import Spinner from "../../../reusable/Spinner";
import { COUNTRY } from "../../../services/Country";

const { Option } = Select;
const { TextArea } = Input;

const _XRIdProofList = [
  {
    docName: "Driving License",
    docId: "2",
    docType: "DL",
  },

  {
    docName: "Passport",
    docId: "1",
    docType: "PP",
  },
];


const _purposeList = [
  {
    purpose: "Emigrating",
    purposeCode: "EMIGRATING"
  },
  {
    purpose: "Mortgage payments",
    purposeCode: "MORTGAGE_PAYMENTS"
  },
  {
    purpose: "Overseas living expenses",
    purposeCode: "OVERSEA_LIV_EXP"
  },
  {
    purpose: "Paying bills / credit card overseas",
    purposeCode: "PAYING_BILL_CREDIT_OVERS"
  },
  {
    purpose: "Pension",
    purposeCode: "PENSION"
  },
  {
    purpose: "Property - Sale/Purchase/Maintenance",
    purposeCode: "PROPERTY_SALE_PUR_MAIN"
  },
  {
    purpose: "Repayment of a loan",
    purposeCode: "REPAYMENT_LOAN"
  },
  {
    purpose: "Supplier/Invoice payments",
    purposeCode: "SUPPLIER_INV_PAYMENTS"
  },
  {
    purpose: "Transfer of savings to own overseas account",
    purposeCode: "TRANSFER_OWN_ACCOUNT"
  },
  {
    purpose: "Tuition fees",
    purposeCode: "TUITION_FEES"
  },
  {
    purpose: "Family support",
    purposeCode: "FAMILY_SUPPORT"
  },
  {
    purpose: "Medical Expenses",
    purposeCode: "MEDICAL"
  },
  {
    purpose: "Donation",
    purposeCode: "DONATION"
  },
  {
    purpose: "Gift",
    purposeCode: "GIFT"
  },
  {
    purpose: "Not Specified",
    purposeCode: "NOT_SPECIFIED"
  }
];

export default function KycPage(props) {
  const [form, form1] = Form.useForm();
  const [addproofId, setAddProofId] = useState("");
  const [spinner, setSpinner] = useState(0);
  const [value, setValue] = useState({});

  const AuthReducer = useSelector((state) => state);
  const ConfigReducer = useSelector((state) => state);
  const dispatch = useDispatch();
  const { inputFields } = ConfigReducer.groupIdSettings.kyc;
  const [frontDoc, setFrontDoc] = useState("");
  const [backDoc, setBackDoc] = useState("");
  const [addProofDoc, setAddProofDoc] = useState("");
  const [loading, setLoading] = useState();
  const [imageUrl, setImageUrl] = useState();
  const [imageUrl1, setImageUrl1] = useState();
  const [imageUrl2, setImageUrl2] = useState();
  const [passFileNo, setPassFileNo] = useState();
  const [editProfilePayload, setEditProfilePayload] = useState({});
  const [docUploadCheck, setDocUploadCheck] = useState({
    idProofFront: false,
    idProofBack: false,
    addressProof: false,
  });
  const [editProfileFormSubmit, setEditProfileFormSubmit] = useState(false);
  const location = useLocation();

  const [state, setState] = useReducer((state, newState) => ({ ...state, ...newState }), {
    userID: AuthReducer.userID,
    nationalities: [],
    additionalInfo2: "",
    occupationLists: [],
    sourceOFFundLists: [],
    purposeLists: [],
    // uniqueIdentifierLists: [],
    idProofLists: [],
    addressProofLists: [],
    stateLists: [],
    cityLists: [],
    profileData: [],
    stateListsIssuer: [],
    issuerCountryList: [],
    sourceFundOther: "",
    occupationOther: "",
    idIssuer: "",
    redirectPage: "",
    redirectPageState: [],
    DocPdf: false,
    DocPdf1: false,
    DocPdf2: false,
    kycPage: 1,
  });

  const hookGetNationality = useHttp(GuestAPI.getNationality);
  const hookGetProfile = useHttp(ProfileAPI.getProfile);
  const hookEditProfile = useHttp(ProfileAPI.editProfile);
  const hookUserDocUpload = useHttp(ProfileAPI.userDocUpload);
  const hookGetOccupationLists = useHttp(GuestAPI.occupationLists);
  const hookGetUniqueIdentifierList = useHttp(GuestAPI.uniqueIdentifierList);
  const hookGetCountryStates = useHttp(GuestAPI.countryStates);
  const hookGetCountryLists = useHttp(GuestAPI.countryList);
  const hookGetSendingCountryLists = useHttp(GuestAPI.sendingCountryList);
  const hookGetStateCities = useHttp(GuestAPI.stateCities);
  const hookGetSourceOFFundLists = useHttp(TransactionAPI.sourceOFFundLists);
  const hookGetPurposeLists = useHttp(TransactionAPI.purposeLists);

  useEffect(() => {
    window.scrollTo({ top: 0, behavior: "smooth" });
    getSourceOFFundLists();
    getPurposeLists();
    getUserProfile();
    getNationality();
    getOccupationLists();
    getUniqueIdentifierNames();
    getStateLists();
    getIssuerCountryList();
    setState({
      redirectPage: location.state?.fromPage,
      redirectPageState: location.state?.fromPageState,
    });
    form.setFieldsValue({
      country: COUNTRY[AuthReducer.regCountryCode].countryName,
    });
  }, []);
  useEffect(() => {
    if (imageUrl && imageUrl1 && imageUrl2) {
      if (
        docUploadCheck.idProofFront &&
        docUploadCheck.idProofBack &&
        docUploadCheck.addressProof
      ) {
        if (editProfileFormSubmit) {
          editProfile();
        }
      }
    } else if (imageUrl && imageUrl2) {
      if (docUploadCheck.idProofFront && docUploadCheck.addressProof) {
        if (editProfileFormSubmit) {
          editProfile();
        }
      }
    }
  }, [editProfileFormSubmit]);
  useEffect(() => {
    if (imageUrl && imageUrl1 && imageUrl2) {
      if (
        docUploadCheck.idProofFront &&
        docUploadCheck.idProofBack &&
        docUploadCheck.addressProof
      ) {
        setEditProfileFormSubmit(true);
      }
    } else if (imageUrl && imageUrl2) {
      if (docUploadCheck.idProofFront && docUploadCheck.addressProof) {
        setEditProfileFormSubmit(true);
      }
    }
  }, [docUploadCheck, editProfilePayload]);

  const editProfile = () => {
    setSpinner((prevState) => prevState + 1);
    hookEditProfile.sendRequest(editProfilePayload, function (data) {
      setSpinner((prevState) => prevState - 1);
      if (data.status == "S") {
        setState({ kycPage: 3 });
        setDocUploadCheck({
          idProofFront: false,
          idProofBack: false,
          addressProof: false,
        });
        setEditProfileFormSubmit(false);
        setImageUrl("");
        setImageUrl1("");
        setImageUrl2("");
        let logPayload = {
          groupId: "XR",
          logText: `KYC Success : ${AuthReducer.userID}`,
          callerFileName: "XR_kyc.js",
          logFileName: "XR_kyc_log",
          stackTrace: "",
          msgLevel: "INFO",
        };
        LogAPI.kycLog(logPayload);
        dispatch({ type: "SET_USER_KYC", payload: "KycDone" });
        dispatch({ type: "SET_USER_KYC_STATUS", payload: "PENDING" });
        if (location.pathname === "/profile") {
          props.getProfile();
        }
        // Branch code start
        var custom_data = {
          Custom_Event_Property_Key1: "Custom_Event_Property_val1",
          Custom_Event_Property_Key2: "Custom_Event_Property_val2",
        };
        // eslint-disable-next-line no-undef
        branch.logEvent("kyc_complete", custom_data, function (err) {
          console.log("LogEventError", err);
        });
        // Brand code end
      } else {
        setEditProfileFormSubmit(false);
        // setDocUploadCheck({
        //   idProofFront: false,
        //   idProofBack: false,
        //   addressProof: false,
        // });
        let logPayload = {
          groupId: "XR",
          logText: `KYC Failed : ${AuthReducer.userID}`,
          callerFileName: "XR_kyc.js",
          logFileName: "XR_kyc_log",
          stackTrace: "",
          msgLevel: "INFO",
        };
        LogAPI.kycLog(logPayload);
        let errors = [];
        data.errorList.forEach((error, i) => {
          let errorData = {
            name: error.field,
            errors: [error.error],
          };
          errors.push(errorData);
        });
        if (errors.length > 0) form.setFields(errors);
        if (errors.length > 0) form1.setFields(errors);
      }
    });
  };
  const getIssuerCountryList = async () => {
    let payload = {
      requestType: "COUNTRYLIST",
    };
    setSpinner((prevState) => prevState + 1);
    hookGetSendingCountryLists.sendRequest(payload, function (data) {
      setSpinner((prevState) => prevState - 1);
      if (data.status === "S") {
        setState({ issuerCountryList: data.responseData });
      } else {
        notification.error({ message: data.errorMessage });
      }
    });
  };
  const getNationality = async () => {
    const payload = {
      requestType: "NATIONALITYLIST",
      keyword: "",
    };
    setSpinner((prevState) => prevState + 1);
    hookGetNationality.sendRequest(payload, function (data) {
      setSpinner((prevState) => prevState - 1);
      if (data.status == "S") {
        setState({ nationalities: data.responseData });
      } else {
        notification.error({ message: data.errorMessage });
      }
    });
  };


  const getPurposeLists = () => {
    const payload = {
      requestType: "PurposeList",
      keyword: "",
      nickName: "NEWRECV",
      recvCountryCode: AuthReducer.recvCountryCode,
      userId: AuthReducer.userID,
    };

    setSpinner((prevState) => prevState + 1);
    hookGetPurposeLists.sendRequest(payload, function (data) {
      setSpinner((prevState) => prevState - 1);
      // if (data.status == "S") {
      //   setState({ purposeLists: data.responseData });
      // }
        setState({ purposeLists: _purposeList });
    });
  };

  const getUserProfile = async () => {
    let payload = {
      requestType: "USERPROFILE",
      userId: state.userID,
    };
    setSpinner((prevState) => prevState + 1);
    hookGetProfile.sendRequest(payload, function (data) {
      setSpinner((prevState) => prevState - 1);
      if (data.status === "S") {
        setState({ profileData: data });
      } else {
        notification.error({ message: data.errorMessage });
      }
    });
  };
  const onSelectStateHandler = async (stateCode) => {
    const cityPayload = {
      requestType: "CITILIST",
      countryCode: AuthReducer.regCountryCode,
      stateCode: stateCode,
    };
    setSpinner((prevState) => prevState + 1);
    hookGetStateCities.sendRequest(cityPayload, function (data) {
      setSpinner((prevState) => prevState - 1);
      if (data.status === "S") {
        setState({
          cityLists: data.responseData,
        });
      }
    });
  };

  const getOccupationLists = async () => {
    let payload = {
      requestType: "LEAD",
    };
    setSpinner((prevState) => prevState + 1);
    hookGetOccupationLists.sendRequest(payload, function (data) {
      setSpinner((prevState) => prevState - 1);
      if (data.status === "S") {
        data.responseData.push({
          displayOrder: "18",
          occupationDesc: "Other",
          occupationId: "100",
          occupationName: "Other",
        });
        setState({ occupationLists: data.responseData });
      } else {
        notification.error({ message: data.errorMessage });
      }
    });
  };

  const getUniqueIdentifierNames = async () => {
    let payload = {
      requestType: "UNNAMESLIST",
      idFor: "RECV",
    };
    setSpinner((prevState) => prevState + 1);
    hookGetUniqueIdentifierList.sendRequest(payload, function (data) {
      setSpinner((prevState) => prevState - 1);
      if (data.status === "S") {
        const docListArray = data.responseData;
        // ID proof list
        const disableIDList = ["BS", "TB", "UB"];
        const idProofListArray = docListArray.reduce(function (prev, current) {
          if (!disableIDList.includes(current.docType)) {
            prev.push(current);
          }
          return prev;
        }, []);

        // Address proof list
        const disableAddressProofList = ["RC", "PP", "DL", "EEA"];
        const addressProofListArray = docListArray.reduce(function (prev, current) {
          if (!disableAddressProofList.includes(current.docType)) {
            prev.push(current);
          }
          return prev;
        }, []);
        setState({ idProofLists: idProofListArray });
        setState({ addressProofLists: addressProofListArray });
        // if (location.pathname === "/profile") {
        //   setState({ addressProofLists: docListArray });
        // }
      } else {
        notification.error({ message: data.errorMessage });
      }
    });
  };

  const getStateLists = async () => {
    let payload = {
      requestType: "STATELIST",
      countryCode: AuthReducer.regCountryCode,
      keyword: "",
    };
    setSpinner((prevState) => prevState + 1);
    hookGetCountryStates.sendRequest(payload, function (data) {
      setSpinner((prevState) => prevState - 1);
      if (data.status === "S") {
        setState({ stateLists: data.responseData });
        const stateIssuerArray = [...data.responseData];
        setState({ stateListsIssuer: stateIssuerArray });
      } else {
        notification.error({ message: data.errorMessage });
      }
    });
  };

  const getSourceOFFundLists = () => {
    const payload = {
      requestType: "FUNDSOURCELIST",
    };
    setSpinner((prevState) => prevState + 1);
    hookGetSourceOFFundLists.sendRequest(payload, function (data) {
      setSpinner((prevState) => prevState - 1);
      if (data.status == "S") {
        setState({ sourceOFFundLists: data.responseData });
      } else {
        notification.error({ message: data.errorMessage });
      }
    });
  };

  const submitHandler = (value) => {
    let logPayload = {
      groupId: "XR",
      logText: `KYC Started : ${AuthReducer.userID}`,
      callerFileName: "XR_kyc.js",
      logFileName: "XR_kyc_log",
      stackTrace: "",
      msgLevel: "INFO",
    };
    LogAPI.kycLog(logPayload);
    let nationalityCode = "";
    state.nationalities.find((i) => {
      if (i.nationality == value.nationality) {
        nationalityCode = i.countryCode;
      }
    });
    let occupationCode = "";
    state.occupationLists.find((i) => {
      if (i.occupationName == value.occupation) {
        occupationCode = i.occupationId;
      }
    });
    let sourcefundVal = "";
    state.sourceOFFundLists.find((i) => {
      if (value.sourcefund == i.sourceOfFund) {
        sourcefundVal = i.sourceFundId;
      }
    });
    if (!docUploadCheck.idProofFront) {
      userDocUpload({ docType: value.idtype });
    }
    if (!docUploadCheck.idProofBack) {
      userDocUpload1({ docType: value.idtype });
    }
    if (!docUploadCheck.addressProof) {
      userDocUpload2({ docType: addproofId });
    }
    let editProfilePayload = {
      requestType: "EDITPROFILE",
      userId: AuthReducer.userID,
      gender: state.profileData.gender,
      dob: state.profileData.dob,
      address1: window.btoa(value.address.trim()),
      address2: window.btoa(value.address2.trim()),
      address3: "",
      address4: "",
      address5: "",
      state: window.btoa(value.state.trim()),
      city: window.btoa(value.city.trim()),
      sendCountry: AuthReducer.regCountryCode,
      zipCode: value.zipCode.replace(/\s/g, ""),
      occupation: occupationCode,
      profession: "1",
      citizenship: nationalityCode,
      pageName: "EDITPROFILE",
      income: "1",
      commAddress1: value.address ? window.btoa(value.address.trim()) : "",
      commAddress2: value.commAddress2 ? window.btoa(value.commAddress2.trim()) : "",
      commCity: value.city ? value.city.trim() : "",
      commStateProvince: value.state ? value.state.trim() : "",
      commPostalCode: value.zipCode ? value.zipCode.replace(/\s/g, "") : "",
      commCountry: AuthReducer.regCountryCode,
      companyName: value.purpose,
      nationality: nationalityCode,
      isSameCommAddressFlag: "N",
      extraInfoRequire: "Y",
      uniqueIdentifierType: value.idtype,
      uniqueIdentifierValue: value.documentidnumber.trim(),
      sourceOfFund: sourcefundVal,
      additionalInfo1: state.idIssuer,
      additionalInfo2: state.additionalInfo2, //for ID Exipiry
      additionalInfo3: value.companyAddress, //for Company Address
      additionalInfo4: value.passportfilenumber, //for ID Exipiry
      additionalInfo5: value.remittance_freq, //for Remintence Frequencey
      // additionalInfo6: value.sourcefund, //for Source of Fund
      sin: "",
    };
    setEditProfilePayload(editProfilePayload);
  };

  const userDocUpload = async (docData) => {
    let logPayload = {
      groupId: "XR",
      logText: `KYC_ID_PROOF_FRONT Upload Started : ${AuthReducer.userID}`,
      callerFileName: "XR_kyc.js",
      logFileName: "XR_kyc_log",
      stackTrace: "",
      msgLevel: "INFO",
    };
    LogAPI.kycLog(logPayload);
    let docPayload = {
      requestType: "USERDOCUPLOAD",
      docType: docData.docType,
      docName: frontDoc.fileName,
      docExtension: frontDoc.fileName.split(".").pop(),
      userId: AuthReducer.userID,
      document: frontDoc.docUrl,
    };
    setSpinner((prevState) => prevState + 1);
    hookUserDocUpload
      .sendRequest(docPayload, function (data) {
        setSpinner((prevState) => prevState - 1);
        if (data.status == "S") {
          setDocUploadCheck((prevState) => ({
            ...prevState,
            idProofFront: true,
          }));
          let logPayload = {
            groupId: "XR",
            logText: `KYC_ID_PROOF_FRONT Upload Success : ${AuthReducer.userID}`,
            callerFileName: "XR_kyc.js",
            logFileName: "XR_kyc_log",
            stackTrace: "",
            msgLevel: "INFO",
          };
          LogAPI.kycLog(logPayload);
        } else {
          let logPayload = {
            groupId: "XR",
            logText: `KYC_ID_PROOF_FRONT Upload Failed : ${AuthReducer.userID}`,
            callerFileName: "XR_kyc.js",
            logFileName: "XR_kyc_log",
            stackTrace: "",
            msgLevel: "INFO",
          };
          LogAPI.kycLog(logPayload);
        }
      })
      .catch((err) => {
        setState({ kycPage: 1 });
        setSpinner((prevState) => prevState - 1);
        let logPayload = {
          groupId: "XR",
          logText: `KYC_ID_PROOF_FRONT Upload Failed : ${AuthReducer.userID}`,
          callerFileName: "XR_kyc.js",
          logFileName: "XR_kyc_log",
          stackTrace: "",
          msgLevel: "INFO",
        };
        LogAPI.kycLog(logPayload);
        setImageUrl("");
        setFrontDoc("");
        setImageUrl2("");
        setAddProofDoc("");
        notification.error({
          message: "ID Proof Front Doc Upload Failed",
        });
      });
  };
  const userDocUpload1 = async (docData) => {
    if (backDoc.docUrl1) {
      let logPayload = {
        groupId: "XR",
        logText: `KYC_ID_PROOF_BACK Upload Started : ${AuthReducer.userID}`,
        callerFileName: "XR_kyc.js",
        logFileName: "XR_kyc_log",
        stackTrace: "",
        msgLevel: "INFO",
      };
      LogAPI.kycLog(logPayload);
      let docPayload = {
        requestType: "USERDOCUPLOAD",
        docType: docData.docType,
        docName: backDoc.fileName1,
        docExtension: backDoc.fileName1.split(".").pop(),
        userId: AuthReducer.userID,
        document: backDoc.docUrl1,
      };
      setSpinner((prevState) => prevState + 1);
      hookUserDocUpload
        .sendRequest(docPayload, function (data) {
          setSpinner((prevState) => prevState - 1);
          if (data.status == "S") {
            setDocUploadCheck((prevState) => ({
              ...prevState,
              idProofBack: true,
            }));
            let logPayload = {
              groupId: "XR",
              logText: `KYC_ID_PROOF_BACK Upload Success : ${AuthReducer.userID}`,
              callerFileName: "XR_kyc.js",
              logFileName: "XR_kyc_log",
              stackTrace: "",
              msgLevel: "INFO",
            };
            LogAPI.kycLog(logPayload);
          } else {
            let logPayload = {
              groupId: "XR",
              logText: `KYC_ID_PROOF_BACK Upload Failed : ${AuthReducer.userID}`,
              callerFileName: "XR_kyc.js",
              logFileName: "XR_kyc_log",
              stackTrace: "",
              msgLevel: "INFO",
            };
            LogAPI.kycLog(logPayload);
          }
        })
        .catch((err) => {
          setState({ kycPage: 1 });
          notification.error({
            message: "ID Proof Back Doc Upload Failed",
          });
          setImageUrl1("");
          setBackDoc("");
          setImageUrl2("");
          setAddProofDoc("");
          setSpinner((prevState) => prevState - 1);
          let logPayload = {
            groupId: "XR",
            logText: `KYC_ID_PROOF_BACK Upload Failed : ${AuthReducer.userID}`,
            callerFileName: "XR_kyc.js",
            logFileName: "XR_kyc_log",
            stackTrace: "",
            msgLevel: "INFO",
          };
          LogAPI.kycLog(logPayload);
        });
    }
  };
  const userDocUpload2 = async (docData) => {
    let logPayload = {
      groupId: "XR",
      logText: `KYC_ADD_PROOF Upload Started : ${AuthReducer.userID}`,
      callerFileName: "XR_kyc.js",
      logFileName: "XR_kyc_log",
      stackTrace: "",
      msgLevel: "INFO",
    };
    LogAPI.kycLog(logPayload);
    let docPayload = {
      requestType: "USERDOCUPLOAD",
      docType: docData.docType,
      docName: addProofDoc.fileName2,
      docExtension: addProofDoc.fileName2.split(".").pop(),
      userId: AuthReducer.userID,
      document: addProofDoc.docUrl2,
    };
    setSpinner((prevState) => prevState + 1);
    hookUserDocUpload
      .sendRequest(docPayload, function (data) {
        setSpinner((prevState) => prevState - 1);
        if (data.status == "S") {
          setDocUploadCheck((prevState) => ({
            ...prevState,
            addressProof: true,
          }));
          let logPayload = {
            groupId: "XR",
            logText: `KYC_ADD_PROOF Upload Success : ${AuthReducer.userID}`,
            callerFileName: "XR_kyc.js",
            logFileName: "XR_kyc_log",
            stackTrace: "",
            msgLevel: "INFO",
          };
          LogAPI.kycLog(logPayload);
        } else {
          let logPayload = {
            groupId: "XR",
            logText: `KYC_ADD_PROOF Upload Failed : ${AuthReducer.userID}`,
            callerFileName: "XR_kyc.js",
            logFileName: "XR_kyc_log",
            stackTrace: "",
            msgLevel: "INFO",
          };
          LogAPI.kycLog(logPayload);
        }
      })
      .catch((err) => {
        notification.error({
          message: "Address Proof Doc Upload Failed",
        });
        setImageUrl2("");
        setAddProofDoc("");
        setSpinner((prevState) => prevState - 1);
        let logPayload = {
          groupId: "XR",
          logText: `KYC_ADD_PROOF Upload Failed : ${AuthReducer.userID}`,
          callerFileName: "XR_kyc.js",
          logFileName: "XR_kyc_log",
          stackTrace: "",
          msgLevel: "INFO",
        };
        LogAPI.kycLog(logPayload);
      });
  };

  const normFile = (e) => {
    if (Array.isArray(e)) {
      return e;
    }
    return e && e.fileList;
  };
  const normFile1 = (e) => {
    if (Array.isArray(e)) {
      return e;
    }
    return e && e.fileList;
  };
  const normFile2 = (e) => {
    if (Array.isArray(e)) {
      return e;
    }
    return e && e.fileList;
  };

  const onChangeIssuerID = (value, type) => {
    if (value === "Other") {
    } else {
      setState({
        idIssuer: value,
      });
      if (type === "ISSUER_STATE") {
      }
    }
  };
  const handleChange = (info) => {
    if (info.file.status === "uploading") {
      setLoading(true);
      return;
    }
    if (info.file.status === "done") {
      getBase64(info.file.originFileObj, (imageUrl) => {
        setLoading(false);
      });
    }
  };

  function getBase64(img, callback) {
    const reader = new FileReader();
    reader.addEventListener("load", () => callback(reader.result));
    reader.readAsDataURL(img);
  }

  const handleTabChange = (activePage) => {
    if (frontDoc) {
      setState({
        kycPage: activePage,
      });
    }
  };

  return (
    <div className="KYCPage">
      <Spinner spinning={spinner === 0 ? false : true}>
        {state.kycPage !== 3 && (
          <>
            <div>
              <h5 className="text-primary text-center">
                Please complete your KYC in order to proceed
              </h5>
            </div>
            <div className="mb-3">
              <h2>Complete Your KYC</h2>
            </div>
            <div className="d-flex align-items-center mb-4 kyc_nav">
              <button
                className={`btn btn-info btn-sm me-3 fw-800 fs-12 ${state.kycPage === 1 ? "active" : "inactive"
                  }`}
                onClick={() => {
                  handleTabChange(1);
                }}
              >
                ID Proof
              </button>
              <button
                className={`btn btn-info btn-sm  fw-800  fs-12 ${state.kycPage === 2 ? "active" : "inactive"
                  }`}
                onClick={() => {
                  handleTabChange(2);
                }}
              >
                Address Proof
              </button>
            </div>
          </>
        )}
        <Tabs defaultActiveKey="1" activeKey={`${state.kycPage}`}>
          <Tabs.TabPane key="1">
            <>
              <Form
                form={form1}
                autoComplete="none"
                onFinish={(values) => {
                  if (frontDoc == "") {
                    form1.setFields([{ name: "document", errors: ["Please upload document"] }]);
                  }
                  if (frontDoc) {
                    setValue(values);
                    setState({ kycPage: 2 });
                  }
                }}
              >
                <Row>
                  <Col className="pe-3">
                    <Row>
                      <Form.Item
                        wrapperCol={{ span: 24 }}
                        className="form-item w-100"
                        name="idtype"
                        rules={[
                          {
                            required: true,
                            message: "Select Document Type.",
                          },
                        ]}
                      >
                        <Select
                          className="primary_selectbox"
                          onChange={(e) => {
                            setPassFileNo(e);
                          }}
                          placeholder="Select Document Type"
                        >
                          {state.idProofLists.map((uiRow, i) => {
                            return (
                              <Option key={i} value={uiRow.docType}>{`${uiRow.docName}`}</Option>
                            );
                          })}
                        </Select>
                      </Form.Item>
                    </Row>
                    <div className="row mb-3">
                      <div className="col-6 text-center">
                        <Form.Item
                          className="mb-2"
                          wrapperCol={{ span: 24 }}
                          name="document"
                          valuePropName="fileList"
                          getValueFromEvent={normFile}
                          multiple={false}
                          rules={[
                            {
                              required: true,
                              message: "Please upload document.",
                            },
                            // {
                            //   validator: (_, value) => {
                            //     console.log("bugggs",value);
                            //     console.log("bugggs 1",_);
                            //     const acceptExtType = [
                            //       "image/jpg",
                            //       "image/jpeg",
                            //       "image/png",
                            //       "application/pdf",
                            //     ];
                            //     const fObj = value[0];
                            //     let fileExt = fObj.type;
                            //     if (!value || acceptExtType.includes(fileExt)) {
                            //       return Promise.resolve();
                            //     }
                            //     return Promise.reject(
                            //       new Error(
                            //         "Upload valid document. Document format should be .jpg, .png & .bmt."
                            //       )
                            //     );
                            //   },
                            // },
                          ]}
                        >
                          <Upload
                            name="logo"
                            listType="picture-card"
                            className="avatar-uploader"
                            accept="image/jpg, image/jpeg, image/png,application/pdf"
                            showUploadList={false}
                            beforeUpload={(file) => {
                              setState({
                                DocPdf: file.type.includes("application/pdf"),
                              });
                              const isLt3MB = file.size;
                              if (isLt3MB >= "3145728") {
                                message.error("Document upload size limit maximum of 3MB!");
                                return false;
                              } else {
                                const fileName = file.name;
                                const fileType = file.type;
                                const reader = new FileReader();
                                reader.onload = (e) => {
                                  setFrontDoc({
                                    fileName,
                                    fileType,
                                    docUrl: e.target.result,
                                  });
                                  setImageUrl(e.target.result);
                                };
                                reader.readAsDataURL(file);

                                return false;
                              }
                            }}
                            onChange={(e) => {
                              handleChange(e);
                              setDocUploadCheck((prevState) => ({
                                ...prevState,
                                idProofFront: false,
                              }));
                            }}
                          >
                            {imageUrl ? (
                              <>
                                {state.DocPdf ? (
                                  <FilePdfOutlined />
                                ) : (
                                  <img
                                    onError={(e) => {
                                      notification.error({
                                        message: "Corrupted Image. Please Select another image.",
                                      });
                                      setImageUrl("");
                                      setFrontDoc("");
                                    }}
                                    src={imageUrl}
                                    alt="avatar"
                                    width="100%"
                                    height="100%"
                                  />
                                )}
                              </>
                            ) : (
                              <div>
                                {loading ? <LoadingOutlined /> : <CameraOutlined />}
                                <div className="mt-8">Upload</div>
                                <div>Front</div>
                              </div>
                            )}
                          </Upload>
                        </Form.Item>
                        {imageUrl && (
                          <DeleteOutlined
                            onClick={() => {
                              setImageUrl("");
                              setFrontDoc("");
                            }}
                          />
                        )}
                      </div>
                      <div className="col-6 text-center">
                        <Form.Item
                          className="mb-2"
                          wrapperCol={{ span: 24 }}
                          name="document2"
                          valuePropName="fileList"
                          getValueFromEvent={normFile1}
                          multiple={false}
                          rules={[
                            {
                              required: false,
                              message: "Please upload document.",
                            },
                          ]}
                        >
                          <Upload
                            name="logo1"
                            listType="picture-card"
                            className="avatar-uploader"
                            accept="image/jpg, image/jpeg, image/png, application/pdf"
                            showUploadList={false}
                            beforeUpload={(file) => {
                              setState({
                                DocPdf1: file.type.includes("application/pdf"),
                              });
                              const isLt3MB = file.size;
                              if (isLt3MB >= "3145728") {
                                message.error("Document upload size limit maximum of 3MB!");
                                return false;
                              } else {
                                const fileName1 = file.name;
                                const fileType1 = file.type;
                                const reader = new FileReader();

                                reader.onload = (e) => {
                                  setBackDoc({
                                    fileName1,
                                    fileType1,
                                    docUrl1: e.target.result,
                                  });
                                  setImageUrl1(e.target.result);
                                };
                                reader.readAsDataURL(file);

                                return false;
                              }
                            }}
                            onChange={(e) => {
                              handleChange(e);
                              setDocUploadCheck((prevState) => ({
                                ...prevState,
                                idProofBack: false,
                              }));
                            }}
                          >
                            {imageUrl1 ? (
                              <>
                                {state.DocPdf1 ? (
                                  <FilePdfOutlined />
                                ) : (
                                  <img
                                    onError={(e) => {
                                      notification.error({
                                        message: "Corrupted Image. Please Select another image.",
                                      });
                                      setImageUrl1("");
                                      setBackDoc("");
                                    }}
                                    src={imageUrl1}
                                    alt="avatar"
                                    width="100%"
                                    height="100%"
                                  />
                                )}
                              </>
                            ) : (
                              <div>
                                {loading ? <LoadingOutlined /> : <CameraOutlined />}
                                <div>Upload</div>
                                <div>Back</div>
                              </div>
                            )}
                          </Upload>
                        </Form.Item>
                        {imageUrl1 && (
                          <DeleteOutlined
                            onClick={() => {
                              setImageUrl1("");
                              setBackDoc("");
                            }}
                          />
                        )}
                      </div>
                    </div>

                    <p>
                      <small className="xr-help-text fw-600">
                        Please upload front and back copy of document.
                        <br />
                        Kindly provide valid, clear, uncut and authentic copy of document.
                        <br />
                        Supported formats: JPG, PNG, BMP, PDF
                        <br />
                        File size limit 3MB
                      </small>
                    </p>
                  </Col>

                  <Col md={8} className="b_left  ps-md-3">
                    <Row>
                      <Col md={4}>
                        <label>Document ID / Number</label>
                      </Col>
                      <Col md={8}>
                        <Form.Item
                          name="documentidnumber"
                          rules={[
                            {
                              required: true,
                              message: "Enter ID Number.",
                            },
                            {
                              min: 3,
                              max: 100,
                              message: "Minimum 3 and Maximum 100",
                            },
                            {
                              pattern: /^[a-z0-9]+([-_\s]{1}[a-z0-9]+)*$/i,
                              message:
                                "Id number must be numeric & alphanumeric without special charecter",
                            },
                          ]}
                        >
                          <Input type="text" autoComplete="none" />
                        </Form.Item>
                      </Col>
                    </Row>
                    <Row>
                      <Col md={4}>
                        <label>Issue Country</label>
                      </Col>
                      <Col md={8}>
                        <Form.Item
                          className="form-item"
                          name="idissuer"
                          rules={[
                            {
                              required: true,
                              message: "Please select ID Issuer",
                            },
                          ]}
                        >
                          <Select
                            className="w-100"
                            onChange={(value) => {
                              onChangeIssuerID(value, "ISSUER_COUNTRY");
                            }}
                            showSearch
                          >
                            {state.issuerCountryList.map((uiRow, i) => {
                              return (
                                <Option
                                  key={i}
                                  value={uiRow.countryName}
                                >{`${uiRow.countryName}`}</Option>
                              );
                            })}
                          </Select>
                        </Form.Item>
                      </Col>
                    </Row>
                    <Row>
                      <Col md={4}>
                        <label>Valid Till</label>
                      </Col>
                      <Col md={8}>
                        <Form.Item
                          name="expiryDate"
                          rules={[
                            {
                              required: true,
                              message: "Enter Expiry Date.",
                            },
                          ]}
                        >
                          <DatePicker
                            className="w-100"
                            disabledDate={(current) => {
                              let customDate = moment().format("YYYY-MM-DD");
                              return current && current < moment(customDate, "YYYY-MM-DD");
                            }}
                            onChange={(value, dateString) => {
                              let formatedDate = moment(dateString).format("MM/DD/YYYY");
                              value !== null
                                ? setState({
                                  additionalInfo2: formatedDate,
                                })
                                : setState({ additionalInfo2: "" });
                            }}
                          />
                        </Form.Item>
                      </Col>
                    </Row>
                    <Row>
                      <Col md={4}>
                        <label>Nationality</label>
                      </Col>
                      <Col md={8}>
                        <Form.Item
                          className="form-item"
                          name="nationality"
                          rules={[
                            {
                              required: true,
                              message: "Please select your Nationality.",
                            },
                          ]}
                        >
                          <Select className="w-100" showSearch>
                            {state.nationalities.map((nationality, i) => {
                              return (
                                <Option key={i} value={nationality.nationality}>
                                  {nationality.nationality}
                                </Option>
                              );
                            })}
                          </Select>
                        </Form.Item>
                      </Col>
                    </Row>
                    {passFileNo == "PP" && (
                      <Row>
                        <Col md={4}>
                          <label>Passport File Number</label>
                        </Col>
                        <Col md={8}>
                          <Form.Item
                            name="passportfilenumber"
                            rules={[
                              {
                                required: false,
                                message: "Enter your passport file Numbers.",
                              },
                              {
                                min: 3,
                                max: 100,
                                message: "Minimum 3 and Maximum 100",
                              },
                              {
                                pattern: /^[a-z0-9]+([-_\s]{1}[a-z0-9]+)*$/i,
                                message:
                                  "Id number must be numeric & alphanumeric without special charecter",
                              },
                            ]}
                          >
                            <Input />
                            <div className="text-end opacity-50">
                              <small>Optional for Passport Selection</small>
                            </div>
                          </Form.Item>
                        </Col>
                      </Row>
                    )}
                    <Row>
                      {!inputFields?.sourceOfFund?.hidden && (
                        <Col md={6}>
                          <label className="form-label">Source of fund</label>
                          <Form.Item
                            className="form-item"
                            name="sourcefund"
                            rules={[
                              {
                                required: true,
                                message: "Select Source of fund.",
                              },
                            ]}
                          >
                            <Select
                              onChange={(value) => {
                                setState({ sourceFundOther: value });
                              }}
                              className="w-100"
                              placeholder="Select Source of fund"
                              showSearch
                            >
                              {state.sourceOFFundLists.map((sList, i) => {
                                return (
                                  <Option key={i} value={sList.sourceOfFund}>
                                    {sList.sourceOfFund}
                                  </Option>
                                );
                              })}
                            </Select>
                          </Form.Item>
                        </Col>
                      )}
                      {!inputFields?.remittanceFrequency?.hidden && (
                        <Col md={6}>
                          <label className="form-label">Remittance Frequency</label>
                          <Form.Item
                            className="form-item"
                            name="remittance_freq"
                            rules={[
                              {
                                required: true,
                                message: "Select Remittance Frequency.",
                              },
                            ]}
                          >
                            <Select
                              className="w-100"
                              placeholder="Select Remittance Frequency"
                              showSearch
                            >
                              <Option value="WEEKLY">Weekly</Option>
                              <Option value="MONTHLY">Monthly</Option>
                              <Option value="QUARTERLY">Quarterly</Option>
                              <Option value="ANNUALLY">Annually</Option>
                              <Option value="ONE_OFF">One-Off</Option>
                            </Select>
                          </Form.Item>
                        </Col>
                      )}
                    </Row>
                    {state.sourceFundOther == "Other" && (
                      <Row>
                        <Col md={6}>
                          <Form.Item
                            name="sourceFundOther"
                            rules={[
                              {
                                required: true,
                                message: "Enter Your Source Of Fund.",
                              },
                            ]}
                          >
                            <Input placeholder="Enter Source of Fund" />
                          </Form.Item>
                        </Col>
                      </Row>
                    )}
                    <Row>
                      <Col md={6}>
                        <label className="form-label">Occupation</label>
                        <Form.Item
                          className="form-item"
                          name="occupation"
                          rules={[
                            {
                              required: true,
                              message: "Select Occupation.",
                            },
                          ]}
                        >
                          <Select
                            onChange={(value) => {
                              setState({ occupationOther: value });
                            }}
                            placeholder="Select Occupation"
                            className="w-100"
                            showSearch
                          >
                            {state.occupationLists.map((ocRow, i) => {
                              return (
                                <Option
                                  key={i}
                                  value={ocRow.occupationName}
                                >{`${ocRow.occupationName}`}</Option>
                              );
                            })}
                          </Select>
                        </Form.Item>
                      </Col>
                      <Col md={6}>
                        <label className="form-label">Purpose</label>
                        <Form.Item
                          className="form-item"
                          name="purpose"
                          rules={[
                            {
                              required: true,
                              message: "Select Purpose.",
                            },
                          ]}
                        >
                          <Select
                            // onChange={(value) => {
                            //   setState({ occupationOther: value });
                            // }}
                            placeholder="Select Purpose"
                            className="w-100"
                            showSearch
                          >
                            {state.purposeLists.map((clist, i) => {
                              return (
                                <Option
                                  key={i}
                                  value={clist.purposeCode}
                                >{`${clist.purpose}`}</Option>
                              );
                            })}
                          </Select>
                        </Form.Item>
                      </Col>
                    </Row>
                    <Row>
                      {state.occupationOther == "Other" && (
                        <Col md={6}>
                          <Form.Item
                            name="occupationOther"
                            rules={[
                              {
                                required: true,
                                message: "Enter Your Occupation.",
                              },
                            ]}
                          >
                            <Input placeholder="Enter Your Occupation" />
                          </Form.Item>
                        </Col>
                      )}
                    </Row>
                  </Col>
                </Row>
                <div className="d-flex justify-content-end">
                  <p
                    className="btn btn-link mb-3 me-3 text-primary fw-800"
                    onClick={() => {
                      props.setIsModalVisible(false);
                      dispatch({ type: "SET_USER_KYC_BOOLEAN", payload: false });
                    }}
                  >
                    I'll do this later
                  </p>
                  <button className="btn btn-primary text-white mb-3" htmlType="submit">
                    Confirm
                  </button>
                </div>
              </Form>
            </>
          </Tabs.TabPane>
          <Tabs.TabPane key="2">
            <>
              <Form
                className="kyc_address_form"
                form={form}
                autoComplete="none"
                onFinish={(values) => {
                  if (addProofDoc == "") {
                    form.setFields([
                      {
                        name: "document3",
                        errors: ["Please upload document"],
                      },
                    ]);
                  } else {
                    let latestVariable = { ...value, ...values };
                    if (state.kycPage === 2) {
                      submitHandler(latestVariable);
                    } else {
                      setState({ kycPage: 2 });
                    }
                  }
                }}
              >
                <Row>
                  <Col md={5} className="pe-3">
                    <Row>
                      <Form.Item
                        wrapperCol={{ span: 24 }}
                        className="form-item w-100"
                        name="addressidtype"
                        rules={[
                          {
                            required: true,
                            message: "Select Document Type.",
                          },
                        ]}
                      >
                        <Select
                          className="primary_selectbox"
                          placeholder="Select Document Type"
                          onSelect={(e) => setAddProofId(e)}
                        >
                          {state.addressProofLists.map((uiRow, i) => {
                            return (
                              <Option key={i} value={uiRow.docType}>{`${uiRow.docName}`}</Option>
                            );
                          })}
                        </Select>
                      </Form.Item>
                    </Row>
                    <Row className="mb-5">
                      <Form.Item
                        wrapperCol={{ span: 24 }}
                        className=" mb-2"
                        name="document3"
                        valuePropName="fileList"
                        getValueFromEvent={normFile2}
                        multiple={false}
                        rules={[
                          {
                            required: true,
                            message: "Please upload document.",
                          },
                          // {
                          //   validator: (_, value) => {
                          //     console.log("bugggs",value)
                          //     const acceptExtType = [
                          //       "image/jpg",
                          //       "image/jpeg",
                          //       "image/png",
                          //       "application/pdf",
                          //     ];
                          //     const fObj = value[0];
                          //     let fileExt = fObj.type;
                          //     if (!value || acceptExtType.includes(fileExt)) {
                          //       return Promise.resolve();
                          //     }
                          //     return Promise.reject(
                          //       new Error(
                          //         "Upload valid document. Document format should be .jpg, .png & .bmt."
                          //       )
                          //     );
                          //   },
                          // },
                        ]}
                      >
                        <Upload
                          name="logo2"
                          listType="picture-card"
                          className="avatar-uploader"
                          accept="image/jpg, image/jpeg, image/png, application/pdf"
                          showUploadList={false}
                          beforeUpload={(file) => {
                            setState({
                              DocPdf2: file.type.includes("application/pdf"),
                            });
                            const isLt3MB = file.size;
                            if (isLt3MB >= "3145728") {
                              message.error("Document upload size limit maximum of 3MB!");
                              return false;
                            } else {
                              const fileName2 = file.name;
                              const fileType2 = file.type;
                              const reader = new FileReader();

                              reader.onload = (e) => {
                                setAddProofDoc({
                                  fileName2,
                                  fileType2,
                                  docUrl2: e.target.result,
                                });
                                setImageUrl2(e.target.result);
                              };
                              reader.readAsDataURL(file);

                              return false;
                            }
                          }}
                          onChange={(e) => {
                            handleChange(e);
                            setDocUploadCheck((prevState) => ({
                              ...prevState,
                              addressProof: false,
                            }));
                          }}
                        >
                          {imageUrl2 ? (
                            <>
                              {state.DocPdf2 ? (
                                <FilePdfOutlined />
                              ) : (
                                <img
                                  onError={(e) => {
                                    notification.error({
                                      message: "Corrupted Image. Please Select another image.",
                                    });
                                    setImageUrl2("");
                                    setAddProofDoc("");
                                  }}
                                  src={imageUrl2}
                                  alt="avatar"
                                  width="100%"
                                  height="100%"
                                />
                              )}
                            </>
                          ) : (
                            <div>
                              {loading ? <LoadingOutlined /> : <CameraOutlined />}
                              <div style={{ marginTop: 8 }}>Upload</div>
                            </div>
                          )}
                        </Upload>
                      </Form.Item>
                      {imageUrl2 && (
                        <DeleteOutlined
                          onClick={() => {
                            setImageUrl2("");
                            setAddProofDoc("");
                          }}
                        />
                      )}
                    </Row>
                    <p>
                      <small className="xr-help-text fw-600">
                        Kindly provide clear copy of official bank statement/utility bill/Local
                        authority tax bill which should match the registered address and should not
                        be older than 3 months old.
                        <br />
                        Supported formats: JPG, PNG, BMP, PDF
                        <br />
                        File size limit 3MB
                      </small>
                    </p>
                  </Col>
                  <Col md={7} className="b_left ps-3">
                    <Row>
                      <Col md={2}>
                        <label>Address</label>
                      </Col>
                      <Col md={10}>
                        <Form.Item
                          name="address"
                          rules={[
                            {
                              required: true,
                              message: "Enter your Address.",
                            },
                            {
                              min: 1,
                              max: 100,
                              message: "Address should be between 1 and 100 characters long",
                            },
                          ]}
                        >
                          <TextArea
                            onKeyDown={(e) => {
                              if (e.key === "Enter") {
                                e.preventDefault();
                                if (!e.shiftKey) {
                                  e.preventDefault();
                                }
                              }
                            }}
                            autoComplete="none"
                          />
                        </Form.Item>
                      </Col>
                    </Row>
                    <Row>
                      <Col md={2}>
                        <label>Street / Line 1</label>
                      </Col>
                      <Col md={10}>
                        <Form.Item
                          className="form-item"
                          name="address2"
                          rules={[
                            {
                              required: true,
                              message: "Enter Street / Line 1.",
                            },
                            {
                              min: 3,
                              max: 50,
                              message: "Street address should be between 3 and 50 characters long",
                            },
                          ]}
                        >
                          <Input placeholder="Street / Line 1" autoComplete="none" />
                        </Form.Item>
                      </Col>
                    </Row>
                    <Row>
                      <Col md={2}>
                        <label>Pin Code</label>
                      </Col>
                      <Col md={4}>
                        <Form.Item
                          name="zipCode"
                          rules={[
                            {
                              required: true,
                              message: "Enter Pincode Code.",
                            },
                            ...inputValidations.zipCode(AuthReducer.sendCountryCode),
                          ]}
                        >
                          <Input type="text" autoComplete="none" />
                        </Form.Item>
                      </Col>
                      <Col md={2}>
                        <label>State</label>
                      </Col>
                      <Col md={4}>
                        <Form.Item
                          name="state"
                          rules={[
                            {
                              required: true,
                              message: "Enter State.",
                            },
                            {
                              pattern: /^[a-zA-Z ]*$/,
                              message: "Only alphabets and space allow.",
                            },
                          ]}
                        >
                          <AutoComplete
                            autoComplete="none"
                            className="w-100"
                            onSelect={onSelectStateHandler}
                            filterOption={(inputValue, option) =>
                              option.value.toUpperCase().indexOf(inputValue.toUpperCase()) !== -1
                            }
                          >
                            {state.stateLists.map((st, i) => {
                              return <Option key={i} value={st.state}>{`${st.state}`}</Option>;
                            })}
                          </AutoComplete>
                        </Form.Item>
                      </Col>
                    </Row>
                    <Row>
                      <Col md={2}>
                        <label>City</label>
                      </Col>
                      <Col md={4}>
                        <Form.Item
                          name="city"
                          rules={[
                            {
                              required: true,
                              message: "Enter City.",
                            },
                            {
                              pattern: /^[a-zA-Z ]*$/,
                              message: "Only alphabets and space allow.",
                            },
                          ]}
                        >
                          <AutoComplete
                            autoComplete="none"
                            className="w-100"
                            filterOption={(inputValue, option) =>
                              option.value.toUpperCase().indexOf(inputValue.toUpperCase()) !== -1
                            }
                          >
                            {state.cityLists.map((st, i) => {
                              return <Option key={i} value={st.city}>{`${st.city}`}</Option>;
                            })}
                          </AutoComplete>
                        </Form.Item>
                      </Col>
                      <Col md={2}>
                        <label>Country</label>
                      </Col>
                      <Col md={4}>
                        <Form.Item
                          name="country"
                          rules={[
                            {
                              required: true,
                              message: "Enter Country.",
                            },
                          ]}
                        >
                          <Select className="w-100">
                            <Option value={AuthReducer.regCountryCode}>
                              {COUNTRY[AuthReducer.regCountryCode].countryName}
                            </Option>
                          </Select>
                        </Form.Item>
                      </Col>
                    </Row>
                  </Col>
                </Row>
                <div className="d-flex justify-content-end">
                  <button
                    className="btn btn-link mb-3 me-3 text-primary fw-800"
                    onClick={() => {
                      props.setIsModalVisible(false);
                      dispatch({ type: "SET_USER_KYC_BOOLEAN", payload: false });
                    }}
                  >
                    I'll do this later
                  </button>
                  <button className="btn btn-primary text-white mb-3" htmlType="submit">
                    Confirm
                  </button>
                </div>
              </Form>
            </>
          </Tabs.TabPane>
          <Tabs.TabPane key="3">
            <>
              <div className="d-flex flex-column justify-content-center align-items-center">
                <Lottie
                  height={300}
                  width={300}
                  options={{
                    loop: false,
                    autoplay: true,
                    animationData: kycLottie,
                    rendererSettings: {
                      preserveAspectRatio: "xMidYMid slice",
                    },
                  }}
                />
                <h3 className="text-primary fw-800 fs-36">Your KYC details has been updated</h3>
              </div>
              <div className="text-end">
                <button
                  className="btn btn-primary text-white mb-3"
                  onClick={() => {
                    props.setIsModalVisible(false);
                    dispatch({ type: "SET_USER_KYC_BOOLEAN", payload: false });
                  }}
                >
                  Done
                </button>
              </div>
            </>
          </Tabs.TabPane>
        </Tabs>
      </Spinner>
    </div>
  );
}
