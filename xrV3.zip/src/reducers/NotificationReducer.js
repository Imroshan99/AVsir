
export const setNotificationCount = (state = '', action) => {
    if (action.type === 'SET_NOTIFICATION_COUNT') {
        return action.payload
    }
    return state;
}
