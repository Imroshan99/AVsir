import React, { useState, useEffect, useReducer } from "react";
import { Form, Input, notification, Spin } from "antd";
import { config } from "../config";
import moment from "moment";
import { GuestAPI } from "../apis/GuestAPI";
import { useSelector } from "react-redux";
import { encrypt, decrypt, publickey } from "../helpers/makeHash";
import Spinner from "../reusable/Spinner";
import { useLocation } from "react-router-dom";
import useHttp from "./../hooks/useHttp";

export default function InputOTPBox(props) {
  const [stateOtp, SetStateOtp] = useState({ otp: "" });
  const location = useLocation();
  const [btn, setBtn] = useState(false);
  const ConfigReducer = useSelector((state) => state);
  const [form] = Form.useForm();
  const [intervalID, setInterID] = useState();

  const [reverseTimer, setReverseTimer] = useState("5m 00s");
  const [otpVerificationToken, setVerificationToken] = useState("");
  const [loader, setLoader] = useState(false);
  const [state, setState] = useReducer((state, newState) => ({ ...state, ...newState }), {
    clientId: ConfigReducer.clientId,
    groupId: ConfigReducer.groupId,
    twofa: ConfigReducer.twofa,
    sessionId: ConfigReducer.sessionId,
    OTPTimer: true,
    OTPVerifed: false,
    disabled: false,
  });

  const hookVerifyOtp = useHttp(GuestAPI.verifyOTP);
  const hookResendOtp = useHttp(GuestAPI.reSendOTP);

  useEffect(() => {
    reverseTimerOnLoad();
  }, []);

  useEffect(() => {
    setVerificationToken(props.state.verificationToken);
  }, [props.state.verificationToken]);

  const reverseTimerOnLoad = () => {
    clearInterval(intervalID);

    let validityAuctionEndTime = moment().add(5, "minutes");
    const second = 1000,
      minute = second * 60,
      hour = minute * 60,
      day = hour * 24;

    let countDown = new Date(`${validityAuctionEndTime}`).getTime();

    let letintervalID = setInterval(function () {
      let now = new Date().getTime(),
        distance = countDown - now;

      var getDay = Math.floor(distance / day);

      var getHour = Math.floor((distance % day) / hour);

      var getMinute = Math.floor((distance % hour) / minute);

      var secound = Math.floor((distance % minute) / second);
      let getSecound = secound > 9 ? secound : 0 + secound;

      let cDay = getDay !== 0 ? `${getDay}d` : "";
      let cHour = getHour !== 0 ? `${getHour}h` : "";
      let cMinute = getMinute !== 0 ? `${getMinute}m` : "";
      let cSecound = getSecound !== 0 ? `${getSecound}s` : "";
      let timer = `${cDay} ${cHour} ${cMinute} ${cSecound}`;

      if (distance <= 0) {
        clearInterval(intervalID);
      } else {
        setReverseTimer(timer);
      }
    }, second);
    setInterID(letintervalID);
  };
  const onFinish = (e) => {
    setState({ disabled: true });
    if (location.pathname === "/profile") {
      props.setLoader(true);
    }
    if (props.unlockA) {
      props.setParentLoader(true);
    } else {
      setLoader(true);
    }
    e.preventDefault();
    form.setFields([{ name: "otp", errors: [] }]);

    const optData = {
      requestType: "VERIFYOTP",
      otpType: props.otpType,
      verificationToken: otpVerificationToken,
      otp: stateOtp.otp,
    };

    if (props.useFor === "addRecipient") {
      optData.accountNo = props.state.formData.accountNo;
    }

    hookVerifyOtp.sendRequest(optData, (data) => {
      clearInterval(intervalID);
      if (data.status === "S") {
        notification.destroy();
        if (location.pathname === "/profile") {
          props.setState({ otpVerfiedToken: data.verifiedToken });
          props.editSenderContactdtls(data.verifiedToken);
          props.setState({ otpVerfiedToken: "" });
          // props.setState({otpBoxEmail:false});
          props.setLoader(false);
          setState({ disabled: true });
          props.setState({ OTPVerifed: true });
        }

        props.setState({ isModalVisible: false });
        setState({ OTPTimer: false });
        if (props.useFor === "signup") {
          props.setState({
            verifiedToken: data.verifiedToken,
          });
          props.checkDedupe(data.verifiedToken);
        } else if (props.useFor === "login") {
          props.setState({ verifiedToken: data.verifiedToken });
          props.storeLoginData(props.state.loginData);
        } else if (props.useFor === "addRecipient") {
          props.saveReceiver(data.verifiedToken);
        } else if (props.useFor === "Edit_Address") {
          props.editProfile(data.verifiedToken);
        } else if (props.useFor === "Edit_Contact") {
          setTimeout(() => {
            props.editSenderContactdtls(data.verifiedToken);
          }, 1000);
        } else if (props.useFor === "Edit_Marketing") {
          props.editProfile(data.verifiedToken);
        } else if (props.useFor === "forgot_password") {
          props.setState({
            verifiedToken: data.verifiedToken,
            _isShowSuccessMessage: true,
          });
        } else if (props.useFor === "unlock_account") {
          props.onUnlockAccountHandler();
        }
        props.setCurrent((prev) => prev + 1);
        if (props.unlockA) {
          props.setParentLoader(false);
        } else {
          setLoader(false);
        }
      } else {
        if (location.pathname === "/profile") {
          props.setState({ OTPVerifed: false });
          props.setLoader(false);
          setState({ disabled: false });
        }
        if (props.unlockA) {
          props.setParentLoader(false);
        } else {
          setLoader(false);
        }
        notification.error({ message: data.errorMessage });
        form.setFields([{ name: "otp", errors: [data.errorMessage] }]);
        let errors = [];
        data.errorList.forEach((error, i) => {
          let errorData = {
            name: error.field,
            errors: [error.error],
          };
          errors.push(errorData);
        });
        if (errors.length > 0) form.setFields(errors);
      }
    });
  };
  const onClickResedOTP = async () => {
    if (location.pathname === "/profile") {
      props.setLoader(true);
    }
    if (props.unlockA) {
      props.setParentLoader(true);
    } else {
      setLoader(true);
    }
    const optData = {
      requestType: "RESENDOTP",
      verificationToken: otpVerificationToken,
      otpOption: "SM",
    };

    if (props.useFor === "addRecipient") {
      optData.accountNo = props.state.formData.accountNo;
    }

    hookResendOtp.sendRequest(optData, (data) => {
      if (data.status === "S") {
        if (location.pathname === "/profile") {
          props.setLoader(false);
        }
        form.setFieldsValue({ otp: "" });
        setState({ OTPTimer: true });
        if (props.unlockA) {
          props.setParentLoader(false);
        } else {
          setLoader(false);
        }
        // notification.success({ message: decodeData.message });
        notification.success({
          // message: data.message,
          message: `OTP Email sent successfully.`,
          description:
            "Kindly check OTP mail in your Notification, Updates or SPAM folder in case if you do not find it in your Inbox",
          duration: 0,
        });
        props.setState({ verificationToken: data.verificationToken });
        setVerificationToken(data.verificationToken);
        clearInterval(intervalID);
        setTimeout(() => {
          reverseTimerOnLoad();
        }, 200);
      } else {
        if (location.pathname === "/profile") {
          props.setLoader(false);
        }
        if (props.unlockA) {
          props.setParentLoader(false);
        } else {
          setLoader(false);
        }

        notification.error({ message: data.errorMessage });

        let errors = [];
        data.errorList.forEach((error, i) => {
          let errorData = {
            name: error.field,
            errors: [error.error],
          };
          errors.push(errorData);
        });
        if (errors.length > 0) form.setFields(errors);
      }
    });
  };
  return (
    <Spinner
      spinning={
        location.pathname === "/profile" ? false : props.unlockA ? props.parentLoader : loader
      }
    >
      <div visible={props.state.isModalVisible}>
        <Form form={form} onFinish={(values) => {}}>
          <>
            <div className="mb-3">
              <label className="step-label mb-1">Enter OTP</label>
              <Form.Item
                className="form-item text-start"
                name="otp"
                rules={[
                  { required: true, message: "Please Enter Your OTP" },
                  {
                    pattern: /^[0-9\b]+$/,
                    message: "Only Numbers allowed",
                  },
                  {
                    min: 6,
                    max: 6,
                    message: "Please enter 6 digit OTP",
                  },
                ]}
              >
                <Input
                  size="large"
                  onChange={(e) => {
                    SetStateOtp({ otp: e.target.value });
                    e.target.value.length == 6 ? setBtn(true) : setBtn(false);
                  }}
                  onPaste={(e) => {
                    e.preventDefault();
                    return false;
                  }}
                  onCopy={(e) => {
                    e.preventDefault();
                    return false;
                  }}
                  onCut={(e) => {
                    e.preventDefault();
                    return false;
                  }}
                  disabled={location.pathname === "/profile" ? state.disabled : false}
                />
              </Form.Item>
              <p className="text-center" style={{ cursor: "pointer" }} onClick={onClickResedOTP}>
                Resend OTP on email
              </p>
              {state.OTPTimer && (
                <p className="mt-2 text-center">
                  <small>OTP will expire in {reverseTimer}</small>
                </p>
              )}
            </div>

            <button
              className={
                location.pathname === "/profile"
                  ? "  btn btn-secondary text-white my-1 w-100   "
                  : `btn btn-primary text-white my-1 w-100`
              }
              disabled={!btn || loader || props.state.OTPVerifed}
              onClick={onFinish}
            >
              {location.pathname === "/profile" ? "Save" : "Next"}
            </button>
          </>
        </Form>
      </div>
    </Spinner>
  );
}
