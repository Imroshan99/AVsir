import axios from "axios";
import { config } from "../../config";

export const ViAmericaPlaidAPI = {
  createLinkToken: async (data, token) => {
    var axosConfig = {
      method: "post",
      url: `${config.API_URL}/services/txn/vi-america-createlinktoken`,
      headers: {
        Authorization: `AuthToken ${token}`,
        "Content-Type": "application/json",
      },
      data: data,
    };

    return await axios(axosConfig);
  },
  linkTokenExchange: async (data, token) => {
    var axosConfig = {
      method: "post",
      url: `${config.API_URL}/services/txn/vi-america-linktokenexchange`,
      headers: {
        Authorization: `AuthToken ${token}`,
        "Content-Type": "application/json",
      },
      data: data,
    };

    return await axios(axosConfig);
  },
  addGetBankAccount: async (data, token) => {
    var axosConfig = {
      method: "post",
      url: `${config.API_URL}/services/txn/vi-america-add-get-bank-accounts`,
      headers: {
        Authorization: `AuthToken ${token}`,
        "Content-Type": "application/json",
      },
      data: data,
    };

    return await axios(axosConfig);
  },
  viaGetFundingAcct: async (data, token) => {
    var axosConfig = {
      method: "post",
      url: `${config.API_URL}/services/txn/vi-america-get-funding-accounts`,
      headers: {
        Authorization: `AuthToken ${token}`,
        "Content-Type": "application/json",
      },
      data: data,
    };

    return await axios(axosConfig);
  },
};
