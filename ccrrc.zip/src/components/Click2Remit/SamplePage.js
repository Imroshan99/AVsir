import Main from "./Layouts/Main";

const SamplePage = () => {
  return (
    <div>
      <Main>
        sdfsdf
      </Main>
    </div>
  );
};
export default SamplePage;
