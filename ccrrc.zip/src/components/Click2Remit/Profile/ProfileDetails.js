import React, { useEffect, useReducer } from "react";
import Main from "../Layouts/Main";
import BackArrow from "../../../assets/images/click2remit/Back_arrow.svg";
import { notification } from "antd";
import useHttp from "../../../hooks/useHttp";
import { ProfileAPI } from "../../../apis/ProfileAPI";
import { useSelector } from "react-redux";
import EditProfileDetails from "./EditProfileDetails";
import { useState } from "react";
import Spinner from "../../../reusable/Spinner";
import { useNavigate } from "react-router-dom";

const ProfileDetails = () => {
  const AuthReducer = useSelector((state) => state.user);
  const navigate = useNavigate();

  const hookGetProfile = useHttp(ProfileAPI.getProfile);

  const [loader, setLoader] = useState(false);
  const [state, setState] = useReducer((state, newState) => ({ ...state, ...newState }), {
    firstName: "",
    middleName: "",
    lastName: "",
    dob: "",
    crn: "",
    mobileNo: "",
    emailId: "",
    address1: "",
    address2: "",
    // address3: "",
    mobilePhoneCode: "",
    zip: "",
    profileComponent: true,
  });

  useEffect(() => {
    getProfile();
  }, []);
  const getProfile = () => {
    let payload = {
      requestType: "LEAD",
      userId: AuthReducer.userID,
    };
    setLoader(true);
    hookGetProfile.sendRequest(payload, function (data) {
      setLoader(false);
      if (data.status == "S") {
        setState({
          firstName: data.firstName,
          middleName: data.middleName,
          lastName: data.lastName,
          emailId: data.emailId,
          dob: data.dob,
          mobileNo: data.mobileNo,
          address1: data.address1,
          address2: data.address2,
          // address3: data.address3,
          zip: data.zip,
          crn: data.cif,
        });
      } else {
        notification.error({ message: data.errorMessage ? data.errorMessage:"Get profile failed."});
      }
    });
  };
  return (
    <Main>
      {state.profileComponent ? (
        <>
          <div className="container h-100">
            <div className="row h-100 justify-content-center">
              <form>
                <div className="align-self-center col-lg-7 col-md-7 col-sm-12 " style={{marginRight:"auto"}}>
                  <div className="CR-default-box CR-max-width-620">
                    <Spinner spinning={loader}>
                      <ul className="row CR-side-space">
                        <li className="back-arrow-nav   d-xs-block d-done">
                          <img src={BackArrow} alt="" />
                        </li>

                        <li className="col-md-12 col-sm-12 col-lg-12 ">
                          <h4 className="text-black CR-font-28 mb-1">Profile details</h4>
                        </li>
                        <li className="col-md-12 col-sm-12 col-lg-12">
                          <p className="text-left CR-font-16"></p>
                        </li>
                        <li className="col-md-12 col-sm-12 col-lg-12 my-2">
                          <div className="align-items-center cr_greyTitle d-flex justify-content-between">
                            <p className="mb-0">Personal information</p>
                          </div>
                        </li>
                        <li className="col-md-12 col-sm-12 col-lg-12 my-2">
                          <ul className="row">
                            <li className="col-md-12 col-sm-12 col-lg-12 my-2">
                              <div className="align-items-center d-flex justify-content-between CR-border-bottom">
                                <label className="CR-font-16 text-left">Name</label>
                                <p className="CR-font-16 text-right CR-black-text CR-fw-500">
                                  {`${state.firstName} ${state.middleName} ${state.lastName}`}
                                </p>
                              </div>
                            </li>
                            <li className="col-md-12 col-sm-12 col-lg-12 my-2">
                              <div className="align-items-center d-flex justify-content-between">
                                <label className="CR-font-16 text-left">Date of birth</label>
                                <p className="CR-font-16 text-right CR-black-text CR-fw-500">
                                  {state.dob}
                                </p>
                              </div>
                            </li>
                            <li className="col-md-12 col-sm-12 col-lg-12 my-2">
                              <div className="align-items-center d-flex justify-content-between">
                                <label className="CR-font-16 text-left">CRN</label>
                                <p className="CR-font-16 text-right CR-black-text CR-fw-500">
                                  {state.crn}
                                </p>
                              </div>
                            </li>
                          </ul>
                        </li>
                        <li className="col-md-12 col-sm-12 col-lg-12 my-2">
                          <div className="align-items-center cr_greyTitle d-flex justify-content-between">
                            <p className="mb-0">Communication details</p>
                          </div>
                        </li>
                        <li className="col-md-12 col-sm-12 col-lg-12 my-2">
                          <ul className="row">
                            <li className="col-md-12 col-sm-12 col-lg-12 my-2">
                              <div className="align-items-center d-flex justify-content-between CR-border-bottom">
                                <label className="CR-font-16 text-left">Phone Number</label>
                                <p className="CR-font-16 text-right CR-black-text CR-fw-500">
                                  {state.mobileNo}
                                </p>
                              </div>
                            </li>
                            <li className="col-md-12 col-sm-12 col-lg-12 my-2">
                              <div className="align-items-center d-flex justify-content-between CR-border-bottom">
                                <label className="CR-font-16 text-left">Email</label>
                                <p className="CR-font-16 text-right CR-black-text CR-fw-500">
                                  {state.emailId}
                                </p>
                              </div>
                            </li>
                            <li className="col-md-12 col-sm-12 col-lg-12 my-2">
                              <div className="align-items-center d-flex justify-content-between">
                                <div className="col-4">
                                  <label className="CR-font-16 text-left">Address line 1 </label>
                                </div>
                                <div className="col-6 w-50 d-flex justify-content-end text-end">
                                  <p
                                    // style={{ lineBreak: "anywhere" }}
                                    className="CR-font-16 text-right CR-black-text CR-fw-500"
                                  >
                                    {state.address1}
                                  </p>
                                </div>
                              </div>
                            </li>
                            <li className="col-md-12 col-sm-12 col-lg-12 my-2">
                              <div className="align-items-center d-flex justify-content-between">
                                <div className="col-4">
                                  <label className="CR-font-16 text-left">Address line 2 </label>
                                </div>
                                <div className="col-6 w-50 d-flex justify-content-end text-end">
                                  <p
                                    // style={{ lineBreak: "anywhere" }}
                                    className="CR-font-16 text-right CR-black-text CR-fw-500"
                                  >
                                    {state.address2}
                                  </p>
                                </div>
                              </div>
                            </li>
                            {/* <li className="col-md-12 col-sm-12 col-lg-12 my-2">
                              <div className="align-items-center d-flex justify-content-between">
                                <div className="col-4">
                                  <label className="CR-font-16 text-left">Address line 3 </label>
                                </div>
                                <div className="col-6 w-50 d-flex justify-content-end">
                                  <p
                                    style={{ lineBreak: "anywhere" }}
                                    className="CR-font-16 text-right CR-black-text CR-fw-500"
                                  >
                                    {state.address3}
                                  </p>
                                </div>
                              </div>
                            </li> */}
                          </ul>
                        </li>
                      </ul>
                    </Spinner>
                    <div className="bottom_panel">
                      <div className="d-flex justify-content-between align-items-center gap-3 gap-md-5">
                        <a onClick={() => navigate("/new-transaction")} className="Back_arrow">
                          {" "}
                          <img src={BackArrow} alt="" />
                          Back
                        </a>
                        <button
                          style={{ maxWidth: "17rem" }}
                          type="button"
                          onClick={() => setState({ profileComponent: false })}
                          className=" CR-primary-btn"
                        >
                          Edit
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              </form>
            </div>
          </div>
        </>
      ) : (
        <EditProfileDetails getProfile={getProfile} setState={setState} />
      )}
    </Main>
  );
};

export default ProfileDetails;
