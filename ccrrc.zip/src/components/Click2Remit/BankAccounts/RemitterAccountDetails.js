import React, { useEffect, useReducer, useState } from "react";
import { useSelector } from "react-redux";
import { useLocation, useNavigate } from "react-router-dom";
import { BankAccountAPI } from "../../../apis/BankAccountAPI";
import { ReceiverAPI } from "../../../apis/ReceiverAPI";
import bank1png from "../../../assets/images/click2remit/bank-1.png";
import { notification } from "antd";
import useHttp from "../../../hooks/useHttp";
import BackArrow from "../../../assets/images/click2remit/Back_arrow.svg";
import Spinner from "../../../reusable/Spinner";
import moment from "moment";
import { achBankAccountAPI } from "../../../apis/achBankAccountAPI";
import Main from "../Layouts/Main";
import { ProfileAPI } from "../../../apis/ProfileAPI";
import VerifyOtp from "../containers/VerifyOtp";

const RemitterAccountDetails = (props) => {
  const navigate = useNavigate();
  const location = useLocation();
  const AuthReducer = useSelector((state) => state.user);
  const bankAccountDetail = location?.state?.remitterData;
  const hookViewBankAccountDetails = useHttp(BankAccountAPI.viewBankAccountDetails);
  const hookViewAchBankAccountDetails = useHttp(achBankAccountAPI.viewBankAccountDetails);
  const hookDeleteBankAccountDetails = useHttp(achBankAccountAPI.deleteBankAccountDetails);
  const hookSendOtp = useHttp(ProfileAPI.sendOTP);

  const [loader, setLoader] = useState(false);
  const [state, setState] = useReducer((state, newState) => ({ ...state, ...newState }), {
    remitterInfo: {},
    viewRemitterComponent: true,
    _isShowOTPBOX: false,
    verificationToken: "",
    otpExpiryTime: "",
  });
  useEffect(() => {
    if (AuthReducer.regCountryCode === "US") {
      getAchBankLists();
    } else {
      viewDetailsHandlerClick();
    }
  }, []);
  const getAchBankLists = () => {
    const payload = {
      requestType: "ACHAccountDetails",
      userId: AuthReducer.userID,
      achAccId: bankAccountDetail.aCHAccId,
      recordToken: bankAccountDetail.recordToken,
    };
    setLoader(true);
    hookViewAchBankAccountDetails.sendRequest(payload, function (data) {
      setLoader(false);
      if (data.status === "S") {
        setState({
          remitterInfo: data,
        });
      } else {
        notification.error({
          message: data.errorMessage ? data.errorMessage : "View Ach Bank account failed.",
        });
      }
    });
  };
  const viewDetailsHandlerClick = () => {
    //  setState({ isModalVisible: true });
    const payload = {
      requestType: "SENDERACCOUNT",
      userId: AuthReducer.userID,
      sendAccId: location?.state?.remitterData?.sendAccId,
      recordToken: location?.state?.remitterData?.recordToken,
    };
    setLoader(true);
    hookViewBankAccountDetails.sendRequest(payload, function (data) {
      setLoader(false);
      if (data.status === "S") {
        setState({
          remitterInfo: data,
        });
      } else {
      }
    });
  };
  const deleteBankAccountDetails = () => {
    setState({
      isModalVisible: false,
    });
    const payload = {
      requestType: "modfifyACHAccount",
      userId: AuthReducer.userID,
      achAccId: bankAccountDetail.aCHAccId,
      recordToken: bankAccountDetail.recordToken,
    };
    setLoader(true);
    hookDeleteBankAccountDetails.sendRequest(payload, function (data) {
      setLoader(false);
      if (data.status === "S") {
        notification.success({ message: data.message });
        navigate("/manage-remitter-accounts");
      } else {
        notification.error({
          message: data.errorMessage ? data.errorMessage : "Delete bank account details failed.",
        });
      }
    });
  };
  const sendOTPforDelete = () => {
    setState({
      isModalVisible: false,
    });
    const payload = {
      requestType: "SENDOTP",
      otpType: "RA",
      userId: AuthReducer.userID,
      otpOption: "SM",
    };
    setLoader(true);
    hookSendOtp.sendRequest(payload, function (data) {
      setLoader(false);
      if (data.status == "S") {
        notification.success({ message: data.message });
        setState({
          verificationToken: data.verificationToken,
          _isShowOTPBOX: true,
          otpExpiryTime: data.otpExpiryTime,
        });
      } else {
        notification.error({ message: data.errorMessage ? data.errorMessage : "Send OTP failed." });
      }
    });
  };
  return (
    <Main>
      <Spinner spinning={loader}>
        {state._isShowOTPBOX ? (
          <VerifyOtp
            setLoader={setLoader}
            deleteBankAccountDetails={deleteBankAccountDetails}
            state={state}
            setState={setState}
          />
        ) : (
          state.viewRemitterComponent && (
            <>
              <div className="container h-100">
                <div className="row h-100 justify-content-center">
                  <form>
                    <div
                      className="align-self-center col-lg-7 col-md-7 col-sm-12  "
                      style={{ marginRight: "auto" }}
                    >
                      <div className="CR-default-box CR-max-width-620">
                        <ul className="row CR-side-space">
                          <li className="back-arrow-nav   d-xs-block d-done">
                            <img src={BackArrow} alt="" />
                          </li>

                          <li className="col-md-12 col-sm-12 col-lg-12 ">
                            <h4 className="text-black CR-font-28 mb-1">Remitter account details</h4>
                          </li>
                          <li className="col-md-12 col-sm-12 col-lg-12">
                            {/* <p className="text-left CR-font-16">Check your remitter details.</p> */}
                          </li>
                          <li className="col-md-12 col-sm-12 col-lg-12 my-2">
                            <div className="align-items-start d-flex justify-content-start w-100 single-box">
                              {/* <div className="CR-bank-logo me-3">
                                <img src={bank1png} width="100%" height="100%" />
                              </div> */}
                              <div className="d-flex justify-content-between flex-column CR-w-80">
                                <label className="CR-font-16 CR-black-text CR-fw-600 text-left">
                                  {AuthReducer.regCountryCode === "US"
                                    ? state.remitterInfo.accountHolderName
                                    : state.remitterInfo.accountHolder}
                                </label>
                                <label className="CR-font-16 CR-black-text CR-fw-600 text-left">
                                  {state.remitterInfo.nickName}
                                </label>
                              </div>
                            </div>
                          </li>
                          <li className="col-md-12 col-sm-12 col-lg-12 my-2">
                            <div className="align-items-center cr_greyTitle d-flex justify-content-between">
                              <p className="mb-0">Personal information</p>
                              {/* <a onClick={() => props.setState({ activeStepForm: 13 })} className="">
                      <img src={editsvg} width="17px" height="17px" className="me-1" />
                      EDIT
                    </a> */}
                            </div>
                          </li>
                          <li className="col-md-12 col-sm-12 col-lg-12 my-2">
                            <ul className="row">
                              <li className="col-md-12 col-sm-12 col-lg-12 my-2">
                                <div className="align-items-center d-flex justify-content-between CR-border-bottom">
                                  <label className="CR-font-16 text-left">Name</label>
                                  <p className="CR-font-16 text-right CR-black-text CR-fw-500">
                                    {AuthReducer.regCountryCode === "US"
                                      ? state.remitterInfo.accountHolderName
                                      : state.remitterInfo.accountHolder}
                                  </p>
                                </div>
                              </li>
                              <li className="col-md-12 col-sm-12 col-lg-12 my-2">
                                <div className="align-items-center d-flex justify-content-between">
                                  <label className="CR-font-16 text-left">Nick name</label>
                                  <p className="CR-font-16 text-right CR-black-text CR-fw-500">
                                    {state.remitterInfo.nickName}
                                  </p>
                                </div>
                              </li>
                            </ul>
                          </li>
                          <li className="col-md-12 col-sm-12 col-lg-12 my-2">
                            <div className="align-items-center cr_greyTitle d-flex justify-content-between">
                              <p className="mb-0">Bank details</p>
                              {/* <a onClick={() => props.setState({ activeStepForm: 13 })} className="">
                      <img src={editsvg} width="17px" height="17px" className="me-1" />
                      EDIT
                    </a> */}
                            </div>
                          </li>
                          <li className="col-md-12 col-sm-12 col-lg-12 my-2">
                            <ul className="row">
                              <li className="col-md-12 col-sm-12 col-lg-12 my-2">
                                <div className="align-items-center d-flex justify-content-between CR-border-bottom">
                                  <label className="CR-font-16 text-left">Bank name</label>
                                  <p className="CR-font-16 text-right CR-black-text CR-fw-500">
                                    {state.remitterInfo.bankName}
                                  </p>
                                </div>
                              </li>
                              <li className="col-md-12 col-sm-12 col-lg-12 my-2">
                                <div className="align-items-center d-flex justify-content-between CR-border-bottom">
                                  <label className="CR-font-16 text-left">Account number</label>
                                  <p className="CR-font-16 text-right CR-black-text CR-fw-500">
                                    {state.remitterInfo.accountNo}
                                  </p>
                                </div>
                              </li>
                              <li className="col-md-12 col-sm-12 col-lg-12 my-2">
                                <div className="align-items-center d-flex justify-content-between">
                                  <label className="CR-font-16 text-left">Account type</label>
                                  <p className="CR-font-16 text-right CR-black-text CR-fw-500">
                                    {state.remitterInfo.accountType}
                                  </p>
                                </div>
                              </li>
                            </ul>
                          </li>
                        </ul>

                        <div className="bottom_panel">
                          <div className="d-flex justify-content-between align-items-baseline">
                            <span
                              className="Back_arrow"
                              onClick={() => {
                                navigate("/manage-remitter-accounts");
                              }}
                            >
                              {" "}
                              <img src={BackArrow} alt="" />
                              Back
                            </span>
                            <button
                              type="button"
                              className="btn btn-primary CR-primary-btn"
                              style={{ width: "100px", margin: "0 !important" }}
                              onClick={() => setState({ isModalVisible: true })}
                            >
                              Delete
                            </button>
                          </div>
                        </div>
                      </div>
                    </div>
                  </form>
                </div>
              </div>
            </>
          )
        )}
      </Spinner>
      {state.isModalVisible && (
        <>
          <div class="modal fade show" tabindex="-1">
            <div class="modal-dialog-centered " style={{ margin: "0 auto", maxWidth: "500px" }}>
              <div class="modal-content">
                <div class="modal-body">
                  <button
                    type="button"
                    class="btn-close"
                    data-bs-dismiss="modal"
                    aria-label="Close"
                    onClick={() => setState({ isModalVisible: false })}
                  ></button>
                  <h5>Delete Remitter Account?</h5>
                  {/* <p class="error">This is you final attempt</p> */}
                  <p>Are you sure you want to delete this remitter account?</p>
                  <div class="btn-modal-wrapper">
                    <span
                      onClick={() => setState({ isModalVisible: false })}
                      class="text-dark p-2"
                      style={{ marginRight: "5px" }}
                    >
                      CANCEL
                    </span>
                    <span onClick={sendOTPforDelete} class="modal-btn1">
                      DELETE
                    </span>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="modal-backdrop fade show"></div>
        </>
      )}
    </Main>
  );
};

export default RemitterAccountDetails;
