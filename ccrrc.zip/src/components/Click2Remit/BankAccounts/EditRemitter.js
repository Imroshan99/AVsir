import React, { useEffect, useReducer, useState } from "react";
import { useSelector } from "react-redux";
import { useLocation, useNavigate } from "react-router-dom";
import { BankAccountAPI } from "../../../apis/BankAccountAPI";
import { ReceiverAPI } from "../../../apis/ReceiverAPI";
import bank1png from "../../../assets/images/click2remit/bank-1.png";
import { Input, notification, Select } from "antd";
import useHttp from "../../../hooks/useHttp";
import BackArrow from "../../../assets/images/click2remit/Back_arrow.svg";
import { Form } from "antd";
import CustomInput from "../../../reusable/CustomInput";
import FloatInput from "../../../reusable/FloatInput";
import Main from "../Layouts/Main";
import { config } from "../../../config";

const EditRemitter = (props) => {
  const [form] = Form.useForm();
  const { Option } = Select;
  const navigate = useNavigate();
  const location = useLocation();
  const AuthReducer = useSelector((state) => state.user);

  const [state, setState] = useReducer((state, newState) => ({ ...state, ...newState }), {
    twofa: AuthReducer.twofa,
    sessionId: AuthReducer.sessionId,
    userID: AuthReducer.userID,
    userFullName: AuthReducer.userFullName,
    nationalities: [],
    stateCities: [],
    _showOTPBOX: false,
    showConfirmBankAccountDetails: false,
    isConfirmAddRecipient: false,
    formData: {},
    verificationToken: "",
    isOTPVerfied: false,
    isModalVisible: false,
    otpType: "RA",

    branchCode: "",
    bankBranch: "",
    bankAddress: "",
    bankState: "",
    bankCity: "",
    bankName: "",
    bankId: "",
    bankCountry: "",
    bankLists: [],
  });

  const hookValidateBankCode = useHttp(BankAccountAPI.validateBankCode);
  const hookGetBankLists = useHttp(ReceiverAPI.bankLists);
  const hookCheckDuplicateBankAccount = useHttp(BankAccountAPI.checkDuplicateBankAccount);
  const hookAddBankAccount = useHttp(BankAccountAPI.addBankAccount);

  useEffect(() => {
    getBankList();
    form.setFieldsValue({
      fullName: state.fullName,
    });
  }, []);

  const afterClose = () => {
    if (location.pathname !== "new-transaction") {
      props.accountsList();
    }
    setState({ showConfirmBankAccountDetails: false });

    props.setVisible(false);
  };

  const onChangeBankSortCode = async (e) => {
    if (e.target.value.length >= 1) {
      const payload = {
        requestType: "VALIDATEBANKCODE",
        bankCode: e.target.value,
        userId: state.userID,
        countryCode: "GB",
      };

      hookValidateBankCode.sendRequest(payload, function (data) {
        if (data.status == "S") {
        } else {
          props.form.setFields([{ name: "bankSortCode", errors: [data.errorMessage] }]);
        }
      });
    }
  };

  const getBankList = async (e) => {
    const payload = {
      requestType: "BANKLIST",
      countryCode: AuthReducer.sendCountryCode,
      userId: state.userID,
    };

    hookGetBankLists.sendRequest(payload, function (data) {
      if (data.status === "S") {
        setState({
          bankLists: data.responseData,
        });
      }
    });
  };

  const onFinish = async (value) => {
    let checkDuplicateData = {
      requestType: "CHECKDUPLICATE",
      userId: state.userID,
      bankName: value.bankName.value,
      accountNo: value.accountNo,
    };

    hookCheckDuplicateBankAccount.sendRequest(checkDuplicateData, function (res) {
      if (res.status === "S") {
        // notification.success({ message: "check duplicate" });
        // addBankAccount(value);
        props.setState({
          addRemitterDetails: value,
          activeStepForm: 14,
        });
      } else {
        notification.error({ message: res.errorMessage?res.errorMessage:"Check duplicate bank account failed." });
      }
    });
  };
  return (
    <Main>
      <div className="container h-100">
        <div className="row h-100 justify-content-center">
          <form form={form} onFinish={onFinish}>
            <div className="align-self-center col-lg-7 col-md-7 col-sm-12 mx-auto">
              <div className="CR-default-box CR-max-width-620">
                <ul className="row CR-side-space">
                  <li className="back-arrow-nav   d-xs-block d-done">
                    <img src={BackArrow} alt="" />
                  </li>

                  <li className="col-md-12 col-sm-12 col-lg-12 ">
                    <h4 className="text-black CR-font-28 mb-1">Edit remitter account details</h4>
                  </li>

                  <li className="col-md-12 col-sm-12 col-lg-12 my-2">
                    <div className="align-items-center cr_greyTitle d-flex justify-content-between">
                      <p className="mb-0">Personal information</p>
                      {/* <a onClick={() => props.setState({ activeStepForm: 13 })} className="">
                      <img src={editsvg} width="17px" height="17px" className="me-1" />
                      EDIT
                    </a> */}
                    </div>
                  </li>
                  <li className="col-md-12 col-sm-12 col-lg-12 my-2">
                    <ul className="row">
                      <li class="col-md-12 col-sm-12 col-lg-12">
                        <CustomInput showLabel={false} name="userName" label="Full Name" required>
                          <FloatInput type="text" placeholder="Full Name" />
                        </CustomInput>
                      </li>
                      <li class="col-md-12 col-sm-12 col-lg-12">
                        <CustomInput showLabel={false} name="nickName" label="Nick Name" required>
                          <FloatInput type="text" placeholder="Nick Name" />
                        </CustomInput>
                      </li>
                    </ul>
                  </li>
                  <li className="col-md-12 col-sm-12 col-lg-12 my-2">
                    <div className="align-items-center cr_greyTitle d-flex justify-content-between">
                      <p className="mb-0">Bank details</p>
                      {/* <a onClick={() => props.setState({ activeStepForm: 13 })} className="">
                      <img src={editsvg} width="17px" height="17px" className="me-1" />
                      EDIT
                    </a> */}
                    </div>
                  </li>
                  <li className="col-md-12 col-sm-12 col-lg-12 my-2">
                    <ul className="row">
                      <li class="col-md-12 col-sm-12 col-lg-12">
                        <CustomInput
                          name="bankName"
                          label="Bank Name"
                          showLabel={false}
                          type="select"
                          showSearch
                          labelInValue
                          placeholder="Select Bank"
                          required
                        >
                          {state.bankLists.map((bank, i) => {
                            return (
                              <Option key={i} value={bank.bankName}>
                                <span bankCode={bank.bankCode} isSameBank={bank.isSameBank}>
                                  {bank.bankName}
                                </span>
                              </Option>
                            );
                          })}
                        </CustomInput>
                        <Form.Item>
                          <Input ype="text" placeholder="Full Name" name="fullName" />
                        </Form.Item>
                      </li>
                      <li class="col-md-12 col-sm-12 col-lg-12">
                        <CustomInput
                          showLabel={false}
                          name="accountNo"
                          label="Account Number"
                          required
                        >
                          <FloatInput type="text" placeholder="Account Number" />
                        </CustomInput>
                      </li>
                      <li class="col-md-12 col-sm-12 col-lg-12">
                        <CustomInput
                          placeholder="Select Account Type "
                          showLabel={false}
                          name="accountType"
                          label="Account Type"
                          type="select"
                          labelInValue
                        >
                          <Option key="ac1" value="S">
                            Saving
                          </Option>
                          <Option key="ac2" value="C">
                            Current / Checking
                          </Option>
                        </CustomInput>
                      </li>
                    </ul>
                  </li>
                </ul>

                <div className="bottom_panel">
                  <div className="d-flex justify-content-between align-items-baseline">
                    <button
                      type="button"
                      className="Back_arrow"
                      onClick={() => {
                        navigate("/manage-remitter-accounts");
                      }}
                    >
                      {" "}
                      <img src={BackArrow} alt="" />
                      Back
                    </button>
                    <button
                      type="button"
                      className="btn btn-primary CR-primary-btn"
                      style={{ width: "100px", margin: "0 !important" }}
                      onClick={() => {
                        navigate("/edit-remitter");
                      }}
                    >
                      edit
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </form>
        </div>
      </div>
    </Main>
  );
};

export default EditRemitter;
