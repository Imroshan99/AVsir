import React, { useEffect, useReducer, useState } from "react";
import Main from "../Layouts/Main";
import BackArrow from "../../../assets/images/click2remit/Back_arrow.svg";
import CustomInput from "../../../reusable/CustomInput";
import FloatInput from "../../../reusable/FloatInput";
import { AutoComplete, Form, notification, Select } from "antd";
import { useSelector } from "react-redux";
import { GuestAPI } from "../../../apis/GuestAPI";
import useHttp from "../../../hooks/useHttp";
import { inputValidations } from "../../../services/validations/validations";
import Spinner from "../../../reusable/Spinner";

const { Option } = Select;

const CreateBeneficiaryResidentialDetails = (props) => {
  const { form } = props;
  const AuthReducer = useSelector((state) => state.user);

  const [loader, setLoader] = useState(0);
  const [state, setState] = useReducer((state, newState) => ({ ...state, ...newState }), {
    stateLists: [],
    cityLists: [],
  });
  const hookGetCountryStates = useHttp(GuestAPI.countryStates);
  const hookGetStateCities = useHttp(GuestAPI.stateCities);

  useEffect(() => {
    getStateLists();
  }, []);
  const submitHandler = (values) => {
    props.setState({
      beneficiaryResidentialDetails: values,
      activeStepForm: 9,
    });
  };
  const getStateLists = async () => {
    let payload = {
      requestType: "STATELIST",
      countryCode: "IN",
      keyword: "",
    };
    setLoader((prevState) => prevState + 1);
    hookGetCountryStates.sendRequest(payload, function (data) {
      setLoader((prevState) => prevState - 1);
      if (data.status === "S") {
        let activeState = data.responseData.filter((state) => {
          return state.isActive == "Y";
        });
        setState({ stateLists: activeState });
        // const stateIssuerArray = [...data.responseData];
        // setState({ stateListsIssuer: stateIssuerArray });
      } else {
        notification.error({ message: data.errorMessage?data.errorMessage:"Get country states failed." });
      }
    });
  };
  const onSelectStateHandler = async (stateCode) => {
    form.setFieldsValue({ city: "" });
    const cityPayload = {
      requestType: "CITILIST",
      countryCode: AuthReducer.sendCountryCode,
      countryCode: "IN",
      stateCode: stateCode,
    };
    setLoader((prevState) => prevState + 1);
    hookGetStateCities.sendRequest(cityPayload, function (data) {
      setLoader((prevState) => prevState - 1);
      if (data.status === "S") {
        setState({
          cityLists: data.responseData,
        });
      } else {
        notification.error({ message: data.errorMessage?data.errorMessage:"Get state cities failed." });
        setState({
          cityLists: [],
        });
      }
    });
  };
  return (
    <div class="col-md-8 col-sm-12 col-lg-8 mobile-order-2">
      <div class="CR-account-form CR-otp-form">
        <Spinner spinning={loader === 0 ? false : true}>
          <Form form={form} onFinish={(values) => submitHandler(values)}>
            <fieldset>
              <ul class="row">
                <li class="col-md-12 col-sm-12 col-lg-12 ">
                  <h4 class="text-black ">Beneficiary Residential Details</h4>
                </li>
                <li class="col-md-12 col-sm-12 col-lg-12">
                  <p class="text-left">Enter address details of your new beneficiary.</p>
                </li>
                <legend></legend>
                <li class="col-md-12 col-sm-12 col-lg-12">
                  {/* <div class="form-floating">
                        <input type="text" class="form-control" id="floatingInput" />
                        <label for="floatingInput">First name</label>
                </div> */}
                  <CustomInput
                    showLabel={false}
                    name="address1"
                    label="Address Line 1"
                    validationRules={[
                      ({ getFieldValue }) => ({
                        validator(rule, value) {
                          let message = "";
                          let obj = inputValidations.validateAddress(value ? value : "");
                          message = obj.message;
                          if (obj.status === "S") {
                            return Promise.resolve();
                          }
                          return Promise.reject(message);
                        },
                      }),
                    ]}
                  >
                    <FloatInput placeholder="Address Line 1" />
                  </CustomInput>
                  {/* <FloatInput type="text" placeholder="First name" /> */}
                </li>
                <li class="col-md-12 col-sm-12 col-lg-12">
                  <CustomInput
                    showLabel={false}
                    name="address2"
                    label="Address Line 2"
                    validationRules={[
                      ({ getFieldValue }) => ({
                        validator(rule, value) {
                          let message = "";
                          let obj = inputValidations.validateAddress(value ? value : "");
                          message = obj.message;
                          if (obj.status === "S") {
                            return Promise.resolve();
                          }
                          return Promise.reject(message);
                        },
                      }),
                    ]}
                  >
                    <FloatInput type="text" placeholder="Address Line 2" />
                  </CustomInput>
                </li>
                {/* <li class="col-md-12 col-sm-12 col-lg-12">
                  <CustomInput
                    showLabel={false}
                    name="address3"
                    label="Address Line 3"
                    validationRules={[
                      ({ getFieldValue }) => ({
                        validator(rule, value) {
                          // validate space before and after string
                          let startSpace = /^\s/;
                          let endSpace = / $/;
                          if (startSpace.test(value) || endSpace.test(value)) {
                            return Promise.reject("Space not allow before and after address.");
                          }

                          return Promise.resolve();
                        },
                      }),
                      ({ getFieldValue }) => ({
                        validator(rule, value) {
                          const validStr =
                            ' abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ.0123456789/-?()",+#&_[]\n\r';
                          const charArray = value ? value : "";
                          const strLen = charArray.length;
                          for (let i = 0; i < strLen; i++) {
                            if (validStr.indexOf(charArray[i]) === -1) {
                              return Promise.reject("Please enter valid address formats.");
                            }
                          }

                          return Promise.resolve();
                        },
                      }),
                      {
                        min: 3,
                        max: 100,
                        message: "Address should be between 3 and 100 characters long.",
                      },
                    ]}
                  >
                    <FloatInput type="text" placeholder="Address Line 3" />
                  </CustomInput>
                </li> */}
                <li class="col-md-12 col-sm-12 col-lg-12">
                  <CustomInput
                    showLabel={false}
                    name="zipcode"
                    label="zipcode"
                    validationRules={[
                      {
                        pattern: /^[1-9]\d*$/,
                        message: "ZipCode should not start with 0",
                      },
                      ...inputValidations.zipCode(AuthReducer.recvCountryCode),
                      ({ getFieldValue }) => ({
                        validator(rule, value) {
                          // validate space before and after string
                          let startSpace = /^\s/;
                          let endSpace = / $/;
                          if (startSpace.test(value) || endSpace.test(value)) {
                            return Promise.reject(
                              "Space not allowed before and after the Zipcode.",
                            );
                          }

                          return Promise.resolve();
                        },
                      }),
                    ]}
                    required
                  >
                    <FloatInput type="text" placeholder="Zipcode" />
                  </CustomInput>
                </li>

                <li class="col-md-12 col-sm-12 col-lg-12">
                  {/* <CustomInput showLabel={false} name="city" label="City/District" >
                  <FloatInput type="select" placeholder="City/District" />
                </CustomInput> */}
                  <CustomInput name="state" label="State" showLabel={false} required>
                    <FloatInput
                      type="select"
                      autoComplete="none"
                      placeholder="State"
                      label="State"
                      className="w-100"
                      onSelect={onSelectStateHandler}
                      filterOption={(inputValue, option) =>
                        option.value.toUpperCase().indexOf(inputValue.toUpperCase()) !== -1
                      }
                    >
                      {state.stateLists.map((st, i) => {
                        return <Option key={i} value={st.state}>{`${st.state}`}</Option>;
                      })}
                    </FloatInput>
                  </CustomInput>
                  {/* <div class="form-floating">
                  <select class="form-select" id="floatingSelect">
                    <option selected>Select your secret question</option>
                    <option value="1">One</option>
                    <option value="2">Two</option>
                    <option value="3">Three</option>
                  </select>
                </div> */}
                </li>

                <li class="col-md-12 col-sm-12 col-lg-12">
                  <CustomInput name="city" label="City" showLabel={false} required>
                    <FloatInput
                      type="select"
                      placeholder="City"
                      label="City"
                      className="w-100"
                      autoComplete="none"
                      filterOption={(inputValue, option) =>
                        option.value.toUpperCase().indexOf(inputValue.toUpperCase()) !== -1
                      }
                    >
                      {state.cityLists.map((st, i) => {
                        return <Option key={i} value={st.city}>{`${st.city}`}</Option>;
                      })}
                    </FloatInput>
                    {/* <AutoComplete
                      placeholder="City"
                      autoComplete="none"
                      className="w-100"
                      filterOption={(inputValue, option) =>
                        option.value.toUpperCase().indexOf(inputValue.toUpperCase()) !== -1
                      }
                    >
                      {state.cityLists.map((st, i) => {
                        return <Option key={i} value={st.city}>{`${st.city}`}</Option>;
                      })}
                    </AutoComplete> */}
                  </CustomInput>
                  {/* <div class="form-floating">
                  <select class="form-select" id="floatingSelect">
                    <option selected>Select your secret question</option>
                    <option value="1">One</option>
                    <option value="2">Two</option>
                    <option value="3">Three</option>
                  </select>
                </div> */}
                </li>
              </ul>
              <div class="bottom_panel">
                <div class="d-flex justify-content-between align-items-center gap-3 gap-md-5">
                  <span
                    class="Back_arrow d-flex align-items-center"
                    onClick={() => props.setState({ activeStepForm: 7 })}
                  >
                    <img src={BackArrow} alt="backArrow" />
                    Back
                  </span>
                  <button style={{ maxWidth: "17rem" }} htmlType="submit" class="CR-primary-btn">
                    Proceed
                  </button>
                </div>
              </div>
            </fieldset>
          </Form>
        </Spinner>
      </div>
    </div>
  );
};

export default CreateBeneficiaryResidentialDetails;
