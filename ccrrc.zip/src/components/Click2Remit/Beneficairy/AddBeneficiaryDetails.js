import React, { useEffect, useReducer, useState } from "react";
import Main from "../Layouts/Main";
import BackArrow from "../../../assets/images/click2remit/Back_arrow.svg";
import CustomInput from "../../../reusable/CustomInput";
import FloatInput from "../../../reusable/FloatInput";
import { Form, notification, Select } from "antd";
import useHttp from "../../../hooks/useHttp";
import { GuestAPI } from "../../../apis/GuestAPI";
import { useSelector } from "react-redux";
import { ReceiverAPI } from "../../../apis/ReceiverAPI";
import { inputValidations } from "../../../services/validations/validations";
import Spinner from "../../../reusable/Spinner";
import { useLocation, useNavigate } from "react-router-dom";
import { TransactionAPI } from "../../../apis/TransactionAPI";

const AddBeneficiaryDetails = (props) => {
  const { Option } = Select;
  const navigate = useNavigate();
  const { form } = props;
  const AuthReducer = useSelector((state) => state.user);
  const location = useLocation();
  const [loader, setLoader] = useState(false);
  const [mobilecode, setMobilecode] = useState();
  const [state, setState] = useReducer((state, newState) => ({ ...state, ...newState }), {
    phoneCodes: [],
    purposeLists: [],
    relationshipLists: [],
  });
  const handleChange = (e) => {
    setMobilecode(e.target.value);
  };
  useEffect(() => {
    getCoutryCodes();
    getRelationshipLists();
    getPurposeLists();
  }, []);

  const hookGetCountryPhoneCodes = useHttp(GuestAPI.getCountryPhoneCodes);
  const hookGetRelationshipLists = useHttp(GuestAPI.relationshipLists);
  const hookGetPurposeLists = useHttp(TransactionAPI.purposeLists);

  const getCoutryCodes = async () => {
    const payload = {
      requestType: "COUNTRYPHONECODE",
    };
    setLoader(true);
    hookGetCountryPhoneCodes.sendRequest(payload, function (data) {
      setLoader(false);
      if (data.status == "S") {
        let _recvCountryCode = data.responseData.filter(
          (item) => item.countryCode === AuthReducer.recvCountryCode,
        );

        setState({
          phoneCodes: [
            // { countryPhoneCode: 1, countryName: "United States" },
            { countryPhoneCode: 91, countryName: "India" },
          ],
        });
        props.newForm1.setFieldsValue({
          mobileCountryCode: _recvCountryCode[0].countryPhoneCode,
        });
        props.setLoader(false);
      }
    });
  };
  const getPurposeLists = () => {
    const payload = {
      requestType: "PurposeList",
      keyword: "",
      nickName: "NEWRECV",
      recvCountryCode: AuthReducer.recvCountryCode,
      userId: AuthReducer.userID,
    };
    setLoader(true);
    hookGetPurposeLists.sendRequest(payload, function (data) {
      setLoader(false);
      if (data.status == "S") {
        props.setState({ _purposeLists: data.responseData });
        setState({ purposeLists: data.responseData });
      }
    });
  };
  const getRelationshipLists = async () => {
    let payload = {
      requestType: "RELAIONSHIPLISTS",
    };
    setLoader(true);
    hookGetRelationshipLists.sendRequest(payload, function (data) {
      setLoader(false);
      if (data.status == "S") {
        setState({ relationshipLists: data.responseData });
      } else {
        setState({ relationshipLists: [] });
      }
    });
  };
  const submitHandler = (value) => {
    props.setState({ beneficiaryDetails: value, activeStepForm: 8 });
  };

  const handleChangePurpose = (purpose) => {
    // setState({ formObj: { ...state.formObj, purpose: purpose } });
    let pur = JSON.parse(purpose);
    props.setState({ purposeName: pur.displayName, purposeCode: pur.purposeCode });
  };

  return (
    <div class="col-md-8 col-sm-12 col-lg-8 mobile-order-2">
      <div class="CR-account-form CR-otp-form">
        <Spinner spinning={loader}>
          <Form form={form} onFinish={(values) => submitHandler(values)}>
            <fieldset>
              <ul class="row">
                <li class="col-md-12 col-sm-12 col-lg-12 ">
                  <h4 class="text-black ">Beneficiary details</h4>
                </li>
                <li class="col-md-12 col-sm-12 col-lg-12">
                  <p class="text-left">Enter details of your new beneficiary.</p>
                </li>
                <legend></legend>
                <li class="col-md-12 col-sm-12 col-lg-12">
                  {/* <div class="form-floating">
                        <input type="text" class="form-control" id="floatingInput" />
                        <label for="floatingInput">First name</label>
                      </div> */}
                  <CustomInput
                    showLabel={false}
                    name="firstName"
                    label="First Name"
                    validationRules={[
                      ({ getFieldValue }) => ({
                        validator(rule, value) {
                          // validate space before and after string
                          let startSpace = /^\s/;
                          let endSpace = / $/;
                          if (startSpace.test(value) || endSpace.test(value)) {
                            return Promise.reject("Space not allow before and after first name.");
                          }

                          return Promise.resolve();
                        },
                      }),
                      {
                        pattern: /^[A-Za-z ]+$/,
                        message: "Enter valid first name",
                      },
                    ]}
                    min={2}
                    max={60}
                    required
                  >
                    <FloatInput placeholder="First name" />
                  </CustomInput>
                  {/* <FloatInput type="text" placeholder="First name" /> */}
                </li>
                <li class="col-md-12 col-sm-12 col-lg-12">
                  <CustomInput
                    showLabel={false}
                    name="middleName"
                    label="Middle Name"
                    validationRules={[
                      ({ getFieldValue }) => ({
                        validator(rule, value) {
                          // validate space before and after string
                          let startSpace = /^\s/;
                          let endSpace = / $/;
                          if (startSpace.test(value) || endSpace.test(value)) {
                            return Promise.reject("Space not allow before and after middle name.");
                          }

                          return Promise.resolve();
                        },
                      }),
                      {
                        pattern: /^[A-Za-z ]+$/,
                        message: "Enter valid middle name",
                      },
                    ]}
                    min={1}
                    max={60}
                  >
                    <FloatInput type="text" placeholder="Middle name (optional)" />
                  </CustomInput>
                </li>
                <li class="col-md-12 col-sm-12 col-lg-12">
                  <CustomInput
                    showLabel={false}
                    name="lastName"
                    label="Last Name"
                    validationRules={[
                      ({ getFieldValue }) => ({
                        validator(rule, value) {
                          // validate space before and after string
                          let startSpace = /^\s/;
                          let endSpace = / $/;
                          if (startSpace.test(value) || endSpace.test(value)) {
                            return Promise.reject("Space not allow before and after last name.");
                          }

                          return Promise.resolve();
                        },
                      }),
                      {
                        pattern: /^[A-Za-z ]+$/,
                        message: "Enter valid last name",
                      },
                    ]}
                    min={2}
                    max={60}
                    required
                  >
                    <FloatInput type="text" placeholder="Last name" />
                  </CustomInput>
                </li>
                <li class="col-md-12 col-sm-12 col-lg-12">
                  <CustomInput
                    showLabel={false}
                    name="nickname"
                    label="Nick Name"
                    validationRules={[
                      ({ getFieldValue }) => ({
                        validator(rule, value) {
                          // validate space before and after string
                          let startSpace = /^\s/;
                          let endSpace = / $/;
                          if (startSpace.test(value) || endSpace.test(value)) {
                            return Promise.reject("Space not allow before and after nick name.");
                          }

                          return Promise.resolve();
                        },
                      }),
                      {
                        pattern: /^[A-Z]+$/i,
                        message: "Only alphabetic characters allowed without space",
                      },
                    ]}
                    min={2}
                    max={30}
                    required
                  >
                    <FloatInput type="text" placeholder="Nick Name" />
                  </CustomInput>
                </li>
                <li class="col-md-12 col-sm-12 col-lg-12">
                  <CustomInput showLabel={false} name="relationship" label="Relationship" required>
                    <FloatInput type="select" placeholder="Relationship">
                      {state.relationshipLists.map((list, i) => {
                        return (
                          <Option key={i} value={list.relationshipDesc}>
                            {list.relationshipDesc}
                          </Option>
                        );
                      })}
                    </FloatInput>
                  </CustomInput>
                </li>
                <li class="col-md-12 col-sm-12 col-lg-12">
                  <CustomInput
                    name="purpose"
                    label="Purpose For Transfer"
                    placeholder="Purpose For Transfer"
                    showLabel={false}
                    required
                  >
                    <FloatInput
                      type="select"
                      name="purpose"
                      className="w-100"
                      onChange={handleChangePurpose}
                      placeholder="Purpose For Transfer"
                      required
                    >
                      {state.purposeLists.map((purpose, i) => {
                        return (
                          <Option key={i} value={JSON.stringify(purpose)}>
                            {purpose.displayName}
                          </Option>
                        );
                      })}
                    </FloatInput>
                  </CustomInput>
                </li>

                <li class="col-md-12 col-sm-12 col-lg-12">
                  <div className="row">
                    <div className="col-12 col-md-5">
                      <CustomInput
                        showLabel={false}
                        name="mobileCountryCode"
                        label="Select Phone Code"
                        required
                      >
                        <FloatInput
                          type="select"
                          placeholder="Select Phone Code"
                          label="Phone Code"
                          name="mobileCountryCode"
                          required
                          //  size="small"
                          showSearch
                          // value={selectValue}
                          // onChange={handleChange}
                        >
                          {state.phoneCodes.map((phoneCode, i) => {
                            return (
                              <Option
                                key={i}
                                value={phoneCode.countryPhoneCode}
                              >{`(${phoneCode.countryPhoneCode}) ${phoneCode.countryName}`}</Option>
                            );
                          })}
                        </FloatInput>
                      </CustomInput>
                    </div>
                    <div className="col-12 col-md-7">
                      <CustomInput
                        showLabel={false}
                        name="mobileNo"
                        label="Mobile Number"
                        validationRules={[
                          {
                            pattern: /^[1-9]\d*$/,
                            message: "Mobile number should not start with 0",
                          },
                          ...inputValidations.mobileNumber(),
                        ]}
                        required
                      >
                        <FloatInput type="text" placeholder="Mobile Number" />
                      </CustomInput>
                    </div>
                  </div>
                </li>
                <li class="col-md-12 col-sm-12 col-lg-12">
                  <CustomInput
                    showLabel={false}
                    name="email"
                    validationRules={[
                      ({ getFieldValue }) => ({
                        validator(rule, value) {
                          // validate space before and after string
                          let startSpace = /^\s/;
                          let endSpace = / $/;
                          if (startSpace.test(value) || endSpace.test(value)) {
                            return Promise.reject("Space not allow before and after email.");
                          }

                          return Promise.resolve();
                        },
                      }),
                      {
                        pattern: /^([A-Za-z0-9_\-\.])+\@([A-Za-z0-9_\-\.])+\.([A-Za-z]{2,4})$/,
                        message: "Please input valid email",
                      },
                    ]}
                    label="Email address"
                  >
                    <FloatInput type="text" placeholder="Email address (optional)" />
                  </CustomInput>
                </li>
              </ul>
              <div class="bottom_panel ">
                <div class="d-flex justify-content-between align-items-center gap-3 gap-md-5">
                  <span
                    class="Back_arrow d-flex align-items-center"
                    onClick={() => {
                      if (location.pathname == "/add-beneficiary") {
                        if (location?.state?.pathname == "/new-transaction") {
                          navigate("/my-beneficiary", {
                            state: {
                              autoFillData: location?.state?.autoFillData,
                              autoFill: location?.state?.autoFill,
                              pathname: "/new-transaction",
                            },
                          });
                        } else {
                          navigate("/my-beneficiary");
                        }
                      } else {
                        props.setState({ activeStepForm: 13 });
                      }
                    }}
                  >
                    <img src={BackArrow} alt="backArrow" />
                    Back
                  </span>
                  <button style={{ maxWidth: "17rem" }} htmlType="submit" class="CR-primary-btn">
                    Proceed
                  </button>
                </div>
              </div>
            </fieldset>
          </Form>
        </Spinner>
      </div>
    </div>
  );
};

export default AddBeneficiaryDetails;
