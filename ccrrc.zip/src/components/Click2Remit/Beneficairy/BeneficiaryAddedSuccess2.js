import React from 'react'
import Main from '../Layouts/Main'
import Downloadpng from '../../../assets/images/click2remit/download.png';
import BackArrow from "../../../assets/images/click2remit/Back_arrow.svg";
import PaymentSuccess from "../../../assets/images/click2remit/Paymentsuccess.svg";
import SecureKotakpng from "../../../assets/images/click2remit/Secure-kotak.png";
import Chevronright from '../../../assets/images/click2remit/Chevronright.svg';

const BeneficiaryAddedSuccess2 = () => {
  return (
    <Main>
      <div className="container h-100">
        <div className="row h-100">
          <form>
            <div className="col-md-6 col-sm-12 col-lg-6 offset-md-3 align-self-center">
              <div className="CR-otp-form">
                <ul className="row">
                  <li className="back-arrow-nav   d-xs-block d-done">
                    <img src={BackArrow} alt="" />
                  </li>
                  <li className="text-center">
                    <img src={PaymentSuccess} style={{ marginBottom: "30px" }} alt="" />
                  </li>
                  <li className="col-md-12 col-sm-12 col-lg-12 mb-4">
                    <h4 className="text-black text-center mb-1">Thank you!</h4>
                    <p className="text-center mb-1">Please fund the Kotak Bank Account with the following details.</p>
                  </li>
                  <li className="col-md-12 col-sm-12 col-lg-12 text-center mb-3">
                    <div className="bene circle">DT</div>
                  </li>
                  <li className="col-md-12 col-sm-12 col-lg-12 text-center">
                    <h5 className="text-black "> Daisy Thomas Doe</h5>
                  </li>
                  <li className="col-md-12 col-sm-12 col-lg-12 text-center my-2">
                    <h3 className="text-black ">
                      {" "}
                      <span className="fw-400">AED</span> 1,100
                    </h3>
                  </li>
                  <li className="col-md-12 col-sm-12 col-lg-12 text-center">
                    <img src={SecureKotakpng} alt="" />
                  </li>

                  <li className="col-md-12 col-sm-12 col-lg-12 mt-3">
                    <div className="align-items-center d-flex justify-content-between CR-border-bottom py-3">
                      <label className="CR-font-16 text-left">CBD account number</label>
                      <p className="CR-font-16 text-right CR-black-text CR-fw-500 m-0">123456789</p>
                    </div>
                  </li>
                  <li className="col-md-12 col-sm-12 col-lg-12 my-2">
                    <div className="align-items-center d-flex justify-content-between mb-1 py-3">
                      <label className="CR-font-16 text-left">Transaction reference number</label>
                      <p className="CR-font-16 text-right CR-black-text CR-fw-500 m-0">32165498710111</p>
                    </div>
                  </li>

                  <li className="col-md-12 col-sm-12 col-lg-12 my-2">
                    <div className="align-items-center  d-flex justify-content-between">
                      <p className="mb-0 fw-500 text-black">Additional details</p>
                      <img src={Chevronright} className="chevron-top me-1" width="17px" height="17px" />
                    </div>
                  </li>
                  <li className="col-md-12 col-sm-12 col-lg-12 my-2">
                    <div className="row">
                      <div className="col-md-12">
                        <div className="align-items-center d-flex justify-content-between CR-border-bottom py-3">
                          <label className="CR-font-16 text-left">Transaction date</label>
                          <p className="CR-font-16 text-right CR-black-text CR-fw-500 m-0">12 Jul 2021, 11:36 PM</p>
                        </div>
                      </div>
                      <div className="col-md-12">
                        <div className="align-items-center d-flex justify-content-between CR-border-bottom py-3">
                          <label className="CR-font-16 text-left">Remittance purpose</label>
                          <p className="CR-font-16 text-right CR-black-text CR-fw-500 m-0">Family maintenance</p>
                        </div>
                      </div>
                      <div className="col-md-12">
                        <div className="align-items-center d-flex justify-content-between CR-border-bottom py-3">
                          <label className="CR-font-16 text-left">Beneficiary</label>
                          <p className="CR-font-16 text-right CR-black-text CR-fw-500 m-0">Daisy Thomas Doe</p>
                        </div>
                      </div>
                      <div className="col-md-12">
                        <div className="align-items-center d-flex justify-content-between CR-border-bottom py-3">
                          <label className="CR-font-16 text-left">Promocode</label>
                          <p className="CR-font-16 text-right CR-black-text CR-fw-500 m-0">PROMO20</p>
                        </div>
                      </div>
                    </div>
                  </li>
                </ul>

                <div className="bottom_panel">
                  <div className="d-flex justify-content-between align-items-baseline">
                    <button type="button" className="btn  download-btn mb-3">
                      <img src={Downloadpng} alt="" />
                    </button>
                    <button type="button" className="btn btn-primary CR-primary-btn">
                      Proceed
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </form>
        </div>
      </div>
    </Main>
  );
}

export default BeneficiaryAddedSuccess2