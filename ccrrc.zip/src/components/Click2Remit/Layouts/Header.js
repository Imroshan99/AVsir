import { MenuOutlined } from "@ant-design/icons";
import IconButton from "@mui/material/IconButton";
import Avatar from "@mui/material/Avatar";
import { useSelector } from "react-redux";
import c2r_logo_via from "../../../assets/images/click2remit/C2R_via_logo.png";
import c2r_logo from "../../../assets/images/click2remit/C2R_logo_pre1.png";
import UserMenu from "../user/UserMenu";
import { useContext, useEffect, useState } from "react";
import { Link, Outlet, useLocation, useNavigate } from "react-router-dom";
import { MenuContext } from "../Context/MenuContext";
import { Dropdown } from "antd";

export default function Header(props) {
  const _menuContext = useContext(MenuContext);
  const navigate = useNavigate();
  const location = useLocation();
  const AuthReducer = useSelector((state) => state.user);

  const [anchorElUser, setAnchorElUser] = useState(null);

  const handleOpenUserMenu = (event) => {
    setAnchorElUser(event.currentTarget);
  };
  const handleCloseUserMenu = (e) => {
    setAnchorElUser(null);
    if (e === "Logout") {
      window.location.href = "/";
    }
  };

  const [dt, setDt] = useState(new Date());
  useEffect(() => {
    setDt(new Date());
  }, []);

  console.log("_menuContext.isVisible", _menuContext.isVisible);
  const onLogoClickHandler = () => {
    if (!AuthReducer.isLoggedInDone) {
      location.pathname == "/"
        ? window.location.reload()
        : AuthReducer.isLoggedIn
        ? navigate("/new-transaction")
        : navigate("/");
    } else {
    }
  };
  return (
    <>
      <header className="px-0 px-md-4  bg-white  sticky-top">
        <nav className="navbar navbar-default">
          <div className="container-fluid">
            <div className="d-flex align-items-center w-100">
              <div className="navbar-header flex-fill">
                <span onClick={onLogoClickHandler} className="navbar-brand">
                  {AuthReducer.sendCountryCode === "US" ? (
                    <img
                      className="img-responsive  img-responsive-width"
                      src={c2r_logo_via}
                      alt="Click 2 Remit"
                      // width="100%"
                    />
                  ) : (
                    <img
                      className="img-responsive img-responsive-width"
                      src={c2r_logo}
                      alt="Click 2 Remit"
                      // width="100%"
                    />
                  )}
                </span>
              </div>
              <div className="flex-fill text-end">
                <p className="CR-linktext mb-0 CR-font-14 d-none d-sm-block">
                  {AuthReducer.isLoggedIn ? (
                    <>
                      <div
                        className="cr_mobile_menu"
                        onClick={() => {
                          _menuContext.toggleMenu(!_menuContext.isVisible);
                        }}
                      >
                        <MenuOutlined />
                      </div>
                    </>
                  ) : (
                    <>
                      {location.pathname !== "/create-account" && (
                        <>  <span className=" ms-2">Don't have an account? </span>
                          <Link to="/create-account" className="CR-blue-link CR-font-12 mx-2">
                            SIGN UP
                          </Link>
                        </>
                      )}
                      {location.pathname !== "/signin" && location.pathname !== "/create-account"
                        ? "|"
                        : ""}
                      {location.pathname !== "/signin" && (
                        <>
                          <span className=" ms-2">Already have an account? </span>
                          <Link to="/signin" className="CR-blue-link CR-font-12 mx-2">
                            SIGN IN
                          </Link>
                        </>
                      )}
                    </>
                  )}
                </p>

                <div className="d-block d-sm-none w-72">
                  {AuthReducer.isLoggedIn ? (
                    <div
                      className="cr_mobile_menu"
                      onClick={() => {
                        _menuContext.toggleMenu(!_menuContext.isVisible);
                      }}
                    >
                      <MenuOutlined style={{ fontSize: "24px", color: "#003a7a" }} />
                    </div>
                  ) : (
                    <Dropdown
                      menu={{
                        items: [
                          {
                            label: (
                              <Link to="/create-account" className="CR-blue-link CR-font-12 mx-2">
                                SIGN UP
                              </Link>
                            ),
                            key: "0",
                          },
                          {
                            label: (
                              <Link to="/signin" className="CR-blue-link CR-font-12 mx-2">
                                SIGN IN
                              </Link>
                            ),
                            key: "1",
                          },
                        ],
                      }}
                      trigger={["click"]}
                    >
                      <a onClick={(e) => e.preventDefault()}>
                        <MenuOutlined style={{ fontSize: "24px", color: "#003a7a" }} />
                      </a>
                    </Dropdown>
                  )}
                </div>
              </div>
            </div>
          </div>
        </nav>
      </header>

      <Outlet />
    </>
  );
}
