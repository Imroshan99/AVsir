import React from "react";
import { useSelector } from "react-redux";
import { useLocation } from "react-router-dom";
import Footer from "./Footer";
import Header from "./Header";
import SidebarMenu from "./SidebarMenu";

const Main = (props) => {
  const { sidebar } = props;
  const location = useLocation();
  const AuthReducer = useSelector((state) => state.user);

  const groupConfig = useSelector((state) => state.user);
  const section_cls = sidebar ? "CR__main" : "container";
  return (
    <>
      <section className="CR-otp-bg">
        {sidebar && <SidebarMenu />}
        <div className={`${section_cls} h-100 p-4`}>{props.children}</div>
        {/* <div className="container h-100 py-4">{props.children}</div> */}
      </section>
      {location.pathname == "/profile" || location.pathname == "/my-beneficiary" ? "" : <Footer />}
    </>
  );
};

Main.defaultProps = {
  sidebar: true,
};
export default Main;
