import { useSelector } from "react-redux";
import { Navigate } from "react-router-dom";
import { getSessionStorage } from "../services/utility/storage";

export const PrivateRoute = ({ auth, children }) => {
  const config = useSelector((state) => state.user);
  const {isLoggedIn, groupIdSettings} = config;

  const isAllowed = groupIdSettings.settings.refreshPage
    ? getSessionStorage("isLoggedIn")
    : isLoggedIn;
  // console.log("isAllowed", isAllowed);
  // if (websiteSettings.refreshPage) {
  //   isAllowed = getSessionStorage("isLoggedIn");
  // } else {
  //   isAllowed = AuthReducer.isLoggedIn;
  // }
  if (!isAllowed) {
    return <Navigate to="/signin" replace />;
  }
  return children;
};
